# Archivio della TEPS 1.4

Il PDF della versione 1.4 (13 ottobre 2026) e il suo testo estratto, citati nei documenti della 1.5,
non sono inclusi in questa copia pubblica. Le versioni pubblicate della TEPS sono su Zenodo:
https://doi.org/10.5281/zenodo.23880577
