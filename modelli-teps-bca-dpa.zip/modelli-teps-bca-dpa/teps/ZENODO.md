# Scheda Zenodo — TEPS 1.5

**Titolo**
TEPS — Teoria dell'Equilibrio Economico Post-Salariale (versione 1.5)

**Tipo di risorsa:** Pubblicazione → Working paper (oppure Preprint)
**Lingua:** italiano
**Versione:** 1.5
**Data di pubblicazione:** 2026-11-02 (versione 1.5 del 30 ottobre 2026, aggiornata al 2 novembre 2026)
**File:** `pdf/TEPS_1_5_IT.pdf` (documento principale), `word/TEPS_1_5_IT.docx`, script Python `teps_1_5_partecipazione.py` e `teps_1_5_banca_pubblica.py`
**Versione inglese:** `pdf/TEPS_1_5_EN.pdf` (stesso contenuto; si può caricare nello stesso record o in un record collegato)
**Licenza suggerita:** Creative Commons Attribution 4.0 International (CC BY 4.0)
**Versione precedente:** TEPS 1.4 (13 ottobre 2026); se la 1.4 è già su Zenodo, caricare la 1.5 come nuova versione dello stesso record

## Descrizione (italiano)

La TEPS è un modello teorico di economia post-salariale: la produzione è interamente svolta da macchine e sistemi di intelligenza artificiale, l'energia da fusione è abbondante e il lavoro umano non è più necessario per la produzione ordinaria. Il capitale produttivo appartiene a un fondo pubblico; la proprietà privata resta solo per uso personale. Ogni persona riceve in natura un paniere di beni essenziali; il consumo discrezionale passa per i prezzi. Le idee che creano valore economico e sociale verificato ricevono premi limitati, in denaro e in peso nelle decisioni tecniche. Le regole sono decise con voto ponderato per competenza su tutta la popolazione ed eseguite da sistemi di IA pubblici, indipendenti e deterministici.

Il modello unisce un blocco fisico input-output, un blocco monetario stock-flow consistente con il fondo pubblico, prezzi e razionamento, una matrice del capitale e un sistema di incentivi, con proposizioni dimostrate e simulazioni riproducibili.

La versione 1.5 introduce:
- un reddito civico monetario proporzionale alla partecipazione alle votazioni (votazioni eseguite rispetto a quelle offerte), con le quote non maturate destinate al fondo per finanziare nuove imprese; si dimostra che domanda, profitti e pareggio del fondo restano invariati in stato stazionario e si calcola il limite fisico di questa conversione in capitale;
- una simulazione dinamica con partecipazione variabile: nessuna inflazione generata dalla partecipazione, recessioni brevi in caso di calo improvviso, deflazione come rischio prevalente;
- l'assenza di banche private: conti, pagamenti ed emissione di moneta su un registro pubblico automatico, con dimostrazioni di conservazione della moneta, impossibilità delle corse agli sportelli, rilevazione degli errori del registro e incompatibilità dell'interesse privato con il limite ai patrimoni.

Il modello è coerente sotto otto condizioni esplicite (C1–C8). Stato scientifico: modello teorico con verifiche algebriche e simulazioni riproducibili su parametri non calibrati; non è una teoria validata empiricamente. Restano non dimostrate la piena automazione, la stabilità globale, la calibrazione su dati reali, l'economia aperta e la superiorità della governance per competenza.

## Description (English)

TEPS (Theory of Post-Wage Economic Equilibrium) is a theoretical model of a post-wage economy: production is fully carried out by machines and AI systems, fusion energy is abundant and human labour is no longer required for ordinary production. Productive capital belongs to a public fund; private property is limited to personal use. Everyone receives an essential basket in kind, while discretionary consumption is priced. Ideas that create verified economic and social value earn capped rewards, both monetary and as weight in technical decisions. Rules are set by competence-weighted voting over the whole population and executed by public, independent, deterministic AI systems.

The model combines an input-output physical block, a stock-flow consistent monetary block with the public fund, prices and rationing, a capital matrix and an incentive system, with proved propositions and reproducible simulations.

Version 1.5 adds a civic income proportional to participation in votes, with unearned shares financing new enterprises (demand neutrality is proved in steady state, and the physical limit of this conversion into capital is computed); a dynamic simulation with variable participation; and a public monetary system without private banks, based on an automated public ledger, with proofs of money conservation, impossibility of bank runs, error detection, and incompatibility of private interest with the bound on personal wealth. The model is consistent under eight explicit conditions. It is a theoretical, non-calibrated model, not an empirically validated theory.

## Parole chiave / Keywords

economia post-salariale; automazione; intelligenza artificiale; capitale pubblico; reddito civico; democrazia per competenza; modello stock-flow consistente; input-output; moneta pubblica; post-wage economy; automation; public capital; civic income; stock-flow consistent model; input-output; sovereign money; AI governance
