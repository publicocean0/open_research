# TEPS — Theory of Post-Wage Economic Equilibrium

## Version 1.5 · 30 October 2026 (updated 2 November 2026)

**Version 1.5 of 30 October 2026, updated 2 November 2026.** The text reproduces the 1.4 model in full (PDF of 13 October 2026, 30 pages) with the 1.5 revisions: incompatible 1.4 passages are corrected directly in the text, the new parts are in the “Integration 1.5” sections and are summarised in Appendix B. The original 1.4 text is preserved in `archivio/TEPS_1_4_estrazione_testuale.txt`. Figures 1–4 are those of the 1.4 PDF (`archivio/TEPS_1_4_Modello_Economico_Consolidato.pdf`); Figure 5 is new (N-10).

---

*Consolidated model of an automated economy, collective capital and competence-based governance*

**WORKING VERSION 1.5 · 30 OCTOBER 2026 · UPDATED 2 NOVEMBER 2026**

**Scenario assumptions.** Complete automation of productive activities. Since version 1.1, fusion energy is a baseline assumption: abundant, at negligible cost, never a binding sector (the plants remain physical capital). Since 1.2 there is no private productive property: private property remains only for personal use. Since 1.3 the reward to innovators is capped and also measures the social benefit, assessed algorithmically; since 1.4 the reward is not only monetary but also weight in technical decisions, always with a cap. Since 1.5 monetary income is proportional to the votes cast relative to those offered. None of the simulations is calibrated on a real economy.

**Scope**

- Production, energy, capital and long-run stability
- Public financing of initiatives and incentives for innovators
- Operational AI and an independent panel of evaluating agents
- Weighted democracy across the whole body of citizens
- Propositions, mathematical proofs, simulations and limits
- Stock-flow consistent block with the fund, prices, capital matrix and incentives (new in 1.1–1.4)
- Civic income proportional to participation in votes (new in 1.5)

**Scientific status:** theoretical model with algebraic checks and reproducible simulations; not an empirically validated theory.

## Executive summary

TEPS studies an economy in which production can be carried out entirely by machines and AI systems. Labour income becomes unnecessary to secure material survival. The system instead preserves individual initiative: whoever proposes a business idea can obtain public capital and receive incremental rewards when the idea generates verified value.

| Dimension | Proposed rule | Required verification |
|---|---|---|
| Production | Robots and AI carry out production; physical constraints by sector | Feasibility and self-reproduction of capital |
| Access | Basket of essential goods guaranteed to every person | Actual availability of the goods |
| New enterprises | Collective fund finances publicly assessed ideas | Fund balance and project selection |
| Innovator | Defines the idea; indirectly supports management | Incentives tied to additional net value |
| Management | AI controls direct operations, within public constraints | Audit, safety and remedies |
| Evaluation | AI panel without mutual dialogue | Errors, correlations and data integrity |
| Technical vote | Weight by relevant knowledge on a universal scale | Competence open to all and verifiable |
| Common rights | Equal vote on matters that affect everyone | Constitutional compatibility |
| Civic income (1.5) | Proportional to votes cast / offered | Demand, fund, capacity (T9) |
| Bank (1.5) | No private bank; automated public ledger | Conservation, payments, audit (D-17–D-21) |

**Verification outcome.** Conditions for existence, financial closure and local convergence of the equilibrium are proved, now also in the stock-flow consistent monetary block with the fund (versions 1.1–1.4, §13–17) and, since 1.5, the functioning of money without private banks (D-17–D-21). The economic model is coherent under eight explicit conditions (§18.3; C7 and C8 since 1.5). Neither global stability nor economic superiority over other systems is proved.

**How to read the results**

| Tag | Meaning |
|---|---|
| [D] | Proposition derived from the equations, with stated assumptions. |
| [N] | Numerical result reproduced by simulation code, not a forecast. |
| [P] | Institutional design principle, not a mathematical theorem. |
| [A] | Technical assumption introduced to close the model. |

**Integration 1.5 — Summary of the revision**

[1.5 P] Civic income proportional to participation. Each citizen’s basic monetary income is the full civic income h̄ₜ multiplied by the participation share Pᵢ,ₜ = votes cast / votes offered in the period (§11.3). Whoever casts all the votes offered receives h̄ₜ in full; whoever casts a part of them receives the same part. The content of the vote does not count: in favour, against and explicit abstention count equally.

Four rules complete the principle:

1. Unearned shares: the part of income not paid out remains with the fund and finances new enterprises (§13.6). In this way aggregate demand does not fall and the machines do not stand idle (D-16), within the physical limit calculated in N-9.
2. Abstention: it counts for income but does not enter the calculation of the outcome; the safeguards on the power of groups (D-14, D-15) apply to the votes expressed (§11.1, §17.8).
3. Secrecy: the system records that a person has voted, never how they voted; the participation ledger is separate from the ballot box (§11.3).
4. Number of votes: a cap on calls to vote per period and a minimum number of calls for the calculation of P, set by equal vote (§11.3).

The in-kind essential basket never depends on participation. The rewards S remain additional. The universal dividend D of 1.4 is replaced by the civic income: in the remaining historical passages (§5, §9.2, §14.2, §15, §17.3) “dividend” should be read as “civic income”. The proofs of 1.4 hold for the case P = 1; for P < 1, D-16 (steady state), N-9 (physical feasibility) and the dynamic simulation N-10 over 30 periods (§19.3) are added. Since without participation there is no monetary income, expected participation is close to 1.

[1.5 P] No private bank. There are no private banks and no interest-bearing loans. Accounts, payments and money issuance are handled by an automated public bank: a public ledger computed by several independent AI systems with deterministic rules (§13.7). Proofs D-17–D-21 (§14.7–14.11) show that money always coincides with the fund’s debt, that bank runs are impossible, that ledger errors are detected and that private interest is incompatible with the cap on wealth (condition C8).

## Contents

- 01 Objective and theoretical references
- 02 Institutions and roles: citizen, innovator, capital, AI
- 03 Physical model: five sectors and constraints
- 04 Proof 1 — Material feasibility
- 05 Post-wage demand and distribution
- 06 Proof 2 — Equilibrium and local stability
- 07 Capital and 100-period stress tests
- 08 Nuclear fusion and robust investment
- 09 Accounting, prices, money and the public fund
- 10 Enterprises, incremental rewards and project selection
- 11 Knowledge, competence and weighted democracy (1.5: §11.3 civic income and participation)
- 12 Independent AI panel and reliability
- 13 Stock-flow consistent block with the fund (new in 1.1–1.4; 1.5: §13.6 unearned shares, §13.7 automated public bank)
- 14 Proofs on the monetary block (new in 1.1–1.4; 1.5: §14.5 D-16, §14.6 N-9, §14.7–14.11 D-17–D-21)
- 15 Prices, rationing and post-fusion shocks (new in 1.1–1.4)
- 16 Capital with a coefficient matrix (new in 1.1–1.4)
- 17 Incentives, personal property, rewards in money and in weight, fund risk (new in 1.1–1.4; 1.5: §17.9)
- 18 Economic assessment, sustainability conditions and verdict (1.5: C7, §18.4)
- 19 Limits, required tests and proved results (1.5: T9, §19.2)
- 20 Glossary, parameters and references

Sections can be navigated in Word from the “Headings” pane (View → Navigation Pane).

## 1. Objective and theoretical references

TEPS arises from the need to reconcile productive abundance, access to goods, investment and innovation when human labour is no longer a necessary input of ordinary production. It draws on Marx (centrality of labour and of property relations), Keynes (role of effective demand), Leontief (material interdependencies between sectors) and Godley–Lavoie (consistency between monetary flows and financial stocks). [1–3]

The model does not claim that Marx and Keynes are “superseded”: it recombines their different problems in an extreme situation of automation. The potential original contribution is the integration of physical constraints, financing of common capital, incentives for initiative and algorithmic governance procedures.

### 1.1 Structural assumptions

- Supply of human productive labour L = 0; wages needed for production W = 0. Rewards to innovators remain possible, but are not indispensable for running the factories.
- Abundant energy: increased availability and reduced variable energy costs only in hypothetical scenarios. The overall cost of plants and networks is not assumed to be zero.
- Population entirely included in the economic order; access to capital and to competence tests not constrained by initial wealth.
- Fundamental rights and the availability of an essential basket take precedence over the distribution of discretionary consumption.
- Machines, raw materials, plants, land surfaces, manufacturing capacity and time remain potentially scarce resources.
- Property (1.2): private property is allowed only for personal use (housing, durable goods, personal tools). There is no private ownership of enterprises or of productive capital: all productive capital belongs to the fund. Personal property grows only through rewards for the value created by thought, creativity and initiative for the public good (§17.4); the rewards, in money and in weight on competences, are capped and measure economic value and social benefit (§17.5, §17.7).
- Government (1.2): public management is not entrusted directly to human bodies. People intervene only through the weighted vote (§11) on parameters and rules; execution, assessments and checks are entrusted to public AI systems with deterministic and public rules.
- Money and banking (1.5): there are no private banks. Accounts, payments and money issuance are handled by an automated public bank: a public ledger managed by AI with deterministic rules (§13.7).

## 2. Institutions and roles

| Actor | Task | Limit on power |
|---|---|---|
| Population | Sets rights, general priorities and parameters, and takes part in votes | No absolute individual power |
| Innovator–entrepreneur | Defines the business, proposes developments and provides indirect support | Does not command direct operations |
| Public productive fund | Allocates capital and receives returns from enterprises | Material, financial and public constraints |
| Management AI | Executes operational decisions and industrial programmes | Verifiable mandate, safety stops |
| AI panel | Certifies knowledge and assesses evidence on ideas | Isolated agency, no dialogue between evaluators |
| Aggregator | Applies public formulas to signed judgements | Neither modifies nor rewrites judgements |
| Independent oversight | Audit, appeal, protection of rights and safety | Does not replace management with favouritism |

**Guiding principle [P].** All human beings belong to the reference population. The weight on a specialist decision depends on relevant knowledge, not on membership of a class of experts. For universal rights a vote of equal weight is provided.

## 3. Physical model: five sectors

Five sectors are considered, ordered as E = energy, M = materials, F = food, S = services/housing, R = robot manufacturing. x is the gross output vector, A the matrix of intermediate requirements, f final demand. Each column j of matrix A describes the inputs needed to produce one unit of output of sector j.

    x=Ax+f;          f = b + q z + i eᵣ
    [A] x* = (I − A)⁻¹ (b + q z + i eᵣ)

In the numerical scenario, the final demand vectors are: b = (12, 0, 50, 30, 0), z = (0, 0, 10, 15, 0), eᵣ = (0, 0, 0, 0, 1). The parameter q ∈ [0,1] measures the fraction of additional consumption actually supplied; i is annual investment in robotic goods.

| Input \ output | E | M | F | S | R |
|---|---|---|---|---|---|
| E | 0.08 | 0.15 | 0.12 | 0.10 | 0.20 |
| M | 0.06 | 0.08 | 0.14 | 0.08 | 0.25 |
| F | 0.00 | 0.00 | 0.04 | 0.02 | 0.00 |
| S | 0.02 | 0.02 | 0.03 | 0.05 | 0.03 |
| R | 0.03 | 0.03 | 0.04 | 0.05 | 0.08 |

*Table 1. Technical matrix A of the numerical model; hypothetical, fixed coefficients. The inverse is computed only if I − A is invertible.*

    x ≤ x̄ (K,ω) ;      Kₜ₊₁ = (1 − δ) Kₜ + Iₜ

Maximum capacity x̄ depends on installed capital and on shocks ω. For simplicity, robotic investment replaces or adds capacity in the other sectors at a conventional 1:1 ratio: this is a strong assumption, not a technological law.

## 4. Proof 1 — Material feasibility

### 4.1 Leontief proposition [D]

Let A ≥ 0 (non-negative technical coefficients), with spectral radius ρ(A) < 1. For a non-negative final demand f, the minimum output in a linear fixed-coefficient system is:

    xₘᵢₙ = (I − A)⁻¹ f = [I + A + A² + ⋯] f

Proof. The Neumann series converges because ρ(A) < 1 and has all non-negative elements. If a plan x produces at least the final demand, x − Ax ≥ f. Multiplying by (I − A)⁻¹ ≥ 0 gives x ≥ (I − A)⁻¹ f. Setting x = (I − A)⁻¹ f yields equality. Hence the plan is minimal component by component. Q.E.D.

    [D] Physical existence in one period ⇔ (I − A)⁻¹ f ≤ x̄

The condition is necessary and sufficient only in this static model, with separately constrained capacities, fixed technology, no substitutable goods, no inventories and no further restrictions.

### 4.2 Numerical verification

With replacement investment i = 24, the data reproduce the following results:

| Sector | Minimum b + replacement | With extra consumption | Initial capacity |
|---|---|---|---|
| Energy | 34.380 | 38.525 | 42.377 |
| Materials | 22.100 | 25.867 | 28.454 |
| Food | 52.822 | 63.579 | 69.937 |
| Services | 35.451 | 51.798 | 56.978 |
| Robots | 32.152 | 33.766 | 37.143 |

Matrix calculations: ρ(A) = 0.281738, so the linear productivity condition is satisfied. All five capacities exceed the output required in the normal scenario.

### 4.3 Physical margin index [D]

    σ(K,ω) = minⱼ { x̄ ⱼ(K,ω) / [(I − A)⁻¹(b + iₘᵢₙ eᵣ)]ⱼ }

Interpretation: σ ≥ 1 means that the essential basket and the minimum replacement of machines can be produced within the single period, for the matrix and capacities considered. σ < 1 means that at least one sector cannot sustain both requirements. It is neither a probability nor a sufficient measure of multi-year resilience.

**Economic consequence.** An economy may have abundant aggregate capacity and money and still fail to supply the essential basket if a critical intermediate input, for example robots or materials, is lacking.

## 5. Post-wage demand and distribution

To study demand without wages, an aggregate Keynesian subsystem is introduced, distinct from the input-output example. Its purpose is to find the range of distribution compatible with consumption and investment.

    C = [cₚ + (cₕ − cₚ) θ] Y = m(θ)Y
    [D] Y = C + I       ⇒      Y* = I / [1 − cₚ − (cₕ − cₚ) θ]

Here θ is the share of income going to the population receiving the dividend, cₕ the propensity to consume of that population and cₚ that of the owners of private capital. θ, an income share, must not be confused with φ, an ownership share.

    θ* = [1 − cₚ − I / Yₒᵦ] / (cₕ − cₚ)

### 5.1 Calculation of the admissible range

We assume: I = 25, capacity Ȳ = 110, cₕ = 0.90, cₚ = 0.30. Ninety citizens need a total of 54 units of minimum consumption, ten owners need 6.

    Y* = 25 / (0.70 − 0.60 θ)
    Consumption, first 90:        0.90 θ Y* ≥ 54 ⇒ θ ≥ 0.688525
    Owners’ consumption: 0.30 (1 − θ) Y* ≥ 6 ⇒ θ ≤ 0.846154
    Capacity:         Y* ≤ 110 ⇒ θ ≤ 0.787879
    [D] Common range: 0.688525 ≤ θ ≤ 0.787879

For θ = 0.75 the model gives Y\* = 100; citizens’ consumption is 67.5, owners’ consumption 7.5 and investment 25. Identity verified: 67.5 + 7.5 + 25 = 100.

The result does not identify a universal “fair” share: the bounds depend on propensities to consume, capacity, requirements, investment and the architecture of the model.

**Update 1.1.** This subsystem is a special case without the fund and with private owners, who no longer exist since version 1.2: investment is financed by private savings and the capacity Ȳ = 110 is not linked to the input-output model. In §13 income coincides with input-output value added (141, capacity 155.1), investment is decided by the fund and the enterprises, and the share θ becomes endogenous. The operational conclusions should be read in §13–14.

## 6. Proof 2 — Local stability of demand

Let d = cₕ − cₚ > 0 and s = 1 − m(θ\*) > 0. Output adjusts gradually to the gap between demand and supply. A regulator modifies the distributive share according to the deviation from the target:

    Yₜ₊₁ = Yₜ + α [m(θₜ) Yₜ + I − Yₜ]
    θₜ₊₁ = θₜ + η (Y* − Yₜ) / Y*

Linearisation at the fixed point (Y\*, θ\*) yields the Jacobian matrix:

    J = [[1 − α s, α d Y*], [−η / Y*, 1]]
    tr(J) = 2 − α s ; det(J) = 1 − α s + α d η

Proof. For a real 2×2 matrix, local discrete-time stability is verified with the three Jury conditions: 1 − tr + det > 0; 1 + tr + det > 0; 1 − det > 0. Substituting:

    1 − tr + det = α d η > 0
    1 + tr + det = 4 − 2αs + αdη > 0
    1 − det = α(s − dη) > 0

Since 0 < α ≤ 1, 0 < s ≤ 1 and d > 0, the first two conditions are satisfied for η > 0. The third requires η < s/d. Hence:

    [D] LOCAL STABILITY 0 < η < (1 − m(θ*)) / (cₕ − cₚ)

In the case θ\* = 0.75, m = 0.75 and d = 0.60, so 0 < η < 0.416667. The value η = 0.10 satisfies the condition. The result holds only near the equilibrium, with autonomous investment, with shares not stuck at the extremes and with non-binding capacity.

### 6.1 Stability of the input-output process

Adjustment across sectors can also be modelled with a linear system:

    xₜ₊₁ = (1 − γ)xₜ + γ(Axₜ + f),     0<γ≤1
    B = (1 − γ)I + γA;     ρ(B) < 1 ⇒ xₜ → x*

Since A is non-negative, ρ(A) < 1 and 0 < γ ≤ 1, it follows that ρ(B) ≤ 1 − γ + γρ(A) < 1. For γ = 0.60 the numerical model gives ρ(B) = 0.569043.

**Essential distinction.** The convergence of these two subsystems does not prove the stability of the complete TEPS model: prices, debt, capital, votes, financing and innovation can produce other instabilities.

## 7. Capital and centennial crisis tests

In the 0.4 simulations the initial aggregate capital is K₀ = 234.889 and normal replacement is 24 units. We use δ = 24 / 234.889 = 0.102176. The capital of each sector evolves in proportion to the existing stock. The priority rule is: first essential needs, then replacement of machines, and finally discretionary consumption.

    Kₜ₊₁ = (1 − δ) Kₜ + Iₜ
    Iₜ = min{Iₜ desired, Iₜ physically producible}

To bring the stock back towards the reference level after a crisis, the controller demands additional investment for as long as the constraints allow it to be produced. Recovery is therefore not guaranteed in general.

| Scenario | Minimum observed capital | Outcome over 100 periods |
|---|---|---|
| No shock | 234.889 | Unchanged |
| Energy −15% for 5 years | 234.889 | Replacement preserved; discretionary consumption reduced |
| Energy −20% for 5 years | 218.109 | Recovery in the model |
| Energy −25% for 3 years | 198.769 | Recovery in the model |
| Energy −25% for 5 years | — | Essential needs not feasible from year 23 |

![](figure/figura_1.png)

*Figure 1. Aggregate capital under different energy shocks. The lines stop when the model declares the loss of feasibility. The results are simulations, not forecasts.*

### 7.1 Economic reading

The example shows by simulation that a short interruption can be absorbed by sacrificing discretionary consumption and, if necessary, part of replacement. A longer interruption can reduce capital to the point where even producing the essential basket becomes impossible.

Increasing the money supply, on its own, cannot make up for a physical shortage of intermediate inputs.

**Post-fusion note (1.1).** With fusion energy as the baseline assumption, the energy shocks in this section describe the pre-fusion regime. In the baseline regime the relevant shocks hit materials, robots and maintenance: they are studied with the monetary model in §15 and with the capital matrix in §16. The qualitative conclusion stands: money does not replace missing physical inputs (quantitative proof in §15.1, rule R3).

## 8. Nuclear fusion and robust investment

TEPS considers the limiting scenario of a fusion system that triples energy capacity. This is not equivalent to proving that the total cost of electricity becomes zero: investment, the grid, maintenance, availability, materials and depreciation continue to matter.

    x̄ᴱ,fusione = 3 · x̄ᴱ,base         [A: scenario, not forecast]

If energy ceases to be the binding sector, the other sectors may determine the limit of the system. In scenario 0.5 an additional budget of 10 units of capacity is available.

### 8.1 Formulation of the robust choice

    max ΔK,σ σ
    subject to: fⱼ(ω) · [Kⱼ + ΔKⱼ] ≥ σ · [(I − A)⁻¹(b + δ Σ(K + ΔK) eᵣ)]ⱼ
    Σ ΔKⱼ = 10; ΔKⱼ ≥ 0; for every sector j and shock ω

With the sum of the increments fixed at 10, total replacement is known: the problem in the example is a linear programme. The optimum maximises the worst margin across the sectors and scenarios explicitly admitted.

| Additional investment | Normal conditions only | Robust optimisation |
|---|---|---|
| Energy | 0.000 | 0.000 |
| Materials | 1.624 | 3.162 |
| Food | 0.889 | 0.000 |
| Services | 0.000 | 0.000 |
| Robot manufacturing | 7.488 | 6.838 |
| Total | 10.000 | 10.000 |

The robust configuration gives more protection to materials and robots because the declared shocks hit precisely these sectors. Note that robust optimisation does not promise higher normal output.

| Scenario with 3× fusion | Extra consumption share q: normal | Share q: robust |
|---|---|---|
| No shock | 1.000 | 1.000 |
| Energy −50% | 1.000 | 1.000 |
| Robots −20% | 1.000 | 1.000 |
| Materials −25% | 0.033 | 0.340 |
| Defined combined shock | 0.433 | 0.759 |

![](figure/figura_2.png)

*Figure 2. Trajectories of the fraction q of discretionary consumption: strategy optimised for normal conditions only (ochre) and robust strategy (green). With the declared coefficients both maintain replacement during the shocks considered.*

Over the declared set of shocks, the worst-case index σ improves from about 1.006 (nominal optimisation, checked against the shocks) to 1.057 (robust optimisation). The advantage disappears or may be reversed for shocks not included in the design.

## 9. Accounting, prices and the collective fund

### 9.1 Real accounting must not double-count intermediate goods

At a conventional unit price for all five sectors, under normal conditions aggregate gross output is 213.535 units, intermediate consumption 72.535 and gross value added 141. The account of final uses is:

    [D] VA = 1ᵀ[x − Ax] = 1ᵀ f = 92 + 25 + 24 = 141

| Annual final use | Units |
|---|---|
| Essential basket (b) | 92 |
| Discretionary consumption (z) | 25 |
| Replacement machines (i) | 24 |
| Total final demand | 141 |

This is an accounting identity at the conventional unit price: it does not mean that 141 is in euros, nor that the five goods are physically interchangeable. The 92 of essential services require a mechanism of access in kind, transfers or equivalent entitlements.

### 9.2 Dividends and ownership

Assuming, for illustration, that the residual discretionary part is 25 units and that 75% of it belongs economically to the collective, dividends could be 18.75 to the fund/citizens and 6.25 to private parties. The essential basket and the 24 of replacement are financed before dividends. An ownership share of 75% is not, however, automatically equivalent to an income share of 75%: transfers and service obligations can modify it.

Note 1.2: with φ = 0.75 the fund would be unable to pay for the basket (it would collect 87.75 against 92), and this split would require a charge of 78.6% on private profits (version 1.1). Version 1.2 abolishes private productive ownership (φ = 1): the whole distributable surplus of 117 goes to the fund, which pays 92 for the basket and 25 in dividend and rewards (from 1.5: civic income, rewards and unearned shares allocated to new enterprises, §13.6) (§14.1).

### 9.3 Public fund account

    Fₜ₊₁ = Fₜ + CFₜ + Tₜ − Iₜʳᵉᵖ − Iₜⁿᵘᵒᵛᵒ − Dₜ − Sₜ

F is the fund’s liquidity/net financial assets; CF is the firms’ net cash flow after operating costs and before investment, T is tax revenue external to CF, D dividends (from 1.5: accrued civic income, §11.3), S incentives to innovators. The terms must be disjoint to avoid double counting. In a steady state with no change in the fund, total receipts must equal total outlays.

An economy can in theory reuse a constant money stock, but this identity alone is not a proof of price stability or of the absence of banking instability. A genuine stock-flow consistent model is needed, with assets, liabilities, money demand and endogenous prices. [3]

Note 1.1: the required stock-flow consistent model is developed in §13, with the balance-sheet matrix, the transactions matrix and the fund’s rules; this equation is its fund column.

### 9.4 Prices without wages

    p = Aᵀ p + d + μ ⇒ p = (I − Aᵀ)⁻¹(d + μ)

The primary cost d incorporates non-wage costs and capital replacement; μ denotes the net unit surplus. In the fusion experiment, reducing the primary energy term from 0.500 to 0.005 and leaving the other coefficients unchanged, the indicative prices change as follows:

| Sector | Base price | Price with reduced primary energy cost | Change |
|---|---|---|---|
| Energy | 0.6332 | 0.0824 | −87.0% |
| Materials | 0.5894 | 0.4931 | −16.3% |
| Food | 0.5981 | 0.5067 | −15.3% |
| Services | 0.8147 | 0.7389 | −9.3% |
| Robots | 1.0309 | 0.8825 | −14.4% |

For the same final goods, the nominal value of the example aggregate falls from 104.889 to 85.819. This is a change in value at current prices in the chosen price system, not a material impoverishment. This exercise uses a second price vector, different from the unit convention used for the 141 balance.

## 10. Firms: public capital and the innovator’s reward

The TEPS entrepreneur identifies a need and presents a business plan: product, technology, users, costs, feasibility evidence, risks and possible developments. If the project is approved, they receive access to collective capital and infrastructure. Direct management is delegated to the operational AI; the innovator takes part indirectly through proposals, advice and new ideas.

### 10.1 Project selection

    max Σⱼ zⱼ [a Uⱼ + b Gⱼ − c Rⱼ] ;     zⱼ ∈ {0,1}
    Σⱼ kⱼ zⱼ ≤ F_disp ;    M z ≤ resources ;     safetyⱼ = 1

U is the expected benefit for citizens, G the technical/scientific value of the innovations and R the risk; the weights a, b, c are set by public rules. The assessments come from the AI panel. The tests of legality and safety are constraints, not compensable scores.

### 10.2 Incremental salary-type incentive

    Sᵢ,ₜ = S₀ + α max(0,Vᵢ,ₜ) + β max(0,Vᵢ,ₜ − Vᵢ,ₜ₋₁)
    Σᵢ Sᵢ,ₜ ≤ S̄ₜ ≤ surplus available after b and replacement

The compensation S does not remunerate the productive activity required by the factories, but rather the definition, improvement and demonstrated usefulness of the idea. V is the incremental net value attributable to the idea, including social benefits and resource savings. Causal attribution, the duration of rewards, co-inventions and a possible base component S₀ remain to be defined.

Note 1.3: the linear form α max(0, V) is replaced by a concave, bounded reward, calculated on total public value (economic plus social advantage): §17.5.

### 10.3 The uncertainty of revolutionary ideas

Established knowledge is the basis of competence, but not the limit of invention. Radical ideas must be open to testing even when they contradict consolidated knowledge. An unproven proposal is not the same as a refuted proposal.

Financing can be progressive: small budgets for formulation, simulations, prototypes and independent measurements; larger budgets only after favourable tests. An experiment is rational even before the enterprise is approved if its expected value of information exceeds the cost of the test.

    VEI = E_D[max(0, E[V|D] − C)] − max(0, E[V] − C) − C_test

### 10.4 Portfolio check [N]

Ten projects cost 10 units each. Each returns 60 units with hypothetical probability 0.20 and zero otherwise; the outcomes are assumed to be independent. The expected value of returns is 10 × 0.20 × 60 = 120, against 100 invested. However, at least two successes are needed to recover at least 100.

    Pr[loss on capital] = Pr[X ≤ 1], X ~ Binomial(10; 0.20)
    = (0.8)¹⁰ + 10 × 0.2 × (0.8)⁹ = 0.37581 ≈ 37.6%

A positive expectation does not guarantee the safety of the fund. Correlations, liquidity, fundable shares per stage and sectoral concentration must be managed. The parameters are invented solely to illustrate the calculation.

## 11. Competence and universal weighted democracy

The reference population is not a narrow group of experts: it coincides with the entire human community admitted to the legal order. Every person can demonstrate and increase their competence over time. Competence is verified mastery of established knowledge in the discipline; it does not depend on entrepreneurial success, on wealth or on adherence to prevailing ideas.

    Cᵢ,ₖ = [Σⱼ aⱼ,ₖ pᵢ,ⱼ,ₖ] / [Σⱼ aⱼ,ₖ]

Each pᵢ,ⱼ,ₖ measures, through tests and demonstrations, understanding and application of known knowledge. The weights aⱼ,ₖ represent the relevance and coverage of the discipline. The evaluating AIs define and update the map of knowledge with verifiable methods.

### 11.1 The specialist vote function

    wᵢ(q) = 0, if Cᵢ(q) < τ(q)
    wᵢ(q) = 1 + (wₘₐₓ − 1)[Cᵢ(q) − τ(q)]/[1 − τ(q)], otherwise
    Outcome(q) = [Σᵢ wᵢ(q) vᵢ(q)] / [Σᵢ wᵢ(q)]

τ is the competence threshold for the technical decision, wₘₐₓ the maximum relative weight and vᵢ(q) the vote. If there are no admitted participants, the technical decision cannot be adopted with this procedure. For decisions affecting universal rights, by contrast, everyone has wᵢ(q) = 1.

Note 1.5: the outcome is calculated only on the votes expressed (in favour or against); explicit abstentions enter neither the numerator nor the denominator (§11.3).

Note 1.4: from version 1.4 this case does not arise: if fewer than N_min are admitted, the threshold automatically falls until N_min are included (§17.8).

**Necessary distinction.** TEPS posits weighted votes in technical decisions and in the governance of the fund. The political vote provided for by the Italian Constitution is personal and equal (Art. 48): replacing equal political suffrage with differentiated weights is not compatible with that principle under the current legal order. [5]

### 11.2 Knowledge does not mean conformism

Being competent means knowing theories, evidence, limits and possible applications: not being obliged to consider them infallible. The panel assesses separately (a) mastery of knowledge, (b) validity of the new proposal, (c) net economic value realised. There are no automatic penalties on competence for a hypothesis that is refuted or not financed.

    Knowledge Cᵢ,ₖ ≠ validity of the proposal V(Pᵢ) ≠ incentive Sᵢ

No one may vote with specialist weight on the financing of their own enterprise: the interested party may present evidence and answer objections, but may not be the decision-maker on their own case.

Note 1.4: recognised innovation enters the specialist weight through the term R of §17.7, with a cap. The assessment of the proposal (§11.2) remains separate, and the ban on voting on one’s own case remains.

**Integration 1.5 — §11.3 civic income and participation in votes**

### 11.3 Participation rule [P]

The system convenes each citizen only to the votes for which they are eligible: all those with an equal vote on universal rights and the technical ones in the disciplines in which they are admitted (§11.1, §17.8). For each citizen i and period t:

    Nᵒᶠᵢ,ₜ = votes offered (due and accessible, net of recognised impediments)
    Nᵉˢᵢ,ₜ = votes cast (vote in favour, against or explicit abstention)
    [P] Pᵢ,ₜ = Nᵉˢᵢ,ₜ / Nᵒᶠᵢ,ₜ   if Nᵒᶠᵢ,ₜ > 0 ;   Pᵢ,ₜ = 1   if Nᵒᶠᵢ,ₜ = 0
    [P] Hᶜᵢ,ₜ = h̄ₜ · Pᵢ,ₜ        (accrued civic income; h̄ₜ full civic income, §13.6)

Example: with h̄ = 100 and 10 votes offered, a person who casts 10 receives 100; a person who casts 8 receives 80; a person who has no convocations, or has a recognised impediment for all of them, receives 100.

Rules of application:

- Content of the vote: the choice, motivation or quality of the vote is not checked. In favour, against and explicit abstention count equally for Pᵢ,ₜ.
- Abstention and outcome: explicit abstention counts for income but does not enter the outcome of §11.1, which is calculated on the votes expressed only: Outcome(q) = [Σᵢ∈E(q) wᵢ(q) vᵢ(q)] / [Σᵢ∈E(q) wᵢ(q)], with E(q) the set of those who voted in favour or against. A person who abstains does not shift the decision towards a neutral value.
- Recognised impediments: cases established by public registers (minority, hospitalisation, certified disability preventing voting, failure of the voting system, convocation not delivered) are excluded from Nᵒᶠ without any application being required. In other cases the citizen submits a justification; while the appeal is pending no deduction is applied. The burden of proving that the convocation was delivered and accessible lies with the system.
- Number of votes: Nᵒᶠᵢ,ₜ ≤ N_max per period, with N_max set by equal vote; each vote remains open for a minimum time and through several channels. The calculation of P uses a moving window that includes at least n_min convocations, so that a single absence does not wipe out the income of a period.
- Secrecy: the participation ledger (who voted and in which vote) is separate from the ballot box (content of the votes, without identity). At each convocation the citizen receives a single-use anonymous credential; no system retains the link between credential and identity; ledger and ballot box are publicly and independently verifiable. This is the condition for the vote to remain personal, free and secret (Art. 48 [5]) while being remunerated.
- Appeals and audit: every citizen can check and contest their own Pᵢ,ₜ; the calculation rules are public and deterministic like the other rules of the system (§12.3).
- Basket: Pᵢ,ₜ never affects the essential basket in kind bₜ.

Why the rule is needed. The safeguards on the power of groups (D-14) and the minimum voting base (D-15) are calculated on those admitted. If those admitted do not vote, decisions are taken by a few and those limits no longer hold. Remunerating participation makes effective the voting base on which TEPS rests the rules of the fund and of the AIs.

## 12. A panel of isolated AIs and independence of judgements

The recognition of competence and the examination of initiatives are entrusted to multiple AI agents, with different architectures and methods. Each agent receives a controlled dossier, carries out a separate examination and signs its own report; it cannot read the others’ judgements, send messages to the other agents or modify its report after submission.

    Oₐ = fₐ(E, Mₐ) ; Oₐ does not use Oᵦ as a direct input (a ≠ b)
    D = G(O₁, …, Oₘ), with G defined before the evaluation

The aggregator applies a public deterministic rule, possibly weighted by reliability measured in the sector. The agents too have a measured weight: no evaluator acquires total power. The weighting must not become self-referential: the agents’ performance is measured with external tests, new data and error calibration, not by their degree of agreement with the other agents.

### 12.1 Combining scores and dissent

    Ĉᵢ,ₖ = medianₐ Cᵢ,ₖ⁽ᵃ⁾
    MADᵢ,ₖ = medianₐ |Cᵢ,ₖ⁽ᵃ⁾ − Ĉᵢ,ₖ|
    C*ᵢ,ₖ = max(0, Ĉᵢ,ₖ − λ MADᵢ,ₖ)

The formula is a prudential index for a set of judgements; it is not automatically a calibrated probability of competence. Complex cases require standardised tests, error analysis and uncertainty assessments.

### 12.2 Proof of the majority under independence [D]

If five agents take binary decisions, each with error probability p = 0.20 and with statistically independent and identically distributed errors, the majority errs when at least three agents err.

    Pr[majority error] = Σₖ₌₃⁵ C(5,k) pᵏ(1 − p)⁽⁵⁻ᵏ⁾
    = 10×0.2³×0.8² + 5×0.2⁴×0.8 + 0.2⁵
    = 0.05792 = 5.792%

The reduction from 20% to 5.792% derives from the probabilistic assumptions, not from the mere ban on dialogue. If the agents use identical erroneous data or have perfectly correlated errors, the panel’s error may remain at 20%. Diversity of methods, technical isolation and external validation are therefore all necessary.

### 12.3 Security, audit and accountability

- Isolated input channels, signed reports, audit logs and verification of model versions.
- Evaluations through external tests, stress tests with falsified data and measures of error correlation.
- The possibility for every citizen to take further tests, contest errors in the dossier and request a new verification.
- Public rules for replacing models, managing conflicts of interest and preventing manipulation of the competence ledger.
- Oversight and blocking tools for operations that violate the law or safety; for high-risk systems the applicable human-oversight obligations under the AI Act also apply. [6–7]

## 13. Stock-flow consistent block with the fund

Version 1.0 left test T3 open: a fund account is not enough to show that money, prices and demand remain consistent. This section closes the monetary circuit with a stock-flow consistent (SFC) model in the style of Godley–Lavoie [3], unified with the input-output accounting of §9.1: every flow has a counterpart and every flow changes a stock.

Baseline assumption from 1.1: abundant fusion energy at negligible cost (§8). Energy is never the binding sector; the relevant constraints and shocks concern materials, robots, buildings and maintenance.

### 13.1 Sectors and instruments

- Citizens (h): receive the essential basket in kind, civic income (1.5, §11.3) and incentives to innovators (together H); they hold money Mₕ and items of personal property.
- Firms (i): wholly owned by the fund (φ = 1, version 1.2); they sell output, set aside depreciation for replacement and distribute the remainder. No wages.
- Public productive fund (f): receives all profits; purchases the basket b, pays H, finances additional investment Iₓ and new enterprises Iₙ; covers deficits with advances A.
- Monetary authority (m): issues money as the counterpart of advances to the fund. Zero rate [A]: it is a public entity that can be consolidated with the fund. From 1.5 it coincides with the automated public bank of §13.7; there are no private banks.

There is no sector of private owners: personal property (housing, durable goods) does not produce business income and does not enter the matrices, except through the location charge of §15.3. The fund, the firms and the monetary authority are managed by public AIs according to rules set by weighted vote.

### 13.2 Balance-sheet matrix

| Instrument | Citizens | Firms | Fund | Monetary auth. | Σ |
|---|---|---|---|---|---|
| Money | +Mₕ |  |  | −M | 0 |
| Advances |  |  | −A | +A | 0 |
| Physical capital |  | +pK |  |  | +pK |
| Equity holdings |  | −pK | +pK |  | 0 |
| Net worth | −Vₕ | 0 | −V_f | 0 | −pK |

*Table 2. Balance-sheet matrix (version 1.2, φ = 1; from 1.5 the “Monetary auth.” column is the automated public bank, §13.7). The monetary authority’s column imposes A = M = Mₕ: the money in circulation is exactly the fund’s net debt to the authority.*

### 13.3 Transactions matrix

| Flow | Citizens | Firms curr. | Firms cap. | Fund | Mon. auth. | Σ |
|---|---|---|---|---|---|---|
| Essential basket |  | +pb (92) |  | −pb (−92) |  | 0 |
| Discretionary consumption | −C (−25) | +C (25) |  |  |  | 0 |
| Capital replacement |  | +pIᵣ (24) | −pIᵣ (−24) |  |  | 0 |
| Depreciation |  | −pδK (−24) | +pδK (24) |  |  | 0 |
| Profits to the fund |  | −Π (−117) |  | +Π (117) |  | 0 |
| Civic income and rewards | +H (25) |  |  | −H (−25) |  | 0 |
| Change in money | −ΔMₕ (0) |  |  |  | +ΔM (0) | 0 |
| Change in advances |  |  |  | +ΔA (0) | −ΔA (0) | 0 |
| Σ | 0 | 0 | 0 | 0 | 0 | 0 |

*Table 3. Transactions matrix; the steady state with p = 1 and φ = 1 is shown in brackets. From 1.5 the civic income row equals H = h̄ Σᵢ Pᵢ + S and, if Pᵢ < 1, the flow pIₙ appears between Fund and Firms cap. (§13.6). Every row and every column sums to zero; in the simulations the condition Mₕ = A is verified in every period with a maximum discrepancy of 3·10⁻¹³.*

### 13.4 Behavioural equations

    Ȳₜ = ωₜ Kₜ / v ;   v = K₀ / Ȳ₀ = 234.889 / 155.1 = 1.5144

Ȳ₀ = 1.10 × 141 = 155.1 is the value-added capacity consistent with the sectoral capacities of §4.2, all equal to 1.10 times requirements. Normal utilisation ū = 141/155.1 = 0.909 leaves 9% of capacity as a reserve for shocks.

    Cₜ = α₁ Hₜ + α₂ Mₕ,ₜ₋₁
    Πₜ = pₜ (Yₜ − Iᵣ,ₜ) ;       Iᵣ,ₜ = δ Kₜ
    ΔAₜ = pₜ b + pₜ Iₓ,ₜ + Hₜ − Πₜ
    pₜ = pₜ₋₁ [1 + κ (Yᵈₜ₋₁ / Ȳₜ₋₁ − ū)]
    Rationing priority: b → Iᵣ → Iₓ → discretionary consumption

Parameters: α₁ = 0.90 (the propensity cₕ of §5), α₂ = 0.10, κ = 0.5, δ = 0.1022. Iₓ = 0.5·max(0, K₀ − Kₜ) is the fund’s recovery reinvestment. When demand exceeds capacity, unmet spending remains in money (forced saving): this is the choice that preserves stock-flow consistency.

### 13.5 Unification with §5 and §9

Income is no longer a separate aggregate: it is the input-output value added Y = b + c + Iᵣ + Iₓ, equal to 141 in the normal state. The share θ of §5 equals 1 by construction: the whole net surplus goes to citizens, in kind (pb) or in money (H). Investment is a decision of the fund and the firms, not an autonomous datum. The fund equation of §9.3 is the “Fund” column of Table 3.

## 14. Proofs on the monetary block

### 14.1 D-7 Closure of the fund [D]

In the steady state (constant p, ΔMₕ = 0, Iₓ = 0) citizens spend their income. The fund breaks even, with dividend D ≥ 0 (from 1.5: full civic income h̄ ≥ 0, §14.5), if and only if:

    [D] Π ≥ p b + S + p Iₙ

Proof. From the fund column, ΔA = pb + pIₙ + H − Π with H = D + S. Imposing ΔA = 0 gives D = Π − pb − S − pIₙ, and D ≥ 0 is equivalent to the condition. Q.E.D.

Numerical consequence: Π = p(b + c) = 117 ≥ 92, with a margin of 25 for civic income, rewards and new enterprises. The comparison with version 1.1 explains the choice: with φ = 0.75 the fund collected 87.75, less than the basket (92), and a charge of 78.6% on private profits was required.

**Economic consequence.** Abolishing private productive ownership closes the fund by construction: no charge is needed and there is no class of profit recipients. The constraint that remains is distributive: the essential basket absorbs 79% of the distributable surplus, so civic income (dividend up to 1.4), rewards to innovators and new enterprises compete for the remaining 21% (25 units).

### 14.2 D-8 Nominal anchor: why a functional rule is needed [D]

With the fund breaking even (rule R0: H = fund revenue − pb − pIₓ) we have ΔA = 0, so total money M = Mₕ remains constant. Summing the columns, every level of Π satisfies the steady-state conditions: the flows do not determine the level of real demand, which depends on the money stock and on the price level. Table 4 verifies this starting from different money stocks (200 periods).

| Initial money | R0, flexible prices | R0, downward-rigid prices | R1 functional |
|---|---|---|---|
| 0.6 × steady state | p 0.930 · u 0.909 · c 25.0 | p 1.000 · u 0.877 · c 20.0 | p 0.966 · u 0.909 · c 25.0 |
| 1.0 × steady state | p 1.000 · u 0.909 · c 25.0 | p 1.000 · u 0.909 · c 25.0 | p 1.000 · u 0.909 · c 25.0 |
| 1.6 × steady state | p 1.106 · u 0.909 · c 25.0 | p 1.273 · u 0.849 · c 15.7 | p 1.050 · u 0.909 · c 25.0 |

*Table 4. Final price level p, capacity utilisation u and real discretionary consumption c. Numerical result [N] illustrating D-8.*

With flexible prices the system rebalances anyway, but through deflation or inflation of 7–11%. If prices do not fall (downward rigidity, which is realistic), the break-even rule leaves machines idle: utilisation 0.85–0.88 and discretionary consumption 16–20 out of a possible 25. An initial excess of money also ends in under-utilisation: the initial inflation erodes real balances and then prices do not come back down. This is the Keynesian trap in an economy without wages: the problem of §5 does not disappear with automation, it shifts from the wage to the money stock. The functional rule, in Lerner’s sense [8], solves it:

    [D] R1: Hₜ = [fund revenue − pₜ b − pₜ Iₓ,ₜ] + λ pₜ (ū Ȳₜ − Yᵈₜ₋₁)

The fund varies money instead of output and brings utilisation back to ū from any initial condition.

Note 1.5: R1 sets the total pool Hᴿ¹ₜ; from it the full civic income h̄ₜ is derived, distributed according to participation (§11.3, §13.6).

**Integration 1.5 — §13.6 unearned shares, §14.5 D-16, §14.6 N-9**

### 13.6 Civic income in the stock-flow block [P]

The functional rule R1 (§14.2) sets, each period, the total pool of transfers Hᴿ¹ₜ as if everyone participated. From it we derive:

    h̄ₜ = (Hᴿ¹ₜ − Sₜ) / N_pop                       full civic income per person
    Hₜ = h̄ₜ Σᵢ Pᵢ,ₜ + Sₜ                            transfers actually paid
    Qₜ = h̄ₜ Σᵢ (1 − Pᵢ,ₜ) = Hᴿ¹ₜ − Hₜ                unearned shares

The shares Qₜ remain with the fund and enter the new-enterprise reserve Fᴵ (the innovation reserve of §17.3):

    Fᴵₜ₊₁ = Fᴵₜ + Qₜ − pₜ Iₙ,ₜ ;    pₜ Iₙ,ₜ ≤ Fᴵₜ + Qₜ ;  Iₙ,ₜ limited by projects approved in stages and physical capacity

The fund column becomes ΔAₜ = pₜbₜ + pₜIₓ,ₜ + pₜIₙ,ₜ + Hₜ − Πₜ. Spending on new enterprises follows the rules of §17.3 (staged financing, automatic stop): unearned shares do not open a channel of discretionary spending. If Fᴵ exceeds a cap F̄ᴵ set by vote, the excess returns to the full civic income h̄ of the following period.

### 14.5 D-16 Demand neutrality [D]

In the steady state (p = 1, Iₓ = 0, S = 0, Hᴿ¹ = 25), if the unearned shares are spent in full on new enterprises in the same period (Iₙ = Q), then for any average participation P̄ = Σᵢ Pᵢ / N_pop:

    [D] Y = b + c + Iᵣ + Iₙ = 141 ;  Π = 117 ;  ΔA = 0 ;  A* = (1 − α₁)/α₂ · H* = 25 P̄

Proof. Transfers paid are H = 25 P̄. In the steady state ΔMₕ = 0 gives Mₕ\* = (1 − α₁)/α₂ · H, hence c = α₁H + α₂Mₕ\* = H = 25 P̄. Spending on new enterprises is Iₙ = Q = 25 (1 − P̄). The sum c + Iₙ = 25 does not depend on P̄: demand, value added and profits remain those of 1.4. From the fund column ΔA = 92 + 25 (1 − P̄) + 25 P̄ − 117 = 0. Q.E.D.

Interpretation: those who do not vote do not reduce aggregate demand, they change its composition: less discretionary consumption, more investment in new enterprises. The desired money stock falls in proportion (A\* = 25 P̄): during the transition citizens spend part of their balances and the excess money returns to the fund without a deficit.

Comparison: if Q stayed idle in the fund, with rigid prices the trap of D-8 would arise. With P̄ = 0.9 demand would fall from 141 to 138.5 and utilisation from 0.909 to 0.893: idle machines and no real resources saved.

### 14.6 N-9 Physical limit of conversion into capital [N]

Shifting Q from discretionary consumption to investment changes which sectors work: less food and services, more robots. Computation with matrix A and the capacities of §4.2, discretionary consumption P̄·z, replacement 24 and the 1:1 convention of §3 (new capital is produced by the robot sector):

| Average participation P̄ | Shares Q | Margin σ with full spending of Q | Q absorbable in one period |
|---|---|---|---|
| 1.00 | 0.00 | 1.100 | 3.04 |
| 0.90 | 2.50 | 1.021 (robot) | 3.19 |
| 0.75 | 6.25 | 0.922 (robot) | 3.41 |
| 0.50 | 12.50 | 0.793 (robot) | 3.77 |

*Table 13. Feasibility of spending the unearned shares in a single period; the binding sector in brackets. The essential basket is never at risk: σ < 1 only indicates that Q cannot be spent in full in the same period.*

- Threshold: with P̄ ≥ 0.871 the unearned shares (up to 3.2 units) are converted into capital in the same period and D-16 holds.
- Below the threshold: the part of Q beyond the limit remains in Fᴵ and is spent in subsequent periods. In the meantime demand is below capacity and rule R1 compensates by raising h̄ in the following period: part of the shares thus returns to the citizens who vote. This is a stabilisation effect, not a distributive choice.
- The limit depends on the 1:1 convention: with the capital matrix B of §16 (machines 60%, buildings 30%, materials 10%) the load on the robot sector is lower and the threshold must be recomputed (T9.2).
- New capital increases future capacity and replacement: if the new enterprises do not produce value, the additional replacement reduces the margin of condition C1 in subsequent periods. This is the same risk as in §17.3 and is managed through staged financing (T9.5).

**Integration 1.5 — §13.7 automated public bank, §14.7–14.11 D-17–D-21**

### 13.7 No private banks: the automated public bank [P]

[P] In TEPS 1.5 there are no private banks: no private party may hold other people’s deposits, issue money or other means of payment, or grant loans at interest. The necessary banking functions are performed by an automated public bank (BPA): a public ledger of accounts run by AI under the deterministic chain of control of §17, consolidated with the fund and with the monetary authority of §13.1.

| Function of a bank | In TEPS 1.5 | Proof |
|---|---|---|
| Accounts and payments | BPA ledger with a deterministic transfer rule | D-17, D-18, D-19 |
| Creation and destruction of money | Only the fund account can go negative, according to R1 | D-17, D-9, N-3 |
| Credit to enterprises | Fund, with staged financing (§10, §17.3) | N-7 |
| Collection and investment of savings | Not needed: savings earn no return and do not finance enterprises | D-20 |
| Risk assessment | Panel of independent AIs (§12) | D-6, N-7 |
| Consumer credit | Not needed: basket in kind and civic income | D-20 |
| Deposit insurance and liquidity | Not needed: the deposit is money itself | D-18 |

Ledger. The accounts are those of citizens h and the fund account f; enterprises, wholly owned by the fund, are accounts consolidated into the fund. The state of the ledger is the vector of balances mⱼ. A transaction is τ = (from, to, x):

    [P] valid(τ) ⇔ x > 0  and  ( m_from ≥ x  or  from = f )
    [P] execute(τ):  m_from ← m_from − x ;   m_to ← m_to + x

The fund account can go negative only for the payments provided for by its rules (basket, civic income, rewards, investment: §13.4, §13.6, R1); citizens’ accounts never. Any cash is issued one for one against the balance and does not change the following properties.

### 14.7 D-17 Conservation: money is the negative balance of the fund [D]

    [D] Σⱼ mⱼ,ₜ = 0 for every t ;     Mₜ = Σₕ mₕ,ₜ = −m_f,ₜ = Aₜ

Proof. Initially the sum of balances is zero. Every executed transaction removes x from one account and adds x to another, so the sum remains zero after every transaction (induction on the number of transactions). Citizens’ balances are non-negative, so the only account that can be negative is that of the fund, and the money held by citizens is exactly the debt of the fund, that is, the advances A of Table 2. Q.E.D.

- No money arises outside the fund: without private banks there is no money created by private credit, and the only monetary lever is rule R1.
- The condition Mₕ = A of Table 2 is no longer a result to be verified but a property of the ledger; in the N-10 simulations the discrepancy is at most 10⁻¹³, i.e. numerical rounding.
- In the steady state the money stock is the one citizens wish to hold: A\* = (1 − α₁)/α₂ · H\* = 25 (D-9).

### 14.8 D-18 No bank runs [D]

In a fractional-reserve bank with deposits D and reserves R = r·D, with r < 1, simultaneous withdrawal requests exceeding R cannot all be paid: the outcome for each depositor depends on what the others do. In the BPA, instead:

    [D] the execution of τ depends only on m_from: the condition valid(τ) contains no balances of other accounts

Proof. It follows from the definition of valid(τ). A set of citizens’ transactions in which the outflows from each account do not exceed its balance can be executed in full and in any order, because each transaction reduces only the account that issues it. The coverage ratio is 1: the deposit is not a claim on the bank to be converted into money, it is money. Q.E.D.

Consequence: there is no bank insolvency, no contagion among depositors, no deposit insurance and no lender of last resort. The only residual monetary risk is the one already studied: an issuance by the fund exceeding desired money, which produces inflation (§15, condition C4).

### 14.9 D-19 Verifiable deterministic execution [D]

The state of the ledger evolves according to a deterministic and public function, Sₜ₊₁ = Φ(Sₜ, τ₁, …, τ_k). The BPA is computed by n independent systems (different architectures, code and operators, like the agents of §12); a new state is accepted only if the majority of the systems produce the same state, otherwise the ledger halts and recomputes. If q is the failure probability of a single system and failures are independent:

    [D] Pr[wrong state accepted] ≤ Σ_{j > n/2} C(n, j) qʲ (1 − q)ⁿ⁻ʲ

Proof. Φ is deterministic, so all correct systems produce exactly the same state. A wrong state can be accepted only if a majority of systems fail and produce the same wrong state; the probability that a majority fails is the binomial sum, which is therefore an upper bound. Q.E.D.

Figures: with q = 0.01 the bound is 3.0·10⁻⁴ for n = 3, 9.9·10⁻⁶ for n = 5 and 3.4·10⁻⁷ for n = 7; with q = 0.001 and n = 5 it is 1.0·10⁻⁸. Compared with D-6 the control is stronger: among correct systems there is no legitimate disagreement, so every difference signals a failure, and anyone can recompute the state from the public transaction records (exact audit, not statistical). The guarantee requires independent failures: common-mode failures (the same faulty code) are reduced through different implementations of the same Φ. Numerical verification (`simulazioni/teps_1_5_banca_pubblica.py`): over 200,000 random transactions among 1,000 accounts the accounting identities of D-17 and the condition of D-18 hold at every transaction; in the worst case, in which all failed systems produce the same wrong state, the observed frequency matches the bound (n = 3, q = 0.05: bound 7.25·10⁻³, observed 7.24·10⁻³; n = 5, q = 0.05: 1.16·10⁻³ and 1.15·10⁻³).

### 14.10 D-20 Private lending at interest is incompatible with D-12 [D]

If a person could lend at rate r > 0, their wealth would earn a return:

    Wᵢ,ₜ₊₁ = (1 + r) Wᵢ,ₜ + h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ − Cᵢ,ₜ

    [D] with r > 0 and Wᵢ,₀ > 0 the bound Wᵢ,T ≤ Wᵢ,₀ + Σₜ (h̄ₜ + S_max) is violated for sufficiently large T

Proof. With zero consumption Wᵢ,T ≥ (1 + r)ᵀ Wᵢ,₀. The left-hand side grows exponentially in T, the bound of D-12 and D-13 at most linearly (h̄ₜ and S_max are bounded), so there exists a T beyond which the bound is exceeded. With r = 0, D-12 holds. Q.E.D.

- The prohibition of private banks and of lending at interest is the mathematical condition for wealth not to generate wealth (§17.4), not an additional choice.
- Without interest no private party has any reason to lend: the supply of private credit is zero even independently of the prohibition. An interest-free loan between persons is a simple transfer between accounts and does not create money (D-17).
- Consumer credit is not needed: the essential basket is in kind, and with r = 0 a loan shifts consumption over time without increasing it, because the constraint Σₜ Cᵢ,ₜ ≤ Wᵢ,₀ + Σₜ (h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ) remains the same; with r > 0 it would reduce it.

### 14.11 D-21 The monetary system without private banks works [D/N]

With the ledger of §13.7, rule R1 with 0 < λ < λ_max (C2) and the closure of the fund (C1):

    (a) in every period money coincides with the debt of the fund, Mₜ = Aₜ (D-17);
    (b) every payment covered by the balance is executed, regardless of the behaviour of others (D-18);
    (c) the money stock converges to the desired one, A* = (1 − α₁)/α₂ · H* = 25 (D-9), and the steady state is locally stable (N-3);
    (d) a wrong state of the ledger is accepted with probability no greater than the bound of D-19, and every state can be recomputed by anyone;
    (e) personal wealth remains bounded, because there is no return on wealth (D-12, D-20).

Proof. (a), (b), (d) and (e) are D-17, D-18, D-19 and D-20; (c) is D-9 for the steady state and N-3 for local stability. Q.E.D.

Scope: (a), (b), (d) and (e) are exact proofs that hold by construction of the rules. (c) is local and numerical as in 1.4: global stability is not proven. Two risks remain, already treated in the model: excessive issuance by the fund (inflation, C4) and common-mode failures of the systems that compute the ledger (D-19). A system of AI and deterministic rules can therefore perform all the banking functions required by TEPS; the functions of private banks that it does not perform (credit at interest, maturity transformation, private money creation) have no object in TEPS.

### 14.3 D-9 The debt of the fund is voluntarily held money [D]

In the steady state ΔMₕ = 0 implies Mₕ\* = (1 − α₁)/α₂ · H\*. Since A = M (Table 2):

    [D] A* = (1 − α₁)/α₂ · H* = 25

The cumulative deficit of the fund does not explode: it converges to the money stock that citizens wish to hold, 0.18 times nominal output (25/141, a value found in all simulations). In version 1.1 it was 62.5: the difference was the hoarding by private owners, who do not exist in 1.2. There is no debt problem separate from the demand for money; the real risk is inflation when the fund issues more money than is desired (§15).

### 14.4 N-3 Local stability of the functional rule [N]

The one-period map (money, prices, fund revenue, demand, transfers) is linearised around the steady state. One eigenvalue is exactly 1: the price level has a unit root, i.e. after a shock inflation returns to zero but prices do not return to their initial level. All other eigenvalues are less than 1 in modulus for:

    [N] 0 ≤ λ < λ_max(κ): λ_max = 1.92 (κ = 0.25) ; 1.73 (κ = 0.5) ; 1.35 (κ = 1)

As in §6, an overly reactive regulator destabilises, and the more reactive prices are, the more prudent the fund must be. The simulations use λ = 0.5. The result is numerical, local and conditional on the parameters.

## 15. Prices, rationing and post-fusion shocks

With energy no longer a constraint, the stress test of the monetary model uses an aggregate capacity shock of −20% for five periods (10–14), interpretable as a failure of the materials supply chain or of the robot fleet. Basket and replacement (116) remain producible on the reduced capacity (124.1); discretionary consumption does not. Six fund rules are compared.

### 15.1 N-4 Six fund rules compared [N]

| Fund rule | Max inflation per period | Maximum prices | Final prices | Minimum real discretionary | Min. share of demand served |
|---|---|---|---|---|---|
| R0 balanced budget | 11.4% | 1.249 | 1.017 | 3.31 | 0.32 |
| R1 functional (λ = 0.5) | 6.3% | 1.158 | 1.068 | 1.79 | 0.66 |
| R1b anticipatory, reserve preserved | 2.3% | 1.109 | 1.109 | 1.51 | 1.00 |
| R1c anticipatory, reserve used | 4.6% | 1.249 | 1.249 | 8.08 | 1.00 |
| R2 fixed nominal dividend | 11.4% | 1.648 | 1.035 | 8.08 | 0.32 |
| R3 real promise financed with money | 13.1% | 2.043 | 2.043 | 8.08 | 0.28 |

*Table 5. Capacity shock of −20% for five periods, 60 simulated periods. R1b and R1c compute in advance the dividend that brings planned demand to the target: R1b maintains the capacity reserve even during the shock, R1c uses it (target = normal output, where possible). The share served is the ratio of discretionary consumption obtained to planned.*

![](figure/figura_3.png)

*Figure 3. Price level and real discretionary consumption under the six fund rules. Band: shock periods. Simulations, not forecasts.*

- Physical limit: during the shock discretionary consumption cannot exceed 8.08 units (124.1 of capacity minus 116 of basket and replacement) under any rule. It is a physical limit, not a monetary one.
- Money and scarcity: promising the same real consumption and financing it with money (R3) does not buy a single unit more than R2 (8.08), but doubles prices (+104%) permanently. This is the quantitative verification of §7.1.
- Reserve or prices: preserving the reserve (R1b) keeps peak inflation at 2.3% but leaves capacity unused (consumption 1.5 out of a possible 8.1); using it (R1c) delivers all possible consumption without queues (share served 1) with inflation of 4.6% per period and prices +25%. Neither dominates: the target during shocks is a parameter to be set by weighted vote.
- Effect of abolishing private ownership: compared with version 1.1, peak inflation under the anticipatory rule halves (4.6% → 2.3%): it was generated by the money stocks of private owners, which the fund did not control and which do not exist in 1.2. The residual inflation depends on citizens’ money and on the fact that basket and replacement exceed the normal utilisation of the reduced capacity.
- Passive rules: the rules that do not react to capacity (R0, R2, R3) ration through queues and forced saving (share served 0.28–0.32) and produce peak inflation of 11–13%.

### 15.2 N-5 Sectoral prices as a scarcity signal [N]

The basket b remains in kind; discretionary consumption is purchased at prices. When a sector is at its limit, its margin μⱼ becomes a scarcity rent, collected by the fund and returned as a dividend:

    p = (I − Aᵀ)⁻¹(d + μ) ;        μⱼ = μ̄ⱼ + rⱼ , rⱼ ≥ 0 such that xⱼ ≤ x̄ⱼ

Post-fusion experiment: base prices of §9.4 with a primary energy cost of 0.005; materials capacity −15%; discretionary demand with price elasticity 1.5; basket and replacement given priority.

| Sector | Post-fusion price | Price with materials scarcity | Change |
|---|---|---|---|
| Energy | 0.0824 | 0.2443 | +196.5% |
| Materials | 0.4931 | 2.5915 | +425.6% |
| Food | 0.5067 | 0.8658 | +70.9% |
| Services | 0.7389 | 0.9725 | +31.6% |
| Robots | 0.8825 | 1.4955 | +69.5% |

*Table 6. Sectoral prices with a scarcity rent on materials (equilibrium rent 1.88 per unit).*

Rationing through prices serves 57.6% of discretionary consumption, against 55.4% under proportional quantity rationing. It allocates slightly better because it shifts demand towards goods less intensive in materials (services). The cost is a materials price five times higher and a scarcity rent of 45.5 units at current prices: with private capital it would be an enormous transfer to owners; in TEPS 1.2 (wholly public capital) it goes to the fund by construction. Energy also triples in price, because its plants use materials, but it remains by far the cheapest good (0.24): the post-fusion premise holds even under the shock.

Lesson: with fixed-coefficient technology prices must do all the work through final demand alone, and they fluctuate widely. Moderate signals require technical substitutability between inputs, which is absent from matrix A: this is why test T4 remains partially open.

### 15.3 Rents on non-reproducible resources [P]

Land, sites, deposits, frequencies and urban locations are not produced by machines, and fusion does not multiply them. In 1.2 those in productive use belong to the fund. What remains is the rent of locations in personal use (a home in the city centre is worth more than one in the outskirts). Rule: a location charge equal to the market rent of the land, collected by the fund, in the spirit of Henry George [11]. In accounting terms it enters the fund’s revenue; in economic terms it prevents personal property from becoming a source of rent. For positional goods, which by definition cannot be multiplied, access must be regulated through auctions or rotation, not through the basket.

## 16. Capital with a coefficient matrix

Version 1.0 assumed that a unit produced by the robot sector became a unit of capacity in any sector (1:1 ratio). Version 1.1 introduces a capital matrix B, in the tradition of Leontief’s dynamic model [13]: Bᵢⱼ is the quantity of capital good from sector i required for one unit of capacity in sector j.

    Bᵢⱼ = κⱼ · sᵢ ;     s = (E 0 ; M 0.10 ; F 0 ; S 0.30 ; R 0.60)
    [A] steady-state replacement r = Δ B x̄ ;                 feasibility (I − A)⁻¹(b + q z + r) ≤ x̄

The vector s gives the composition of capital: machines (R) 60%, buildings and infrastructure (S) 30%, materials (M) 10%. κⱼ is the capital intensity per unit of capacity and Δ the diagonal matrix of depreciation rates. Post-fusion premise: energy capacity ×3 and energy plants that do not weigh on replacement (κ_E = 0), consistent with the assumption that energy is no longer a problem.

| Configuration | Annual replacement | Margin σ (b + replacement) | Maximum share q |
|---|---|---|---|
| v1.0 pre-fusion, 1:1 all robots | 24.0 | 1.155 | 1.00 |
| Fusion, 1:1 without energy capital | 19.7 | 1.324 | 1.00 |
| Matrix B, uniform intensity 1.0 | 19.7 | 1.321 | 0.97 |
| Uniform intensity 1.5 | 29.5 | 1.164 | 0.76 |
| Uniform intensity 2.0 | 39.3 | 1.023 | 0.17 |
| Uniform intensity 2.5 | 49.2 | 0.912 | not feasible |
| Sectoral (M 1.5; F 1.2; S 2.5; R 1.2), δ 10.2% | 32.0 | 1.124 | 0.70 |
| Sectoral, differentiated δ (M 5%, S 3%, R 10%) | 23.2 | 1.264 | 1.00 |
| Differentiated δ, uniform intensity 2.0 | 28.5 | 1.167 | 1.00 |
| Differentiated δ, uniform intensity 2.5 | 35.6 | 0.978 | not feasible |

*Table 7. Feasibility with a capital matrix; «not feasible» indicates that not even basket and replacement are producible (σ < 1).*

![](figure/figura_4.png)

*Figure 4. Maximum share of discretionary consumption as non-energy capital intensity increases. Bands: region in which the essential basket is not producible.*

Thresholds: with uniform depreciation the essential basket ceases to be producible beyond a capital intensity 2.09 times that of 1.0; with realistic useful lives the threshold rises to 2.44. If fusion plants had to be replaced like any other capital, the threshold would fall to 1.72: the «energy without problems» assumption is worth about 20% of margin on capital.

Interpretation: fusion shifts the constraint, it does not eliminate it. After fusion the bottleneck is non-energy physical capital (machines, buildings, materials). The model holds up if capital intensity per unit of capacity stays below about twice the assumed level and structures have long useful lives. The decisive technological parameter to be calibrated (T1–T2) is the productivity with which robots produce robots (row R of A and of B).

## 17. Incentives, personal property, monetary and weight rewards, fund risk

In version 1.2 the management of the fund is not entrusted to human bodies: people vote, with the weight of §11, only on parameters and rules; execution, evaluations and checks are carried out by public AIs with deterministic and public rules, and the systems that produce the agents are also public. Two consequences follow, formalised below: the discretionary rescue of projects (the classic source of the soft budget constraint) is excluded by construction, and manipulation has no channel if the evaluation data are produced by public systems. Two risks remain that do not depend on who governs: measurement noise and the estimation error common to the models.

    [P] Control architecture: several independent AIs decide separately; a deterministic process-control system applies the chain of public rules and blocks any action outside the mandate

With several independent AIs there is no single point of failure and no AI can prevail: an isolated deviation is outvoted by the aggregator (§12.2) and, in any case, the action goes through only if it complies with the deterministic control chain, which no AI can modify. The condition that makes this guarantee true is the effective independence of errors: models trained on common data or methods err together, and then the majority does not correct (D-6). Independence must therefore be treated as a measurable requirement: error correlation estimated on public test cases, with replacement of the models that exceed it.

### 17.1 D-10 Manipulation of metrics [D]

The innovator can inflate the verified value V̂ by an amount m (selected data, undue attribution). If the manipulation is discovered with probability π, by the panel or by the ex post audit, and in that case the innovator must repay k times the undue reward, the expected gain is:

    E[gain] = α m [(1 − π) − π k]

    [D] No incentive to manipulate ⇔ k ≥ (1 − π) / π

Proof. The gain is non-positive if and only if the term in brackets is, that is k ≥ (1 − π)/π. Q.E.D. Numbers: with π = 0.5 full repayment is needed (k ≥ 1); with π = 0.8 k ≥ 0.25 suffices; with π = 0.2 a fourfold penalty would be needed (k ≥ 4) [12].

    [A] Verification at source: the data on which V is measured are produced by public systems (sensors, ledgers, automatic accounting), not supplied by the innovator

Under this assumption manipulation has no channel: π → 1 and the condition becomes k ≥ 0, that is, manipulating does not pay for any value of k. This is the formalisation of the institutional choice of TEPS 1.2: public agents and public agent-production systems, deterministic verification. The assumption must be maintained in the design: where part of the evidence is still supplied by the proposer (prototypes, own experimental data), the reward must be deferred until V is confirmed by public data.

### 17.2 D-11 Noise rent of the max(0, ·) formula [D]

This is not a problem of manipulation but of measurement, and it holds even with perfectly honest public systems: the causal value of an idea is always estimated with an error. In §10.2 the reward is S = α max(0, V). If V is measured with error ε ~ N(0, σ²), even an idea of zero value receives on average:

    [D] E[α max(0, ε)] = α σ / √(2π) ≈ 0.399 α σ

With a threshold h = zσ (reward only on the part of V̂ above h) the noise rent becomes α σ [φ(z) − z(1 − Φ(z))], with φ and Φ the standard normal density and cumulative distribution function.

| Threshold z | Expected reward to a null idea | Expected reward to an idea with V = σ |
|---|---|---|
| 0 | 0.399 ασ | 1.083 ασ |
| 1 | 0.083 ασ | 0.399 ασ |
| 1.645 | 0.021 ασ | 0.157 ασ |
| 2 | 0.008 ασ | 0.083 ασ |

*Table 8. Effect of the threshold on the undue reward and on the reward to good ideas.*

The threshold reduces the noise rent but also the reward to good ideas. A threshold z = 1 eliminates 79% of the undue rent and preserves 37% of the reward to good ideas, which is offset by raising α. The alternative is to pay on the value realised ex post (deferred reward), which reduces σ.

### 17.3 N-7 Fund risk: staged financing and common estimation error [N]

With rule-based management the risk of the fund is not political but one of estimation: even public and honest AIs can overestimate in a coordinated way the probability of success of a class of projects, if they share data or methods (§12.2). The following test measures how much this matters if independence fails; with effective independence the “optimistic” case does not arise and only liquidity risk remains.

Model: each period the fund spends a budget B on projects of 0.5. Each project is “good” with probability 0.25 and, if good, succeeds with probability 0.8 (overall success 0.2); success returns 6 times the cost after 5 periods, as in §10.4. Initial reserve 20, replenishment 1 per period. “Ruin” means a negative reserve: the fund would have to cut the dividend or issue money. Lump-sum financing is compared with staged financing (a test at 20% of the cost, sensitivity 0.9, false positives 0.2). The evaluators can be correct or 30% optimistic, with an estimation error common to the whole panel; the correlation of outcomes is ρ = 0.5. 20,000 paths of 100 periods are simulated.

| Budget B per period | Lump sum, correct evaluators | Lump sum, 30% optimistic | Staged, correct | Staged, 30% optimistic |
|---|---|---|---|---|
| 2.5 | 0.02% | 4.1% | 0.0% | 0.0% |
| 5 | 49.3% | 91.0% | 0.0% | 0.03% |
| 10 | 100% | 100% | 55.4% | 69.3% |

*Table 9. Probability of ruin of the innovation reserve over 100 periods. Invented parameters, for illustration only.*

- Liquidity: even with a positive expected return (1.2), a budget equal to 5 times the replenishment ruins the reserve in half the cases. The problem is liquidity (delayed returns), not the expected value.
- Systematic error: an estimation error common to the whole panel (not a manipulation) turns a prudent budget into almost certain ruin (91%) if financing is lump-sum.
- Stages: staged financing is the most effective rule: with B = 5 it brings ruin from 49–91% to about 0%, because the test stops bad projects before the main expenditure. The correlation of outcomes has a secondary effect in this example (47% → 49%); the systematic error of the evaluators weighs much more.

    [P] Hard budget constraint: budget sized on reserve and payback times; mandatory stages; automatic stop at the declared threshold; rules modifiable only by weighted vote on parameters, never case by case

The “soft” budget constraint described by Kornai [9] arises from the discretionary rescue of projects in difficulty by human decision-makers. In TEPS 1.2 this channel is closed by construction: the AI executes the stop without discretion and the weighted vote acts only on the general rules. The residual risk is one of estimation, and the defence is staged financing.

### 17.4 D-12 Incentives and personal property [D]

In version 1.2 the only source of income besides the universal dividend (from 1.5 the civic income h̄ₜPᵢ,ₜ, §11.3) is the reward S for the value created by thought, creativity and initiative for the public good: it is the only channel through which personal property grows. Personal wealth Wᵢ (money and goods for personal use) evolves without any return, because money pays no interest and personal property cannot be employed in production:

    Wᵢ,ₜ₊₁ = Wᵢ,ₜ + h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ − Cᵢ,ₜ ,   Cᵢ,ₜ ≥ 0   (1.5: h̄ₜ Pᵢ,ₜ in place of Dₜ)
    [D] Wᵢ,T ≤ Wᵢ,₀ + Σₜ (h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ)

Proof. Summing the equation from 0 to T − 1 gives Wᵢ,T = Wᵢ,₀ + Σₜ(h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ) − Σₜ Cᵢ,ₜ, and consumption is non-negative. Q.E.D.

- Limited inequality: those who create more public value accumulate more personal property, but wealth does not generate further wealth. The term r·W, which in capitalist economies makes inequalities grow on their own, is missing: the gap between two people is at most the difference between the rewards received.
- Cost of incentives: with b = 92 the margin of 25 must be divided among civic income (dividend D up to 1.4), rewards S and new enterprises Iₙ (D-7). Every unit to rewards is one unit less to everyone’s civic income: the share of rewards is a weighted-vote parameter, and it decides how strong the incentive is.
- Strength of incentives: the reward is an incentive only if it buys something scarce: discretionary consumption and the best locations (§15.3). The broader the basket, the less the monetary reward counts, and the more the non-monetary levers count: recognition and access to the fund’s capital for new ideas.
- Inheritance: inheritance of personal property is the only channel through which wealth passes between generations without new value created; its regulation is a matter of vote.

### 17.5 D-13 Form of the reward: limited and social [D]

Two design choices of version 1.3. First, the reward does not grow in proportion to the value produced: it has a limit. The reward has two components, both capped: the monetary one (this section) and the one in weight on competences (§17.7). Second, the value that is rewarded is not only economic but includes the social benefit. The total public value of an idea is:

    Vᵗᵒᵗ = Vᵉᶜ + Σₖ ωₖ Iₖ

Vᵉᶜ is the additional net economic value (resources saved, consumption made possible). Iₖ are social indicators in physical units, measured by public systems: healthy life years gained, time freed, pollution avoided, access and inclusion, knowledge made public. ωₖ are the coefficients that convert each indicator into value. The Iₖ count only effects not already included in Vᵉᶜ (public goods and externalities), so as not to count the same benefit twice. A social harm enters with a negative sign: a very profitable but harmful idea can have Vᵗᵒᵗ ≤ 0 and no reward.

    [P] Algorithmic, non-arguable evaluation: Iₖ measured by public systems; ωₖ calculated by public models of conversion into a single common unit

The social benefit is not left to case-by-case judgements. Each indicator is converted, with public and deterministic models, into a single common physical unit: the time of healthy human life gained or freed. Time freed is counted directly; health in healthy life years; pollution avoided through dose-response models that estimate the effects on health; access to a service through the time and health it allows those previously excluded to gain. The coefficients ωₖ are therefore outputs of verifiable models, not voted weights. The only normative choice is the common unit itself, fixed once by equal vote (§11.1) at constitutional level; the conversion models are public, versioned and reproducible by anyone. Limitation to be declared: the conversion models have an uncertainty of their own, which adds to the measurement error of §17.2 and must be treated in the same way (threshold or deferred reward).

The reward is a concave and bounded function of the total public value:

    Sᵢ = S_max · [1 − exp(−max(0, Vᵢᵗᵒᵗ) / V₀)]

S_max is the maximum reward and V₀ the scale at which the reward reaches 63% of the maximum; both are voting parameters. Properties, each directly verifiable from the formula:

- Limit: 0 ≤ Sᵢ < S_max for every idea, however large.
- Always positive incentive: dS/dV = (S_max/V₀)·exp(−V/V₀) > 0: more public value always gives more reward, so the incentive never switches off (unlike a rigid cap, beyond which the marginal incentive is zero).
- Limited noise: the slope is at most S_max/V₀, so the noise rent of §17.2 is at most 0.399 σ S_max/V₀ and decreases as V₀ increases.
- Inequality with a known cap: with the bounded reward, D-12 becomes Wᵢ,T ≤ Wᵢ,₀ + Σₜ(h̄ₜ + S_max): the wealth gap between two people over T periods is at most T·S_max, regardless of the value created.
- Predictable budget: the maximum expenditure on rewards is known in advance (number of rewarded ideas × S_max), so it is planned on the margin of 25 of D-7.

### 17.6 N-8 Effect of the form of the reward [N]

Simulation on 100,000 ideas with heavy-tailed economic value (lognormal, like real innovation: few ideas are worth a great deal) and social benefit that is correlated but also negative in 31% of cases. The three forms of reward receive the same total budget.

| Form of the reward | Share of budget to the top 1% | Gini index of rewards | Maximum / median reward |
|---|---|---|---|
| Proportional to value | 22.6% | 0.74 | 846 |
| Rigid cap (95th percentile) | 5.4% | 0.64 | 13 |
| Concave bounded (§17.5) | 2.6% | 0.47 | 3.5 |

*Table 10. Concentration of rewards at equal budget. Illustrative parameters; V₀ at the 75th percentile of value.*

With the proportional reward 1% of ideas take almost a quarter of the budget and the maximum reward is 846 times the median one: it would rebuild large personal fortunes. The concave reward distributes the same budget over many more ideas (maximum 3.5 times the median), while maintaining an always positive marginal incentive.

| Idea | Economic value | Social benefit | Total public value | Reward (fraction of S_max) | Reward if only the economic value counted |
|---|---|---|---|---|---|
| A — profitable but harmful | 10 | −9 | 1 | 0.25 | 0.94 |
| B — barely profitable, very useful | 1 | +6 | 7 | 0.87 | 0.25 |
| C — high value on both | 50 | +10 | 60 | 1.00 | 1.00 |

*Table 11. Three example ideas with V₀ = 3.46. Also measuring the social benefit reverses the order between A and B.*

The limit has a cost to be declared: for ideas of enormous value the monetary reward hardly grows any more. TEPS compensates for this with non-monetary levers already present in the model: public recognition and priority access to the fund’s capital to develop subsequent ideas (§10.3).

### 17.7 D-14 Reward in weight on competences [D]

The reward is not only money. A recognised innovation demonstrates a capability that mastery tests (§11) do not measure: the ability to produce new and useful knowledge. In version 1.4 this capability enters the voting weight for technical decisions in the discipline in which the innovation was recognised. Effective competence combines verified mastery and recognised contributions:

    Cᵢ,ₖᵉᶠᶠ = min(1, Cᵢ,ₖ + ρ · Rᵢ,ₖ)
    Rᵢ,ₖ = min(R_max, Σⱼ (Sⱼ / S_max) · exp(−(t − tⱼ) / T_R))

Rᵢ,ₖ sums the rewards received for innovations in discipline k, normalised on the maximum reward and calculated by the same algorithmic systems of §17.5; ρ converts contributions into competence. The voting weight remains that of §11.1 with Cᵉᶠᶠ in place of C, so it never exceeds w_max. The term exp(−(t − tⱼ)/T_R) is a proposal of this version: the weight derived from an innovation decreases over time if it is not renewed by new contributions, so that recognition does not become a permanent rent of power. T_R, ρ and R_max are voting parameters.

- Access through innovation: those who have recognised innovations but do not pass the test threshold τ can be admitted to the technical vote, if ρ·R bridges the difference. This is consistent with §10.3: known knowledge is not the limit of inventions.
- Individual cap: Cᵉᶠᶠ ≤ 1 implies wᵢ ≤ w_max for every person, whatever the number of innovations.
- Scope: the weight applies only to technical decisions in discipline k; on matters that affect everyone the vote remains equal (§11.1), and no one votes on their own case (§11.2).

The cap has a demonstrable consequence: it limits the power of any group. Among those admitted to vote every weight is at least 1 and at most w_max. The worst case is that a fraction f of those admitted has weight w_max and all the others weight 1:

    [D] group's weight share ≤ f · w_max / [f · w_max + (1 − f)]

Proof. The group’s share increases with the weight of its members and decreases with that of the others; the maximum is reached with the members at w_max and the others at 1. Q.E.D.

| Maximum weight w_max | Top 1% of those admitted weighs at most | Top 10% of those admitted weighs at most |
|---|---|---|
| 2 | 2.0% | 18.2% |
| 3 | 2.9% | 25.0% |
| 5 | 4.8% | 35.7% |

*Table 12. Maximum share of the total voting weight held by a group, as a function of the cap w_max.*

With w_max = 3 even the most competent and innovative 10% remains in the minority (at most 25% of the weight): innovation gives voice, not control. For a group to reach a majority it would need f > 1/(1 + w_max), that is at least 25% of those admitted with w_max = 3.

### 17.8 D-15 Automatic widening of the voting base [D]

If too few people have weight, the base widens: the entry threshold τ falls automatically just enough to have at least N_min admitted. Ordering effective competence in decreasing order, C₍₁₎ ≥ C₍₂₎ ≥ …, the threshold applied to decision q is:

    [D] τ*(q) = min( τ₀(q), C₍N_min₎ )

τ₀ is the ordinary threshold of the decision and C₍N_min₎ the competence of the person in position N_min. In the weight calculation (§11.1) τ\* replaces τ. The rule is deterministic and public, like the others.

- Guaranteed minimum base: those admitted are always at least N_min, if the population contains them; a technical decision is never left without voters (the case excluded in §11.1 no longer arises).
- Minimal lowering: if those admitted with τ₀ are already N_min or more, τ\* = τ₀ and nothing changes; otherwise the threshold falls only to the competence of the N_min-th person, that is the indispensable minimum.
- No dominant individual weight: with at least N_min admitted and weights between 1 and w_max, a single person holds at most w_max / (w_max + N_min − 1) of the total weight.

Proof. If N(τ₀) ≥ N_min, then C₍N_min₎ ≥ τ₀ and τ\* = τ₀. Otherwise τ\* = C₍N_min₎ < τ₀ and exactly the first N_min are admitted (plus any ties), that is the minimum number with the highest possible threshold. The individual limit follows from D-14 with one member at w_max and the other N_min − 1 at weight 1. Q.E.D.

Example: with w_max = 3 and N_min = 101, no person exceeds 2.9% of the weight; with N_min = 1,001, 0.3%. N_min is a voting parameter: the higher it is, the broader the decision, but the lower the minimum competence required.

Note 1.5: the guarantees D-14 and D-15 apply to votes cast, not only to those admitted. If the votes cast (abstentions excluded) are fewer than N_min, the vote is automatically extended to the next in the ranking of Cᵉᶠᶠ until the votes cast reach N_min; the new summonses enter the Nᵒᶠ of those summoned (§11.3).

**Integration 1.5 — §17.9 wealth and incentives**

### 17.9 D-12 and D-13 with civic income [D]

With civic income the personal wealth equation becomes:

    Wᵢ,ₜ₊₁ = Wᵢ,ₜ + h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ − Cᵢ,ₜ
    [D] Wᵢ,T ≤ Wᵢ,₀ + Σₜ (h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ) ≤ Wᵢ,₀ + Σₜ (h̄ₜ + S_max)

The proof is that of D-12, with h̄ₜPᵢ,ₜ in place of Dₜ. The wealth gap between two people over T periods remains bounded: at most Σₜ h̄ₜ \|Pᵢ,ₜ − Pⱼ,ₜ\| + T·S_max. Participation adds an income difference that depends only on the behaviour of the citizen themselves; wealth still generates no return. Rewards S for economic and social value remain additional, concave and bounded (§17.5); the weight on competences (§17.7) does not depend on Pᵢ,ₜ.

## 18. Does the model hold up? Economic assessment

On the logical-accounting level TEPS is conceivable: real goods and capital can be produced without necessary wages and a collective fund can finance replacement and new enterprises. But an accounting condition or a simulation calibrated on arbitrary assumptions is not enough to prove that this order works better or is stable in the real economy.

| Question | Answer in version 1.4 | Proof still missing |
|---|---|---|
| Can there be production without human labour? | Yes in the model; with fusion energy is not binding (§8, §16) | Technical feasibility of full automation |
| Can demand be sustained without wages? | Yes, with the functional rule of the fund (D-8, N-3); with balanced budget alone and rigid prices, no (utilisation 0.84) | Calibration of the propensities α and β |
| Is the fund self-financing? | Yes, by construction: without private productive property Π = 117 ≥ pb + S + pIₙ, margin 25 (D-7) | Allocation of the margin among civic income, rewards and new enterprises |
| Who governs the fund? | No direct human body: weighted vote on parameters and rules, execution by public AIs (§1.1, §17) | Validation of competence-based governance |
| Where does personal wealth come from? | Only from rewards and civic income (1.5); without returns wealth does not feed itself (D-12) | Calibration of the share of rewards on the margin of 25 |
| What does the reward reward? | Economic value plus social benefit, with a concave and bounded reward: always positive incentive, inequality at most T·S_max (D-13, N-8) | Validation of the conversion models into the common unit |
| Is the reward only money? | No: also weight in the technical decisions of the discipline, with cap w_max; no group below 25% of those admitted can have a majority with w_max = 3 (D-14) | Experiments on the quality of weighted decisions |
| Is money stable? | The fund’s debt converges to the desired money, 25 (D-9); inflation arises from physical shocks and from real promises financed with money (N-4) | Open economy, foreign trade |
| Can prices ration discretionary consumption? | Yes, with rent to the fund; they allocate better than proportional rationing but are very volatile (N-5) | Technical substitutability between inputs |
| Can capital be preserved? | Yes if the non-energy capital intensity stays below 2.1–2.4 times the assumed one (N-6) | Calibration of B and of useful lives |
| Does the fund finance innovation without excessive risk? | Yes with staged financing and automatic stop; no with a common estimation error and lump-sum financing (N-7) | Data on real portfolios |
| Are more AIs necessarily more reliable? | Not manipulable if public and with verification at source (D-10); accuracy still depends on error and correlation (D-6, N-7) | Independent validation of estimates |
| Does competence-based voting improve decisions? | Not proven | Comparative experiments in well-defined contexts |
| Does fusion make energy a non-problem? | Baseline assumption since 1.1; energy remains the cheapest good even in material shocks (N-5) | Full costs of the industrial cycle |

### 18.1 Criteria of joint sustainability

    For every t and every admissible shock ω:
    (I − Aₜ)⁻¹(bₜ + iₜ) ≤ x̄ (Kₜ,ω)
    Kₜ₊₁ ≥ K_min ; Fₜ₊₁ ≥ F_min ; bₜ guaranteed
    Governance ∈ public rules; harm to fundamental rights excluded

To demonstrate a robust form of stability one would need to identify a set of safe states Ω and a control policy π such that, starting from any state in Ω and for every admissible shock, the next state remains in Ω. This means keeping the state within a safe set through control, to be proven on a model that is still incomplete today.

### 18.2 What must not be confused

- Replacing productive wages does not mean eliminating all human compensation: the innovator receives incremental incentives.
- Financing the enterprise with a public fund does not make building the enterprise free: capital, machines and materials are real resources.
- The managerial autonomy of AI does not authorise the elimination of verification, the right of appeal or safety stops.
- A technical vote weighted by knowledge does not automatically demonstrate the scientific validity of the winning opinion.
- Very cheap fusion does not abolish all scarcity, especially materials, robots, industrial sites and repair capacity.

### 18.3 Verdict (version 1.4, updated to 1.5): does the economic model hold up?

Yes, under explicit conditions. With fusion as the baseline assumption, productive capital entirely public, rule-based management under weighted vote and the stock-flow consistent block closed, TEPS is a coherent economy: every flow has a counterpart, the fund is self-financing, money has an anchor and capital is renewed. The conditions are eight, all verifiable (C7 and C8 from 1.5):

- C1 Closure of the fund: Π ≥ pb + S + pIₙ. Satisfied by construction with φ = 1 (margin 25); the basket absorbs 79% of the distributable surplus.
- C2 Nominal anchor: functional rule for the transfer to citizens (civic income from 1.5) with 0 < λ < λ_max (about 1.7), or a forward-looking rule; the target in shocks (reserve or prices) is a voting parameter. A balanced budget is not enough if prices are rigid downwards.
- C3 Physical margin: σ ≥ 1 under every admissible shock. After fusion the constraint is non-energy capital, with intensity below about twice the assumed one.
- C4 No real promise financed with money: in shocks discretionary consumption is reduced by public decision; printing its equivalent value produces only inflation (prices doubled in the test).
- C5 Public rents: sectoral scarcity rents to the fund; location charge on land for personal use.
- C6 Compatible incentives: verification at source by public systems (π → 1), reward with threshold or deferred against measurement noise, staged financing with automatic stop; multiple AIs with independent (measured) errors under a deterministic control chain; rewards are the only source of accumulation of personal property (D-12), bounded and calculated on economic value plus algorithmically measured social benefit (D-13); the reward is also weight on competences, with a cap that limits the power of any group (D-14) and a voting base that widens by itself if too few are admitted (D-15).
- C7 Participation (1.5): civic income h̄ₜPᵢ,ₜ proportional to the votes cast out of those offered; unearned shares to the fund for new enterprises, spent within physical capacity and with staged financing (D-16, N-9); in-kind basket never conditional; secret ballot with participation verified separately from content (§11.3).
- C8 Public-only money (1.5): no private banks and no interest-bearing loans; accounts, payments and issuance on a deterministic public ledger computed by independent systems (D-17–D-21).

Still unproven are full automation itself, calibration on real data (A, B, propensities), global stability (the proofs are local or numerical), the open economy and the superiority of competence-based governance. These are empirical and political limitations, not internal inconsistencies: in version 1.4 no logical or accounting contradiction was found in the economic model. In 1.5 the participation rule keeps the fund balanced in steady state (D-16); the dynamics over 30 periods are simulated in N-10 (§19.3). Money without private banks is demonstrated in D-17–D-21.

In substance, TEPS 1.2 is an economy with entirely public productive capital, an in-kind basket, civic income proportional to participation (universal dividend up to 1.4), prices for discretionary consumption and public-only money, without private banks (§13.7), managed by automatic rules under weighted vote, in which the only source of personal wealth is the public value, economic and social, created by ideas, rewarded within a limit in money and in weight on technical decisions. Compared with Roemer’s market socialism [10], private shares in enterprises are absent; compared with central planning, preferences on discretionary consumption pass through prices and initiative remains with the innovators.

**Integration 1.5 — §18.4 Sustainability with the participation rule**

### 18.4 Condition C7 and open questions from 1.5

| Question | Answer in version 1.5 | Proof still missing |
|---|---|---|
| Does income proportional to participation reduce demand? | Not in steady state, if the unearned shares finance new enterprises (D-16); below P̄ = 0.87 conversion is limited by robots (N-9); dynamically a fall in P̄ gives a recession of 3–6 periods (N-10) | Long horizons and matrix B (T9); 30-period dynamics in N-10 |
| Does the paid vote remain free and secret? | Yes by construction: participation register separate from the ballot box, anonymous credentials (§11.3) | Cryptographic verification and audit of the voting system |
| Does paying for abstention hollow out decisions? | No: abstention counts for income but not for the outcome; N_min applies to votes cast (§17.8) | Data on the share of abstentions |

Condition C7 (§18.3) is added to C1–C6; C8, public-only money, is demonstrated in §14.7–14.11. With full participation (P̄ = 1) TEPS 1.5 coincides with 1.4; for P̄ < 1 the available proofs are D-16, N-9 and N-10. The local or numerical checks of 1.4 must not be read as a general proof of the dynamics with variable participation.

## 19. Limits and verification programme

| Phase | Objective | Status in version 1.4 |
|---|---|---|
| T1 — Production | Calibrate the sectoral matrix with real data | Open |
| T2 — Capital | Robots, energy, networks and repairs | Partially closed: matrix B and intensity thresholds (§16); calibration open |
| T3 — Money | Stock-flow consistent model | Closed at the theoretical level (§13–14): zero-sum matrices, D-7–D-9, N-3; with φ = 1 the fund closes by construction |
| T4 — Market | Endogenous demand, prices and rationing | Partially closed: endogenous prices, scarcity rents, fund rules (§15); substitutability between inputs still missing |
| T5 — Innovation | Project portfolios with trials | Partially closed: D-10–D-15, N-7, N-8 (§17); real data and the measurement of social indicators still missing |
| T6 — Competences | Fair and multidisciplinary examinations | Open |
| T7 — AI panel | Correlated errors and manipulation | Open; linked to incentives through π (D-10) |
| T8 — Policies | Comparison between scenarios and organisations | Open |
| T9 — Participation | Civic income, unearned shares, demand (1.5) | Partially closed: D-16, N-9, N-10 (§19.2–19.3) |
| T10 — Public bank | Deterministic ledger, payments, money (1.5) | Closed at the theoretical level: D-17–D-21; test of a real ledger still missing |

### 19.1 Summary register of proofs

| Code | Result | Scope |
|---|---|---|
| D-1 | x\* = (I − A)⁻¹ f; feasibility condition x\* ≤ x̄ | True in the linear model, with ρ(A) < 1 |
| D-2 | Y\* = I/[1 − m(θ)] and range 68.85–78.79% | True under the aggregate-demand assumptions |
| D-3 | 0 < η < (1 − m\*)/(cₕ − cₚ) | Local stability of the regulator, under stated assumptions |
| D-4 | ρ[(1−γ)I+γA] < 1 | Convergence of linear production |
| D-5 | VA = Σ final demand = 141 | Identity at the unit prices of the example |
| D-6 | Pr[majority error] = 5.792% | Only with independent Bernoulli errors |
| N-1 | Energy shock −25% for 5 years: stop in year 23 | Hypothetical sectoral simulation only |
| N-2 | Robust allocation maintains replacement in the tests indicated | Admissible scenarios and simplified technology only |
| D-7 | Π ≥ pb + S + pIₙ; with φ = 1 margin 25 (with φ = 0.75 a charge of 78.6% would be needed) | Steady state of the SFC block |
| D-8 | With the fund in balance M is constant: the level of demand depends on M and p | With rigid prices ⇒ underutilisation |
| D-9 | A\* = (1−α₁)/α₂ H\* = 25 | Steady state |
| D-10 | No manipulation ⇔ k ≥ (1 − π)/π; with verification at source π → 1 | Risk-neutral innovator |
| D-11 | Noise rent ασ/√(2π); with threshold ασ[φ(z) − z(1 − Φ(z))] | Normal measurement error |
| D-12 | Wᵢ,T ≤ Wᵢ,₀ + Σ(D + Sᵢ): personal property grows only through rewards | No return on personal wealth |
| D-13 | Bounded concave reward: 0 ≤ S < S_max, dS/dV > 0, wealth gap ≤ T·S_max | Public value = economic + social |
| D-14 | Capped weight: share of a group ≤ f·w_max/[f·w_max + (1 − f)] | Weights between 1 and w_max among those admitted |
| D-15 | τ\* = min(τ₀, C₍N_min₎): at least N_min admitted; individual weight ≤ w_max/(w_max + N_min − 1) | Deterministic widening rule |
| N-3 | Functional rule stable for 0 ≤ λ < 1.73 (κ = 0.5) | Numerical and local; prices with a unit root |
| N-4 | Real promise met with money: prices +104%, no additional consumption; inflation 2.3% with the reserve kept or 4.6% with the reserve used | Shock −20% for 5 periods |
| N-5 | Scarcity prices: share served 0.576 versus 0.554; materials +426% | Materials −15%, elasticity 1.5 |
| N-6 | Capital-intensity thresholds 2.09 and 2.44 (1.72 with energy capital) | Hypothetical matrix B |
| N-7 | Staged financing: ruin from 49% to about 0% (B = 5) | Illustrative parameters |
| N-8 | For the same budget, share going to the top 1%: 22.6% proportional, 2.6% concave | Illustrative lognormal values |

**Integration 1.5 — §19.2 T9 verification programme and 1.5 register**

### 19.2 Programme T9 — Participation

- T9.1 (closed): P̄ = 1 reproduces the 1.4 scenario (D-16 with P̄ = 1).
- T9.2 (partially closed): P̄ = 0.9; 0.75; 0.5 in steady state (D-16) and physical feasibility with matrix A (N-9); to be repeated with the capital matrix B.
- T9.3 (partially closed): participation varying over time, response of R1, transition of the money stock, inflation: simulation N-10 over 30 periods; long horizons and matrix B remain open.
- T9.4 (open): test of the calculation rules: with recognised impediments or Nᵒᶠ = 0 no deduction.
- T9.5 (partially closed): effect of new-enterprise capital on replacement, capacity and margin C1: scenarios with full, 20% and zero success in N-10; calibration of the real return of new enterprises still missing.
- T9.6 (open): share of abstentions, quality of weighted decisions, security of the participation ledger.

### 19.3 N-10 Dynamics with variable participation [N]

Since without participation there is no monetary income, expected participation is close to 1 and in practice TEPS 1.5 coincides with 1.4; the scenarios with low P̄ are limiting cases. Simulation of the stock-flow block of §13.4 with rule R1 (λ = 0.5, κ = 0.5) and civic income h̄ₜPᵢ,ₜ; unearned shares go into the reserve Fᴵ and are spent on new enterprises within the physical limit of N-9 (cap F̄ᴵ = 20, excess returned with civic income). Full participation up to period 9, then the scenario indicated; 30 periods after the change. The original script `teps_sfc.py` is not in the repository: the equations are reconstructed from the text and the reconstruction is verified on 1.4 (with P̄ = 1 the steady state remains unchanged; scenario S8 recovers row R1 of Table 5: maximum inflation 6.3%, final prices 1.068, minimum discretionary consumption 1.79). Code: `simulazioni/teps_1_5_partecipazione.py`.

| Scenario | Max infl. per per. | Max defl. per per. | Prices t = 40 | Minimum utilisation | Minimum discr. | Periods to return to 25 | Discr. t = 40 | Capital t = 40 |
|---|---|---|---|---|---|---|---|---|
| S0 P̄ = 1 (1.4 reference) | 0.00% | 0.00% | 1.000 | 0.909 | 25.00 | — | 25.0 | 234.9 |
| S1 P̄ = 0.90 | 0.08% | 1.26% | 0.809 | 0.884 | 22.75 | 3 | 75.0 | 355.5 |
| S2 P̄ = 0.75 | 0.00% | 1.76% | 0.768 | 0.874 | 19.38 | 6 | 78.1 | 357.8 |
| S3 P̄ = 0.50 | 0.00% | 3.25% | 0.727 | 0.844 | 13.71 | 4 | 78.1 | 360.6 |
| S4 random P̄ 0.70–1.00 | 0.25% | 2.87% | 0.784 | 0.852 | 20.37 | 3 | 79.5 | 343.9 |
| S5 P̄ = 0.90, rigid prices | 0.08% | 0.00% | 1.001 | 0.867 | 22.75 | 3 | 71.2 | 359.3 |
| S6 P̄ = 0.90, 20% succeed | 0.08% | 0.12% | 0.981 | 0.907 | 22.75 | 12 | 29.9 | 252.8 |
| S7 P̄ = 0.90, none succeed | 0.08% | 0.00% | 1.008 | 0.909 | 22.51 | never | 22.5 | 234.9 |
| S8 shock −20%, P̄ = 1 | 6.25% | 4.20% | 1.070 | 0.825 | 1.79 | — | 24.9 | 234.9 |
| S9 shock −20%, P̄ = 0.90 | 5.85% | 3.88% | 0.915 | 0.832 | 1.73 | — | 60.9 | 331.4 |
| S10 P̄ = 0.90, idle shares | 0.00% | 0.84% | 0.780 | 0.892 | 22.41 | never | 22.4 | 234.9 |

*Table 14. Periods 10–40. “20% succeed”: only 20% of new-enterprise capital becomes productive capacity (probability of success of §10.4); the rest is lost. “Idle shares”: comparison with unearned shares retained by the fund without being spent. Shock −20% in periods 10–14 as in Table 5. In all simulations citizens’ money coincides with the advances to the fund (Mₕ = A) with a maximum discrepancy of 10⁻¹³.*

![](figure/figura_5_en.png)

*Figure 5. Price level and real discretionary consumption with average participation reduced from period 10 (S0–S3) and with unearned shares retained in the fund without being spent (S10). Band: periods after the change. Simulations, not forecasts.*

- Inflation: participation does not generate inflation. Without shocks maximum inflation is 0.25% per period, even with random participation; with the −20% shock, 90% participation gives a slightly lower peak inflation than 1.4 (5.85% versus 6.25%).
- Sudden fall in participation: it is a short recession. Discretionary consumption falls almost proportionally (down to 13.7 with P̄ = 0.50) because conversion into capital is limited by robots (N-9). It returns to 25 in 3–6 periods, when the reserve reaches the cap F̄ᴵ, the excess flows back into civic income and R1 restores demand. The cap F̄ᴵ is the parameter that determines the length of the recession.
- Prevailing risk: deflation, not inflation. New enterprises increase capacity faster than R1 increases demand: utilisation between 0.84 and 0.88 and prices falling by up to 1.3–3.3% per period. With prices rigid downwards (S5) deflation disappears but minimum utilisation falls to 0.867. A larger λ, within the stability limit of N-3, would reduce the lag.
- Destination B versus idle shares: with shares retained without being spent (S10) consumption remains steadily at 22.4, capacity remains unused (0.892) and prices fall without end (−22% in 30 periods). Allocation to new enterprises is never worse: even when no enterprise succeeds (S7) it gives the same consumption with stable prices and normal utilisation.
- Real cost if enterprises fail: with S7 discretionary consumption remains at 22.5 instead of 25. The resources of the unearned shares are spent on projects that do not produce: this is the real cost of the rule when investments yield no return, and it is covered by staged financing (§17.3).
- Growth if enterprises succeed: with full success (S1–S4) capital grows by about 50% in 30 periods and discretionary consumption triples. The result depends on the 1.4 assumption that new capital is as productive as existing capital (v = 1.51, δ = 10.2%), with a net return of about 0.5 per unit and per period: it should be read as an upper bound. The scenario with 20% success (S6) is more prudent: consumption returns to 25 after 12 periods and rises to 29.9.
- Limits: aggregate model with a fixed composition of consumption (b and z unchanged), 1:1 conversion of capital, horizon of 30 periods. Over longer horizons growth takes consumption far from the composition of the model, and the matrix B and an endogenous sectoral demand are needed.

Register of proofs 1.5

| Code | Result | Scope |
|---|---|---|
| D-16 | With Iₙ = Q: Y = 141, Π = 117, ΔA = 0, A\* = 25 P̄ for every P̄ | Steady state, S = 0, Iₓ = 0 |
| N-9 | Q convertible into capital in the same period if P̄ ≥ 0.871 | Matrix A, capacities §4.2, 1:1 convention |
| N-10 | No inflation from participation (≤ 0.25%); fall in P̄: recession of 3–6 periods; prevailing risk deflation | SFC reconstruction verified on 1.4, 30 periods, fixed composition |
| D-17 | Σⱼ mⱼ = 0; money = debt of the fund, M = A, in every period | Ledger of the BPA (§13.7) |
| D-18 | Execution of a payment independent of the other accounts: no bank runs | Coverage 1, no fractional reserve |
| D-19 | Wrong state accepted ≤ Σ_{j>n/2} C(n,j) qʲ(1−q)ⁿ⁻ʲ (9.9·10⁻⁶ with n = 5, q = 0.01) | Independent failures of the replicated systems |
| D-20 | Loan at interest r > 0 incompatible with the limit of D-12 | Positive initial wealth |
| D-21 | Monetary system without private banks: (a)–(e) of §14.11 | (c) local and numerical (N-3) |

**General conclusion.** With fusion as the baseline assumption, productive capital entirely public, management by rules under weighted vote and the stock-flow consistent block, TEPS 1.5 is an internally coherent economic model: all flows have a counterpart, the fund is self-financing under conditions C1–C8 (§18.3) and the monetary, physical and incentive subsystems are closed and numerically verified; the participation rule of 1.5 is verified in steady state (D-16, N-9) and dynamically over 30 periods (N-10); money, without private banks, always coincides with the debt of the fund and is managed by a deterministic public ledger (D-17–D-21). Global stability, empirical calibration and the superiority of competence-based governance and of management entrusted to AI remain unproven.

## 20. Glossary, parameters and references

### 20.1 Essential symbols

| Symbol | Meaning |
|---|---|
| A, x, f | Input matrix, gross output, sectoral final demand |
| b, z, q | Essential basket, full discretionary consumption, share delivered |
| K, δ, I | Productive capital, depreciation, new investment/replacement |
| θ, φ | Share of income distributed, share of collective ownership |
| σ, ρ | Index of the most binding sector, spectral radius |
| F, CF | Productive financial fund, operating cash flow |
| Cᵢ,ₖ, wᵢ | Certified competence in the subject and voting weight |
| Oₐ, G | Judgement of an isolated AI agent, predetermined aggregator |
| H, A, M | Transfers to citizens; advances to the fund; money in circulation |
| λ, κ, ū | Responsiveness of the functional rule; responsiveness of prices; normal utilisation |
| B, κⱼ, s | Capital matrix; capital intensity by sector; composition of capital goods |
| π, k | Probability of detecting manipulation; restitution multiple |
| Wᵢ | Personal wealth: from 1.2 the only form of private property |
| Vᵗᵒᵗ, Iₖ, ωₖ | Total public value; social indicators in physical units; conversion coefficients into the common unit (healthy life time), calculated by public models |
| S_max, V₀ | Maximum reward; saturation scale of the reward |
| τ₀, τ\*, N_min | Ordinary competence threshold; threshold applied after widening; minimum number of those admitted |
| Rᵢ,ₖ, ρ, T_R | Recognised innovative contributions in discipline k; their conversion into competence; decay time |
| Nᵒᶠᵢ,ₜ, Nᵉˢᵢ,ₜ, Pᵢ,ₜ | (1.5) Votes offered; votes cast; participation share Nᵉˢ/Nᵒᶠ |
| h̄ₜ, Hᶜᵢ,ₜ, Qₜ, Fᴵ | (1.5) Full civic income; accrued civic income h̄ₜPᵢ,ₜ; unearned shares; new-enterprise reserve |
| N_max, n_min, F̄ᴵ | (1.5) Cap on convocations per period; minimum number of convocations for calculating P; cap on the new-enterprise reserve |
| mⱼ, m_f, Φ | (1.5) Balance of account j in the automated public bank; balance of the fund (= −M); deterministic ledger update function |
| n, q | (1.5) Number of systems computing the ledger; failure probability of a system |

### 20.2 Sources and reference texts

[1] Acemoglu, D. and Restrepo, P. (2018), “Modeling Automation”, AEA Papers and Proceedings. https://www.aeaweb.org/articles?id=10.1257%2Fpandp.20181020

[2] Acemoglu, D. and Restrepo, P. (2019), “Automation and New Tasks”, Journal of Economic Perspectives. https://www.nber.org/papers/w25684

[3] Godley, W. and Lavoie, M. (2007), Monetary Economics, Palgrave Macmillan. https://doi.org/10.1057/9780230626546

[4] Leontief, W. — input-output structure and productivity condition; the identities used in the text are standard derivations of fixed-coefficient modelling.

[5] Senato della Repubblica, Costituzione italiana, article 48. https://www.senato.it/istituzione/la-costituzione/parte-i/titolo-iv/articolo-48

[6] Commissione europea, AI Act, article 14 — human oversight for high-risk systems. https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-14

[7] NIST (2023), AI Risk Management Framework 1.0. https://doi.org/10.6028/NIST.AI.100-1

[8] Lerner, A. P. (1943), “Functional Finance and the Federal Debt”, Social Research, 10(1).

[9] Kornai, J. (1986), “The Soft Budget Constraint”, Kyklos, 39(1).

[10] Roemer, J. E. (1994), A Future for Socialism, Harvard University Press.

[11] George, H. (1879), Progress and Poverty.

[12] Becker, G. S. (1968), “Crime and Punishment: An Economic Approach”, Journal of Political Economy, 76(2).

[13] Leontief, W. (1953), Studies in the Structure of the American Economy, Oxford University Press (dynamic model with capital matrix).

### 20.3 Provenance of the numerical results

The [N] results were rechecked against the TEPS 0.4, 0.5 and 0.6 simulation code developed in the course of building the model. They are scenario values without calibration on national macroeconomic data. Optimisation was carried out with linear programming and the verification of the matrices with numerical computation.

The results of versions 1.1–1.4 (§13–17, D-7–D-15, N-3–N-8) are reproduced by the script `teps_sfc.py` accompanying the document (Python with NumPy and SciPy, fixed seeds). Consistency check: in every period of every simulation money plus the net position of the fund is zero, with a maximum discrepancy of 3·10⁻¹³. The script is parametrised: φ = 0.75 reproduces the numbers of version 1.1, φ = 1 those of 1.2.

Consolidation date: 13 October 2026 (versions 1.1–1.4 on the same date). Revision 1.5: 30 October 2026, updated 2 November 2026; the N-9 values are calculated with matrix A and the capacities of §4.2, the N-10 values with the script `simulazioni/teps_1_5_partecipazione.py` (NumPy), which reconstructs the stock-flow block of §13.4 and verifies its 1.4 results before simulating. The checks of the automated public bank (D-17–D-19) are in the script `simulazioni/teps_1_5_banca_pubblica.py`. The document summarises the model as discussed and specifies the boundaries between governance postulates, mathematical derivations and illustrative simulations.

## Appendix A — Why collective ownership must be protected

A result that already emerged in the early stages of the model concerns the dilution of ownership: if new machines are assigned to those who finance replacement, and holders of private capital save proportionally more, the collective share can shrink even without explicit sales of holdings.

Let φₜ be the share of collective ownership, sₕ the saving rate of the beneficiary group and sₚ the private saving rate. With constant aggregate capital, uniform depreciation δ and replacement financed in proportion to savings:

    φₜ₊₁ = (1 − δ)φₜ + δ [sₕ φₜ/(sₕ φₜ + sₚ(1 − φₜ))]

For 0 < φₜ < 1 and sₕ < sₚ, the share of new capital acquired by the collective group is less than φₜ; therefore φₜ₊₁ < φₜ.

Proof: sₕ φ/[sₕ φ + sₚ(1−φ)] < φ is equivalent to sₕ < sₕφ+sₚ(1−φ), i.e. (sₚ−sₕ)(1−φ)>0. Q.E.D.

Example: φ₀ = 0.75, sₕ = 0.10, sₚ = 0.70 and δ = 0.10. Savings finance 30% of the new capital in the collective group:

    φ₁ = 0.90 × 0.75 + 0.10 × 0.30 = 0.705.

In TEPS with a public fund, this dilution is not necessary: replacement can be set aside before dividends and ownership of collective capital maintained by law. However, the financial accounts of the whole system still remain to be closed.

In version 1.2 the problem is solved at the root: productive private property does not exist (φ = 1), so there is nothing to dilute; personal savings remain money or goods for personal use and yield no return (§17.4). The financial accounts of the whole system are closed in §13–14.

## Appendix B — Version 1.5 (30 October 2026, updated 2 November 2026)

Source: 30-page TEPS 1.4 PDF of 13 October 2026, kept in `archivio/TEPS_1_4_Modello_Economico_Consolidato.pdf` and in text form in `archivio/TEPS_1_4_estrazione_testuale.txt`; figures 1–4 are those of the original. In this edition the 1.4 passages incompatible with 1.5 are corrected directly in the text (dividend → civic income, wealth D-12, conditions C1–C8, conclusion); the new parts are in the “INTEGRATION 1.5” blocks.

Changes in version 1.5:

1. Civic income Hᶜᵢ,ₜ = h̄ₜ Pᵢ,ₜ, with Pᵢ,ₜ = votes cast / votes offered; the content of the vote does not count (§11.3).
2. Unearned shares go to the fund to finance new enterprises (§13.6); neutrality of demand in steady state (D-16) and physical limit of the conversion into capital (N-9).
3. Abstention: it counts for income, not for the outcome; minimum voting base on the votes expressed (§11.1, §17.8).
4. Secrecy: participation ledger separate from the ballot box, single-use anonymous credentials (§11.3).
5. Cap on convocations per period and minimum number of convocations for calculating P; recognised impediments without deduction (§11.3).
6. Personal wealth with civic income (§17.9); condition C7 (§18.3–18.4); verification programme T9 (§19.2).
7. Dynamic simulation with variable participation (N-10, §19.3, Figure 5), scripts `simulazioni/teps_1_5_partecipazione.py` and `simulazioni/teps_1_5_figura_n10.py`.
8. No private banks: automated public bank (§13.7), proofs D-17–D-21 (§14.7–14.11), condition C8, script `simulazioni/teps_1_5_banca_pubblica.py`.
