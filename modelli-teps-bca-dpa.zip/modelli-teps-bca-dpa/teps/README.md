# TEPS — Teoria dell'Equilibrio Economico Post-Salariale

Repository per il modello economico TEPS e le successive revisioni.

## Struttura della cartella

| Cartella / file | Contenuto |
|---|---|
| [`pdf/`](pdf/) | **Documenti finali in PDF**: [TEPS_1_5_IT.pdf](pdf/TEPS_1_5_IT.pdf) (italiano, 42 pagine) e [TEPS_1_5_EN.pdf](pdf/TEPS_1_5_EN.pdf) (English, 42 pages) |
| [`word/`](word/) | Gli stessi documenti in Word: [TEPS_1_5_IT.docx](word/TEPS_1_5_IT.docx), [TEPS_1_5_EN.docx](word/TEPS_1_5_EN.docx) |
| [`TEPS_1_5_Modello_Economico_Integrato.md`](TEPS_1_5_Modello_Economico_Integrato.md) | Testo sorgente italiano della 1.5 (testo completo della 1.4 con le revisioni 1.5) |
| [`TEPS_1_5_Economic_Model_EN.md`](TEPS_1_5_Economic_Model_EN.md) | English source text |
| [`figure/`](figure/) | Figure 1–4 originali della 1.4 (scritte in italiano anche nella versione inglese) e Figura 5 nuova (`figura_5.png`, `figura_5_en.png`) |
| [`simulazioni/`](simulazioni/) | Script Python: partecipazione variabile (N-10), banca pubblica automatica (D-17–D-19), Figura 5 |
| [`ZENODO.md`](ZENODO.md) | Titolo, descrizione e parole chiave per Zenodo |

I documenti si rigenerano con `bash strumenti/genera_documenti.sh` dalla radice del repository. Gli script delle simulazioni si lanciano dalla cartella `teps/`, per esempio `python3 simulazioni/teps_1_5_partecipazione.py`.

## Novità della versione 1.5 (30 ottobre 2026, aggiornata al 2 novembre 2026)

**Regola:** il reddito civico di ogni cittadino è proporzionale alle votazioni eseguite rispetto a quelle offerte: P = eseguite / offerte, reddito = reddito pieno × P. Chi non riceve convocazioni o ha un impedimento riconosciuto riceve il reddito pieno. Il contenuto del voto non conta: favorevole, contrario e astensione valgono allo stesso modo. Il paniere essenziale in natura non dipende mai dalla partecipazione; i premi per innovazione e valore sociale restano aggiuntivi.

Regole che completano il principio:

- **Quote non maturate al fondo per nuove imprese** (§13.6). In stato stazionario la domanda complessiva, i profitti e il pareggio del fondo restano quelli della 1.4 per qualunque livello di partecipazione (D-16, §14.5). Il limite fisico è la capacità del settore robot: tutto viene convertito in capitale nello stesso periodo se la partecipazione media è almeno 0,871; sotto questa soglia l'eccesso resta in riserva (N-9, §14.6).
- **Astensione**: conta per il reddito ma non per l'esito; la base minima di voto N_min si applica ai voti espressi (§11.1, §17.8).
- **Segretezza**: registro di partecipazione separato dall'urna, credenziali anonime monouso (§11.3).
- **Numero di votazioni**: tetto di convocazioni per periodo e numero minimo di convocazioni per calcolare P (§11.3).

Nuova condizione C7 (§18.3–18.4) e programma di verifica T9 (§19.2).

**Simulazione dinamica (N-10, §19.3)** — script [`simulazioni/teps_1_5_partecipazione.py`](simulazioni/teps_1_5_partecipazione.py), che ricostruisce il blocco stock-flow della 1.4 e ne verifica i risultati prima di simulare. Su 30 periodi:

- la partecipazione non genera inflazione (al massimo 0,25% per periodo, anche con partecipazione casuale);
- un calo improvviso di partecipazione produce una recessione breve: il consumo discrezionale torna al livello iniziale in 3–6 periodi;
- il rischio prevalente è la deflazione con capacità in parte inutilizzata, perché le nuove imprese aumentano la capacità più rapidamente della domanda;
- destinare le quote alle nuove imprese non è mai peggio che trattenerle: se nessuna impresa riesce il consumo scende del 10% ma i prezzi restano stabili; trattenute, le quote producono deflazione continua.

Da completare: orizzonti lunghi, matrice del capitale B e rendimento reale delle nuove imprese.

## Nessuna banca privata (1.5)

Non esistono banche private né prestiti a interesse. Conti, pagamenti ed emissione di moneta sono svolti da una **banca pubblica automatica**: un registro pubblico calcolato da più sistemi indipendenti con regole deterministiche (§13.7). Dimostrazioni (§14.7–14.11):

- **D-17** — la somma dei saldi è sempre zero: la moneta coincide in ogni periodo con il debito del fondo, e nessuna moneta nasce fuori dal fondo;
- **D-18** — un pagamento dipende solo dal saldo di chi paga: le corse agli sportelli sono impossibili;
- **D-19** — con 5 sistemi indipendenti e probabilità di guasto dell'1% ciascuno, uno stato errato è accettato con probabilità inferiore a 10⁻⁵, e chiunque può ricalcolare il registro;
- **D-20** — il prestito a interesse è incompatibile con il limite ai patrimoni personali (D-12);
- **D-21** — riunisce i risultati: il sistema monetario senza banche private funziona; la stabilità resta locale (N-3), come nella 1.4.

