# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""TEPS 1.5 — Figura 5 (N-10): prezzi e consumo discrezionale con partecipazione variabile.

Stesso stile delle figure della versione 1.4. Usa la simulazione di teps_1_5_partecipazione.py.
Uso (dalla cartella teps/):  python3 simulazioni/teps_1_5_figura_n10.py [--en]   (--en: etichette in inglese, figure/figura_5_en.png)
Richiede NumPy e Matplotlib.
"""
import os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from teps_1_5_partecipazione import simula, verifica

if any("Inter" in f.name for f in font_manager.fontManager.ttflist):
    plt.rcParams["font.family"] = "Inter"
plt.rcParams.update({"font.size": 8, "axes.linewidth": 0.8})

COL = {"S0": "#5B6A85", "S1": "#138D75", "S2": "#2E6DB4", "S3": "#7D4FA3", "S10": "#D99A43"}
da10 = lambda v: (lambda t: 1.0 if t < 10 else v)
EN = "--en" in sys.argv
T_ = (lambda it, en: en if EN else it)
scenari = [
    ("S0", T_("S0 P̄ = 1 (riferimento 1.4)", "S0 P̄ = 1 (1.4 reference)"), dict(P=lambda t: 1.0)),
    ("S1", T_("S1 P̄ = 0,90", "S1 P̄ = 0.90"), dict(P=da10(0.90))),
    ("S2", T_("S2 P̄ = 0,75", "S2 P̄ = 0.75"), dict(P=da10(0.75))),
    ("S3", T_("S3 P̄ = 0,50", "S3 P̄ = 0.50"), dict(P=da10(0.50))),
    ("S10", T_("S10 P̄ = 0,90, quote ferme nel fondo", "S10 P̄ = 0.90, unearned shares held in the fund"), dict(P=da10(0.90), quote="ferme")),
]

verifica()
fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.17, 2.47), dpi=231)
T = 41
for key, nome, kw in scenari:
    r = simula(T=T, **kw)
    a1.plot(range(T), r["p"], color=COL[key], lw=1.6, label=nome)
    a2.plot(range(T), r["c"], color=COL[key], lw=1.6, label=nome)
for ax, yl in ((a1, T_("Livello dei prezzi p", "Price level p")), (a2, T_("Consumo discrezionale reale", "Real discretionary consumption"))):
    ax.axvspan(10, 40, color="#F3E6D6", alpha=0.55, lw=0)
    ax.grid(True, color="#E3E3E3", lw=0.6)
    ax.set_xlim(0, 40)
    ax.set_xlabel(T_("Periodo simulato", "Simulated period"))
    ax.set_ylabel(yl)
a1.set_title(T_("Partecipazione media ridotta dal periodo 10", "Average participation reduced from period 10"), fontsize=7.5, loc="left")
a2.legend(fontsize=5.6, loc="upper left", frameon=True, framealpha=0.95, edgecolor="#CCCCCC")
fig.tight_layout(pad=0.6, w_pad=1.6)
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figure", "figura_5_en.png" if EN else "figura_5.png")
fig.savefig(out, dpi=231)
print("scritto", os.path.normpath(out))
