# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""TEPS 1.5 — verifica numerica della banca pubblica automatica (§13.7, D-17–D-19).

1. Esegue il registro della BPA su operazioni casuali (pagamenti fra cittadini,
   pagamenti del fondo che creano moneta, acquisti che la riassorbono) e controlla
   a ogni operazione:  Σ saldi = 0,  M = −m_f,  saldi dei cittadini ≥ 0  (D-17),
   e che l'esito di un pagamento dipenda solo dal saldo di chi paga (D-18).
2. Stima con Monte Carlo la probabilità che un registro replicato su n sistemi accetti
   uno stato errato, nel caso peggiore in cui tutti i sistemi guasti producono lo
   stesso stato errato, e la confronta con il limite della D-19.

Uso (dalla cartella teps/):  python3 simulazioni/teps_1_5_banca_pubblica.py      (solo NumPy)
"""
from math import comb
import numpy as np

FONDO = 0


def valida(m, da, x):
    return x > 0 and (da == FONDO or m[da] >= x)


def esegui(m, da, a, x):
    m[da] -= x
    m[a] += x


def verifica_registro(n_cittadini=1000, n_operazioni=200_000, seme=1):
    rng = np.random.default_rng(seme)
    m = np.zeros(n_cittadini + 1, dtype=np.int64)   # importi interi: nessun errore di arrotondamento
    rifiutate = 0
    for _ in range(n_operazioni):
        tipo = rng.random()
        if tipo < 0.2:                               # il fondo paga un cittadino: crea moneta
            da, a = FONDO, int(rng.integers(1, n_cittadini + 1))
        elif tipo < 0.5:                             # un cittadino compra dal fondo/imprese: riassorbe moneta
            da, a = int(rng.integers(1, n_cittadini + 1)), FONDO
        else:                                        # pagamento fra cittadini
            da, a = (int(v) for v in rng.integers(1, n_cittadini + 1, 2))
        x = int(rng.integers(1, 200))
        # D-18: la validità dipende solo dal saldo di chi paga; cambiare gli altri saldi non la modifica
        altri = m.copy(); altri[[i for i in range(len(m)) if i != da][:5]] += 10**6
        assert valida(m, da, x) == valida(altri, da, x)
        if valida(m, da, x):
            esegui(m, da, a, x)
        else:
            rifiutate += 1
        assert m.sum() == 0                          # D-17: conservazione
        assert (m[1:] >= 0).all()                    # cittadini mai in negativo
        assert m[1:].sum() == -m[FONDO]              # moneta = debito del fondo
    return m[1:].sum(), rifiutate


def limite_d19(n, q):
    return sum(comb(n, j) * q**j * (1 - q)**(n - j) for j in range(n // 2 + 1, n + 1))


def monte_carlo_d19(n, q, prove=2_000_000, seme=2):
    rng = np.random.default_rng(seme)
    guasti = rng.random((prove, n)) < q
    # caso peggiore: tutti i guasti producono lo stesso stato errato
    return (guasti.sum(axis=1) > n / 2).mean()


if __name__ == "__main__":
    M, rif = verifica_registro()
    print(f"D-17/D-18: 200.000 operazioni su 1.000 conti, identità contabili rispettate a ogni operazione; "
          f"moneta finale {M} = debito del fondo; operazioni rifiutate per saldo insufficiente {rif}")
    print(f"{'n':>3} {'q':>6} {'limite D-19':>12} {'Monte Carlo':>12}")
    for n, q in [(3, 0.01), (5, 0.01), (7, 0.01), (3, 0.05), (5, 0.05)]:
        print(f"{n:>3} {q:>6} {limite_d19(n, q):>12.2e} {monte_carlo_d19(n, q):>12.2e}")
