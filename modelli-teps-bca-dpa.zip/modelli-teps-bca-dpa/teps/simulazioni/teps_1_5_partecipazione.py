# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""TEPS 1.5 — simulazione dinamica del reddito civico proporzionale alla partecipazione.

Ricostruzione del blocco stock-flow della §13.4 (TEPS 1.4) con le integrazioni 1.5:
reddito civico h̄·P, quote non maturate Q al fondo per nuove imprese (§13.6),
limite fisico della conversione in capitale calcolato con la matrice A (N-9).

Lo script originale teps_sfc.py della 1.4 non è nel repository: le equazioni sono
ricostruite dal testo (§13.4, §14.2) e la ricostruzione è verificata sugli stati
di riferimento 1.4 (vedi verifica() in fondo).

Uso (dalla cartella teps/):  python3 simulazioni/teps_1_5_partecipazione.py
Richiede solo NumPy.
"""
import numpy as np

# ---------------------------------------------------------------- dati 1.4
A_TEC = np.array([[.08, .15, .12, .10, .20],
                  [.06, .08, .14, .08, .25],
                  [.00, .00, .04, .02, .00],
                  [.02, .02, .03, .05, .03],
                  [.03, .03, .04, .05, .08]])
L = np.linalg.inv(np.eye(5) - A_TEC)
B_VEC = np.array([12, 0, 50, 30, 0.])      # paniere essenziale
Z_VEC = np.array([0, 0, 10, 15, 0.])       # consumo discrezionale pieno (25)
CAP0 = np.array([42.377, 28.454, 69.937, 56.978, 37.143])  # capacità §4.2

K0 = 234.889
Y0 = 141.0
YBAR0 = 155.1
V = K0 / YBAR0                 # 1,5144
DELTA = 24 / K0                # 0,1022
UBAR = Y0 / YBAR0              # 0,909
B = 92.0
ALPHA1, ALPHA2, KAPPA, LAMBDA = 0.90, 0.10, 0.5, 0.5
F_TETTO = 20.0                 # tetto della riserva per nuove imprese F̄ᴵ (riserva iniziale §17.3)


def in_max_settoriale(scala, c, ir_ix):
    """Massimo investimento in nuove imprese (beni del settore robot, convenzione 1:1)
    compatibile con le capacità settoriali, dato il consumo discrezionale reale c."""
    base = L @ (B_VEC + (c / 25.0) * Z_VEC)
    marg = (CAP0 * scala - base) / L[:, 4]
    return max(0.0, marg.min() - ir_ix)


def simula(P, T=100, omega=None, efficacia=1.0, rigidi=False, quote="imprese"):
    """P: funzione t -> partecipazione media P̄ₜ.
    omega: funzione t -> moltiplicatore della capacità (shock).
    efficacia: frazione del capitale delle nuove imprese che diventa capacità
               produttiva (il resto è perso: progetti falliti e arrestati).
    rigidi: prezzi rigidi verso il basso.
    quote: 'imprese' (scelta B della 1.5) oppure 'ferme' (Q trattenute senza spesa)."""
    omega = omega or (lambda t: 1.0)
    K, p, Mh, A, FI = K0, 1.0, 25.0, 25.0, 0.0
    Yd_prev, Ybar_prev, Pi_prev, eccedenza = Y0, YBAR0, 117.0, 0.0
    out = {k: [] for k in "p infl u c In Q FI K H hR1 Pi err P".split()}
    for t in range(T):
        Pt, w = P(t), omega(t)
        # prezzi (§13.4)
        p_new = p * (1 + KAPPA * (Yd_prev / Ybar_prev - UBAR))
        if rigidi:
            p_new = max(p_new, p)
        infl, p = p_new / p - 1, p_new
        Ybar = w * K / V
        Ir = DELTA * K
        Ix = 0.5 * max(0.0, K0 - K)
        # regola funzionale R1 (§14.2): monte dei trasferimenti come se tutti votassero
        hR1 = max(0.0, Pi_prev - p * B - p * Ix + LAMBDA * p * (UBAR * Ybar - Yd_prev))
        H = Pt * hR1 + eccedenza            # reddito civico pagato (+ eventuale eccedenza della riserva)
        Q = (1 - Pt) * hR1                  # quote non maturate
        # domanda (§13.4)
        cd = (ALPHA1 * H + ALPHA2 * Mh) / p
        # razionamento: b -> Ir -> Ix -> consumo discrezionale -> nuove imprese
        disp = Ybar
        b_eff = min(B, disp); disp -= b_eff
        Ir_eff = min(Ir, disp); disp -= Ir_eff
        Ix_eff = min(Ix, disp); disp -= Ix_eff
        c = min(cd, disp); disp -= c
        if quote == "imprese":
            # piano del fondo: spende la riserva entro il limite fisico del settore robot (N-9)
            In_piano = min((FI + Q) / p, in_max_settoriale(w * K / K0, c, Ir_eff + Ix_eff))
            In = min(In_piano, disp)
        else:
            In_piano = In = 0.0
        Y = b_eff + Ir_eff + Ix_eff + c + In
        Yd = B + Ir + Ix + cd + In_piano
        Pi = p * (Y - Ir_eff)
        # stock (matrici delle Tabelle 2-3)
        Mh += H - p * c
        A += p * b_eff + p * Ix_eff + p * In + H - Pi
        FI = FI + Q - p * In
        eccedenza = max(0.0, FI - F_TETTO) if quote == "imprese" else 0.0
        FI -= eccedenza
        K = K - (Ir - Ir_eff) + Ix_eff + efficacia * In   # Kₜ₊₁ = (1−δ)K + Ir + Ix + e·In
        for k, val in zip("p infl u c In Q FI K H hR1 Pi err P".split(),
                          [p, infl, Y / Ybar, c, In, Q, FI, K, H, hR1, Pi, abs(Mh - A), Pt]):
            out[k].append(val)
        Yd_prev, Ybar_prev, Pi_prev = Yd, Ybar, Pi
    return {k: np.array(v) for k, v in out.items()}


def riga(nome, r, da=10):
    s = slice(da, None)   # dal periodo del cambiamento alla fine
    return (f"{nome:<44} {r['infl'][s].max()*100:6.2f}% {r['p'][-1]:6.3f} "
            f"{r['u'][s].min():6.3f} {r['c'][s].min():6.2f} {r['c'][-1]:7.2f} "
            f"{r['In'][s].sum():7.1f} {r['FI'][s].max():6.1f} {r['K'][-1]:7.1f} {r['err'].max():8.1e}")


def verifica():
    """Ricostruzione verificata sulla 1.4.
    (1) Con P = 1 lo stato stazionario resta p = 1, u = 0,909, c = 25, A = Mₕ = 25.
    (2) Shock di capacità −20% nei periodi 10–14 con regola R1: si ritrova la riga R1 della
        Tabella 5 (inflazione massima 6,3%, prezzi finali 1,068, discrezionale minimo 1,79)."""
    r = simula(lambda t: 1.0, T=200)
    assert abs(r["p"][-1] - 1) < 1e-9 and abs(r["c"][-1] - 25) < 1e-9 and abs(r["u"][-1] - UBAR) < 1e-9
    assert r["In"].sum() == 0 and r["err"].max() < 1e-9
    s = simula(lambda t: 1.0, T=60, omega=lambda t: 0.8 if 10 <= t <= 14 else 1.0)
    assert abs(s["infl"].max() - 0.063) < 0.001 and abs(s["p"][-1] - 1.068) < 0.001 and abs(s["c"].min() - 1.79) < 0.005
    return r


if __name__ == "__main__":
    verifica()
    # Orizzonte: 10 periodi di riferimento e 30 dopo il cambiamento. Oltre, la crescita del
    # capitale porta i consumi lontano dalla composizione fissa del modello (b e z invariati).
    rng = np.random.default_rng(15)
    casuale = rng.uniform(0.7, 1.0, 200)
    shock = lambda t: 0.8 if 10 <= t <= 14 else 1.0
    da10 = lambda v: (lambda t: 1.0 if t < 10 else v)
    scenari = [
        ("S0  P̄ = 1 (riferimento 1.4)", dict(P=lambda t: 1.0)),
        ("S1  P̄ = 0,90 dal periodo 10", dict(P=da10(0.90))),
        ("S2  P̄ = 0,75 dal periodo 10", dict(P=da10(0.75))),
        ("S3  P̄ = 0,50 dal periodo 10", dict(P=da10(0.50))),
        ("S4  P̄ casuale fra 0,70 e 1,00", dict(P=lambda t: 1.0 if t < 10 else casuale[t])),
        ("S5  P̄ = 0,90, prezzi rigidi verso il basso", dict(P=da10(0.90), rigidi=True)),
        ("S6  P̄ = 0,90, solo 20% delle imprese riesce", dict(P=da10(0.90), efficacia=0.2)),
        ("S7  P̄ = 0,90, nessuna impresa riesce", dict(P=da10(0.90), efficacia=0.0)),
        ("S8  shock −20% (10–14), P̄ = 1", dict(P=lambda t: 1.0, omega=shock)),
        ("S9  shock −20% (10–14), P̄ = 0,90", dict(P=da10(0.90), omega=shock)),
        ("S10 P̄ = 0,90, quote ferme nel fondo", dict(P=da10(0.90), quote="ferme")),
    ]
    print(f"{'Scenario (periodi 10–40)':<44} {'infl.max':>7} {'p fin':>6} {'u min':>6} "
          f"{'c min':>6} {'c fin':>7} {'ΣIn':>7} {'Fᴵmax':>6} {'K fin':>7} {'|M−A|':>8}")
    for nome, kw in scenari:
        print(riga(nome, simula(T=41, **kw)))
