# TEPS — Teoria dell’Equilibrio Economico Post-Salariale

## Versione 1.5 · 30 ottobre 2026 (aggiornata al 2 novembre 2026)

**Versione 1.5 del 30 ottobre 2026, aggiornata al 2 novembre 2026.** Il testo riprende integralmente il modello 1.4 (PDF del 13 ottobre 2026, 30 pagine) con le revisioni 1.5: i passaggi 1.4 incompatibili sono corretti direttamente nel testo, le parti nuove sono nelle sezioni «Integrazione 1.5» e sono riassunte nell'Appendice B. Il testo 1.4 originale è conservato in `archivio/TEPS_1_4_estrazione_testuale.txt`. Le figure 1–4 sono quelle del PDF 1.4 (`archivio/TEPS_1_4_Modello_Economico_Consolidato.pdf`); la figura 5 è nuova (N-10).

---

*Modello consolidato di economia automatizzata, capitale collettivo e governance per competenza*

**VERSIONE DI LAVORO 1.5 · 30 OTTOBRE 2026 · AGGIORNATA AL 2 NOVEMBRE 2026**

**Ipotesi di scenario.** Automazione completa delle attività produttive. Dalla versione 1.1 l’energia da fusione è ipotesi di base: abbondante, a costo trascurabile, mai settore vincolante (gli impianti restano capitale fisico). Dalla 1.2 non esiste proprietà privata produttiva: la proprietà privata resta solo per uso personale. Dalla 1.3 il premio agli ideatori è limitato e misura anche il vantaggio sociale, valutato in modo algoritmico; dalla 1.4 il premio non è solo monetario ma anche peso nelle decisioni tecniche, sempre con un tetto. Dalla 1.5 il reddito monetario è proporzionale alle votazioni eseguite rispetto a quelle offerte. Nessuna delle simulazioni è calibrata su una economia reale.

**Ambiti coperti**

- Produzione, energia, capitale e stabilità di lungo periodo
- Finanziamento pubblico delle iniziative e incentivi agli ideatori
- IA operativa e consesso indipendente di agenti valutatori
- Democrazia ponderata su tutto l’insieme dei cittadini
- Proposizioni, dimostrazioni matematiche, simulazioni e limiti
- Blocco stock-flow consistente con il fondo, prezzi, matrice del capitale e incentivi (novità 1.1–1.4)
- Reddito civico proporzionale alla partecipazione alle votazioni (novità 1.5)

**Stato scientifico:** modello teorico con verifiche algebriche e simulazioni riproducibili; non teoria empiricamente validata.

## Sintesi esecutiva

La TEPS studia un’economia nella quale la produzione può essere integralmente svolta da macchine e sistemi di IA. Il reddito da lavoro diventa non necessario per assicurare la sopravvivenza materiale. Il sistema preserva invece l’iniziativa individuale: chi propone un’idea di business può ottenere capitale pubblico e ricevere compensi incrementali quando l’idea genera valore verificato.

| Dimensione | Regola proposta | Verifica richiesta |
|---|---|---|
| Produzione | Robot e IA svolgono la produzione; vincoli fisici per settore | Fattibilità e autoriproduzione del capitale |
| Accesso | Paniere di beni essenziali garantito a ogni persona | Disponibilità effettiva dei beni |
| Nuove imprese | Fondo collettivo finanzia idee valutate pubblicamente | Bilancio del fondo e selezione dei progetti |
| Ideatore | Definisce l’idea; supporta indirettamente la gestione | Incentivi legati al valore netto aggiuntivo |
| Gestione | IA controlla le operazioni dirette, entro vincoli pubblici | Audit, sicurezza e rimedi |
| Valutazione | Consesso di IA senza dialogo reciproco | Errori, correlazioni e integrità dei dati |
| Voto tecnico | Peso per conoscenza pertinente su scala universale | Competenza aperta a tutti e verificabile |
| Diritti comuni | Voto eguale sulle materie che toccano tutti | Compatibilità costituzionale |
| Reddito civico (1.5) | Proporzionale a votazioni eseguite / offerte | Domanda, fondo, capacità (T9) |
| Banca (1.5) | Nessuna banca privata; registro pubblico automatico | Conservazione, pagamenti, audit (D-17–D-21) |

**Esito della verifica.** Sono dimostrate condizioni di esistenza, chiusura finanziaria e convergenza locale dell’equilibrio, ora anche nel blocco monetario stock-flow consistente con il fondo (versioni 1.1–1.4, §13–17) e, dalla 1.5, il funzionamento della moneta senza banche private (D-17–D-21). Il modello economico risulta coerente sotto otto condizioni esplicite (§18.3; C7 e C8 dalla 1.5). Non sono dimostrate la stabilità globale né la superiorità economica rispetto ad altri ordinamenti.

**Lettura corretta delle prove**

| Sigla | Significato |
|---|---|
| [D] | Proposizione derivata dalle equazioni, con ipotesi esplicitate. |
| [N] | Risultato numerico riprodotto da un codice di simulazione, non previsione. |
| [P] | Principio istituzionale progettuale, non teorema matematico. |
| [A] | Assunzione tecnica introdotta per chiudere il modello. |

**Integrazione 1.5 — Sintesi della revisione**

[1.5 P] Reddito civico proporzionale alla partecipazione. Il reddito monetario di base di ogni cittadino è il reddito civico pieno h̄ₜ moltiplicato per la quota di partecipazione Pᵢ,ₜ = votazioni eseguite / votazioni offerte nel periodo (§11.3). Chi esegue tutte le votazioni offerte riceve h̄ₜ per intero; chi ne esegue una parte riceve la stessa parte. Il contenuto del voto non conta: favorevole, contrario e astensione esplicita valgono allo stesso modo.

Quattro regole completano il principio:

1. Quote non maturate: la parte di reddito non pagata resta al fondo e finanzia nuove imprese (§13.6). Così la domanda complessiva non cala e le macchine non restano ferme (D-16), entro il limite fisico calcolato in N-9.
2. Astensione: conta per il reddito ma non entra nel calcolo dell'esito; le garanzie sul potere dei gruppi (D-14, D-15) si applicano ai voti espressi (§11.1, §17.8).
3. Segretezza: il sistema registra che una persona ha votato, mai come ha votato; il registro di partecipazione è separato dall'urna (§11.3).
4. Numero di votazioni: tetto di convocazioni per periodo e numero minimo di convocazioni per il calcolo di P, fissati con voto eguale (§11.3).

Il paniere essenziale in natura non dipende mai dalla partecipazione. I premi S restano aggiuntivi. Il dividendo universale D della 1.4 è sostituito dal reddito civico: nei passaggi storici rimasti (§5, §9.2, §14.2, §15, §17.3) «dividendo» va letto «reddito civico». Le prove della 1.4 valgono per il caso P = 1; per P < 1 sono aggiunte D-16 (stato stazionario), N-9 (fattibilità fisica) e la simulazione dinamica N-10 su 30 periodi (§19.3). Poiché senza partecipazione manca il reddito monetario, la partecipazione attesa è vicina a 1.

[1.5 P] Nessuna banca privata. Non esistono banche private né prestiti a interesse. Conti, pagamenti ed emissione di moneta sono svolti da una banca pubblica automatica: un registro pubblico calcolato da più sistemi di IA indipendenti con regole deterministiche (§13.7). Le dimostrazioni D-17–D-21 (§14.7–14.11) mostrano che la moneta coincide sempre con il debito del fondo, che le corse agli sportelli sono impossibili, che gli errori del registro sono rilevati e che l’interesse privato è incompatibile con il limite ai patrimoni (condizione C8).

## Indice dei contenuti

- 01 Obiettivo e riferimenti teorici
- 02 Istituzioni e ruoli: cittadino, ideatore, capitale, IA
- 03 Modello fisico: cinque settori e vincoli
- 04 Dimostrazione 1 — Fattibilità materiale
- 05 Domanda post-salariale e distribuzione
- 06 Dimostrazione 2 — Equilibrio e stabilità locale
- 07 Capitale e prove di crisi a 100 periodi
- 08 Fusione nucleare e investimenti robusti
- 09 Contabilità, prezzi, moneta e fondo pubblico
- 10 Imprese, compensi incrementali e selezione dei progetti
- 11 Conoscenza, competenza e democrazia ponderata (1.5: §11.3 reddito civico e partecipazione)
- 12 Consesso indipendente di IA e affidabilità
- 13 Blocco stock-flow consistente con il fondo (nuovo 1.1–1.4; 1.5: §13.6 quote non maturate, §13.7 banca pubblica automatica)
- 14 Dimostrazioni sul blocco monetario (nuovo 1.1–1.4; 1.5: §14.5 D-16, §14.6 N-9, §14.7–14.11 D-17–D-21)
- 15 Prezzi, razionamento e shock post-fusione (nuovo 1.1–1.4)
- 16 Capitale con matrice dei coefficienti (nuovo 1.1–1.4)
- 17 Incentivi, proprietà personale, premi in denaro e in peso, rischio del fondo (nuovo 1.1–1.4; 1.5: §17.9)
- 18 Valutazione economica, condizioni di sostenibilità e verdetto (1.5: C7, §18.4)
- 19 Limiti, test necessari e risultati dimostrati (1.5: T9, §19.2)
- 20 Glossario, parametri e riferimenti

Le sezioni sono navigabili in Word dal riquadro «Titoli» (Visualizza → Riquadro di spostamento).

## 1. Obiettivo e riferimenti teorici

La TEPS nasce dall’esigenza di conciliare abbondanza produttiva, accesso ai beni, investimento e innovazione quando il lavoro umano non è più un input necessario della produzione ordinaria. Prende spunto da Marx (centralità del lavoro e dei rapporti di proprietà), Keynes (ruolo della domanda effettiva), Leontief (dipendenze materiali tra settori) e Godley–Lavoie (coerenza fra flussi monetari e stock finanziari). [1–3]

Il modello non afferma che Marx e Keynes risultino “superati”: ne ricompone problemi differenti in una situazione estrema di automazione. L’oggetto originale potenziale è l’integrazione tra vincoli fisici, finanziamento del capitale comune, incentivi all’iniziativa e procedure di governance algoritmica.

### 1.1 Ipotesi strutturali

- Offerta di lavoro produttivo umano L = 0; salari necessari alla produzione W = 0. Restano possibili compensi agli ideatori, non indispensabili per far funzionare le fabbriche.
- Energia abbondante: disponibilità aumentata e costi variabili energetici ridotti solo in scenari ipotetici. Il costo complessivo di impianti e reti non è assunto nullo.
- Popolazione interamente inclusa nell’ordinamento economico; accesso al capitale e alle prove di competenza non vincolato al patrimonio iniziale.
- Diritti fondamentali e disponibilità di un paniere essenziale precedono la distribuzione del consumo discrezionale.
- Macchine, materie prime, impianti, superfici, capacità di fabbricazione e tempo restano risorse potenzialmente scarse.
- Proprietà (1.2): la proprietà privata è ammessa solo per uso personale (abitazione, beni durevoli, strumenti personali). Non esiste proprietà privata di imprese o di capitale produttivo: tutto il capitale produttivo appartiene al fondo. La proprietà personale cresce solo grazie ai premi per il valore creato dal pensiero, dalla creatività e dall’iniziativa per il bene pubblico (§17.4); i premi, in denaro e in peso sulle competenze, sono limitati e misurano il valore economico e il vantaggio sociale (§17.5, §17.7).
- Governo (1.2): la gestione pubblica non è affidata direttamente a organi umani. Le persone intervengono solo con il voto ponderato (§11) su parametri e regole; esecuzione, valutazioni e verifiche sono affidate a IA pubbliche con regole deterministiche e pubbliche.
- Moneta e banca (1.5): non esistono banche private. Conti, pagamenti ed emissione di moneta sono svolti da una banca pubblica automatica: un registro pubblico gestito da IA con regole deterministiche (§13.7).

## 2. Istituzioni e ruoli

| Soggetto | Compito | Limite del potere |
|---|---|---|
| Popolazione | Fissa diritti, priorità generali, parametri e partecipa alle votazioni | Nessun potere individuale assoluto |
| Ideatore–imprenditore | Definisce il business, propone evoluzioni e supporta indirettamente | Non comanda le operazioni dirette |
| Fondo produttivo pubblico | Assegna capitale e riceve i ritorni dalle imprese | Vincoli materiali, finanziari e pubblici |
| IA gestionale | Esegue decisioni operative e programmi industriali | Mandato verificabile, arresti di sicurezza |
| Consesso di IA | Certifica conoscenze e valuta evidenze di idee | Agentività isolata, nessun dialogo tra valutatori |
| Aggregatore | Applica formule pubbliche ai giudizi firmati | Non modifica né riscrive giudizi |
| Controllo indipendente | Audit, ricorso, tutela dei diritti e sicurezza | Non sostituisce la gestione con favoritismi |

**Principio guida [P].** Tutti gli esseri umani appartengono alla popolazione di riferimento. Il peso su una decisione specialistica dipende dalla conoscenza pertinente, non dall’appartenenza a una classe di esperti. Per i diritti universali è previsto un voto di peso uguale.

## 3. Modello fisico: cinque settori

Si considerano cinque settori ordinati come E = energia, M = materiali, F = alimenti, S = servizi/abitazioni, R = fabbricazione robot. x è il vettore della produzione lorda, A la matrice dei fabbisogni intermedi, f la domanda finale. Ogni colonna j della matrice A descrive gli input necessari a produrre una unità di output del settore j.

    x=Ax+f;          f = b + q z + i eᵣ
    [A] x* = (I − A)⁻¹ (b + q z + i eᵣ)

Nello scenario numerico, i vettori della domanda finale sono: b = (12, 0, 50, 30, 0), z = (0, 0, 10, 15, 0), eᵣ = (0, 0, 0, 0, 1). Il parametro q ∈ [0,1] misura la frazione di consumo aggiuntivo effettivamente fornita; i è l’investimento annuo in beni robotici.

| Input \ output | E | M | F | S | R |
|---|---|---|---|---|---|
| E | 0,08 | 0,15 | 0,12 | 0,10 | 0,20 |
| M | 0,06 | 0,08 | 0,14 | 0,08 | 0,25 |
| F | 0,00 | 0,00 | 0,04 | 0,02 | 0,00 |
| S | 0,02 | 0,02 | 0,03 | 0,05 | 0,03 |
| R | 0,03 | 0,03 | 0,04 | 0,05 | 0,08 |

*Tabella 1. Matrice tecnica A del modello numerico; coefficienti ipotetici e fissi. L’inversa viene calcolata solo se I − A è invertibile.*

    x ≤ x̄ (K,ω) ;      Kₜ₊₁ = (1 − δ) Kₜ + Iₜ

La capacità massima x̄ dipende dal capitale installato e dagli shock ω. Per semplicità, gli investimenti robotici sostituiscono o aggiungono capacità negli altri settori secondo un rapporto convenzionale di 1:1: è una ipotesi forte, non una legge tecnologica.

## 4. Dimostrazione 1 — Fattibilità materiale

### 4.1 Proposizione di Leontief [D]

Sia A ≥ 0 (coefficienti tecnici non negativi), con raggio spettrale ρ(A) < 1. Per una domanda finale non negativa f, la produzione minima in un sistema lineare a coefficienti fissi è:

    xₘᵢₙ = (I − A)⁻¹ f = [I + A + A² + ⋯] f

Dimostrazione. La serie di Neumann converge perché ρ(A) < 1 e ha tutti gli elementi non negativi. Se un piano x produce almeno la domanda finale, x − Ax ≥ f. Moltiplicando per (I − A)⁻¹ ≥ 0 risulta x ≥ (I − A)⁻¹ f. Ponendo x = (I − A)⁻¹ f si ottiene uguaglianza. Perciò il piano è minimo componente per componente. Q.E.D.

    [D] Esistenza fisica in un periodo ⇔ (I − A)⁻¹ f ≤ x̄

La condizione è necessaria e sufficiente solo in questo modello statico, con capacità a vincoli separati, tecnologia fissa, nessun bene sostituibile, nessuna scorta e assenza di restrizioni ulteriori.

### 4.2 Verifica numerica

Con investimento di sostituzione i = 24, i dati riproducono i seguenti risultati:

| Settore | Minimo b + rinnovo | Con consumi extra | Capacità iniziale |
|---|---|---|---|
| Energia | 34,380 | 38,525 | 42,377 |
| Materiali | 22,100 | 25,867 | 28,454 |
| Alimenti | 52,822 | 63,579 | 69,937 |
| Servizi | 35,451 | 51,798 | 56,978 |
| Robot | 32,152 | 33,766 | 37,143 |

Calcoli matriciali: ρ(A) = 0,281738, quindi la condizione di produttività lineare è soddisfatta. Tutte le cinque capacità sono maggiori della produzione richiesta nello scenario normale.

### 4.3 Indice di margine fisico [D]

    σ(K,ω) = minⱼ { x̄ ⱼ(K,ω) / [(I − A)⁻¹(b + iₘᵢₙ eᵣ)]ⱼ }

Interpretazione: σ ≥ 1 significa che il paniere essenziale e la sostituzione minima delle macchine sono producibili nel singolo periodo, per la matrice e le capacità considerate. σ < 1 significa che almeno un settore non può sostenere entrambe le richieste. Non è una probabilità né una misura sufficiente di resilienza pluriennale.

**Conseguenza economica.** Un’economia può avere capacità e denaro in abbondanza aggregata e tuttavia non riuscire a fornire il paniere essenziale se manca un input intermedio critico, per esempio robot o materiali.

## 5. Domanda post-salariale e distribuzione

Per studiare la domanda senza salari viene introdotto un sottosistema keynesiano aggregato, distinto dall’esempio input-output. Il suo scopo è trovare l’intervallo di distribuzione compatibile con il consumo e con gli investimenti.

    C = [cₚ + (cₕ − cₚ) θ] Y = m(θ)Y
    [D] Y = C + I       ⇒      Y* = I / [1 − cₚ − (cₕ − cₚ) θ]

Qui θ è la quota del reddito destinata alla popolazione beneficiaria del dividendo, cₕ la propensione al consumo di tale popolazione e cₚ quella dei proprietari di capitale privato. Non si deve confondere θ, quota di reddito, con φ, quota di proprietà.

    θ* = [1 − cₚ − I / Yₒᵦ] / (cₕ − cₚ)

### 5.1 Calcolo dell’intervallo ammissibile

Assumiamo: I = 25, capacità Ȳ = 110, cₕ = 0,90, cₚ = 0,30. Novanta cittadini necessitano complessivamente di 54 unità di consumo minimo, dieci proprietari di 6.

    Y* = 25 / (0,70 − 0,60 θ)
    Consumi primi 90:        0,90 θ Y* ≥ 54 ⇒ θ ≥ 0,688525
    Consumi proprietari: 0,30 (1 − θ) Y* ≥ 6 ⇒ θ ≤ 0,846154
    Capacità:         Y* ≤ 110 ⇒ θ ≤ 0,787879
    [D] Intervallo comune: 0,688525 ≤ θ ≤ 0,787879

Per θ = 0,75 il modello dà Y\* = 100; i consumi dei cittadini sono 67,5, quelli dei proprietari 7,5 e gli investimenti 25. Identità verificata: 67,5 + 7,5 + 25 = 100.

Il risultato non identifica una quota “giusta” universale: i confini dipendono da propensioni al consumo, capacità, fabbisogni, investimenti e architettura del modello.

**Aggiornamento 1.1.** Questo sottosistema è un caso speciale senza fondo e con proprietari privati, che dalla versione 1.2 non esistono più: gli investimenti sono finanziati dai risparmi privati e la capacità Ȳ = 110 non è collegata al modello input-output. Nella §13 il reddito coincide con il valore aggiunto input-output (141, capacità 155,1), l’investimento è deciso dal fondo e dalle imprese e la quota θ diventa endogena. Le conclusioni operative vanno lette nelle §13–14.

## 6. Dimostrazione 2 — Stabilità locale della domanda

Poniamo d = cₕ − cₚ > 0 e s = 1 − m(θ\*) > 0. La produzione si adegua gradualmente alla differenza tra domanda e offerta. Un regolatore modifica la quota distributiva in funzione dello scostamento dall’obiettivo:

    Yₜ₊₁ = Yₜ + α [m(θₜ) Yₜ + I − Yₜ]
    θₜ₊₁ = θₜ + η (Y* − Yₜ) / Y*

La linearizzazione nel punto fisso (Y\*, θ\*) produce la matrice Jacobiana:

    J = [[1 − α s, α d Y*], [−η / Y*, 1]]
    tr(J) = 2 − α s ; det(J) = 1 − α s + α d η

Dimostrazione. Per una matrice reale 2×2 la stabilità discreta locale si verifica con le tre condizioni di Jury: 1 − tr + det > 0; 1 + tr + det > 0; 1 − det > 0. Sostituendo:

    1 − tr + det = α d η > 0
    1 + tr + det = 4 − 2αs + αdη > 0
    1 − det = α(s − dη) > 0

Poiché 0 < α ≤ 1, 0 < s ≤ 1 e d > 0, le prime due condizioni sono soddisfatte per η > 0. La terza richiede η < s/d. Quindi:

    [D] STABILITÀ LOCALE 0 < η < (1 − m(θ*)) / (cₕ − cₚ)

Nel caso θ\* = 0,75, m = 0,75 e d = 0,60, quindi 0 < η < 0,416667. Il valore η = 0,10 rispetta la condizione. L’esito vale soltanto vicino all’equilibrio, a investimenti autonomi, con quote non bloccate agli estremi e capacità non vincolante.

### 6.1 Stabilità del processo input-output

Anche l’aggiustamento fra settori può essere modellato con un sistema lineare:

    xₜ₊₁ = (1 − γ)xₜ + γ(Axₜ + f),     0<γ≤1
    B = (1 − γ)I + γA;     ρ(B) < 1 ⇒ xₜ → x*

Poiché A è non negativa, ρ(A) < 1 e 0 < γ ≤ 1, risulta ρ(B) ≤ 1 − γ + γρ(A) < 1. Per γ = 0,60 il modello numerico fornisce ρ(B) = 0,569043.

**Distinzione essenziale.** La convergenza di questi due sottosistemi non dimostra la stabilità del modello TEPS completo: prezzi, debito, capitale, votazioni, finanziamenti e innovazione possono produrre altre instabilità.

## 7. Capitale e prove di crisi centennali

Nelle simulazioni 0.4 il capitale iniziale aggregato è K₀ = 234,889 e il rinnovo normale è 24 unità. Si usa δ = 24 / 234,889 = 0,102176. Il capitale dei comparti evolve in proporzione allo stock esistente. La regola di priorità è: prima bisogni essenziali, poi sostituzione delle macchine, infine consumi discrezionali.

    Kₜ₊₁ = (1 − δ) Kₜ + Iₜ
    Iₜ = min{Iₜ desiderato, Iₜ fisicamente producibile}

Per riportare lo stock verso il riferimento dopo una crisi, il controllore domanda investimenti addizionali finché i vincoli permettono di produrli. Il recupero quindi non è assicurato in generale.

| Scenario | Capitale minimo osservato | Esito in 100 periodi |
|---|---|---|
| Senza shock | 234,889 | Invariato |
| Energia −15% per 5 anni | 234,889 | Rinnovo preservato; consumi discrezionali ridotti |
| Energia −20% per 5 anni | 218,109 | Recupero nel modello |
| Energia −25% per 3 anni | 198,769 | Recupero nel modello |
| Energia −25% per 5 anni | — | Bisogni essenziali non fattibili dall’anno 23 |

![](figure/figura_1.png)

*Figura 1. Capitale aggregato con shock energetici diversi. Le linee si interrompono quando il modello dichiara la perdita di fattibilità. I risultati sono simulazioni, non previsioni.*

### 7.1 Lettura economica

L’esempio dimostra mediante simulazione che un’interruzione breve può essere assorbita sacrificando il consumo discrezionale e, se necessario, parte del rinnovo. Una interruzione più lunga può ridurre il capitale a tal punto da rendere impossibile perfino produrre il paniere essenziale.

L’aumento dell’offerta di moneta, isolatamente, non può colmare una carenza fisica di input intermedi.

**Nota post-fusione (1.1).** Con l’energia da fusione come ipotesi di base, gli shock energetici di questa sezione descrivono il regime pre-fusione. Nel regime di base gli shock rilevanti colpiscono materiali, robot e manutenzione: sono studiati con il modello monetario nella §15 e con la matrice del capitale nella §16. La conclusione qualitativa resta: la moneta non sostituisce input fisici mancanti (prova quantitativa in §15.1, regola R3).

## 8. Fusione nucleare e investimenti robusti

La TEPS considera lo scenario limite di un sistema a fusione che moltiplica per tre la capacità energetica. Questo non equivale a dimostrare che il costo totale dell’elettricità diventi zero: investimenti, rete, manutenzione, disponibilità, materiali e ammortamento continuano a contare.

    x̄ᴱ,fusione = 3 · x̄ᴱ,base         [A: scenario, non previsione]

Se l’energia smette di essere il settore vincolante, gli altri comparti possono determinare il limite del sistema. Nello scenario 0.5 è disponibile un budget aggiuntivo di 10 unità di capacità.

### 8.1 Formulazione della scelta robusta

    max ΔK,σ σ
    soggetto a: fⱼ(ω) · [Kⱼ + ΔKⱼ] ≥ σ · [(I − A)⁻¹(b + δ Σ(K + ΔK) eᵣ)]ⱼ
    Σ ΔKⱼ = 10; ΔKⱼ ≥ 0; per ogni settore j e shock ω

Con somma degli incrementi fissata a 10, il rinnovo complessivo è noto: il problema dell’esempio è un programma lineare. L’ottimo massimizza il peggior margine fra settori e scenari esplicitamente ammessi.

| Investimento aggiuntivo | Solo condizioni normali | Ottimizzazione robusta |
|---|---|---|
| Energia | 0,000 | 0,000 |
| Materiali | 1,624 | 3,162 |
| Alimenti | 0,889 | 0,000 |
| Servizi | 0,000 | 0,000 |
| Fabbricazione robot | 7,488 | 6,838 |
| Totale | 10,000 | 10,000 |

La configurazione robusta protegge maggiormente materiali e robot perché gli shock dichiarati colpiscono proprio questi comparti. Si noti che l’ottimizzazione robusta non promette una produzione normale più elevata.

| Scenario con fusione 3× | Quota consumo extra q: normale | Quota q: robusta |
|---|---|---|
| Nessuno shock | 1,000 | 1,000 |
| Energia −50% | 1,000 | 1,000 |
| Robot −20% | 1,000 | 1,000 |
| Materiali −25% | 0,033 | 0,340 |
| Shock combinato definito | 0,433 | 0,759 |

![](figure/figura_2.png)

*Figura 2. Traiettorie della frazione q di consumi discrezionali: strategia ottimizzata solo in condizioni normali (ocra) e strategia robusta (verde). Con i coefficienti dichiarati entrambe mantengono il rinnovo durante gli shock considerati..*

Nell’insieme di shock dichiarato, l’indice peggiore σ migliora da circa 1,006 (ottimizzazione nominale, verificata sugli shock) a 1,057 (ottimizzazione robusta). Il vantaggio scompare o può invertirsi rispetto a shock non compresi nel progetto.

## 9. Contabilità, prezzi e fondo collettivo

### 9.1 La contabilità reale non deve duplicare i beni intermedi

Al prezzo convenzionale unitario per tutti e cinque i settori, in condizioni normali la produzione lorda aggregata è 213,535 unità, i consumi intermedi 72,535 e il valore aggiunto lordo 141. Il conto delle destinazioni finali è:

    [D] VA = 1ᵀ[x − Ax] = 1ᵀ f = 92 + 25 + 24 = 141

| Impiego finale annuo | Unità |
|---|---|
| Paniere essenziale (b) | 92 |
| Consumo discrezionale (z) | 25 |
| Macchine di sostituzione (i) | 24 |
| Totale domanda finale | 141 |

È un’identità contabile al prezzo unitario convenzionale: non significa che 141 siano euro, né che i cinque beni siano fisicamente intercambiabili. I 92 di servizi essenziali richiedono un meccanismo di accesso in natura, trasferimenti o diritti equivalenti.

### 9.2 Dividendi e proprietà

Assumendo, per illustrazione, che la parte discrezionale residua sia di 25 unità e che il 75% di essa appartenga economicamente al collettivo, i dividendi possono essere 18,75 al fondo/cittadini e 6,25 a soggetti privati. Prima dei dividendi sono finanziati il paniere essenziale e i 24 di sostituzione. Una quota di proprietà pari al 75% non equivale però automaticamente a una quota di reddito pari al 75%: i trasferimenti e gli obblighi di servizio possono modificarla.

Nota 1.2: con φ = 0,75 il fondo non riuscirebbe a pagare il paniere (incasserebbe 87,75 contro 92) e questa ripartizione richiederebbe un canone del 78,6% sui profitti privati (versione 1.1). La versione 1.2 abolisce la proprietà privata produttiva (φ = 1): l’intero surplus distribuibile di 117 va al fondo, che paga 92 di paniere e 25 di dividendo e premi (dalla 1.5: reddito civico, premi e quote non maturate destinate a nuove imprese, §13.6) (§14.1).

### 9.3 Conto del fondo pubblico

    Fₜ₊₁ = Fₜ + CFₜ + Tₜ − Iₜʳᵉᵖ − Iₜⁿᵘᵒᵛᵒ − Dₜ − Sₜ

F è la liquidità/attività finanziaria netta del fondo; CF è la cassa netta delle imprese dopo costi operativi e prima degli investimenti, T sono entrate fiscali esterne a CF, D dividendi (dalla 1.5: reddito civico maturato, §11.3), S incentivi agli ideatori. I termini devono essere disgiunti per evitare doppio conteggio. In regime stazionario senza variazioni del fondo il totale delle entrate deve uguagliare gli esborsi.

Una economia può teoricamente riutilizzare uno stock monetario costante, ma questa identità da sola non è una dimostrazione di stabilità dei prezzi o di assenza di instabilità bancaria. Serve un vero modello stock-flow consistent con attività, passività, domanda di moneta e prezzi endogeni. [3]

Nota 1.1: il modello stock-flow consistente richiesto è sviluppato nella §13, con matrice dei bilanci, matrice delle transazioni e regole del fondo; questa equazione ne è la colonna del fondo.

### 9.4 Prezzi senza salari

    p = Aᵀ p + d + μ ⇒ p = (I − Aᵀ)⁻¹(d + μ)

Il costo primario d incorpora costi non salariali e rinnovo del capitale; μ indica il surplus netto unitario. Nell’esperimento di fusione, riducendo da 0,500 a 0,005 il termine primario dell’energia e lasciando invariati gli altri coefficienti, i prezzi indicativi cambiano così:

| Settore | Prezzo base | Prezzo con costo energetico primario ridotto | Variazione |
|---|---|---|---|
| Energia | 0,6332 | 0,0824 | −87,0% |
| Materiali | 0,5894 | 0,4931 | −16,3% |
| Alimenti | 0,5981 | 0,5067 | −15,3% |
| Servizi | 0,8147 | 0,7389 | −9,3% |
| Robot | 1,0309 | 0,8825 | −14,4% |

A parità di beni finali, il valore nominale dell’aggregato dell’esempio scende da 104,889 a 85,819. È una variazione del valore a prezzi correnti nel sistema di prezzi scelto, non un impoverimento materiale. Questo esercizio usa un secondo vettore di prezzi, diverso dalla convenzione unitaria usata per il bilancio di 141.

## 10. Le imprese: capitale pubblico e premio all’ideatore

L’imprenditore TEPS individua un bisogno e presenta un piano di business: prodotto, tecnologia, utenti, costi, prove di fattibilità, rischi e possibili sviluppi. Se il progetto viene approvato, riceve accesso a capitale e infrastrutture collettive. La gestione diretta è delegata alla IA operativa; l’ideatore partecipa indirettamente mediante proposte, consulenza e nuove idee.

### 10.1 Scelta dei progetti

    max Σⱼ zⱼ [a Uⱼ + b Gⱼ − c Rⱼ] ;     zⱼ ∈ {0,1}
    Σⱼ kⱼ zⱼ ≤ F_disp ;    M z ≤ risorse ;     sicurezzaⱼ = 1

U è il beneficio atteso per i cittadini, G il valore tecnico/scientifico delle innovazioni e R il rischio; i pesi a, b, c sono determinati da regole pubbliche. Le valutazioni provengono dal consesso di IA. Le prove di legalità e sicurezza sono vincoli, non punteggi compensabili.

### 10.2 Incentivo salariale incrementale

    Sᵢ,ₜ = S₀ + α max(0,Vᵢ,ₜ) + β max(0,Vᵢ,ₜ − Vᵢ,ₜ₋₁)
    Σᵢ Sᵢ,ₜ ≤ S̄ₜ ≤ surplus disponibile dopo b e rinnovo

Il compenso S non remunera l’attività produttiva necessaria alle fabbriche, bensì la definizione, il miglioramento e la dimostrata utilità dell’idea. V è il valore netto incrementale attribuibile all’idea, inclusi benefici sociali e risparmio di risorse. Restano da definire l’attribuzione causale, la durata dei premi, le co-invenzioni e una eventuale componente base S₀.

Nota 1.3: la forma lineare α max(0, V) è sostituita da un premio concavo e limitato, calcolato sul valore pubblico totale (economico più vantaggio sociale): §17.5.

### 10.3 L’incertezza delle idee rivoluzionarie

Lo scibile conosciuto è la base della competenza, ma non il limite alle invenzioni. Idee radicali devono poter essere sottoposte a verifica anche quando contraddicono conoscenze consolidate. Una proposta non dimostrata non equivale a una proposta confutata.

Il finanziamento può essere progressivo: piccoli budget per formulazione, simulazioni, prototipi e misure indipendenti; budget maggiori solo dopo test favorevoli. Un esperimento è razionale anche prima di approvare l’impresa se il suo valore atteso dell’informazione supera il costo del test.

    VEI = E_D[max(0, E[V|D] − C)] − max(0, E[V] − C) − C_test

### 10.4 Verifica di portafoglio [N]

Dieci progetti costano 10 unità ciascuno. Ognuno restituisce 60 unità con probabilità ipotetica 0,20 e zero altrimenti; gli esiti sono supposti indipendenti. Il valore atteso dei rientri è 10 × 0,20 × 60 = 120, contro 100 investiti. Tuttavia per recuperare almeno 100 occorrono due successi.

    Pr[perdita sul capitale] = Pr[X ≤ 1], X ~ Binomiale(10; 0,20)
    = (0,8)¹⁰ + 10 × 0,2 × (0,8)⁹ = 0,37581 ≈ 37,6%

L’aspettativa positiva non garantisce sicurezza del fondo. Occorre gestire correlazioni, liquidità, quote finanziabili per fase e concentrazione settoriale. I parametri sono inventati soltanto per mostrare il calcolo.

## 11. Competenza e democrazia ponderata universale

La popolazione di riferimento non è un gruppo ristretto di esperti: coincide con l’intera comunità umana ammessa all’ordinamento. Ogni persona può dimostrare e accrescere nel tempo la propria competenza. La competenza è la padronanza verificata dello scibile conosciuto nella disciplina; non dipende dal successo imprenditoriale, dalla ricchezza o dall’adesione alle idee prevalenti.

    Cᵢ,ₖ = [Σⱼ aⱼ,ₖ pᵢ,ⱼ,ₖ] / [Σⱼ aⱼ,ₖ]

Ogni pᵢ,ⱼ,ₖ misura, tramite test e dimostrazioni, comprensione e applicazione delle conoscenze note. I pesi aⱼ,ₖ rappresentano rilevanza e copertura della disciplina. Le IA valutatrici definiscono e aggiornano la mappa dello scibile con metodi verificabili.

### 11.1 Funzione del voto specialistico

    wᵢ(q) = 0, se Cᵢ(q) < τ(q)
    wᵢ(q) = 1 + (wₘₐₓ − 1)[Cᵢ(q) − τ(q)]/[1 − τ(q)], altrimenti
    Esito(q) = [Σᵢ wᵢ(q) vᵢ(q)] / [Σᵢ wᵢ(q)]

τ è la soglia di competenza per la decisione tecnica, wₘₐₓ il peso massimo relativo e vᵢ(q) il voto. In mancanza di partecipanti ammessi la decisione tecnica non può essere adottata con questa procedura. Per le decisioni che toccano i diritti universali, tutti hanno invece wᵢ(q) = 1.

Nota 1.5: l’esito si calcola solo sui voti espressi (favorevoli o contrari); le astensioni esplicite non entrano né al numeratore né al denominatore (§11.3).

Nota 1.4: dalla versione 1.4 questo caso non si presenta: se gli ammessi sono meno di N_min, la soglia scende automaticamente fino a includerne N_min (§17.8).

**Distinzione necessaria.** La TEPS ipotizza voti ponderati nelle decisioni tecniche e nella governance del fondo. Il voto politico previsto dalla Costituzione italiana è personale ed eguale (art. 48): la sostituzione del suffragio politico eguale con pesi differenziati non è compatibile con quel principio nell’ordinamento vigente. [5]

### 11.2 Conoscenza non significa conformismo

Essere competenti significa conoscere teorie, prove, limiti e possibilità applicative: non essere obbligati a ritenerle infallibili. Il consesso valuta separatamente (a) padronanza delle conoscenze, (b) validità della nuova proposta, (c) valore economico netto realizzato. Non esistono penalizzazioni automatiche della competenza per un’ipotesi smentita o non finanziata.

    Conoscenza Cᵢ,ₖ ≠ validità della proposta V(Pᵢ) ≠ incentivo Sᵢ

Nessuno può votare con peso specialistico sul finanziamento della propria impresa: l’interessato può presentare evidenze e rispondere alle contestazioni, ma non essere il decisore della propria pratica.

Nota 1.4: l’innovazione riconosciuta entra nel peso specialistico tramite il termine R della §17.7, con un tetto. Resta separata la valutazione della proposta (§11.2) e resta il divieto di votare sulla propria pratica.

**Integrazione 1.5 — §11.3 reddito civico e partecipazione alle votazioni**

### 11.3 Regola di partecipazione [P]

Il sistema convoca ciascun cittadino solo alle votazioni alle quali è abilitato: tutte quelle a voto eguale sui diritti universali e quelle tecniche nelle discipline in cui è ammesso (§11.1, §17.8). Per ogni cittadino i e periodo t:

    Nᵒᶠᵢ,ₜ = votazioni offerte (dovute e accessibili, al netto degli impedimenti riconosciuti)
    Nᵉˢᵢ,ₜ = votazioni eseguite (voto favorevole, contrario o astensione esplicita)
    [P] Pᵢ,ₜ = Nᵉˢᵢ,ₜ / Nᵒᶠᵢ,ₜ   se Nᵒᶠᵢ,ₜ > 0 ;   Pᵢ,ₜ = 1   se Nᵒᶠᵢ,ₜ = 0
    [P] Hᶜᵢ,ₜ = h̄ₜ · Pᵢ,ₜ        (reddito civico maturato; h̄ₜ reddito civico pieno, §13.6)

Esempio: con h̄ = 100 e 10 votazioni offerte, chi ne esegue 10 riceve 100; chi ne esegue 8 riceve 80; chi non ha convocazioni, o ha un impedimento riconosciuto per tutte, riceve 100.

Regole di applicazione:

- Contenuto del voto: non si controllano scelta, motivazione o qualità del voto. Favorevole, contrario e astensione esplicita contano allo stesso modo per Pᵢ,ₜ.
- Astensione ed esito: l’astensione esplicita conta per il reddito ma non entra nell’esito della §11.1, che si calcola sui soli voti espressi: Esito(q) = [Σᵢ∈E(q) wᵢ(q) vᵢ(q)] / [Σᵢ∈E(q) wᵢ(q)], con E(q) insieme di chi ha votato favorevole o contrario. Chi si astiene non sposta la decisione verso un valore neutro.
- Impedimenti riconosciuti: sono esclusi da Nᵒᶠ, senza bisogno di domanda, i casi accertati da registri pubblici (minore età, ricovero, disabilità certificata che impedisce il voto, guasto del sistema di voto, convocazione non recapitata). Per gli altri casi il cittadino presenta una giustificazione; finché il ricorso è pendente non si applica alcuna decurtazione. L’onere di provare che la convocazione è stata recapitata e accessibile spetta al sistema.
- Numero di votazioni: Nᵒᶠᵢ,ₜ ≤ N_max per periodo, con N_max fissato con voto eguale; ogni votazione resta aperta per un tempo minimo e su più canali. Il calcolo di P usa una finestra mobile che comprende almeno n_min convocazioni, così una singola assenza non azzera il reddito di un periodo.
- Segretezza: il registro di partecipazione (chi ha votato e in quale votazione) è separato dall’urna (contenuto dei voti, senza identità). A ogni convocazione il cittadino riceve una credenziale anonima monouso; nessun sistema conserva il collegamento fra credenziale e identità; registro e urna sono verificabili pubblicamente in modo indipendente. È la condizione perché il voto resti personale, libero e segreto (art. 48 [5]) pur essendo remunerato.
- Ricorsi e audit: ogni cittadino può verificare e contestare il proprio Pᵢ,ₜ; le regole di calcolo sono pubbliche e deterministiche come le altre regole del sistema (§12.3).
- Paniere: Pᵢ,ₜ non incide mai sul paniere essenziale in natura bₜ.

Perché la regola serve. Le garanzie sul potere dei gruppi (D-14) e la base minima di voto (D-15) sono calcolate sugli ammessi. Se gli ammessi non votano, le decisioni sono prese da pochi e quei limiti non valgono più. Remunerare la partecipazione rende effettiva la base di voto su cui la TEPS fa poggiare le regole del fondo e delle IA.

## 12. Consesso di IA isolate e indipendenza dei giudizi

Il riconoscimento delle competenze e l’esame delle iniziative sono affidati a molteplici agenti IA, con architetture e metodi differenti. Ogni agente riceve un dossier controllato, svolge un esame separato e firma il proprio rapporto; non può leggere i giudizi altrui, inviare messaggi agli altri agenti o modificarlo dopo la consegna.

    Oₐ = fₐ(E, Mₐ) ; Oₐ non usa Oᵦ come input diretto (a ≠ b)
    D = G(O₁, …, Oₘ), con G definita prima della valutazione

L’aggregatore applica una regola deterministica pubblica, eventualmente ponderata per affidabilità misurata nel settore. Anche gli agenti hanno un peso misurato: nessun valutatore acquisisce il potere totale. La ponderazione non deve diventare autoreferenziale: la prestazione degli agenti si misura con prove esterne, dati nuovi e calibratura degli errori, non con il grado di accordo con gli altri agenti.

### 12.1 Combinare punteggi e dissenso

    Ĉᵢ,ₖ = medianaₐ Cᵢ,ₖ⁽ᵃ⁾
    MADᵢ,ₖ = medianaₐ |Cᵢ,ₖ⁽ᵃ⁾ − Ĉᵢ,ₖ|
    C*ᵢ,ₖ = max(0, Ĉᵢ,ₖ − λ MADᵢ,ₖ)

La formula è un indice prudenziale per un insieme di giudizi; non è automaticamente una probabilità calibrata di competenza. Su esempi complessi occorrono prove standardizzate, analisi degli errori e valutazioni di incertezza.

### 12.2 Dimostrazione della maggioranza sotto indipendenza [D]

Se cinque agenti prendono decisioni binarie, hanno ciascuno probabilità di errore p = 0,20 ed errori statisticamente indipendenti e identicamente distribuiti, la maggioranza sbaglia quando almeno tre agenti sbagliano.

    Pr[errore maggioranza] = Σₖ₌₃⁵ C(5,k) pᵏ(1 − p)⁽⁵⁻ᵏ⁾
    = 10×0,2³×0,8² + 5×0,2⁴×0,8 + 0,2⁵
    = 0,05792 = 5,792%

La diminuzione da 20% a 5,792% deriva dalle ipotesi probabilistiche, non dal semplice divieto di dialogo. Se gli agenti usano dati identici errati o errori perfettamente correlati, l’errore del consesso può rimanere al 20%. Diversità dei metodi, isolamento tecnico e validazione esterna sono quindi tutti necessari.

### 12.3 Sicurezza, audit e responsabilità

- Canali di input isolati, rapporti firmati, audit log e verifica della versione dei modelli.
- Valutazioni mediante prove esterne, stress test con falsificazioni dei dati e misure della correlazione degli errori.
- Possibilità per ogni cittadino di sostenere ulteriori prove, contestare errori di dossier e richiedere nuova verifica.
- Regole pubbliche per sostituire modelli, gestire conflitti di interesse e impedire manipolazioni del registro delle competenze.
- Sorveglianza e strumenti di blocco per operazioni che violano legge o sicurezza; per sistemi ad alto rischio valgono anche gli obblighi applicabili di supervisione umana previsti dall’AI Act. [6–7]

## 13. Blocco stock-flow consistente con il fondo

La versione 1.0 lasciava aperto il test T3: un conto del fondo non basta a dimostrare che moneta, prezzi e domanda restino coerenti. Questa sezione chiude il circuito monetario con un modello stock-flow consistente (SFC) nello stile di Godley–Lavoie [3], unificato con la contabilità input-output della §9.1: ogni flusso ha una controparte e ogni flusso modifica uno stock.

Ipotesi di base dalla 1.1: energia da fusione abbondante e a costo trascurabile (§8). L’energia non è mai il settore vincolante; i vincoli e gli shock rilevanti riguardano materiali, robot, edifici e manutenzione.

### 13.1 Settori e strumenti

- Cittadini (h): ricevono il paniere essenziale in natura, il reddito civico (1.5, §11.3) e gli incentivi agli ideatori (insieme H); detengono moneta Mₕ e beni di proprietà personale.
- Imprese (i): interamente possedute dal fondo (φ = 1, versione 1.2); vendono la produzione, accantonano l’ammortamento per il rinnovo e distribuiscono il resto. Nessun salario.
- Fondo produttivo pubblico (f): riceve tutti i profitti; acquista il paniere b, paga H, finanzia investimenti aggiuntivi Iₓ e nuove imprese Iₙ; copre i disavanzi con anticipazioni A.
- Autorità monetaria (m): emette moneta come contropartita delle anticipazioni al fondo. Tasso nullo [A]: è un ente pubblico consolidabile con il fondo. Dalla 1.5 coincide con la banca pubblica automatica della §13.7; non esistono banche private.

Non esiste un settore di proprietari privati: la proprietà personale (abitazione, beni durevoli) non produce redditi d’impresa e non entra nelle matrici, se non tramite il canone di localizzazione della §15.3. Fondo, imprese e autorità monetaria sono gestiti da IA pubbliche secondo regole fissate con voto ponderato.

### 13.2 Matrice dei bilanci

| Strumento | Cittadini | Imprese | Fondo | Aut. monetaria | Σ |
|---|---|---|---|---|---|
| Moneta | +Mₕ |  |  | −M | 0 |
| Anticipazioni |  |  | −A | +A | 0 |
| Capitale fisico |  | +pK |  |  | +pK |
| Partecipazioni |  | −pK | +pK |  | 0 |
| Ricchezza netta | −Vₕ | 0 | −V_f | 0 | −pK |

*Tabella 2. Matrice dei bilanci (versione 1.2, φ = 1; dalla 1.5 la colonna «Aut. monetaria» è la banca pubblica automatica, §13.7). La colonna dell’autorità monetaria impone A = M = Mₕ: la moneta in circolazione è esattamente il debito netto del fondo verso l’autorità.*

### 13.3 Matrice delle transazioni

| Flusso | Cittadini | Imprese corr. | Imprese cap. | Fondo | Aut. mon. | Σ |
|---|---|---|---|---|---|---|
| Paniere essenziale |  | +pb (92) |  | −pb (−92) |  | 0 |
| Consumo discrezionale | −C (−25) | +C (25) |  |  |  | 0 |
| Rinnovo del capitale |  | +pIᵣ (24) | −pIᵣ (−24) |  |  | 0 |
| Ammortamento |  | −pδK (−24) | +pδK (24) |  |  | 0 |
| Profitti al fondo |  | −Π (−117) |  | +Π (117) |  | 0 |
| Reddito civico e premi | +H (25) |  |  | −H (−25) |  | 0 |
| Variazione moneta | −ΔMₕ (0) |  |  |  | +ΔM (0) | 0 |
| Variazione anticipazioni |  |  |  | +ΔA (0) | −ΔA (0) | 0 |
| Σ | 0 | 0 | 0 | 0 | 0 | 0 |

*Tabella 3. Matrice delle transazioni; fra parentesi lo stato stazionario con p = 1 e φ = 1. Dalla 1.5 la riga del reddito civico vale H = h̄ Σᵢ Pᵢ + S e, se Pᵢ < 1, compare il flusso pIₙ fra Fondo e Imprese cap. (§13.6). Ogni riga e ogni colonna somma a zero; nelle simulazioni la condizione Mₕ = A è verificata in ogni periodo con scarto massimo 3·10⁻¹³.*

### 13.4 Equazioni di comportamento

    Ȳₜ = ωₜ Kₜ / v ;   v = K₀ / Ȳ₀ = 234,889 / 155,1 = 1,5144

Ȳ₀ = 1,10 × 141 = 155,1 è la capacità in valore aggiunto coerente con le capacità settoriali della §4.2, tutte pari a 1,10 volte il fabbisogno. L’utilizzo normale ū = 141/155,1 = 0,909 lascia il 9% di capacità come riserva per gli shock.

    Cₜ = α₁ Hₜ + α₂ Mₕ,ₜ₋₁
    Πₜ = pₜ (Yₜ − Iᵣ,ₜ) ;       Iᵣ,ₜ = δ Kₜ
    ΔAₜ = pₜ b + pₜ Iₓ,ₜ + Hₜ − Πₜ
    pₜ = pₜ₋₁ [1 + κ (Yᵈₜ₋₁ / Ȳₜ₋₁ − ū)]
    Priorità di razionamento: b → Iᵣ → Iₓ → consumo discrezionale

Parametri: α₁ = 0,90 (la propensione cₕ della §5), α₂ = 0,10, κ = 0,5, δ = 0,1022. Iₓ = 0,5·max(0, K₀ − Kₜ) è il reinvestimento di recupero del fondo. Quando la domanda supera la capacità, la spesa non soddisfatta resta in moneta (risparmio forzato): è la scelta che preserva la coerenza stock-flusso.

### 13.5 Unificazione con le §5 e §9

Il reddito non è più un aggregato separato: è il valore aggiunto input-output Y = b + c + Iᵣ + Iₓ, pari a 141 nello stato normale. La quota θ della §5 vale 1 per costruzione: tutto il surplus netto va ai cittadini, in natura (pb) o in moneta (H). L’investimento è una decisione del fondo e delle imprese, non un dato autonomo. L’equazione del fondo della §9.3 è la colonna «Fondo» della Tabella 3.

## 14. Dimostrazioni sul blocco monetario

### 14.1 D-7 Chiusura del fondo [D]

In stato stazionario (p costante, ΔMₕ = 0, Iₓ = 0) i cittadini spendono il proprio reddito. Il fondo è in pareggio, con dividendo D ≥ 0 (dalla 1.5: reddito civico pieno h̄ ≥ 0, §14.5), se e solo se:

    [D] Π ≥ p b + S + p Iₙ

Dimostrazione. Dalla colonna del fondo, ΔA = pb + pIₙ + H − Π con H = D + S. Imponendo ΔA = 0 si ottiene D = Π − pb − S − pIₙ, e D ≥ 0 equivale alla condizione. Q.E.D.

Conseguenza numerica: Π = p(b + c) = 117 ≥ 92, con un margine di 25 per reddito civico, premi e nuove imprese. Il confronto con la versione 1.1 spiega la scelta: con φ = 0,75 il fondo incassava 87,75, meno del paniere (92), e serviva un canone del 78,6% sui profitti privati.

**Conseguenza economica.** Abolire la proprietà privata produttiva chiude il fondo per costruzione: non serve alcun canone e non esiste una classe di percettori di profitti. Il vincolo che resta è distributivo: il paniere essenziale assorbe il 79% del surplus distribuibile, quindi reddito civico (dividendo fino alla 1.4), premi agli ideatori e nuove imprese si contendono il restante 21% (25 unità).

### 14.2 D-8 Àncora nominale: perché serve una regola funzionale [D]

Con il fondo in pareggio (regola R0: H = entrate del fondo − pb − pIₓ) si ha ΔA = 0, quindi la moneta totale M = Mₕ resta costante. Sommando le colonne, ogni livello di Π soddisfa le condizioni di stato stazionario: i flussi non determinano il livello della domanda reale, che dipende dallo stock di moneta e dal livello dei prezzi. La Tabella 4 lo verifica partendo da stock monetari diversi (200 periodi).

| Moneta iniziale | R0, prezzi flessibili | R0, prezzi rigidi verso il basso | R1 funzionale |
|---|---|---|---|
| 0,6 × stazionaria | p 0,930 · u 0,909 · c 25,0 | p 1,000 · u 0,877 · c 20,0 | p 0,966 · u 0,909 · c 25,0 |
| 1,0 × stazionaria | p 1,000 · u 0,909 · c 25,0 | p 1,000 · u 0,909 · c 25,0 | p 1,000 · u 0,909 · c 25,0 |
| 1,6 × stazionaria | p 1,106 · u 0,909 · c 25,0 | p 1,273 · u 0,849 · c 15,7 | p 1,050 · u 0,909 · c 25,0 |

*Tabella 4. Livello finale dei prezzi p, utilizzo della capacità u e consumo discrezionale reale c. Risultato numerico [N] che illustra D-8.*

Con prezzi flessibili il sistema si riequilibra comunque, ma tramite deflazione o inflazione del 7–11%. Se i prezzi non scendono (rigidità verso il basso, realistica), la regola di pareggio lascia macchine inutilizzate: utilizzo 0,85–0,88 e consumo discrezionale 16–20 su 25 possibili. Anche un eccesso iniziale di moneta finisce in sottoutilizzo: l’inflazione iniziale erode i saldi reali e poi i prezzi non tornano indietro. È la trappola keynesiana in un’economia senza salari: il problema della §5 non scompare con l’automazione, si sposta dal salario allo stock monetario. La regola funzionale, nel senso di Lerner [8], la risolve:

    [D] R1: Hₜ = [entrate del fondo − pₜ b − pₜ Iₓ,ₜ] + λ pₜ (ū Ȳₜ − Yᵈₜ₋₁)

Il fondo varia la moneta anziché la produzione e riporta l’utilizzo a ū da ogni condizione iniziale.

Nota 1.5: R1 fissa il monte complessivo Hᴿ¹ₜ; da esso si ricava il reddito civico pieno h̄ₜ, ripartito secondo la partecipazione (§11.3, §13.6).

**Integrazione 1.5 — §13.6 quote non maturate, §14.5 D-16, §14.6 N-9**

### 13.6 Reddito civico nel blocco stock-flow [P]

La regola funzionale R1 (§14.2) fissa ogni periodo il monte dei trasferimenti Hᴿ¹ₜ come se tutti partecipassero. Da esso si ricavano:

    h̄ₜ = (Hᴿ¹ₜ − Sₜ) / N_pop                       reddito civico pieno per persona
    Hₜ = h̄ₜ Σᵢ Pᵢ,ₜ + Sₜ                            trasferimenti effettivamente pagati
    Qₜ = h̄ₜ Σᵢ (1 − Pᵢ,ₜ) = Hᴿ¹ₜ − Hₜ                quote non maturate

Le quote Qₜ restano al fondo ed entrano nella riserva per nuove imprese Fᴵ (la riserva per l’innovazione della §17.3):

    Fᴵₜ₊₁ = Fᴵₜ + Qₜ − pₜ Iₙ,ₜ ;    pₜ Iₙ,ₜ ≤ Fᴵₜ + Qₜ ;  Iₙ,ₜ limitato da progetti approvati a stadi e capacità fisica

La colonna del fondo diventa ΔAₜ = pₜbₜ + pₜIₓ,ₜ + pₜIₙ,ₜ + Hₜ − Πₜ. La spesa per nuove imprese segue le regole della §17.3 (finanziamento a stadi, arresto automatico): le quote non maturate non aprono un canale di spesa discrezionale. Se Fᴵ supera un tetto F̄ᴵ fissato con voto, l’eccedenza torna nel reddito civico pieno h̄ del periodo successivo.

### 14.5 D-16 Neutralità della domanda [D]

In stato stazionario (p = 1, Iₓ = 0, S = 0, Hᴿ¹ = 25), se le quote non maturate sono spese per intero in nuove imprese nello stesso periodo (Iₙ = Q), allora per qualunque partecipazione media P̄ = Σᵢ Pᵢ / N_pop:

    [D] Y = b + c + Iᵣ + Iₙ = 141 ;  Π = 117 ;  ΔA = 0 ;  A* = (1 − α₁)/α₂ · H* = 25 P̄

Dimostrazione. I trasferimenti pagati sono H = 25 P̄. In stato stazionario ΔMₕ = 0 dà Mₕ\* = (1 − α₁)/α₂ · H, quindi c = α₁H + α₂Mₕ\* = H = 25 P̄. La spesa per nuove imprese è Iₙ = Q = 25 (1 − P̄). La somma c + Iₙ = 25 non dipende da P̄: domanda, valore aggiunto e profitti restano quelli della 1.4. Dalla colonna del fondo ΔA = 92 + 25 (1 − P̄) + 25 P̄ − 117 = 0. Q.E.D.

Lettura: chi non vota non riduce la domanda complessiva, ne cambia la composizione: meno consumo discrezionale, più investimento in nuove imprese. Lo stock di moneta desiderato scende in proporzione (A\* = 25 P̄): nella transizione i cittadini spendono parte dei saldi e la moneta in eccesso rientra al fondo senza disavanzo.

Confronto: se Q restasse ferma nel fondo, a prezzi rigidi si avrebbe la trappola della D-8. Con P̄ = 0,9 la domanda scenderebbe da 141 a 138,5 e l’utilizzo da 0,909 a 0,893: macchine ferme e nessuna risorsa reale risparmiata.

### 14.6 N-9 Limite fisico della conversione in capitale [N]

Spostare Q dal consumo discrezionale agli investimenti cambia i settori che lavorano: meno alimenti e servizi, più robot. Calcolo con la matrice A e le capacità della §4.2, consumo discrezionale P̄·z, rinnovo 24 e convenzione 1:1 della §3 (il nuovo capitale è prodotto dal settore robot):

| Partecipazione media P̄ | Quote Q | Margine σ con spesa integrale di Q | Q assorbibile in un periodo |
|---|---|---|---|
| 1,00 | 0,00 | 1,100 | 3,04 |
| 0,90 | 2,50 | 1,021 (robot) | 3,19 |
| 0,75 | 6,25 | 0,922 (robot) | 3,41 |
| 0,50 | 12,50 | 0,793 (robot) | 3,77 |

*Tabella 13. Fattibilità della spesa delle quote non maturate in un solo periodo; fra parentesi il settore vincolante. Il paniere essenziale non è mai a rischio: σ < 1 indica soltanto che Q non può essere speso tutto nello stesso periodo.*

- Soglia: con P̄ ≥ 0,871 le quote non maturate (fino a 3,2 unità) sono convertite in capitale nello stesso periodo e vale D-16.
- Sotto la soglia: la parte di Q oltre il limite resta in Fᴵ ed è spesa nei periodi successivi. Nel frattempo la domanda è inferiore alla capacità e la regola R1 la compensa alzando h̄ nel periodo seguente: una parte delle quote torna così ai cittadini che votano. È un effetto di stabilizzazione, non una scelta di ripartizione.
- Il limite dipende dalla convenzione 1:1: con la matrice del capitale B della §16 (macchine 60%, edifici 30%, materiali 10%) il carico sul settore robot è minore e la soglia va ricalcolata (T9.2).
- Il nuovo capitale aumenta capacità e rinnovo futuri: se le nuove imprese non producono valore, il rinnovo aggiuntivo riduce il margine della condizione C1 nei periodi successivi. È lo stesso rischio della §17.3 e si gestisce con il finanziamento a stadi (T9.5).

**Integrazione 1.5 — §13.7 banca pubblica automatica, §14.7–14.11 D-17–D-21**

### 13.7 Nessuna banca privata: banca pubblica automatica [P]

[P] Nella TEPS 1.5 non esistono banche private: nessun soggetto privato può tenere depositi altrui, emettere moneta o altri mezzi di pagamento, o concedere prestiti a interesse. Le funzioni bancarie necessarie sono svolte da una banca pubblica automatica (BPA): un registro pubblico dei conti gestito da IA sotto la catena deterministica di controllo della §17, consolidato con il fondo e con l’autorità monetaria della §13.1.

| Funzione di una banca | Nella TEPS 1.5 | Dimostrazione |
|---|---|---|
| Conti e pagamenti | Registro della BPA con regola deterministica di trasferimento | D-17, D-18, D-19 |
| Creazione e distruzione di moneta | Solo il conto del fondo può andare in negativo, secondo R1 | D-17, D-9, N-3 |
| Credito alle imprese | Fondo, con finanziamento a stadi (§10, §17.3) | N-7 |
| Raccolta e impiego del risparmio | Non serve: il risparmio non rende e non finanzia imprese | D-20 |
| Valutazione del rischio | Consesso di IA indipendenti (§12) | D-6, N-7 |
| Credito al consumo | Non serve: paniere in natura e reddito civico | D-20 |
| Garanzia dei depositi e liquidità | Non serve: il deposito è la moneta stessa | D-18 |

Registro. I conti sono quelli dei cittadini h e il conto del fondo f; le imprese, interamente del fondo, sono conti consolidati nel fondo. Lo stato del registro è il vettore dei saldi mⱼ. Un’operazione è τ = (da, a, x):

    [P] valida(τ) ⇔ x > 0  e  ( m_da ≥ x  oppure  da = f )
    [P] esegui(τ):  m_da ← m_da − x ;   m_a ← m_a + x

Il conto del fondo può andare in negativo solo per i pagamenti previsti dalle sue regole (paniere, reddito civico, premi, investimenti: §13.4, §13.6, R1); i conti dei cittadini mai. Contante eventuale è emesso uno a uno contro il saldo e non cambia le proprietà seguenti.

### 14.7 D-17 Conservazione: la moneta è il saldo negativo del fondo [D]

    [D] Σⱼ mⱼ,ₜ = 0 per ogni t ;     Mₜ = Σₕ mₕ,ₜ = −m_f,ₜ = Aₜ

Dimostrazione. All’inizio la somma dei saldi è zero. Ogni operazione eseguita toglie x a un conto e aggiunge x a un altro, quindi la somma resta zero dopo ogni operazione (induzione sul numero di operazioni). I saldi dei cittadini sono non negativi, quindi l’unico conto che può essere negativo è quello del fondo, e la moneta detenuta dai cittadini è esattamente il debito del fondo, cioè le anticipazioni A della Tabella 2. Q.E.D.

- Nessuna moneta nasce fuori dal fondo: senza banche private non esiste moneta creata dal credito privato, e l’unica leva monetaria è la regola R1.
- La condizione Mₕ = A della Tabella 2 non è più un risultato da verificare ma una proprietà del registro; nelle simulazioni N-10 lo scarto è al massimo 10⁻¹³, cioè arrotondamento numerico.
- In stato stazionario lo stock di moneta è quello che i cittadini desiderano detenere: A\* = (1 − α₁)/α₂ · H\* = 25 (D-9).

### 14.8 D-18 Nessuna corsa agli sportelli [D]

In una banca a riserva frazionaria con depositi D e riserve R = r·D, con r < 1, le richieste di prelievo simultanee superiori a R non possono essere pagate tutte: l’esito di ogni depositante dipende da cosa fanno gli altri. Nella BPA invece:

    [D] l’esecuzione di τ dipende solo da m_da: la condizione valida(τ) non contiene i saldi di altri conti

Dimostrazione. Segue dalla definizione di valida(τ). Un insieme di operazioni di cittadini in cui le uscite di ciascun conto non superano il suo saldo è eseguibile per intero e in qualunque ordine, perché ogni operazione riduce soltanto il conto che la emette. Il rapporto di copertura è 1: il deposito non è un credito verso la banca da convertire in moneta, è la moneta. Q.E.D.

Conseguenza: non esistono insolvenza bancaria, contagio fra depositanti, garanzia dei depositi o prestatore di ultima istanza. Il solo rischio monetario residuo è quello già studiato: un’emissione del fondo superiore alla moneta desiderata, che produce inflazione (§15, condizione C4).

### 14.9 D-19 Esecuzione deterministica verificabile [D]

Lo stato del registro evolve con una funzione deterministica e pubblica, Sₜ₊₁ = Φ(Sₜ, τ₁, …, τ_k). La BPA è calcolata da n sistemi indipendenti (architetture, codice e operatori diversi, come gli agenti della §12); un nuovo stato è accettato solo se la maggioranza dei sistemi produce lo stesso stato, altrimenti il registro si arresta e ricalcola. Se q è la probabilità di guasto di un singolo sistema e i guasti sono indipendenti:

    [D] Pr[stato errato accettato] ≤ Σ_{j > n/2} C(n, j) qʲ (1 − q)ⁿ⁻ʲ

Dimostrazione. Φ è deterministica, quindi tutti i sistemi corretti producono esattamente lo stesso stato. Uno stato errato può essere accettato solo se una maggioranza di sistemi è guasta e produce lo stesso stato errato; la probabilità che una maggioranza sia guasta è la somma binomiale, che è quindi un limite superiore. Q.E.D.

Numeri: con q = 0,01 il limite vale 3,0·10⁻⁴ per n = 3, 9,9·10⁻⁶ per n = 5 e 3,4·10⁻⁷ per n = 7; con q = 0,001 e n = 5 vale 1,0·10⁻⁸. Rispetto alla D-6 il controllo è più forte: fra sistemi corretti non esiste disaccordo legittimo, quindi ogni differenza segnala un guasto, e chiunque può ricalcolare lo stato dai registri pubblici delle operazioni (audit esatto, non statistico). La garanzia richiede guasti indipendenti: i guasti comuni (stesso codice errato) si riducono con implementazioni diverse della stessa Φ. Verifica numerica (`simulazioni/teps_1_5_banca_pubblica.py`): su 200.000 operazioni casuali fra 1.000 conti le identità contabili della D-17 e la condizione della D-18 sono rispettati a ogni operazione; nel caso peggiore in cui tutti i sistemi guasti producono lo stesso stato errato, la frequenza osservata coincide con il limite (n = 3, q = 0,05: limite 7,25·10⁻³, osservato 7,24·10⁻³; n = 5, q = 0,05: 1,16·10⁻³ e 1,15·10⁻³).

### 14.10 D-20 Il prestito privato a interesse è incompatibile con la D-12 [D]

Se una persona potesse prestare al tasso r > 0, il suo patrimonio avrebbe un rendimento:

    Wᵢ,ₜ₊₁ = (1 + r) Wᵢ,ₜ + h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ − Cᵢ,ₜ

    [D] con r > 0 e Wᵢ,₀ > 0 il limite Wᵢ,T ≤ Wᵢ,₀ + Σₜ (h̄ₜ + S_max) è violato per T abbastanza grande

Dimostrazione. Con consumi nulli Wᵢ,T ≥ (1 + r)ᵀ Wᵢ,₀. Il primo membro cresce in modo esponenziale in T, il limite della D-12 e D-13 al più in modo lineare (h̄ₜ e S_max sono limitati), quindi esiste T oltre il quale il limite è superato. Con r = 0 vale la D-12. Q.E.D.

- Il divieto di banche private e di prestiti a interesse è la condizione matematica perché il patrimonio non generi patrimonio (§17.4), non una scelta aggiuntiva.
- Senza interesse nessun privato ha motivo di prestare: l’offerta di credito privato è nulla anche indipendentemente dal divieto. Un prestito gratuito fra persone è un semplice trasferimento fra conti e non crea moneta (D-17).
- Il credito al consumo non serve: il paniere essenziale è in natura, e con r = 0 un prestito sposta il consumo nel tempo senza aumentarlo, perché il vincolo Σₜ Cᵢ,ₜ ≤ Wᵢ,₀ + Σₜ (h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ) resta lo stesso; con r > 0 lo ridurrebbe.

### 14.11 D-21 Il sistema monetario senza banche private funziona [D/N]

Con il registro della §13.7, la regola R1 con 0 < λ < λ_max (C2) e la chiusura del fondo (C1):

    (a) in ogni periodo la moneta coincide con il debito del fondo, Mₜ = Aₜ (D-17);
    (b) ogni pagamento coperto dal saldo è eseguito, indipendentemente dal comportamento degli altri (D-18);
    (c) lo stock di moneta converge a quello desiderato, A* = (1 − α₁)/α₂ · H* = 25 (D-9), e lo stato stazionario è localmente stabile (N-3);
    (d) uno stato errato del registro è accettato con probabilità non superiore al limite della D-19, e ogni stato è ricalcolabile da chiunque;
    (e) i patrimoni personali restano limitati, perché non esiste rendimento sul patrimonio (D-12, D-20).

Dimostrazione. (a), (b), (d) ed (e) sono D-17, D-18, D-19 e D-20; (c) è D-9 per lo stato stazionario e N-3 per la stabilità locale. Q.E.D.

Portata: (a), (b), (d) ed (e) sono dimostrazioni esatte che valgono per costruzione delle regole. (c) è locale e numerica come nella 1.4: la stabilità globale non è dimostrata. Restano due rischi, già trattati nel modello: l’emissione eccessiva del fondo (inflazione, C4) e i guasti comuni dei sistemi che calcolano il registro (D-19). Un sistema di IA e regole deterministiche può quindi svolgere tutte le funzioni bancarie necessarie alla TEPS; le funzioni delle banche private che non svolge (credito a interesse, trasformazione delle scadenze, creazione privata di moneta) nella TEPS non hanno oggetto.

### 14.3 D-9 Il debito del fondo è moneta detenuta volontariamente [D]

In stato stazionario ΔMₕ = 0 implica Mₕ\* = (1 − α₁)/α₂ · H\*. Poiché A = M (Tabella 2):

    [D] A* = (1 − α₁)/α₂ · H* = 25

Il disavanzo cumulato del fondo non esplode: converge allo stock di moneta che i cittadini desiderano detenere, 0,18 volte il prodotto nominale (25/141, valore ritrovato in tutte le simulazioni). Nella versione 1.1 era 62,5: la differenza era la tesaurizzazione dei proprietari privati, che nella 1.2 non esistono. Non esiste un problema di debito separato dalla domanda di moneta; il rischio reale è l’inflazione quando il fondo emette più moneta di quella desiderata (§15).

### 14.4 N-3 Stabilità locale della regola funzionale [N]

Si linearizza la mappa di un periodo (moneta, prezzi, entrate del fondo, domanda, trasferimenti) attorno allo stato stazionario. Un autovalore vale esattamente 1: il livello dei prezzi ha radice unitaria, cioè dopo uno shock l’inflazione torna a zero ma i prezzi non tornano al livello iniziale. Tutti gli altri autovalori sono minori di 1 in modulo per:

    [N] 0 ≤ λ < λ_max(κ): λ_max = 1,92 (κ = 0,25) ; 1,73 (κ = 0,5) ; 1,35 (κ = 1)

Come nella §6, un regolatore troppo reattivo destabilizza, e più i prezzi sono reattivi più il fondo deve essere prudente. Nelle simulazioni si usa λ = 0,5. Il risultato è numerico, locale e condizionato ai parametri.

## 15. Prezzi, razionamento e shock post-fusione

Con l’energia fuori dai vincoli, la prova di stress del modello monetario usa uno shock di capacità aggregata del −20% per cinque periodi (10–14), interpretabile come guasto della filiera dei materiali o del parco robot. Paniere e rinnovo (116) restano producibili sulla capacità ridotta (124,1); il consumo discrezionale no. Si confrontano sei regole del fondo.

### 15.1 N-4 Sei regole del fondo a confronto [N]

| Regola del fondo | Inflazione max per periodo | Prezzi massimi | Prezzi finali | Discrezionale reale minimo | Quota min. di domanda servita |
|---|---|---|---|---|---|
| R0 pareggio di bilancio | 11,4% | 1,249 | 1,017 | 3,31 | 0,32 |
| R1 funzionale (λ = 0,5) | 6,3% | 1,158 | 1,068 | 1,79 | 0,66 |
| R1b anticipata, riserva conservata | 2,3% | 1,109 | 1,109 | 1,51 | 1,00 |
| R1c anticipata, riserva usata | 4,6% | 1,249 | 1,249 | 8,08 | 1,00 |
| R2 dividendo nominale fisso | 11,4% | 1,648 | 1,035 | 8,08 | 0,32 |
| R3 promessa reale finanziata con moneta | 13,1% | 2,043 | 2,043 | 8,08 | 0,28 |

*Tabella 5. Shock di capacità −20% per cinque periodi, 60 periodi simulati. R1b e R1c calcolano in anticipo il dividendo che porta la domanda pianificata all’obiettivo: R1b mantiene la riserva di capacità anche nello shock, R1c la usa (obiettivo = produzione normale, se possibile). La quota servita è il rapporto fra consumo discrezionale ottenuto e pianificato.*

![](figure/figura_3.png)

*Figura 3. Livello dei prezzi e consumo discrezionale reale con le sei regole del fondo. Banda: periodi di shock. Simulazioni, non previsioni.*

- Limite fisico: durante lo shock il consumo discrezionale non può superare 8,08 unità (124,1 di capacità meno 116 di paniere e rinnovo) con qualunque regola. È un limite fisico, non monetario.
- Moneta e scarsità: promettere lo stesso consumo reale e finanziarlo con moneta (R3) non compra un’unità in più rispetto a R2 (8,08), ma raddoppia i prezzi (+104%) in modo permanente. È la verifica quantitativa della §7.1.
- Riserva o prezzi: conservare la riserva (R1b) tiene l’inflazione di punta al 2,3% ma lascia capacità inutilizzata (consumo 1,5 su 8,1 possibili); usarla (R1c) consegna tutto il consumo possibile senza code (quota servita 1) con inflazione del 4,6% per periodo e prezzi +25%. Nessuna delle due domina: l’obiettivo durante gli shock è un parametro da fissare con voto ponderato.
- Effetto dell’abolizione della proprietà privata: rispetto alla versione 1.1 l’inflazione di punta della regola anticipata si dimezza (4,6% → 2,3%): era generata dagli stock monetari dei proprietari privati, che il fondo non controllava e che nella 1.2 non esistono. Quella residua dipende dalla moneta dei cittadini e dal fatto che paniere e rinnovo superano l’utilizzo normale della capacità ridotta.
- Regole passive: le regole che non reagiscono alla capacità (R0, R2, R3) razionano con code e risparmio forzato (quota servita 0,28–0,32) e producono un’inflazione di punta dell’11–13%.

### 15.2 N-5 Prezzi settoriali come segnale di scarsità [N]

Il paniere b resta in natura; il consumo discrezionale si acquista a prezzi. Quando un settore è al limite, il suo margine μⱼ diventa una rendita di scarsità, incassata dal fondo e restituita come dividendo:

    p = (I − Aᵀ)⁻¹(d + μ) ;        μⱼ = μ̄ⱼ + rⱼ , rⱼ ≥ 0 tale che xⱼ ≤ x̄ⱼ

Esperimento post-fusione: prezzi di base della §9.4 con costo primario dell’energia 0,005; capacità dei materiali −15%; domanda discrezionale con elasticità al prezzo 1,5; paniere e rinnovo prioritari.

| Settore | Prezzo post-fusione | Prezzo con scarsità di materiali | Variazione |
|---|---|---|---|
| Energia | 0,0824 | 0,2443 | +196,5% |
| Materiali | 0,4931 | 2,5915 | +425,6% |
| Alimenti | 0,5067 | 0,8658 | +70,9% |
| Servizi | 0,7389 | 0,9725 | +31,6% |
| Robot | 0,8825 | 1,4955 | +69,5% |

*Tabella 6. Prezzi settoriali con rendita di scarsità sui materiali (rendita di equilibrio 1,88 per unità).*

Il razionamento tramite prezzi serve il 57,6% del consumo discrezionale, contro il 55,4% del razionamento proporzionale per quantità. Alloca un po’ meglio perché sposta la domanda verso i beni meno intensivi in materiali (servizi). Il costo è un prezzo dei materiali cinque volte più alto e una rendita di scarsità di 45,5 unità a prezzi correnti: con capitale privato sarebbe un trasferimento enorme ai proprietari, nella TEPS 1.2 (capitale interamente pubblico) va al fondo per costruzione. Anche l’energia triplica di prezzo, perché i suoi impianti usano materiali, ma resta di gran lunga il bene più economico (0,24): la premessa post-fusione regge anche nello shock.

Lezione: con tecnologia a coefficienti fissi i prezzi devono fare tutto il lavoro tramite la sola domanda finale, e oscillano molto. Segnali moderati richiedono sostituibilità tecnica fra input, assente nella matrice A: per questo il test T4 resta parzialmente aperto.

### 15.3 Rendite su risorse non riproducibili [P]

Terreni, siti, giacimenti, frequenze e localizzazioni urbane non sono prodotti dalle macchine, e la fusione non li moltiplica. Nella 1.2 quelle a uso produttivo appartengono al fondo. Resta la rendita delle localizzazioni a uso personale (un’abitazione in centro vale più di una in periferia). Regola: un canone di localizzazione pari alla rendita di mercato del suolo, incassato dal fondo, nello spirito di Henry George [11]. Contabilmente entra fra le entrate del fondo; economicamente impedisce che la proprietà personale diventi una fonte di rendita. Per i beni posizionali, per definizione non moltiplicabili, l’accesso va regolato con aste o turnazioni, non con il paniere.

## 16. Capitale con matrice dei coefficienti

La versione 1.0 assumeva che un’unità prodotta dal settore robot diventasse un’unità di capacità in qualunque settore (rapporto 1:1). La 1.1 introduce una matrice del capitale B, nella tradizione del modello dinamico di Leontief [13]: Bᵢⱼ è la quantità di bene capitale del settore i necessaria per un’unità di capacità del settore j.

    Bᵢⱼ = κⱼ · sᵢ ;     s = (E 0 ; M 0,10 ; F 0 ; S 0,30 ; R 0,60)
    [A] rinnovo stazionario r = Δ B x̄ ;                 fattibilità (I − A)⁻¹(b + q z + r) ≤ x̄

Il vettore s indica la composizione del capitale: macchine (R) 60%, edifici e infrastrutture (S) 30%, materiali (M) 10%. κⱼ è l’intensità di capitale per unità di capacità e Δ la matrice diagonale dei deprezzamenti. Premessa post-fusione: capacità energetica ×3 e impianti energetici che non gravano sul rinnovo (κ_E = 0), coerentemente con l’ipotesi che l’energia non sia più un problema.

| Configurazione | Rinnovo annuo | Margine σ (b + rinnovo) | Quota q massima |
|---|---|---|---|
| v1.0 pre-fusione, 1:1 tutto robot | 24,0 | 1,155 | 1,00 |
| Fusione, 1:1 senza capitale energetico | 19,7 | 1,324 | 1,00 |
| Matrice B, intensità uniforme 1,0 | 19,7 | 1,321 | 0,97 |
| Intensità uniforme 1,5 | 29,5 | 1,164 | 0,76 |
| Intensità uniforme 2,0 | 39,3 | 1,023 | 0,17 |
| Intensità uniforme 2,5 | 49,2 | 0,912 | non fattibile |
| Settoriale (M 1,5; F 1,2; S 2,5; R 1,2), δ 10,2% | 32,0 | 1,124 | 0,70 |
| Settoriale, δ differenziato (M 5%, S 3%, R 10%) | 23,2 | 1,264 | 1,00 |
| δ differenziato, intensità uniforme 2,0 | 28,5 | 1,167 | 1,00 |
| δ differenziato, intensità uniforme 2,5 | 35,6 | 0,978 | non fattibile |

*Tabella 7. Fattibilità con matrice del capitale; «non fattibile» indica che nemmeno paniere e rinnovo sono producibili (σ < 1).*

![](figure/figura_4.png)

*Figura 4. Quota massima di consumo discrezionale al crescere dell’intensità di capitale non energetico. Bande: regione in cui il paniere essenziale non è producibile.*

Soglie: con deprezzamento uniforme il paniere essenziale cessa di essere producibile oltre un’intensità di capitale 2,09 volte quella della 1.0; con vite utili realistiche la soglia sale a 2,44. Se gli impianti a fusione dovessero essere rinnovati come ogni altro capitale, la soglia scenderebbe a 1,72: l’ipotesi «energia senza problemi» vale circa il 20% di margine sul capitale.

Lettura: la fusione sposta il vincolo, non lo elimina. Dopo la fusione il collo di bottiglia è il capitale fisico non energetico (macchine, edifici, materiali). Il modello sta in piedi se l’intensità di capitale per unità di capacità resta sotto circa due volte quella ipotizzata e le strutture hanno vite utili lunghe. Il parametro tecnologico decisivo da calibrare (T1–T2) è la produttività con cui i robot producono robot (riga R di A e di B).

## 17. Incentivi, proprietà personale, premi in denaro e in peso, rischio del fondo

Nella versione 1.2 la gestione del fondo non è affidata a organi umani: le persone votano, con il peso della §11, solo parametri e regole; esecuzione, valutazioni e verifiche sono svolte da IA pubbliche con regole deterministiche e pubbliche, e anche i sistemi che producono gli agenti sono pubblici. Ne seguono due conseguenze, formalizzate sotto: il salvataggio discrezionale dei progetti (la fonte classica del vincolo di bilancio soffice) è escluso per costruzione, e la manipolazione non ha un canale se i dati di valutazione sono prodotti da sistemi pubblici. Restano due rischi che non dipendono da chi governa: il rumore di misura e l’errore di stima comune ai modelli.

    [P] Architettura di controllo: più IA indipendenti decidono separatamente; un sistema deterministico di controllo dei processi applica la catena di regole pubbliche e blocca ogni azione fuori mandato

Con più IA indipendenti non esiste un punto unico di guasto e nessuna IA può prevalere: una deviazione isolata è messa in minoranza dall’aggregatore (§12.2) e, in ogni caso, l’azione passa solo se rispetta la catena deterministica di controllo, che nessuna IA può modificare. La condizione che rende vera questa garanzia è l’indipendenza effettiva degli errori: modelli addestrati su dati o metodi comuni sbagliano insieme, e allora la maggioranza non corregge (D-6). L’indipendenza va quindi trattata come requisito misurabile: correlazione degli errori stimata su casi di verifica pubblici, con sostituzione dei modelli che la superano.

### 17.1 D-10 Manipolazione delle metriche [D]

L’ideatore può gonfiare il valore verificato V̂ di un importo m (dati selezionati, attribuzione indebita). Se la manipolazione viene scoperta con probabilità π, dal consesso o dall’audit ex post, e in tal caso deve restituire k volte il premio indebito, il guadagno atteso è:

    E[guadagno] = α m [(1 − π) − π k]

    [D] Nessun incentivo a manipolare ⇔ k ≥ (1 − π) / π

Dimostrazione. Il guadagno è non positivo se e solo se il termine fra parentesi lo è, cioè k ≥ (1 − π)/π. Q.E.D. Numeri: con π = 0,5 serve la restituzione integrale (k ≥ 1); con π = 0,8 basta k ≥ 0,25; con π = 0,2 servirebbe una sanzione quadrupla (k ≥ 4) [12].

    [A] Verifica alla fonte: i dati su cui si misura V sono prodotti da sistemi pubblici (sensori, registri, contabilità automatica), non forniti dall’ideatore

Sotto questa ipotesi la manipolazione non ha un canale: π → 1 e la condizione diventa k ≥ 0, cioè manipolare non conviene per nessun valore di k. È la formalizzazione della scelta istituzionale della TEPS 1.2: agenti e sistemi di produzione degli agenti pubblici, verifica deterministica. L’ipotesi va mantenuta nel disegno: dove una parte dell’evidenza è ancora fornita dal proponente (prototipi, dati sperimentali propri), il premio va differito finché V non è confermato da dati pubblici.

### 17.2 D-11 Rendita da rumore della formula max(0, ·) [D]

Questo non è un problema di manipolazione ma di misura, e vale anche con sistemi pubblici perfettamente onesti: il valore causale di un’idea si stima sempre con un errore. Nella §10.2 il premio è S = α max(0, V). Se V è misurato con errore ε ~ N(0, σ²), anche un’idea di valore nullo riceve in media:

    [D] E[α max(0, ε)] = α σ / √(2π) ≈ 0,399 α σ

Con una soglia h = zσ (premio solo sulla parte di V̂ oltre h) la rendita da rumore diventa α σ [φ(z) − z(1 − Φ(z))], con φ e Φ densità e funzione di ripartizione normali standard.

| Soglia z | Premio atteso a un’idea nulla | Premio atteso a un’idea con V = σ |
|---|---|---|
| 0 | 0,399 ασ | 1,083 ασ |
| 1 | 0,083 ασ | 0,399 ασ |
| 1,645 | 0,021 ασ | 0,157 ασ |
| 2 | 0,008 ασ | 0,083 ασ |

*Tabella 8. Effetto della soglia sul premio indebito e sul premio alle idee buone.*

La soglia riduce la rendita da rumore ma anche il premio delle idee buone. Una soglia z = 1 elimina il 79% della rendita indebita e conserva il 37% del premio alle idee buone, che si compensa alzando α. L’alternativa è pagare sul valore realizzato ex post (premio differito), che riduce σ.

### 17.3 N-7 Rischio del fondo: finanziamento a stadi ed errore di stima comune [N]

Con la gestione per regole il rischio del fondo non è politico ma di stima: anche IA pubbliche e oneste possono sovrastimare in modo coordinato la probabilità di successo di una classe di progetti, se condividono dati o metodi (§12.2). La prova seguente misura quanto conta se l’indipendenza viene meno; con indipendenza effettiva il caso «ottimisti» non si presenta e resta solo il rischio di liquidità.

Modello: ogni periodo il fondo spende un budget B in progetti da 0,5. Ogni progetto è «buono» con probabilità 0,25 e, se buono, riesce con probabilità 0,8 (successo complessivo 0,2); il successo rende 6 volte il costo dopo 5 periodi, come nella §10.4. Riserva iniziale 20, reintegro 1 per periodo. «Rovina» significa riserva negativa: il fondo dovrebbe tagliare il dividendo o emettere moneta. Si confrontano il finanziamento in un’unica soluzione e quello a stadi (un test al 20% del costo, sensibilità 0,9, falsi positivi 0,2). I valutatori possono essere corretti oppure ottimisti del 30%, con un errore di stima comune a tutto il consesso; la correlazione degli esiti è ρ = 0,5. Sono simulati 20.000 percorsi di 100 periodi.

| Budget B per periodo | Unica soluzione, valutatori corretti | Unica soluzione, ottimisti 30% | A stadi, corretti | A stadi, ottimisti 30% |
|---|---|---|---|---|
| 2,5 | 0,02% | 4,1% | 0,0% | 0,0% |
| 5 | 49,3% | 91,0% | 0,0% | 0,03% |
| 10 | 100% | 100% | 55,4% | 69,3% |

*Tabella 9. Probabilità di rovina della riserva per l’innovazione in 100 periodi. Parametri inventati, solo dimostrativi.*

- Liquidità: anche con rendimento atteso positivo (1,2), un budget pari a 5 volte il reintegro rovina la riserva in metà dei casi. Il problema è la liquidità (rientri ritardati), non il valore atteso.
- Errore sistematico: un errore di stima comune a tutto il consesso (non una manipolazione) trasforma un budget prudente in rovina quasi certa (91%) se il finanziamento è in un’unica soluzione.
- Stadi: il finanziamento a stadi è la regola più efficace: con B = 5 porta la rovina da 49–91% a circa 0%, perché il test ferma i progetti cattivi prima della spesa principale. La correlazione degli esiti ha un effetto secondario in questo esempio (47% → 49%); l’errore sistematico dei valutatori pesa molto di più.

    [P] Vincolo di bilancio duro: budget dimensionato su riserva e tempi di rientro; stadi obbligatori; arresto automatico alla soglia dichiarata; regole modificabili solo con voto ponderato sui parametri, mai caso per caso

Il vincolo di bilancio «soffice» descritto da Kornai [9] nasce dal salvataggio discrezionale dei progetti in difficoltà da parte di decisori umani. Nella TEPS 1.2 questo canale è chiuso per costruzione: l’IA esegue l’arresto senza discrezionalità e il voto ponderato agisce solo sulle regole generali. Il rischio residuo è di stima, e la difesa è il finanziamento a stadi.

### 17.4 D-12 Incentivi e proprietà personale [D]

Nella versione 1.2 l’unica fonte di reddito oltre al dividendo universale (dalla 1.5 il reddito civico h̄ₜPᵢ,ₜ, §11.3) è il premio S per il valore creato dal pensiero, dalla creatività e dall’iniziativa per il bene pubblico: è il solo canale da cui cresce la proprietà personale. Il patrimonio personale Wᵢ (moneta e beni a uso personale) evolve senza alcun rendimento, perché la moneta non paga interessi e la proprietà personale non può essere impiegata nella produzione:

    Wᵢ,ₜ₊₁ = Wᵢ,ₜ + h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ − Cᵢ,ₜ ,   Cᵢ,ₜ ≥ 0   (1.5: h̄ₜ Pᵢ,ₜ al posto di Dₜ)
    [D] Wᵢ,T ≤ Wᵢ,₀ + Σₜ (h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ)

Dimostrazione. Sommando l’equazione da 0 a T − 1 si ottiene Wᵢ,T = Wᵢ,₀ + Σₜ(h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ) − Σₜ Cᵢ,ₜ, e i consumi sono non negativi. Q.E.D.

- Disuguaglianza limitata: chi crea più valore pubblico accumula più proprietà personale, ma il patrimonio non genera altro patrimonio. Manca il termine r·W che nelle economie capitalistiche fa crescere le disuguaglianze da sole: la distanza fra due persone è al massimo la differenza fra i premi ricevuti.
- Costo degli incentivi: con b = 92 il margine di 25 va diviso fra reddito civico (dividendo D fino alla 1.4), premi S e nuove imprese Iₙ (D-7). Ogni unità ai premi è un’unità in meno al reddito civico di tutti: la quota dei premi è un parametro di voto ponderato, e decide quanto è forte l’incentivo.
- Forza degli incentivi: il premio è un incentivo solo se compra qualcosa di scarso: il consumo discrezionale e le localizzazioni migliori (§15.3). Più il paniere è ampio, meno il premio monetario conta, e più contano le leve non monetarie: riconoscimento e accesso al capitale del fondo per nuove idee.
- Eredità: l’eredità della proprietà personale è l’unico canale con cui un patrimonio passa fra generazioni senza nuovo valore creato; la sua disciplina è una scelta di voto.

### 17.5 D-13 Forma del premio: limitato e sociale [D]

Due scelte di disegno della versione 1.3. Primo, il premio non cresce in proporzione al valore prodotto: ha un limite. Il premio ha due componenti, entrambe con un tetto: quella monetaria (questa sezione) e quella in peso sulle competenze (§17.7). Secondo, il valore che si premia non è solo economico ma include il vantaggio sociale. Il valore pubblico totale di un’idea è:

    Vᵗᵒᵗ = Vᵉᶜ + Σₖ ωₖ Iₖ

Vᵉᶜ è il valore economico netto aggiuntivo (risorse risparmiate, consumo reso possibile). Iₖ sono indicatori sociali in unità fisiche, misurati da sistemi pubblici: anni di vita in salute guadagnati, tempo liberato, inquinamento evitato, accesso e inclusione, conoscenza resa pubblica. ωₖ sono i coefficienti che convertono ogni indicatore in valore. Gli Iₖ contano solo gli effetti non già compresi in Vᵉᶜ (beni pubblici ed esternalità), per non contare due volte lo stesso beneficio. Un danno sociale entra con segno negativo: un’idea molto redditizia ma dannosa può avere Vᵗᵒᵗ ≤ 0 e nessun premio.

    [P] Valutazione algoritmica, non opinabile: Iₖ misurati da sistemi pubblici; ωₖ calcolati da modelli pubblici di conversione in un’unica unità comune

Il vantaggio sociale non è affidato a giudizi caso per caso. Ogni indicatore è convertito, con modelli pubblici e deterministici, in una sola unità fisica comune: il tempo di vita umana in salute guadagnato o liberato. Il tempo liberato si conta direttamente; la salute in anni di vita in salute; l’inquinamento evitato tramite modelli dose-risposta che stimano gli effetti sulla salute; l’accesso a un servizio tramite il tempo e la salute che fa guadagnare a chi prima ne era escluso. I coefficienti ωₖ sono quindi output di modelli verificabili, non pesi votati. L’unica scelta normativa è l’unità comune stessa, fissata una volta con voto eguale (§11.1) a livello costituzionale; i modelli di conversione sono pubblici, versionati e riproducibili da chiunque. Limite da dichiarare: i modelli di conversione hanno un’incertezza propria, che si somma all’errore di misura della §17.2 e va trattata allo stesso modo (soglia o premio differito).

Il premio è una funzione concava e limitata del valore pubblico totale:

    Sᵢ = S_max · [1 − exp(−max(0, Vᵢᵗᵒᵗ) / V₀)]

S_max è il premio massimo e V₀ la scala alla quale il premio raggiunge il 63% del massimo; entrambi sono parametri di voto. Proprietà, ciascuna verificabile direttamente dalla formula:

- Limite: 0 ≤ Sᵢ < S_max per ogni idea, comunque grande.
- Incentivo sempre positivo: dS/dV = (S_max/V₀)·exp(−V/V₀) > 0: più valore pubblico dà sempre più premio, quindi l’incentivo non si spegne mai (a differenza di un tetto rigido, oltre il quale l’incentivo marginale è nullo).
- Rumore limitato: la pendenza è al massimo S_max/V₀, quindi la rendita da rumore della §17.2 è al massimo 0,399 σ S_max/V₀ e diminuisce con l’aumentare di V₀.
- Disuguaglianza con un tetto noto: con il premio limitato, D-12 diventa Wᵢ,T ≤ Wᵢ,₀ + Σₜ(h̄ₜ + S_max): la distanza patrimoniale fra due persone in T periodi è al massimo T·S_max, indipendentemente dal valore creato.
- Bilancio prevedibile: la spesa massima per premi è nota in anticipo (numero di idee premiate × S_max), quindi si pianifica sul margine di 25 della D-7.

### 17.6 N-8 Effetto della forma del premio [N]

Simulazione su 100.000 idee con valore economico a coda pesante (lognormale, come l’innovazione reale: poche idee valgono moltissimo) e vantaggio sociale correlato ma anche negativo nel 31% dei casi. Le tre forme di premio ricevono lo stesso budget totale.

| Forma del premio | Quota del budget al top 1% | Indice di Gini dei premi | Premio massimo / mediano |
|---|---|---|---|
| Proporzionale al valore | 22,6% | 0,74 | 846 |
| Tetto rigido (95° percentile) | 5,4% | 0,64 | 13 |
| Concavo limitato (§17.5) | 2,6% | 0,47 | 3,5 |

*Tabella 10. Concentrazione dei premi a parità di budget. Parametri dimostrativi; V₀ al 75° percentile del valore.*

Con il premio proporzionale l’1% delle idee prende quasi un quarto del budget e il premio massimo è 846 volte quello mediano: ricostituirebbe grandi patrimoni personali. Il premio concavo distribuisce lo stesso budget su molte più idee (massimo 3,5 volte il mediano), mantenendo un incentivo marginale sempre positivo.

| Idea | Valore economico | Vantaggio sociale | Valore pubblico totale | Premio (frazione di S_max) | Premio se contasse solo l’economico |
|---|---|---|---|---|---|
| A — redditizia ma dannosa | 10 | −9 | 1 | 0,25 | 0,94 |
| B — poco redditizia, molto utile | 1 | +6 | 7 | 0,87 | 0,25 |
| C — grande valore su entrambi | 50 | +10 | 60 | 1,00 | 1,00 |

*Tabella 11. Tre idee di esempio con V₀ = 3,46. Misurare anche il vantaggio sociale inverte l’ordine fra A e B.*

Il limite ha un costo da dichiarare: per idee di valore enorme il premio monetario non cresce quasi più. La TEPS lo compensa con leve non monetarie già presenti nel modello: riconoscimento pubblico e accesso prioritario al capitale del fondo per sviluppare le idee successive (§10.3).

### 17.7 D-14 Premio in peso sulle competenze [D]

Il premio non è solo denaro. Un’innovazione riconosciuta dimostra una capacità che i test di padronanza (§11) non misurano: saper produrre conoscenza nuova e utile. Nella versione 1.4 questa capacità entra nel peso di voto per le decisioni tecniche della disciplina in cui l’innovazione è stata riconosciuta. La competenza efficace combina padronanza verificata e contributi riconosciuti:

    Cᵢ,ₖᵉᶠᶠ = min(1, Cᵢ,ₖ + ρ · Rᵢ,ₖ)
    Rᵢ,ₖ = min(R_max, Σⱼ (Sⱼ / S_max) · exp(−(t − tⱼ) / T_R))

Rᵢ,ₖ somma i premi ricevuti per innovazioni nella disciplina k, normalizzati sul premio massimo e calcolati dagli stessi sistemi algoritmici della §17.5; ρ converte i contributi in competenza. Il peso di voto resta quello della §11.1 con Cᵉᶠᶠ al posto di C, quindi non supera mai w_max. Il termine exp(−(t − tⱼ)/T_R) è una proposta di questa versione: il peso derivato da un’innovazione si riduce nel tempo se non è rinnovato da nuovi contributi, così il riconoscimento non diventa una rendita di potere permanente. T_R, ρ e R_max sono parametri di voto.

- Accesso tramite innovazione: chi ha innovazioni riconosciute ma non supera la soglia τ dei test può essere ammesso al voto tecnico, se ρ·R colma la differenza. È coerente con la §10.3: lo scibile conosciuto non è il limite delle invenzioni.
- Tetto individuale: Cᵉᶠᶠ ≤ 1 implica wᵢ ≤ w_max per ogni persona, qualunque sia il numero di innovazioni.
- Perimetro: il peso vale solo per le decisioni tecniche della disciplina k; sulle materie che toccano tutti il voto resta eguale (§11.1), e nessuno vota sulla propria pratica (§11.2).

Il tetto ha una conseguenza dimostrabile: limita il potere di qualunque gruppo. Fra gli ammessi al voto ogni peso è almeno 1 e al massimo w_max. Il caso peggiore è che una frazione f di ammessi abbia peso w_max e tutti gli altri peso 1:

    [D] quota di peso del gruppo ≤ f · w_max / [f · w_max + (1 − f)]

Dimostrazione. La quota del gruppo cresce con il peso dei suoi membri e diminuisce con quello degli altri; il massimo si ottiene con i membri a w_max e gli altri a 1. Q.E.D.

| Peso massimo w_max | Il top 1% degli ammessi pesa al massimo | Il top 10% degli ammessi pesa al massimo |
|---|---|---|
| 2 | 2,0% | 18,2% |
| 3 | 2,9% | 25,0% |
| 5 | 4,8% | 35,7% |

*Tabella 12. Quota massima del peso totale di voto detenuta da un gruppo, in funzione del tetto w_max.*

Con w_max = 3 anche il 10% più competente e innovativo resta in minoranza (al massimo il 25% del peso): l’innovazione dà voce, non controllo. Perché un gruppo raggiunga la maggioranza servirebbe f > 1/(1 + w_max), cioè almeno il 25% degli ammessi con w_max = 3.

### 17.8 D-15 Allargamento automatico della base di voto [D]

Se chi ha peso è troppo poco, la base si allarga: la soglia di ingresso τ scende in modo automatico quanto basta per avere almeno N_min ammessi. Ordinando la competenza efficace in modo decrescente, C₍₁₎ ≥ C₍₂₎ ≥ …, la soglia applicata alla decisione q è:

    [D] τ*(q) = min( τ₀(q), C₍N_min₎ )

τ₀ è la soglia ordinaria della decisione e C₍N_min₎ la competenza della persona in posizione N_min. Nel calcolo del peso (§11.1) τ\* sostituisce τ. La regola è deterministica e pubblica, come le altre.

- Base minima garantita: gli ammessi sono sempre almeno N_min, se la popolazione li contiene; una decisione tecnica non resta mai senza votanti (il caso escluso nella §11.1 non si presenta più).
- Abbassamento minimo: se gli ammessi con τ₀ sono già N_min o più, τ\* = τ₀ e nulla cambia; altrimenti la soglia scende solo fino alla competenza dell’N_min-esimo, cioè il minimo indispensabile.
- Nessun peso individuale dominante: con almeno N_min ammessi e pesi fra 1 e w_max, una singola persona detiene al massimo w_max / (w_max + N_min − 1) del peso totale.

Dimostrazione. Se N(τ₀) ≥ N_min, allora C₍N_min₎ ≥ τ₀ e τ\* = τ₀. Altrimenti τ\* = C₍N_min₎ < τ₀ e sono ammessi esattamente i primi N_min (più gli eventuali pari merito), cioè il numero minimo con la soglia più alta possibile. Il limite individuale segue da D-14 con un membro a w_max e gli altri N_min − 1 a peso 1. Q.E.D.

Esempio: con w_max = 3 e N_min = 101, nessuna persona supera il 2,9% del peso; con N_min = 1.001 lo 0,3%. N_min è un parametro di voto: più è alto, più la decisione è ampia, ma più scende la competenza minima richiesta.

Nota 1.5: le garanzie D-14 e D-15 valgono sui voti espressi, non sui soli ammessi. Se i voti espressi (astensioni escluse) sono meno di N_min, la votazione si estende automaticamente ai successivi nella graduatoria di Cᵉᶠᶠ finché i voti espressi raggiungono N_min; le nuove convocazioni entrano in Nᵒᶠ dei convocati (§11.3).

**Integrazione 1.5 — §17.9 patrimonio e incentivi**

### 17.9 D-12 e D-13 con il reddito civico [D]

Con il reddito civico l’equazione del patrimonio personale diventa:

    Wᵢ,ₜ₊₁ = Wᵢ,ₜ + h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ − Cᵢ,ₜ
    [D] Wᵢ,T ≤ Wᵢ,₀ + Σₜ (h̄ₜ Pᵢ,ₜ + Sᵢ,ₜ) ≤ Wᵢ,₀ + Σₜ (h̄ₜ + S_max)

La dimostrazione è quella della D-12, con h̄ₜPᵢ,ₜ al posto di Dₜ. La distanza patrimoniale fra due persone in T periodi resta limitata: al massimo Σₜ h̄ₜ \|Pᵢ,ₜ − Pⱼ,ₜ\| + T·S_max. La partecipazione aggiunge una differenza di reddito che dipende solo dal comportamento del cittadino stesso; il patrimonio continua a non generare rendimento. I premi S per valore economico e sociale restano aggiuntivi, concavi e limitati (§17.5); il peso sulle competenze (§17.7) non dipende da Pᵢ,ₜ.

## 18. Il modello sta in piedi? Valutazione economica

Sul piano logico-contabile la TEPS è concepibile: beni reali e capitale possono essere prodotti senza salario necessario e un fondo collettivo può finanziare il rinnovo e le nuove imprese. Ma una condizione contabile o una simulazione calibrata su ipotesi arbitrarie non bastano a provare che questo ordinamento funzioni meglio o sia stabile nell’economia reale.

| Domanda | Risposta nella versione 1.4 | Prova ancora mancante |
|---|---|---|
| Può esserci produzione senza lavoro umano? | Sì nel modello; con la fusione l’energia non è vincolante (§8, §16) | Fattibilità tecnica della piena automazione |
| La domanda può essere sostenuta senza salari? | Sì, con la regola funzionale del fondo (D-8, N-3); con il solo pareggio e prezzi rigidi no (utilizzo 0,84) | Calibrazione delle propensioni α e β |
| Il fondo si autofinanzia? | Sì, per costruzione: senza proprietà privata produttiva Π = 117 ≥ pb + S + pIₙ, margine 25 (D-7) | Ripartizione del margine fra reddito civico, premi e nuove imprese |
| Chi governa il fondo? | Nessun organo umano diretto: voto ponderato su parametri e regole, esecuzione da IA pubbliche (§1.1, §17) | Validazione della governance per competenza |
| Da dove nasce la ricchezza personale? | Solo dai premi e dal reddito civico (1.5); senza rendimento il patrimonio non si autoalimenta (D-12) | Taratura della quota dei premi sul margine di 25 |
| Che cosa premia il premio? | Valore economico più vantaggio sociale, con premio concavo e limitato: incentivo sempre positivo, disuguaglianza al massimo T·S_max (D-13, N-8) | Validazione dei modelli di conversione nell’unità comune |
| Il premio è solo denaro? | No: anche peso nelle decisioni tecniche della disciplina, con tetto w_max; nessun gruppo sotto il 25% degli ammessi può avere la maggioranza con w_max = 3 (D-14) | Esperimenti sulla qualità delle decisioni ponderate |
| La moneta è stabile? | Il debito del fondo converge alla moneta desiderata, 25 (D-9); l’inflazione nasce da shock fisici e da promesse reali finanziate con moneta (N-4) | Economia aperta, scambi con l’estero |
| I prezzi possono razionare il discrezionale? | Sì, con rendita al fondo; allocano meglio del razionamento proporzionale ma sono molto volatili (N-5) | Sostituibilità tecnica fra input |
| Il capitale può conservarsi? | Sì se l’intensità di capitale non energetico resta sotto 2,1–2,4 volte quella ipotizzata (N-6) | Calibrazione di B e delle vite utili |
| Il fondo finanzia l’innovazione senza rischio eccessivo? | Sì con finanziamento a stadi e arresto automatico; no con un errore di stima comune e finanziamento in un’unica soluzione (N-7) | Dati su portafogli reali |
| Più IA sono necessariamente più affidabili? | Non manipolabili se pubbliche e con verifica alla fonte (D-10); l’accuratezza dipende comunque da errore e correlazione (D-6, N-7) | Validazione indipendente delle stime |
| Votare per competenza migliora le decisioni? | Non dimostrato | Esperimenti comparativi in contesti ben definiti |
| La fusione rende l’energia un non-problema? | Ipotesi di base dalla 1.1; l’energia resta il bene più economico anche negli shock sui materiali (N-5) | Costi completi del ciclo industriale |

### 18.1 Criteri di sostenibilità congiunta

    Per ogni t e ogni shock ammesso ω:
    (I − Aₜ)⁻¹(bₜ + iₜ) ≤ x̄ (Kₜ,ω)
    Kₜ₊₁ ≥ K_min ; Fₜ₊₁ ≥ F_min ; bₜ garantito
    Governance ∈ regole pubbliche; danni a diritti fondamentali esclusi

Per dimostrare una forma robusta di stabilità occorrerebbe identificare un insieme di stati sicuri Ω e una politica di controllo π tale che, partendo da qualunque stato di Ω e per ogni shock ammesso, lo stato successivo rimanga in Ω. Si tratta di mantenere lo stato in un insieme sicuro con il controllo, da dimostrare su un modello che oggi è ancora incompleto.

### 18.2 Cosa non va confuso

- Sostituire i salari produttivi non significa eliminare ogni compenso umano: l’ideatore riceve incentivi incrementali.
- Finanziare l’impresa con un fondo pubblico non rende gratuita la costruzione dell’impresa: capitale, macchine e materiali sono risorse reali.
- L’autonomia gestionale dell’IA non autorizza a eliminare verifica, diritto di ricorso o arresti di sicurezza.
- Un voto tecnico pesato per conoscenza non dimostra automaticamente la validità scientifica dell’opinione vincente.
- Una fusione molto economica non abolisce ogni scarsità, specialmente materiali, robot, siti industriali e capacità di riparazione.

### 18.3 Verdetto (versione 1.4, aggiornato alla 1.5): il modello economico sta in piedi?

Sì, a condizioni esplicite. Con la fusione come ipotesi di base, il capitale produttivo interamente pubblico, la gestione per regole sotto voto ponderato e il blocco stock-flow consistente chiuso, la TEPS è un’economia coerente: ogni flusso ha una controparte, il fondo si autofinanzia, la moneta ha un’àncora e il capitale si rinnova. Le condizioni sono otto, tutte verificabili (C7 e C8 dalla 1.5):

- C1 Chiusura del fondo: Π ≥ pb + S + pIₙ. Soddisfatta per costruzione con φ = 1 (margine 25); il paniere assorbe il 79% del surplus distribuibile.
- C2 Àncora nominale: regola funzionale del trasferimento ai cittadini (reddito civico dalla 1.5) con 0 < λ < λ_max (circa 1,7), oppure regola anticipata; l’obiettivo negli shock (riserva o prezzi) è un parametro di voto. Il pareggio di bilancio non basta se i prezzi sono rigidi verso il basso.
- C3 Margine fisico: σ ≥ 1 sotto ogni shock ammesso. Dopo la fusione il vincolo è il capitale non energetico, con intensità sotto circa due volte quella ipotizzata.
- C4 Nessuna promessa reale finanziata con moneta: negli shock il consumo discrezionale si riduce per decisione pubblica; stamparne il controvalore produce solo inflazione (prezzi raddoppiati nella prova).
- C5 Rendite pubbliche: rendite di scarsità settoriali al fondo; canone di localizzazione sul suolo a uso personale.
- C6 Incentivi compatibili: verifica alla fonte da sistemi pubblici (π → 1), premio con soglia o differito contro il rumore di misura, finanziamento a stadi con arresto automatico; IA multiple con errori indipendenti (misurati) sotto una catena deterministica di controllo; i premi sono l’unica fonte di accumulo della proprietà personale (D-12), limitati e calcolati su valore economico più vantaggio sociale misurato algoritmicamente (D-13); il premio è anche peso sulle competenze, con tetto che limita il potere di ogni gruppo (D-14) e base di voto che si allarga da sola se gli ammessi sono troppo pochi (D-15).
- C7 Partecipazione (1.5): reddito civico h̄ₜPᵢ,ₜ proporzionale alle votazioni eseguite su quelle offerte; quote non maturate al fondo per nuove imprese, spese entro la capacità fisica e con finanziamento a stadi (D-16, N-9); paniere in natura mai condizionato; voto segreto con partecipazione verificata separatamente dal contenuto (§11.3).
- C8 Moneta solo pubblica (1.5): nessuna banca privata né prestito a interesse; conti, pagamenti ed emissione su un registro pubblico deterministico calcolato da sistemi indipendenti (D-17–D-21).

Restano non dimostrate la piena automazione stessa, la calibrazione su dati reali (A, B, propensioni), la stabilità globale (le prove sono locali o numeriche), l’economia aperta e la superiorità della governance per competenza. Sono limiti empirici e politici, non incoerenze interne: nella versione 1.4 non è stata trovata alcuna contraddizione logica o contabile nel modello economico. Nella 1.5 la regola di partecipazione mantiene il fondo in pareggio in stato stazionario (D-16); la dinamica su 30 periodi è simulata in N-10 (§19.3). La moneta senza banche private è dimostrata in D-17–D-21.

Nella sostanza, la TEPS 1.2 è un’economia a capitale produttivo interamente pubblico, con paniere in natura, reddito civico proporzionale alla partecipazione (dividendo universale fino alla 1.4), prezzi per il consumo discrezionale e moneta solo pubblica, senza banche private (§13.7), gestita da regole automatiche sotto voto ponderato, in cui la sola fonte di ricchezza personale è il valore pubblico, economico e sociale, creato dalle idee, premiato entro un limite in denaro e in peso sulle decisioni tecniche. Rispetto al socialismo di mercato di Roemer [10] mancano le quote private delle imprese; rispetto alla pianificazione centrale, le preferenze sul discrezionale passano attraverso i prezzi e l’iniziativa resta agli ideatori.

**Integrazione 1.5 — §18.4 Sostenibilità con la regola di partecipazione**

### 18.4 Condizione C7 e domande aperte dalla 1.5

| Domanda | Risposta nella versione 1.5 | Prova ancora mancante |
|---|---|---|
| Il reddito proporzionale alla partecipazione riduce la domanda? | No in stato stazionario, se le quote non maturate finanziano nuove imprese (D-16); sotto P̄ = 0,87 la conversione è limitata dai robot (N-9); in dinamica un calo di P̄ dà una recessione di 3–6 periodi (N-10) | Orizzonti lunghi e matrice B (T9); dinamica a 30 periodi in N-10 |
| Il voto remunerato resta libero e segreto? | Sì per costruzione: registro di partecipazione separato dall’urna, credenziali anonime (§11.3) | Verifica crittografica e audit del sistema di voto |
| Pagare l’astensione svuota le decisioni? | No: l’astensione conta per il reddito ma non per l’esito; N_min si applica ai voti espressi (§17.8) | Dati sulla quota di astensioni |

La condizione C7 (§18.3) si aggiunge a C1–C6; la C8, moneta solo pubblica, è dimostrata nelle §14.7–14.11. Con piena partecipazione (P̄ = 1) la TEPS 1.5 coincide con la 1.4; per P̄ < 1 le prove disponibili sono D-16, N-9 e N-10. Le verifiche locali o numeriche della 1.4 non vanno lette come prova generale della dinamica con partecipazione variabile.

## 19. Limiti e programma di verifica

| Fase | Obiettivo | Stato nella versione 1.4 |
|---|---|---|
| T1 — Produzione | Calibrare la matrice settoriale con dati reali | Aperto |
| T2 — Capitale | Robot, energia, reti e riparazioni | Parzialmente chiuso: matrice B e soglie di intensità (§16); calibrazione aperta |
| T3 — Moneta | Modello stock-flow consistente | Chiuso a livello teorico (§13–14): matrici a somma nulla, D-7–D-9, N-3; con φ = 1 il fondo si chiude per costruzione |
| T4 — Mercato | Domanda, prezzi e razionamento endogeni | Parzialmente chiuso: prezzi endogeni, rendite di scarsità, regole del fondo (§15); manca la sostituibilità fra input |
| T5 — Innovazione | Portafogli di progetti con prove | Parzialmente chiuso: D-10–D-15, N-7, N-8 (§17); mancano dati reali e la misura degli indicatori sociali |
| T6 — Competenze | Esami equi e multidisciplinari | Aperto |
| T7 — Consesso IA | Errori correlati e manipolazioni | Aperto; collegato agli incentivi tramite π (D-10) |
| T8 — Politiche | Confronto fra scenari e organizzazioni | Aperto |
| T9 — Partecipazione | Reddito civico, quote non maturate, domanda (1.5) | Parzialmente chiuso: D-16, N-9, N-10 (§19.2–19.3) |
| T10 — Banca pubblica | Registro deterministico, pagamenti, moneta (1.5) | Chiuso a livello teorico: D-17–D-21; manca il test di un registro reale |

### 19.1 Registro sintetico delle dimostrazioni

| Codice | Risultato | Portata |
|---|---|---|
| D-1 | x\* = (I − A)⁻¹ f; condizione di fattibilità x\* ≤ x̄ | Vero nel modello lineare, con ρ(A) < 1 |
| D-2 | Y\* = I/[1 − m(θ)] e intervallo 68,85–78,79% | Vero nelle ipotesi della domanda aggregata |
| D-3 | 0 < η < (1 − m\*)/(cₕ − cₚ) | Stabilità locale del regolatore, ipotesi specificate |
| D-4 | ρ[(1−γ)I+γA] < 1 | Convergenza della produzione lineare |
| D-5 | VA = Σ domanda finale = 141 | Identità ai prezzi unitari dell’esempio |
| D-6 | Pr[errore maggioranza] = 5,792% | Solo con errori Bernoulli indipendenti |
| N-1 | Shock energetico −25% per 5 anni: arresto anno 23 | Solo simulazione settoriale ipotetica |
| N-2 | Allocazione robusta mantiene rinnovo nei test indicati | Solo scenari ammessi e tecnologia semplificata |
| D-7 | Π ≥ pb + S + pIₙ; con φ = 1 margine 25 (con φ = 0,75 servirebbe un canone del 78,6%) | Stato stazionario del blocco SFC |
| D-8 | Con il fondo in pareggio M è costante: il livello della domanda dipende da M e p | Con prezzi rigidi ⇒ sottoutilizzo |
| D-9 | A\* = (1−α₁)/α₂ H\* = 25 | Stato stazionario |
| D-10 | Nessuna manipolazione ⇔ k ≥ (1 − π)/π; con verifica alla fonte π → 1 | Ideatore neutrale al rischio |
| D-11 | Rendita da rumore ασ/√(2π); con soglia ασ[φ(z) − z(1 − Φ(z))] | Errore di misura normale |
| D-12 | Wᵢ,T ≤ Wᵢ,₀ + Σ(D + Sᵢ): la proprietà personale cresce solo con i premi | Nessun rendimento sul patrimonio personale |
| D-13 | Premio concavo limitato: 0 ≤ S < S_max, dS/dV > 0, distanza patrimoniale ≤ T·S_max | Valore pubblico = economico + sociale |
| D-14 | Peso con tetto: quota di un gruppo ≤ f·w_max/[f·w_max + (1 − f)] | Pesi fra 1 e w_max tra gli ammessi |
| D-15 | τ\* = min(τ₀, C₍N_min₎): almeno N_min ammessi; peso individuale ≤ w_max/(w_max + N_min − 1) | Regola deterministica di allargamento |
| N-3 | Regola funzionale stabile per 0 ≤ λ < 1,73 (κ = 0,5) | Numerica e locale; prezzi con radice unitaria |
| N-4 | Promessa reale con moneta: prezzi +104%, nessun consumo in più; riserva conservata 2,3% o usata 4,6% di inflazione | Shock −20% per 5 periodi |
| N-5 | Prezzi di scarsità: quota servita 0,576 contro 0,554; materiali +426% | Materiali −15%, elasticità 1,5 |
| N-6 | Soglie di intensità di capitale 2,09 e 2,44 (1,72 con capitale energetico) | Matrice B ipotetica |
| N-7 | Finanziamento a stadi: rovina da 49% a circa 0% (B = 5) | Parametri dimostrativi |
| N-8 | A parità di budget, quota al top 1%: 22,6% proporzionale, 2,6% concavo | Valori lognormali dimostrativi |

**Integrazione 1.5 — §19.2 Programma di verifica T9 e registro 1.5**

### 19.2 Programma T9 — Partecipazione

- T9.1 (chiuso): P̄ = 1 riproduce lo scenario 1.4 (D-16 con P̄ = 1).
- T9.2 (parzialmente chiuso): P̄ = 0,9; 0,75; 0,5 in stato stazionario (D-16) e fattibilità fisica con la matrice A (N-9); da ripetere con la matrice del capitale B.
- T9.3 (parzialmente chiuso): partecipazione variabile nel tempo, risposta di R1, transizione dello stock di moneta, inflazione: simulazione N-10 su 30 periodi; restano orizzonti lunghi e la matrice B.
- T9.4 (aperto): test delle regole di calcolo: con impedimenti riconosciuti o Nᵒᶠ = 0 nessuna decurtazione.
- T9.5 (parzialmente chiuso): effetto del capitale delle nuove imprese su rinnovo, capacità e margine C1: scenari con successo pieno, 20% e nullo in N-10; manca la calibrazione del rendimento reale delle nuove imprese.
- T9.6 (aperto): quota di astensioni, qualità delle decisioni ponderate, sicurezza del registro di partecipazione.

### 19.3 N-10 Dinamica con partecipazione variabile [N]

Poiché senza partecipazione manca il reddito monetario, la partecipazione attesa è vicina a 1 e in pratica la TEPS 1.5 coincide con la 1.4; gli scenari con P̄ basso sono casi limite. Simulazione del blocco stock-flow della §13.4 con regola R1 (λ = 0,5, κ = 0,5) e reddito civico h̄ₜPᵢ,ₜ; le quote non maturate vanno nella riserva Fᴵ e sono spese in nuove imprese entro il limite fisico della N-9 (tetto F̄ᴵ = 20, eccedenza restituita con il reddito civico). Partecipazione piena fino al periodo 9, poi lo scenario indicato; 30 periodi dopo il cambiamento. Lo script originale `teps_sfc.py` non è nel repository: le equazioni sono ricostruite dal testo e la ricostruzione è verificata sulla 1.4 (con P̄ = 1 lo stato stazionario resta invariato; lo scenario S8 ritrova la riga R1 della Tabella 5: inflazione massima 6,3%, prezzi finali 1,068, discrezionale minimo 1,79). Codice: `simulazioni/teps_1_5_partecipazione.py`.

| Scenario | Infl. max per per. | Defl. max per per. | Prezzi t = 40 | Utilizzo minimo | Discrez. minimo | Periodi per tornare a 25 | Discrez. t = 40 | Capitale t = 40 |
|---|---|---|---|---|---|---|---|---|
| S0 P̄ = 1 (riferimento 1.4) | 0,00% | 0,00% | 1,000 | 0,909 | 25,00 | — | 25,0 | 234,9 |
| S1 P̄ = 0,90 | 0,08% | 1,26% | 0,809 | 0,884 | 22,75 | 3 | 75,0 | 355,5 |
| S2 P̄ = 0,75 | 0,00% | 1,76% | 0,768 | 0,874 | 19,38 | 6 | 78,1 | 357,8 |
| S3 P̄ = 0,50 | 0,00% | 3,25% | 0,727 | 0,844 | 13,71 | 4 | 78,1 | 360,6 |
| S4 P̄ casuale 0,70–1,00 | 0,25% | 2,87% | 0,784 | 0,852 | 20,37 | 3 | 79,5 | 343,9 |
| S5 P̄ = 0,90, prezzi rigidi | 0,08% | 0,00% | 1,001 | 0,867 | 22,75 | 3 | 71,2 | 359,3 |
| S6 P̄ = 0,90, riesce il 20% | 0,08% | 0,12% | 0,981 | 0,907 | 22,75 | 12 | 29,9 | 252,8 |
| S7 P̄ = 0,90, nessuna riesce | 0,08% | 0,00% | 1,008 | 0,909 | 22,51 | mai | 22,5 | 234,9 |
| S8 shock −20%, P̄ = 1 | 6,25% | 4,20% | 1,070 | 0,825 | 1,79 | — | 24,9 | 234,9 |
| S9 shock −20%, P̄ = 0,90 | 5,85% | 3,88% | 0,915 | 0,832 | 1,73 | — | 60,9 | 331,4 |
| S10 P̄ = 0,90, quote ferme | 0,00% | 0,84% | 0,780 | 0,892 | 22,41 | mai | 22,4 | 234,9 |

*Tabella 14. Periodi 10–40. «Riesce il 20%»: solo il 20% del capitale delle nuove imprese diventa capacità produttiva (probabilità di successo della §10.4); il resto è perso. «Quote ferme»: confronto con quote non maturate trattenute dal fondo senza spesa. Shock −20% nei periodi 10–14 come nella Tabella 5. In tutte le simulazioni la moneta dei cittadini coincide con le anticipazioni al fondo (Mₕ = A) con scarto massimo 10⁻¹³.*

![](figure/figura_5.png)

*Figura 5. Livello dei prezzi e consumo discrezionale reale con partecipazione media ridotta dal periodo 10 (S0–S3) e con le quote non maturate trattenute nel fondo senza spesa (S10). Banda: periodi dopo il cambiamento. Simulazioni, non previsioni.*

- Inflazione: la partecipazione non genera inflazione. Senza shock l’inflazione massima è 0,25% per periodo, anche con partecipazione casuale; con lo shock del −20% la partecipazione al 90% dà un’inflazione di punta leggermente inferiore alla 1.4 (5,85% contro 6,25%).
- Calo improvviso di partecipazione: è una recessione breve. Il consumo discrezionale scende quasi in proporzione (fino a 13,7 con P̄ = 0,50) perché la conversione in capitale è limitata dai robot (N-9). Torna a 25 in 3–6 periodi, quando la riserva raggiunge il tetto F̄ᴵ, l’eccedenza rientra nel reddito civico e R1 recupera la domanda. Il tetto F̄ᴵ è il parametro che decide la durata della recessione.
- Rischio prevalente: deflazione, non inflazione. Le nuove imprese aumentano la capacità più rapidamente di quanto R1 aumenti la domanda: utilizzo fra 0,84 e 0,88 e prezzi in calo fino a 1,3–3,3% per periodo. Con prezzi rigidi verso il basso (S5) la deflazione scompare ma l’utilizzo minimo scende a 0,867. Una λ maggiore, entro il limite di stabilità della N-3, ridurrebbe il ritardo.
- Destinazione B contro quote ferme: con le quote trattenute senza spesa (S10) il consumo resta stabilmente a 22,4, la capacità resta inutilizzata (0,892) e i prezzi scendono senza fine (−22% in 30 periodi). La destinazione alle nuove imprese non è mai peggiore: anche quando nessuna impresa riesce (S7) dà lo stesso consumo con prezzi stabili e utilizzo normale.
- Costo reale se le imprese falliscono: con S7 il consumo discrezionale resta a 22,5 invece di 25. Le risorse delle quote non maturate sono spese in progetti che non producono: è il costo reale della regola quando gli investimenti non rendono, ed è coperto dal finanziamento a stadi (§17.3).
- Crescita se le imprese riescono: con successo pieno (S1–S4) il capitale cresce di circa il 50% in 30 periodi e il consumo discrezionale triplica. Il risultato dipende dall’ipotesi 1.4 che il nuovo capitale sia produttivo come quello esistente (v = 1,51, δ = 10,2%), con rendimento netto di circa 0,5 per unità e per periodo: va letto come limite superiore. Lo scenario con il 20% di successo (S6) è più prudente: il consumo torna a 25 dopo 12 periodi e sale a 29,9.
- Limiti: modello aggregato a composizione fissa dei consumi (b e z invariati), conversione 1:1 del capitale, orizzonte di 30 periodi. Su orizzonti più lunghi la crescita porta i consumi lontano dalla composizione del modello e servono la matrice B e una domanda settoriale endogena.

Registro delle dimostrazioni 1.5

| Codice | Risultato | Portata |
|---|---|---|
| D-16 | Con Iₙ = Q: Y = 141, Π = 117, ΔA = 0, A\* = 25 P̄ per ogni P̄ | Stato stazionario, S = 0, Iₓ = 0 |
| N-9 | Q convertibile in capitale nello stesso periodo se P̄ ≥ 0,871 | Matrice A, capacità §4.2, convenzione 1:1 |
| N-10 | Nessuna inflazione dalla partecipazione (≤ 0,25%); calo di P̄: recessione di 3–6 periodi; rischio prevalente deflazione | Ricostruzione SFC verificata sulla 1.4, 30 periodi, composizione fissa |
| D-17 | Σⱼ mⱼ = 0; moneta = debito del fondo, M = A, in ogni periodo | Registro della BPA (§13.7) |
| D-18 | Esecuzione di un pagamento indipendente dagli altri conti: nessuna corsa agli sportelli | Copertura 1, nessuna riserva frazionaria |
| D-19 | Stato errato accettato ≤ Σ_{j>n/2} C(n,j) qʲ(1−q)ⁿ⁻ʲ (9,9·10⁻⁶ con n = 5, q = 0,01) | Guasti indipendenti dei sistemi replicati |
| D-20 | Prestito a interesse r > 0 incompatibile con il limite della D-12 | Patrimonio iniziale positivo |
| D-21 | Sistema monetario senza banche private: (a)–(e) della §14.11 | (c) locale e numerica (N-3) |

**Conclusione generale.** Con la fusione come ipotesi di base, il capitale produttivo interamente pubblico, la gestione per regole sotto voto ponderato e il blocco stock-flow consistente, la TEPS 1.5 è un modello economico internamente coerente: tutti i flussi hanno una controparte, il fondo si autofinanzia alle condizioni C1–C8 (§18.3) e i sottosistemi monetario, fisico e degli incentivi sono chiusi e verificati numericamente; la regola di partecipazione della 1.5 è verificata in stato stazionario (D-16, N-9) e in dinamica su 30 periodi (N-10); la moneta, senza banche private, coincide sempre con il debito del fondo ed è gestita da un registro pubblico deterministico (D-17–D-21). Restano non dimostrate la stabilità globale, la calibrazione empirica e la superiorità della governance per competenza e della gestione affidata a IA.

## 20. Glossario, parametri e riferimenti

### 20.1 Simboli essenziali

| Simbolo | Significato |
|---|---|
| A, x, f | Matrice degli input, produzione lorda, domanda finale settoriale |
| b, z, q | Paniere essenziale, consumo discrezionale pieno, quota erogata |
| K, δ, I | Capitale produttivo, deprezzamento, nuovi investimenti/rinnovo |
| θ, φ | Quota di reddito distribuito, quota di proprietà collettiva |
| σ, ρ | Indice del settore più vincolante, raggio spettrale |
| F, CF | Fondo finanziario produttivo, flusso di cassa operativo |
| Cᵢ,ₖ, wᵢ | Competenza certificata nella materia e peso di voto |
| Oₐ, G | Giudizio di un agente IA isolato, aggregatore prestabilito |
| H, A, M | Trasferimenti ai cittadini; anticipazioni al fondo; moneta in circolazione |
| λ, κ, ū | Reattività della regola funzionale; reattività dei prezzi; utilizzo normale |
| B, κⱼ, s | Matrice del capitale; intensità di capitale per settore; composizione dei beni capitali |
| π, k | Probabilità di scoperta della manipolazione; multiplo di restituzione |
| Wᵢ | Patrimonio personale: dalla 1.2 l’unica forma di proprietà privata |
| Vᵗᵒᵗ, Iₖ, ωₖ | Valore pubblico totale; indicatori sociali in unità fisiche; coefficienti di conversione nell’unità comune (tempo di vita in salute), calcolati da modelli pubblici |
| S_max, V₀ | Premio massimo; scala di saturazione del premio |
| τ₀, τ\*, N_min | Soglia ordinaria di competenza; soglia applicata dopo l’allargamento; numero minimo di ammessi |
| Rᵢ,ₖ, ρ, T_R | Contributi innovativi riconosciuti nella disciplina k; loro conversione in competenza; tempo di attenuazione |
| Nᵒᶠᵢ,ₜ, Nᵉˢᵢ,ₜ, Pᵢ,ₜ | (1.5) Votazioni offerte; votazioni eseguite; quota di partecipazione Nᵉˢ/Nᵒᶠ |
| h̄ₜ, Hᶜᵢ,ₜ, Qₜ, Fᴵ | (1.5) Reddito civico pieno; reddito civico maturato h̄ₜPᵢ,ₜ; quote non maturate; riserva per nuove imprese |
| N_max, n_min, F̄ᴵ | (1.5) Tetto di convocazioni per periodo; minimo di convocazioni per il calcolo di P; tetto della riserva per nuove imprese |
| mⱼ, m_f, Φ | (1.5) Saldo del conto j nella banca pubblica automatica; saldo del fondo (= −M); funzione deterministica di aggiornamento del registro |
| n, q | (1.5) Numero di sistemi che calcolano il registro; probabilità di guasto di un sistema |

### 20.2 Fonti e testi di riferimento

[1] Acemoglu, D. e Restrepo, P. (2018), “Modeling Automation”, AEA Papers and Proceedings. https://www.aeaweb.org/articles?id=10.1257%2Fpandp.20181020

[2] Acemoglu, D. e Restrepo, P. (2019), “Automation and New Tasks”, Journal of Economic Perspectives. https://www.nber.org/papers/w25684

[3] Godley, W. e Lavoie, M. (2007), Monetary Economics, Palgrave Macmillan. https://doi.org/10.1057/9780230626546

[4] Leontief, W. — struttura input-output e condizione di produttività; le identità utilizzate nel testo sono derivazioni standard della modellistica a coefficienti fissi.

[5] Senato della Repubblica, Costituzione italiana, articolo 48. https://www.senato.it/istituzione/la-costituzione/parte-i/titolo-iv/articolo-48

[6] Commissione europea, AI Act, articolo 14 — supervisione umana per sistemi ad alto rischio. https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-14

[7] NIST (2023), AI Risk Management Framework 1.0. https://doi.org/10.6028/NIST.AI.100-1

[8] Lerner, A. P. (1943), “Functional Finance and the Federal Debt”, Social Research, 10(1).

[9] Kornai, J. (1986), “The Soft Budget Constraint”, Kyklos, 39(1).

[10] Roemer, J. E. (1994), A Future for Socialism, Harvard University Press.

[11] George, H. (1879), Progress and Poverty.

[12] Becker, G. S. (1968), “Crime and Punishment: An Economic Approach”, Journal of Political Economy, 76(2).

[13] Leontief, W. (1953), Studies in the Structure of the American Economy, Oxford University Press (modello dinamico con matrice del capitale).

### 20.3 Provenienza dei risultati numerici

I risultati [N] sono stati ricontrollati sul codice di simulazione TEPS 0.4, 0.5 e 0.6 elaborato nel percorso di costruzione del modello. Sono valori di scenario senza calibrazione su dati macroeconomici nazionali. L’ottimizzazione è stata svolta con programmazione lineare e la verifica delle matrici con calcolo numerico.

I risultati delle versioni 1.1–1.4 (§13–17, D-7–D-15, N-3–N-8) sono riprodotti dallo script `teps_sfc.py` che accompagna il documento (Python con NumPy e SciPy, semi fissi). Controllo di coerenza: in ogni periodo di ogni simulazione la moneta più la posizione netta del fondo è zero, con scarto massimo 3·10⁻¹³. Lo script è parametrizzato: φ = 0,75 riproduce i numeri della versione 1.1, φ = 1 quelli della 1.2.

Data di consolidamento: 13 ottobre 2026 (versioni 1.1–1.4 nella stessa data). Revisione 1.5: 30 ottobre 2026, aggiornata al 2 novembre 2026; i valori N-9 sono calcolati con la matrice A e le capacità della §4.2, i valori N-10 con lo script `simulazioni/teps_1_5_partecipazione.py` (NumPy), che ricostruisce il blocco stock-flow della §13.4 e ne verifica i risultati 1.4 prima di simulare. Le verifiche della banca pubblica automatica (D-17–D-19) sono nello script `simulazioni/teps_1_5_banca_pubblica.py`. Il documento riassume il modello come discusso e precisa i confini tra postulati di governance, derivazioni matematiche e simulazioni illustrative.

## Appendice A — Perché la proprietà collettiva deve essere protetta

Un risultato già emerso nelle prime fasi del modello riguarda la diluizione della proprietà: se le nuove macchine vengono attribuite a chi finanzia il rinnovo e chi detiene capitale privato risparmia proporzionalmente di più, la quota collettiva può restringersi anche senza vendite esplicite di partecipazioni.

Siano φₜ la quota di proprietà collettiva, sₕ il tasso di risparmio del gruppo beneficiario e sₚ il tasso di risparmio privato. Con capitale aggregato costante, deprezzamento uniforme δ e rinnovo finanziato in proporzione ai risparmi:

    φₜ₊₁ = (1 − δ)φₜ + δ [sₕ φₜ/(sₕ φₜ + sₚ(1 − φₜ))]

Per 0 < φₜ < 1 e sₕ < sₚ, la quota del nuovo capitale acquistata dal gruppo collettivo è inferiore a φₜ; pertanto φₜ₊₁ < φₜ.

Dimostrazione: sₕ φ/[sₕ φ + sₚ(1−φ)] < φ equivale a sₕ < sₕφ+sₚ(1−φ), cioè (sₚ−sₕ)(1−φ)>0. Q.E.D.

Esempio: φ₀ = 0,75, sₕ = 0,10, sₚ = 0,70 e δ = 0,10. I risparmi finanziano il 30% del nuovo capitale nel gruppo collettivo:

    φ₁ = 0,90 × 0,75 + 0,10 × 0,30 = 0,705.

Nella TEPS a fondo pubblico, questa diluizione non è necessaria: il rinnovo può essere accantonato prima dei dividendi e la titolarità del capitale collettivo mantenuta per norma. Rimangono però da chiudere i conti finanziari dell’intero sistema.

Nella versione 1.2 il problema è risolto alla radice: la proprietà privata produttiva non esiste (φ = 1), quindi non c’è nulla da diluire; i risparmi personali restano moneta o beni a uso personale e non rendono (§17.4). I conti finanziari dell’intero sistema sono chiusi nelle §13–14.

## Appendice B — Versione 1.5 (30 ottobre 2026, aggiornata al 2 novembre 2026)

Fonte: PDF TEPS 1.4 di 30 pagine del 13 ottobre 2026, conservato in `archivio/TEPS_1_4_Modello_Economico_Consolidato.pdf` e in forma testuale in `archivio/TEPS_1_4_estrazione_testuale.txt`; le figure 1–4 sono quelle dell'originale. In questa edizione i passaggi 1.4 incompatibili con la 1.5 sono corretti direttamente nel testo (dividendo → reddito civico, patrimonio D-12, condizioni C1–C8, conclusione); le parti nuove sono nei blocchi «INTEGRAZIONE 1.5».

Modifiche della versione 1.5:

1. Reddito civico Hᶜᵢ,ₜ = h̄ₜ Pᵢ,ₜ, con Pᵢ,ₜ = votazioni eseguite / votazioni offerte; il contenuto del voto non conta (§11.3).
2. Quote non maturate al fondo per finanziare nuove imprese (§13.6); neutralità della domanda in stato stazionario (D-16) e limite fisico della conversione in capitale (N-9).
3. Astensione: conta per il reddito, non per l’esito; base minima di voto sui voti espressi (§11.1, §17.8).
4. Segretezza: registro di partecipazione separato dall’urna, credenziali anonime monouso (§11.3).
5. Tetto alle convocazioni per periodo e numero minimo di convocazioni per il calcolo di P; impedimenti riconosciuti senza decurtazione (§11.3).
6. Patrimonio personale con reddito civico (§17.9); condizione C7 (§18.3–18.4); programma di verifica T9 (§19.2).
7. Simulazione dinamica con partecipazione variabile (N-10, §19.3, Figura 5), script `simulazioni/teps_1_5_partecipazione.py` e `simulazioni/teps_1_5_figura_n10.py`.
8. Nessuna banca privata: banca pubblica automatica (§13.7), dimostrazioni D-17–D-21 (§14.7–14.11), condizione C8, script `simulazioni/teps_1_5_banca_pubblica.py`.
