# Modelli economici e decisionali — TEPS, BCA, DPA

Modelli teorici di Cristian Lorenzetto (ricercatore indipendente, Padova · ORCID [0009-0001-4925-4728](https://orcid.org/0009-0001-4925-4728)), pubblicati liberamente con documenti, dimostrazioni, codice delle simulazioni e risultati riproducibili.

*Theoretical economic and decision-making models (TEPS, BCA, DPA), with papers in Italian and English, proofs, simulation code and reproducible results.*

## Modelli

| Modello | Di che cosa tratta | Paper (Zenodo) |
|---|---|---|
| [**TEPS — Teoria dell'Equilibrio Economico Post-Salariale**](teps/README.md) | Economia completamente automatizzata, capitale produttivo pubblico, beni essenziali garantiti, reddito civico proporzionale alla partecipazione alle votazioni, moneta solo pubblica senza banche private. Versione 1.5. | [IT](https://doi.org/10.5281/zenodo.23880578) · [EN](https://doi.org/10.5281/zenodo.23881220) |
| [**BCA — Economia di mercato con Banca Centrale Algoritmica**](bca/README.md) | L'economia di mercato attuale senza banche private: un'unica banca centrale pubblica, con regole deterministiche eseguite da più sistemi di IA indipendenti, tiene i conti e concede il credito a un tasso pubblico senza margine di profitto. Versione 1.0. | [IT](https://doi.org/10.5281/zenodo.23880939) · [EN](https://doi.org/10.5281/zenodo.23881186) |
| [**DPA — Democrazia Ponderata Adattiva**](dpa/README.md) | Una rete neurale collettiva per le decisioni democratiche: ogni tema è votato da chi ha competenze certificate per quel tema, con tetto ai pesi, base minima e diritti universali a voto eguale; la base si allarga in verticale se mancano votanti e in orizzontale se una decisione favorisce chi l'ha votata. Versione 1.0. | [IT](https://doi.org/10.5281/zenodo.24100807) · [EN](https://doi.org/10.5281/zenodo.24100875) |

Tutti i risultati numerici vengono da modelli simulati, con parametri dimostrativi: le proprietà principali sono dimostrate in forma matematica, il resto è verificato in simulazione su più scenari. Non sono prove su economie o istituzioni reali.

## Struttura

```
README.md
teps/                            TEPS — documenti finali in pdf/ e word/ (IT, EN), testi sorgente, figure, simulazioni
bca/                             BCA  — documenti finali in pdf/ e word/ (IT, EN), testi sorgente, figure, simulazioni
dpa/                             DPA  — documenti finali in pdf/ e word/ (IT, EN), testi sorgente, figure
democrazia-ponderata-adattiva/   codice, test e risultati delle simulazioni della DPA (V0–V16, V21–V27)
strumenti/                       generatori dei documenti Word/PDF
```

Ogni cartella di modello ha un README con la sua struttura e una scheda `ZENODO.md`.

## Riprodurre

- Simulazioni: Python 3 con NumPy, SciPy e Matplotlib (`democrazia-ponderata-adattiva/requirements.txt`). Ogni versione ha un README con i comandi; le esecuzioni sono deterministiche con semi fissati.
- Documenti: `bash strumenti/genera_documenti.sh` dalla radice rigenera Word e PDF (richiede pandoc, lxml e, per i PDF, LibreOffice).

## Licenza

Vedi [LICENZA.md](LICENZA.md): documenti CC BY 4.0, codice MIT.
