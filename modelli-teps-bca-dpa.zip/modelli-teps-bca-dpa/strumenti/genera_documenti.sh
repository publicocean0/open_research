#!/usr/bin/env bash
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
# Rigenera i paper a colori (Word, e PDF se è installato LibreOffice) di tutti i modelli, in italiano e in inglese.
# Uso (dalla radice del repository):  bash strumenti/genera_documenti.sh
# Richiede pandoc e lxml; per i PDF serve LibreOffice (soffice). Il PDF definitivo, con i caratteri Aptos e
# Cambria Math dell'originale, si ottiene aprendo il Word e salvandolo come PDF da Microsoft Word.
set -euo pipefail
cd "$(dirname "$0")/.."
P="python3 strumenti/paper_docx.py"

# TEPS 1.5
$P teps/TEPS_1_5_Modello_Economico_Integrato.md teps/word/TEPS_1_5_IT.docx
$P teps/TEPS_1_5_Economic_Model_EN.md teps/word/TEPS_1_5_EN.docx --lingua en \
   --titolo "Theory of Post-Wage|Economic Equilibrium" \
   --intestazione "TEPS  |  THEORY OF POST-WAGE ECONOMIC EQUILIBRIUM" \
   --piede "TEPS 1.5  ·  30 October 2026, upd. 2 November 2026" \
   --titolo-doc "TEPS 1.5 — Theory of Post-Wage Economic Equilibrium"

# BCA 1.0
$P bca/BCA_1_0_Modello_Economico.md bca/word/BCA_1_0_IT.docx --sigla BCA \
   --titolo "Economia di mercato con|Banca Centrale Algoritmica" \
   --sottotitolo "Moneta, credito e politica monetaria senza banche private: una banca centrale pubblica gestita da IA con regole deterministiche" \
   --versione "VERSIONE 1.0 · 2 NOVEMBRE 2026" \
   --intestazione "BCA  |  ECONOMIA DI MERCATO CON BANCA CENTRALE ALGORITMICA" \
   --piede "BCA 1.0  ·  2 novembre 2026" \
   --titolo-doc "BCA 1.0 — Economia di mercato con Banca Centrale Algoritmica" \
   --riquadri "Conclusione della §6;Il costo da dichiarare;Perché conta per la moneta" --indice
$P bca/BCA_1_0_Economic_Model_EN.md bca/word/BCA_1_0_EN.docx --lingua en --sigla BCA \
   --titolo "Market Economy with an|Algorithmic Central Bank" \
   --sottotitolo "Money, credit and monetary policy without private banks: a public central bank run by AI under deterministic rules" \
   --versione "VERSION 1.0 · 2 NOVEMBER 2026" \
   --intestazione "BCA  |  MARKET ECONOMY WITH AN ALGORITHMIC CENTRAL BANK" \
   --piede "BCA 1.0  ·  2 November 2026" \
   --titolo-doc "BCA 1.0 — Market Economy with an Algorithmic Central Bank" \
   --riquadri "Conclusion of §6;The cost to be declared;Why it matters for money" --indice

# DPA 1.0
$P dpa/DPA_1_0_Modello_Democratico.md dpa/word/DPA_1_0_IT.docx --sigla DPA \
   --titolo "Democrazia Ponderata|Adattiva" \
   --sottotitolo "Decisioni indirizzate per competenza certificata, con tetto ai pesi, base minima e diritti universali a voto eguale" \
   --versione "VERSIONE 1.0 · 9 NOVEMBRE 2026" \
   --intestazione "DPA  |  DEMOCRAZIA PONDERATA ADATTIVA" \
   --piede "DPA 1.0  ·  9 novembre 2026" \
   --titolo-doc "DPA 1.0 — Democrazia Ponderata Adattiva" --indice


$P dpa/DPA_1_0_Democratic_Model_EN.md dpa/word/DPA_1_0_EN.docx --lingua en --sigla DPA \
   --titolo "Adaptive Weighted|Democracy" \
   --sottotitolo "Decisions routed by certified competence, with capped weights, a minimum voting base and an equal vote on universal rights" \
   --versione "VERSION 1.0 · 9 NOVEMBER 2026" \
   --intestazione "DPA  |  ADAPTIVE WEIGHTED DEMOCRACY" \
   --piede "DPA 1.0  ·  9 November 2026" \
   --titolo-doc "DPA 1.0 — Adaptive Weighted Democracy" --indice

# PDF
if command -v soffice >/dev/null 2>&1; then
  for m in teps bca dpa; do
    for f in "$m"/word/*.docx; do
      soffice --headless --convert-to pdf --outdir "$m/pdf" "$f" >/dev/null
    done
  done
fi
echo "Documenti rigenerati in teps/, bca/, dpa/ (word e pdf)"
