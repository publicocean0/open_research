# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Modello «paper» a colori per i documenti dei modelli economici (stile del PDF originale TEPS 1.4).

Stile misurato sul PDF TEPS 1.4 del 13 ottobre 2026 (Word per Microsoft 365): formato Letter, testo in Aptos 9,5 pt,
titoli in Calibri grassetto blu notte, copertina con la sigla verde petrolio, riquadri su fondo verde chiaro con
etichetta in maiuscolo, tabelle con intestazione blu notte e righe alternate, formule in Cambria Math,
intestazione e piè di pagina piccoli allineati a destra, figure a tutta larghezza.

Uso (dalla radice del repository):
    TEPS:  python3 strumenti/paper_docx.py teps/TEPS_1_5_Modello_Economico_Integrato.md teps/word/TEPS_1_5_IT.docx
    BCA:   python3 strumenti/paper_docx.py bca/BCA_1_0_Modello_Economico.md bca/word/BCA_1_0_IT.docx --sigla BCA \
             --titolo "Economia di mercato con|Banca Centrale Algoritmica" --sottotitolo "…" --versione "VERSIONE 1.0 · …" \
             --intestazione "BCA  |  …" --piede "BCA 1.0  ·  2 novembre 2026" --titolo-doc "BCA 1.0 — …" --indice
I valori predefiniti sono quelli della TEPS. Richiede pandoc e lxml.
"""
import argparse, os, re, shutil, subprocess, sys, tempfile, zipfile
from lxml import etree

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("src"); ap.add_argument("out")
ap.add_argument("--sigla", default="TEPS")
ap.add_argument("--titolo", default="Teoria dell’Equilibrio Economico|Post-Salariale", help="righe del titolo separate da |")
ap.add_argument("--sottotitolo", default=None)
ap.add_argument("--versione", default=None)
ap.add_argument("--autore", default="Cristian Lorenzetto", help="autore, in copertina e nei metadati")
ap.add_argument("--orcid", default="0009-0001-4925-4728", help="ORCID dell'autore, in copertina")
ap.add_argument("--intestazione", default="TEPS  |  TEORIA DELL’EQUILIBRIO ECONOMICO POST-SALARIALE")
ap.add_argument("--piede", default="TEPS 1.5  ·  30 ottobre 2026, agg. 2 novembre 2026")
ap.add_argument("--titolo-doc", default="TEPS 1.5 — Teoria dell’Equilibrio Economico Post-Salariale")
ap.add_argument("--riquadri", default="", help="etichette di riquadro aggiuntive, separate da ;")
ap.add_argument("--indice", action="store_true", help="crea l'indice dei contenuti dai capitoli numerati")
ap.add_argument("--lingua", choices=["it", "en"], default="it", help="lingua delle etichette fisse")
A = ap.parse_args()
SRC, OUT = A.src, A.out
SRCDIR = os.path.dirname(os.path.abspath(SRC))
FOOTER_TEXT, HEADER_TEXT = A.piede, A.intestazione

# colori e misure dell'originale
TXT, NAVY, TEAL, GREY = "2B353F", "183147", "147772", "5B6A77"
BOXBG, HEADFILL, BAND, RULE, LINEBLUE = "EAF4F2", "16344E", "F1F6F7", "D9E2E8", "4F81BD"
PAGE_W, PAGE_H, M_LEFT, M_RIGHT, M_TOP, M_BOTTOM = 12240, 15840, 1332, 1240, 1180, 1180
TEXT_W = PAGE_W - M_LEFT - M_RIGHT
BOXES = ["Ipotesi di scenario", "Esito della verifica", "Principio guida [P]", "Conseguenza economica",
         "Aggiornamento 1.1", "Distinzione essenziale", "Nota post-fusione (1.1)", "Distinzione necessaria",
         "Conclusione generale"] + [b for b in A.riquadri.split(";") if b.strip()]
L = dict(it=dict(versione="**VERSIONE DI LAVORO", sottotitolo="*Modello consolidato", integrazione="Integrazione 1.5 — ",
                 INTEGRAZIONE="INTEGRAZIONE 1.5 — ", ambiti="Ambiti coperti", stato="Stato scientifico",
                 lettura="Lettura corretta delle prove", sintesi="Sintesi esecutiva", indice="Indice dei contenuti",
                 appendice="Appendice", tabella="Tabella", figura="Figura", lang="it-IT", pag="Pag."),
         en=dict(versione="**WORKING VERSION", sottotitolo="*Consolidated model", integrazione="Integration 1.5 — ",
                 INTEGRAZIONE="INTEGRATION 1.5 — ", ambiti="Scope", stato="Scientific status",
                 lettura="How to read the results", sintesi="Executive summary", indice="Contents",
                 appendice="Appendix", tabella="Table", figura="Figure", lang="en-GB", pag="Page"))[A.lingua]
if A.lingua == "en":
    BOXES = ["Scenario assumptions", "Verification outcome", "Guiding principle [P]", "Economic consequence", "Update 1.1",
             "Essential distinction", "Post-fusion note (1.1)", "Necessary distinction", "General conclusion"] + \
            [b for b in A.riquadri.split(";") if b.strip()]

work = tempfile.mkdtemp()

# ======================================================================= 1. markdown → markdown con stili
ESC = re.compile(r'([\\`*_\[\]<>|#~^$@])')
SUBRE = re.compile(r'(?<![\\\w.])([A-Za-zΑ-Ωα-ωᴬ-ᵿ]+)_(\{[^}]*\}|[A-Za-z0-9Α-Ωα-ω*]+)')
def sub_placeholders(s):
    return SUBRE.sub(lambda m: m.group(1) + "\x00" + m.group(2).strip("{}") + "\x01", s)
def finish_sub(s, escape):
    def rep(m):
        x = m.group(1)
        if escape:
            x = ESC.sub(r'\\\1', x)
        return "~" + x.replace(" ", "\\ ") + "~"
    return re.sub("\x00(.*?)\x01", rep, s)
def text_subs(line):
    parts = line.split("`")
    for i in range(0, len(parts), 2):
        parts[i] = finish_sub(sub_placeholders(parts[i]), escape=False)
    return "`".join(parts)
def formula_line(s):
    s = s[4:].rstrip()
    s = sub_placeholders(s)
    s = ESC.sub(r'\\\1', s)
    s = finish_sub(s, escape=True)
    s = re.sub(r' {3,}', '  ', s)
    return re.sub(r'^( +)', lambda m: ' ' * (len(m.group(1)) // 2), s)
def div(style, *paras):
    out = ['::: {custom-style="%s"}' % style]
    for k, p in enumerate(paras):
        out.append(p)
        if k < len(paras) - 1:
            out.append("")
    out.append(":::")
    return out
PAGEBREAK = ['```{=openxml}', '<w:p><w:r><w:br w:type="page"/></w:r></w:p>', '```']

lines = open(SRC, encoding="utf-8").read().split("\n")
if any(l.startswith(L["versione"]) for l in lines[:20]):
    # documento con copertina già scritta (TEPS): sottotitolo e versione dalle prime righe
    sottotitolo = A.sottotitolo or next(l for l in lines[:20] if l.startswith(L["sottotitolo"])).strip("*")
    versione = A.versione or next(l for l in lines[:20] if l.startswith(L["versione"])).strip("*")
    start = next(i_ for i_, l in enumerate(lines) if l.startswith(L["versione"])) + 1
else:
    # documento con titolo «# …» e riga «## Versione …»: la copertina viene dagli argomenti
    sottotitolo, versione, start = A.sottotitolo or "", A.versione or "", 0
    while start < len(lines) and (lines[start].startswith(("# ", "## Versione", "## Version")) or not lines[start].strip()):
        start += 1
lines = lines[start:]
capitoli = [m.groups() for m in (re.match(r'^## (\d+)\. (.*)$', l) for l in lines) if m]

out = []
out += div("CopertinaSigla", A.sigla) + [""]
righe = A.titolo.split("|")
out += ['::: {custom-style="CopertinaTitolo"}'] + [r + "\\" for r in righe[:-1]] + [righe[-1], ":::", ""]
if sottotitolo:
    out += div("CopertinaSottotitolo", sottotitolo) + [""]
if A.autore:
    out += div("CopertinaAutore", A.autore + ("  ·  ORCID " + A.orcid if A.orcid else "")) + [""]
if versione:
    out += div("CopertinaVersione", versione) + [""]

boxre = re.compile(r'^\*\*(%s)\.\*\* (.*)$' % "|".join(re.escape(b) for b in BOXES))
in_index = False
k = 0
while k < len(lines):
    ln = lines[k]
    prev_blank = k == 0 or lines[k - 1].strip() == ""
    # blocchi di formule
    if ln.startswith("    ") and ln.strip() and prev_blank and not ln.lstrip().startswith(("- ", "* ")):
        block = []
        while k < len(lines) and (lines[k].startswith("    ") or (lines[k].strip() == "" and k + 1 < len(lines) and lines[k + 1].startswith("    "))):
            if lines[k].strip():
                block.append(formula_line(lines[k]))
            k += 1
        out += div("Formula", *block)
        continue
    k += 1
    if ln.strip() == "---":
        continue
    if A.indice and capitoli and ln.startswith("## %s. " % capitoli[0][0]):
        out += PAGEBREAK + ["", "## " + L["indice"], ""]
        for num, tit in capitoli:
            out += div("Indice", '[%02d]{custom-style="IndiceNumero"} %s' % (int(num), text_subs(tit))) + [""]
        capitoli = []
    if ln.startswith("## "):
        in_index = ln.startswith("## " + L["indice"])
        if ln.startswith(tuple("## " + x for x in (L["sintesi"], L["indice"], L["appendice"] + " A", L["appendice"] + " B"))):
            out += PAGEBREAK + [""]
        out.append(text_subs(ln)); continue
    m = boxre.match(ln)
    if m:
        out += div("RiquadroEtichetta", m.group(1).upper()) + [""] + div("Riquadro", text_subs(m.group(2)))
        continue
    m = re.match(r'^\*\*' + re.escape(L["integrazione"]) + r'(.*)\*\*$', ln)
    if m:
        out += div("IntegrazioneEtichetta", text_subs(L["INTEGRAZIONE"] + m.group(1).upper()))
        continue
    if ln == "**%s**" % L["ambiti"]:
        out.append(L["ambiti"]); continue
    if ln.startswith(("**%s:**" % L["stato"], "**%s.**" % L["stato"])):
        out.append(text_subs(re.sub(r'^\*\*' + L["stato"] + r'[:.]\*\*', L["stato"] + ":", ln))); continue
    if ln == "**%s**" % L["lettura"]:
        out.append("### " + L["lettura"]); continue
    m = re.match(r'^- (\d\d) (.*)$', ln)
    if in_index and m:
        out += div("Indice", '[%s]{custom-style="IndiceNumero"} %s' % (m.group(1), text_subs(m.group(2))))
        continue
    m = re.match(r'^\*((?:%s|%s) \d+\..*)\*$' % (L["tabella"], L["figura"]), ln)
    if m:
        out += div("Didascalia", text_subs(m.group(1))); continue
    m = re.match(r'^!\[\]\((figure/[^)]+)\)$', ln)
    if m:
        out += div("Immagine", "![](%s){width=6.17in}" % m.group(1)); continue
    out.append(text_subs(ln))

md = os.path.join(work, "in.md")
open(md, "w", encoding="utf-8").write("\n".join(out))

# ======================================================================= 2. stili
ref = os.path.join(work, "ref.docx")
subprocess.run(["pandoc", "-o", ref, "--print-default-data-file", "reference.docx"], check=True)
refdir = os.path.join(work, "ref"); os.mkdir(refdir)
zipfile.ZipFile(ref).extractall(refdir)
sp = os.path.join(refdir, "word", "styles.xml")
s = open(sp, encoding="utf-8").read()

def F(name):
    return '<w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"/>' % (name, name, name, name)
def set_style(sid, ppr=None, rpr=None):
    global s
    m = re.search(r'(<w:style [^>]*w:styleId="%s">)(.*?)(</w:style>)' % sid, s, re.S)
    body = m.group(2)
    if ppr is not None:
        body = re.sub(r'<w:pPr>.*?</w:pPr>|<w:pPr ?/>', '', body, flags=re.S) + "<w:pPr>%s</w:pPr>" % ppr
    if rpr is not None:
        body = re.sub(r'<w:rPr>.*?</w:rPr>', '', body, flags=re.S) + "<w:rPr>%s</w:rPr>" % rpr
    s = s[:m.start()] + m.group(1) + body + m.group(3) + s[m.end():]
def add_style(sid, ppr, rpr, kind="paragraph"):
    global s
    s = s.replace("</w:styles>", '<w:style w:type="%s" w:customStyle="1" w:styleId="%s"><w:name w:val="%s"/>%s<w:qFormat/>%s%s</w:style></w:styles>'
                  % (kind, sid, sid, '<w:basedOn w:val="Normal"/>' if kind == "paragraph" else "",
                     "<w:pPr>%s</w:pPr>" % ppr if ppr else "", "<w:rPr>%s</w:rPr>" % rpr if rpr else ""))
SHD = '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>'
s = re.sub(r'<w:rPrDefault>.*?</w:rPrDefault>', '<w:rPrDefault><w:rPr>%s<w:color w:val="%s"/><w:sz w:val="19"/><w:szCs w:val="19"/><w:lang w:val="%s" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>' % (F("Aptos"), TXT, L["lang"]), s, flags=re.S)
s = re.sub(r'<w:pPrDefault>.*?</w:pPrDefault>', '<w:pPrDefault><w:pPr><w:spacing w:after="140" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault>', s, flags=re.S)
set_style("BodyText", ppr='<w:spacing w:before="0" w:after="140"/>')
set_style("FirstParagraph", ppr='<w:spacing w:before="0" w:after="140"/>')
set_style("Compact", ppr='<w:spacing w:before="20" w:after="40"/>')
set_style("Heading1", ppr='<w:keepNext/><w:keepLines/><w:spacing w:before="400" w:after="160"/><w:outlineLvl w:val="0"/>',
          rpr='%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="31"/><w:szCs w:val="31"/>' % (F("Calibri"), NAVY))
set_style("Heading2", ppr='<w:keepNext/><w:keepLines/><w:spacing w:before="240" w:after="100"/><w:outlineLvl w:val="1"/>',
          rpr='%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="23"/><w:szCs w:val="23"/>' % (F("Calibri"), NAVY))
set_style("Heading3", ppr='<w:keepNext/><w:keepLines/><w:spacing w:before="200" w:after="80"/><w:outlineLvl w:val="2"/>',
          rpr='%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="21"/><w:szCs w:val="21"/>' % (F("Calibri"), NAVY))
add_style("Formula", '<w:keepLines/><w:spacing w:before="60" w:after="60" w:line="264" w:lineRule="auto"/><w:ind w:left="312"/>',
          '%s<w:color w:val="%s"/><w:sz w:val="21"/><w:szCs w:val="21"/>' % (F("Cambria Math"), NAVY))
add_style("RiquadroEtichetta", '<w:keepNext/><w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="%s"/><w:left w:val="single" w:sz="4" w:space="4" w:color="%s"/><w:right w:val="single" w:sz="4" w:space="4" w:color="%s"/></w:pBdr>%s<w:spacing w:before="200" w:after="40"/><w:ind w:left="96" w:right="96"/>' % (BOXBG, BOXBG, BOXBG, SHD % BOXBG),
          '<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="17"/><w:szCs w:val="17"/>' % TEAL)
add_style("Riquadro", '<w:pBdr><w:left w:val="single" w:sz="4" w:space="4" w:color="%s"/><w:bottom w:val="single" w:sz="4" w:space="4" w:color="%s"/><w:right w:val="single" w:sz="4" w:space="4" w:color="%s"/></w:pBdr>%s<w:spacing w:before="0" w:after="240" w:line="264" w:lineRule="auto"/><w:ind w:left="96" w:right="96"/>' % (BOXBG, BOXBG, BOXBG, SHD % BOXBG),
          '<w:sz w:val="18"/><w:szCs w:val="18"/>')
add_style("IntegrazioneEtichetta", '<w:keepNext/><w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="%s"/><w:left w:val="single" w:sz="24" w:space="6" w:color="%s"/><w:bottom w:val="single" w:sz="4" w:space="4" w:color="%s"/><w:right w:val="single" w:sz="4" w:space="4" w:color="%s"/></w:pBdr>%s<w:spacing w:before="280" w:after="160"/><w:ind w:left="120" w:right="96"/>' % (BOXBG, TEAL, BOXBG, BOXBG, SHD % BOXBG),
          '<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="17"/><w:szCs w:val="17"/>' % TEAL)
add_style("Didascalia", '<w:spacing w:before="60" w:after="200" w:line="240" w:lineRule="auto"/>', '<w:color w:val="%s"/><w:sz w:val="16"/><w:szCs w:val="16"/>' % GREY)
add_style("Immagine", '<w:keepNext/><w:spacing w:before="160" w:after="40"/><w:jc w:val="center"/>', None)
add_style("Indice", '<w:spacing w:before="0" w:after="60"/>', None)
add_style("IndiceNumero", None, '<w:b/><w:bCs/><w:color w:val="%s"/>' % TEAL, kind="character")
add_style("CopertinaSigla", '<w:spacing w:before="1500" w:after="300" w:line="240" w:lineRule="auto"/>', '%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="84"/><w:szCs w:val="84"/>' % (F("Aptos"), TEAL))
add_style("CopertinaTitolo", '<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="6" w:color="%s"/></w:pBdr><w:spacing w:before="200" w:after="240" w:line="240" w:lineRule="auto"/>' % LINEBLUE,
          '%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="54"/><w:szCs w:val="54"/>' % (F("Calibri"), NAVY))
add_style("CopertinaSottotitolo", '<w:spacing w:before="0" w:after="600"/>', '%s<w:i/><w:iCs/><w:color w:val="%s"/><w:spacing w:val="10"/><w:sz w:val="26"/><w:szCs w:val="26"/>' % (F("Calibri"), TEAL))
add_style("CopertinaAutore", '<w:spacing w:before="0" w:after="240"/>', '%s<w:b/><w:bCs/><w:color w:val="%s"/><w:sz w:val="22"/><w:szCs w:val="22"/>' % (F("Calibri"), NAVY))
add_style("CopertinaVersione", '<w:spacing w:before="0" w:after="480"/>', '<w:b/><w:bCs/><w:sz w:val="19"/><w:szCs w:val="19"/>')
# tabella: solo linee orizzontali
tbl = re.search(r'<w:style w:type="table" w:default="1" w:styleId="Table">.*?</w:style>', s, re.S).group(0)
s = s.replace(tbl, '''<w:style w:type="table" w:default="1" w:styleId="Table"><w:name w:val="Table"/><w:basedOn w:val="TableNormal"/><w:qFormat/>
<w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblBorders><w:bottom w:val="single" w:sz="4" w:space="0" w:color="%s"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="%s"/></w:tblBorders>
<w:tblCellMar><w:top w:w="45" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="45" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>''' % (RULE, RULE))
s = re.sub(r'(<w:style [^>]*w:styleId="Hyperlink".*?<w:color w:val=")[0-9A-Fa-f]+(")', r'\g<1>%s\2' % NAVY, s, flags=re.S)
open(sp, "w", encoding="utf-8").write(s)
os.remove(ref)
with zipfile.ZipFile(ref, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(refdir):
        for f in files:
            full = os.path.join(root, f); z.write(full, os.path.relpath(full, refdir))

# ======================================================================= 3. pandoc
raw = os.path.join(work, "raw.docx")
subprocess.run(["pandoc", md, "-f", "markdown-implicit_figures", "--shift-heading-level-by=-1",
                "--resource-path", SRCDIR, "-o", raw, "--reference-doc", ref,
                "-M", "lang=" + L["lang"]], check=True)

# ======================================================================= 4. pagina, intestazione, piè di pagina, tabelle
od = os.path.join(work, "out"); os.mkdir(od)
zipfile.ZipFile(raw).extractall(od)
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
q = lambda n: "{%s}%s" % (W, n)
dp = os.path.join(od, "word", "document.xml")
d = open(dp, encoding="utf-8").read()
d = re.sub(r'<w:sectPr\s*/>|<w:sectPr.*?</w:sectPr>', '', d, flags=re.S)
d = d.replace("</w:body>", '<w:sectPr><w:headerReference w:type="default" r:id="rIdHeader1"/><w:footerReference w:type="default" r:id="rIdFooter1"/>'
              '<w:pgSz w:w="%d" w:h="%d"/><w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" w:header="560" w:footer="600" w:gutter="0"/></w:sectPr></w:body>'
              % (PAGE_W, PAGE_H, M_TOP, M_RIGHT, M_BOTTOM, M_LEFT))
open(dp, "w", encoding="utf-8").write(d)

def run(text, sz, color, bold=False):
    return ('<w:r><w:rPr>%s%s<w:color w:val="%s"/><w:sz w:val="%d"/><w:szCs w:val="%d"/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r>'
            % (F("Aptos"), "<w:b/><w:bCs/>" if bold else "", color, sz, sz, text))
NS = 'xmlns:w="%s" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"' % W
header = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr %s><w:p><w:pPr><w:jc w:val="right"/></w:pPr>%s</w:p></w:hdr>' % (NS, run(HEADER_TEXT, 14, GREY, True))
fld = lambda kind: '<w:r><w:rPr>%s<w:color w:val="%s"/><w:sz w:val="18"/></w:rPr><w:fldChar w:fldCharType="%s"/></w:r>' % (F("Aptos"), NAVY, kind)
footer = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr %s><w:p><w:pPr><w:jc w:val="right"/></w:pPr>%s%s'
          '<w:r><w:rPr>%s<w:color w:val="%s"/><w:sz w:val="18"/></w:rPr><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>%s'
          '<w:r><w:rPr>%s<w:color w:val="%s"/><w:sz w:val="18"/></w:rPr><w:t>1</w:t></w:r>%s</w:p></w:ftr>'
          % (NS, run(FOOTER_TEXT + "     |     %s " % L["pag"], 15, GREY), fld("begin"), F("Aptos"), NAVY, fld("separate"), F("Aptos"), NAVY, fld("end")))
open(os.path.join(od, "word", "header1.xml"), "w", encoding="utf-8").write(header)
open(os.path.join(od, "word", "footer1.xml"), "w", encoding="utf-8").write(footer)
rp = os.path.join(od, "word", "_rels", "document.xml.rels")
r = open(rp, encoding="utf-8").read().replace("</Relationships>",
    '<Relationship Id="rIdHeader1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'
    '<Relationship Id="rIdFooter1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
open(rp, "w", encoding="utf-8").write(r)
cp = os.path.join(od, "[Content_Types].xml")
c = open(cp, encoding="utf-8").read().replace("</Types>",
    '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>'
    '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
if 'Extension="png"' not in c:
    c = c.replace("<Types ", "<Types ", 1).replace("</Types>", '<Default Extension="png" ContentType="image/png"/></Types>')
open(cp, "w", encoding="utf-8").write(c)

def set_run_props(rnode, sz=None, color=None, bold=None):
    rpr = rnode.find(q("rPr"))
    if rpr is None:
        rpr = etree.Element(q("rPr")); rnode.insert(0, rpr)
    if bold:
        for tag in ("b", "bCs"):
            if rpr.find(q(tag)) is None:
                etree.SubElement(rpr, q(tag))
    if color:
        e = rpr.find(q("color"))
        if e is None:
            e = etree.SubElement(rpr, q("color"))
        e.set(q("val"), color)
    if sz:
        for tag in ("sz", "szCs"):
            e = rpr.find(q(tag))
            if e is None:
                e = etree.SubElement(rpr, q(tag))
            e.set(q("val"), str(sz))

def style_tables(path):
    tree = etree.parse(path); root = tree.getroot()
    for tbl in root.iter(q("tbl")):
        rows = tbl.findall(q("tr"))
        ncol = max(len(rw.findall(q("tc"))) for rw in rows)
        lens, minword = [[] for _ in range(ncol)], [3] * ncol
        for rw in rows:
            for j, tc in enumerate(rw.findall(q("tc"))):
                txt = "".join(x.text or "" for x in tc.iter(q("t")))
                lens[j].append(len(txt))
                minword[j] = max(minword[j], max([len(w) for w in txt.split()] or [1]) + 2)
        weights = []
        for j, L in enumerate(lens):
            mx, avg = max(L or [1]), sum(L or [1]) / max(1, len(L))
            cap = 16.0 if ncol >= 7 else 55.0
            weights.append(max(6.0, minword[j] * (1.7 if ncol >= 7 else 1.3), min(0.5 * mx + 0.5 * avg, cap)))
        widths = [int(TEXT_W * w / sum(weights)) for w in weights]
        widths[-1] += TEXT_W - sum(widths)
        tblPr = tbl.find(q("tblPr"))
        tw = tblPr.find(q("tblW")); tw.set(q("w"), str(TEXT_W)); tw.set(q("type"), "dxa")
        look = tblPr.find(q("tblLook"))
        if look is not None:
            for k_, v_ in (("val", "0420"), ("firstRow", "1"), ("lastRow", "0"), ("firstColumn", "0"), ("lastColumn", "0"), ("noHBand", "0"), ("noVBand", "1")):
                look.set(q(k_), v_)
        grid = tbl.find(q("tblGrid"))
        for g in list(grid): grid.remove(g)
        for w_ in widths:
            etree.SubElement(grid, q("gridCol")).set(q("w"), str(w_))
        for i, rw in enumerate(rows):
            trPr = rw.find(q("trPr"))
            if trPr is None:
                trPr = etree.Element(q("trPr")); rw.insert(1 if rw.find(q("tblPrEx")) is not None else 0, trPr)
            if trPr.find(q("cantSplit")) is None:
                trPr.insert(0, etree.Element(q("cantSplit")))
            if i == 0 and trPr.find(q("tblHeader")) is None:
                etree.SubElement(trPr, q("tblHeader"))
            fill = HEADFILL if i == 0 else (BAND if i % 2 == 1 else None)
            for j, tc in enumerate(rw.findall(q("tc"))):
                tcPr = tc.find(q("tcPr"))
                if tcPr is None:
                    tcPr = etree.Element(q("tcPr")); tc.insert(0, tcPr)
                tcw = tcPr.find(q("tcW"))
                if tcw is None:
                    tcw = etree.Element(q("tcW")); tcPr.insert(0, tcw)
                tcw.set(q("w"), str(widths[j])); tcw.set(q("type"), "dxa")
                for old in tcPr.findall(q("shd")):
                    tcPr.remove(old)
                if fill:
                    shd = etree.SubElement(tcPr, q("shd")); shd.set(q("val"), "clear"); shd.set(q("color"), "auto"); shd.set(q("fill"), fill)
                for rn in tc.iter(q("r")):
                    if i == 0:
                        set_run_props(rn, sz=17, color="FFFFFF", bold=True)
                    else:
                        set_run_props(rn, sz=16 if ncol < 7 else 15)
    tree.write(path, xml_declaration=True, encoding="UTF-8", standalone=True)
style_tables(dp)

# ======================================================================= 5. pulizia conforme allo schema
PPR = "pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange".split()
TBLPR = "tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription".split()
TCPR = "cnfStyle tcW gridSpan hMerge vMerge tcBorders shd noWrap tcMar textDirection tcFitText vAlign hideMark".split()
RPR = "rStyle rFonts b bCs i iCs caps smallCaps strike dstrike outline shadow emboss imprint noProof snapToGrid vanish webHidden color spacing w kern position sz szCs highlight u effect bdr shd fitText vertAlign rtl cs em lang eastAsianLayout specVanish oMath".split()
SETTINGS = """writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors activeWritingStyle proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle defaultTableStyle evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning characterSpacingControl printTwoOnOne strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang clrSchemeMapping doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults doNotEmbedSmartTags decimalSymbol listSeparator""".split()
def reorder(el, order):
    rank = {n: i for i, n in enumerate(order)}
    kids = sorted(list(el), key=lambda k_: rank.get(etree.QName(k_).localname, len(order)) if isinstance(k_.tag, str) else len(order))
    for k_ in list(el): el.remove(k_)
    for k_ in kids: el.append(k_)
def clean(path, settings=False):
    tree = etree.parse(path); root = tree.getroot()
    for e in root.iter(q("pPr")): reorder(e, PPR)
    for e in root.iter(q("tblPr")): reorder(e, TBLPR)
    for e in root.iter(q("tcPr")): reorder(e, TCPR)
    for e in root.iter(q("rPr")):
        e.text = None
        for k_ in e: k_.tail = None
        if e.getparent() is not None and etree.QName(e.getparent()).localname in ("r", "rPrDefault", "style"):
            reorder(e, RPR)
    for e in root.iter(q("nsid")):
        e.set(q("val"), "%08X" % (int(e.get(q("val")), 16) & 0xFFFFFFFF))
    if settings:
        reorder(root, SETTINGS)
    tree.write(path, xml_declaration=True, encoding="UTF-8", standalone=True)
for f, st in (("document.xml", False), ("styles.xml", False), ("numbering.xml", False), ("settings.xml", True)):
    clean(os.path.join(od, "word", f), settings=st)
core = os.path.join(od, "docProps", "core.xml")
if os.path.exists(core):
    cx = open(core, encoding="utf-8").read()
    title = A.titolo_doc
    cx = re.sub(r'<dc:title>.*?</dc:title>', '', cx, flags=re.S)
    cx = re.sub(r'<dc:creator>.*?</dc:creator>|<dc:creator/>', '', cx, flags=re.S)
    if A.autore:
        cx = cx.replace("</cp:coreProperties>", "<dc:creator>%s</dc:creator></cp:coreProperties>" % A.autore)
    cx = cx.replace("</cp:coreProperties>", "<dc:title>%s</dc:title></cp:coreProperties>" % title)
    open(core, "w", encoding="utf-8").write(cx)

if os.path.exists(OUT):
    os.remove(OUT)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(cp, "[Content_Types].xml")
    for root, _, files in os.walk(od):
        for f in files:
            full = os.path.join(root, f); rel = os.path.relpath(full, od)
            if rel != "[Content_Types].xml":
                z.write(full, rel)
shutil.rmtree(work)
print("scritto", OUT)
