# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Converte un documento Markdown dei modelli in un file Word (.docx) impaginato in nero, A4, testo a 12 pt.
Uso: python3 strumenti/md_to_docx.py input.md output.docx "Titolo" "Sottotitolo" "Testo piè di pagina"
Richiede pandoc e lxml.
"""
import re, sys, os, shutil, subprocess, zipfile, tempfile

src, out, title, subtitle, footer_text = sys.argv[1:6]
here = os.path.dirname(os.path.abspath(__file__))
work = tempfile.mkdtemp(dir=here)

# ---------------------------------------------------------------- 1. preprocess markdown
lines = open(src, encoding="utf-8").read().split("\n")
# togli titolo (# ...) e riga di versione (## Versione ...): vanno nei metadati
assert lines[0].startswith("# ")
i = 1
while i < len(lines) and (lines[i].strip() == "" or lines[i].startswith("## Versione")):
    i += 1
lines = lines[i:]

ESC = re.compile(r'([\\`*_\[\]<>|#~^$@])')
SUBRE = re.compile(r'(?<![\\\w.])([A-Za-zΑ-Ωα-ωᴬ-ᵿ]+)_(\{[^}]*\}|[A-Za-z0-9Α-Ωα-ω*]+)')
def sub_placeholders(s):
    return SUBRE.sub(lambda m: m.group(1) + "\x00" + m.group(2).strip("{}") + "\x01", s)
def finish_sub(s, escape):
    def rep(m):
        x = m.group(1)
        if escape:
            x = ESC.sub(r'\\\1', x)
        return "~" + x.replace(" ", "\\ ") + "~"
    return re.sub("\x00(.*?)\x01", rep, s)
def text_subs(line):
    parts = line.split("`")
    for idx in range(0, len(parts), 2):
        parts[idx] = finish_sub(sub_placeholders(parts[idx]), escape=False)
    return "`".join(parts)
def formula_line(s):
    s = s[4:].rstrip()
    s = sub_placeholders(s)
    s = ESC.sub(r'\\\1', s)
    s = finish_sub(s, escape=True)
    s = re.sub(r' {3,}', '  ', s)      # spaziature ampie → due em-space
    s = re.sub(r'^( +)', lambda m: ' ' * (len(m.group(1)) // 2), s)
    return s

outl, k = [], 0
while k < len(lines):
    ln = lines[k]
    prev_blank = (k == 0 or lines[k - 1].strip() == "")
    if ln.startswith("    ") and ln.strip() and prev_blank and not ln.lstrip().startswith(("- ", "* ")):
        block = []
        while k < len(lines) and (lines[k].startswith("    ") or (lines[k].strip() == "" and k + 1 < len(lines) and lines[k + 1].startswith("    "))):
            if lines[k].strip():
                block.append(formula_line(lines[k]))
            k += 1
        outl.append('::: {custom-style="Formula"}')
        for j, b in enumerate(block):
            outl.append(b)
            if j < len(block) - 1:
                outl.append("")
        outl.append(":::")
        continue
    outl.append(text_subs(ln))
    k += 1
md = os.path.join(work, "in.md")
open(md, "w", encoding="utf-8").write("\n".join(outl))

# ---------------------------------------------------------------- 2. reference.docx con stili
ref = os.path.join(work, "ref.docx")
subprocess.run(["pandoc", "-o", ref, "--print-default-data-file", "reference.docx"], check=True)
refdir = os.path.join(work, "ref"); os.mkdir(refdir)
zipfile.ZipFile(ref).extractall(refdir)
sp = os.path.join(refdir, "word", "styles.xml")
s = open(sp, encoding="utf-8").read()

def set_style(sid, ppr=None, rpr=None):
    global s
    m = re.search(r'(<w:style [^>]*w:styleId="%s">)(.*?)(</w:style>)' % sid, s, re.S)
    body = m.group(2)
    if ppr is not None:
        body = re.sub(r'<w:pPr>.*?</w:pPr>|<w:pPr ?/>', '', body, flags=re.S)
        body += "<w:pPr>%s</w:pPr>" % ppr
    if rpr is not None:
        body = re.sub(r'<w:rPr>.*?</w:rPr>', '', body, flags=re.S)
        body += "<w:rPr>%s</w:rPr>" % rpr
    s = s[:m.start()] + m.group(1) + body + m.group(3) + s[m.end():]

FONT = '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/>'
s = re.sub(r'<w:rPrDefault>.*?</w:rPrDefault>',
           '<w:rPrDefault><w:rPr>%s<w:sz w:val="24"/><w:szCs w:val="24"/><w:lang w:val="it-IT" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>' % FONT, s, flags=re.S)
s = re.sub(r'<w:pPrDefault>.*?</w:pPrDefault>', '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault>', s, flags=re.S)
set_style("BodyText", ppr='<w:spacing w:before="0" w:after="120"/><w:jc w:val="both"/>')
set_style("FirstParagraph", ppr='<w:spacing w:before="0" w:after="120"/><w:jc w:val="both"/>')
set_style("Compact", ppr='<w:spacing w:before="30" w:after="30" w:line="252" w:lineRule="auto"/>', rpr='<w:sz w:val="24"/><w:szCs w:val="24"/>')
set_style("Title", ppr='<w:keepNext/><w:spacing w:before="1200" w:after="200"/><w:jc w:val="left"/>',
          rpr='%s<w:b/><w:color w:val="000000"/><w:sz w:val="36"/><w:szCs w:val="36"/>' % FONT)
set_style("Subtitle", ppr='<w:pBdr><w:bottom w:val="single" w:sz="8" w:space="8" w:color="000000"/></w:pBdr><w:spacing w:before="0" w:after="480"/>',
          rpr='%s<w:b w:val="0"/><w:bCs w:val="0"/><w:color w:val="000000"/><w:sz w:val="26"/><w:szCs w:val="26"/>' % FONT)
set_style("Heading1", ppr='<w:keepNext/><w:keepLines/><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr><w:spacing w:before="420" w:after="160"/><w:outlineLvl w:val="0"/>',
          rpr='%s<w:b/><w:color w:val="000000"/><w:sz w:val="30"/><w:szCs w:val="30"/>' % FONT)
set_style("Heading2", ppr='<w:keepNext/><w:keepLines/><w:spacing w:before="280" w:after="100"/><w:outlineLvl w:val="1"/>',
          rpr='%s<w:b/><w:color w:val="000000"/><w:sz w:val="26"/><w:szCs w:val="26"/>' % FONT)
set_style("Heading3", ppr='<w:keepNext/><w:keepLines/><w:spacing w:before="200" w:after="80"/><w:outlineLvl w:val="2"/>',
          rpr='%s<w:b/><w:color w:val="000000"/><w:sz w:val="24"/><w:szCs w:val="24"/>' % FONT)
# tabelle: bordi leggeri, intestazione colorata
tbl = re.search(r'<w:style w:type="table" w:default="1" w:styleId="Table">.*?</w:style>', s, re.S).group(0)
newtbl = '''<w:style w:type="table" w:default="1" w:styleId="Table"><w:name w:val="Table"/><w:basedOn w:val="TableNormal"/><w:qFormat/>
<w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblBorders>
<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>
<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>
<w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/></w:tblBorders>
<w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="90" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/><w:right w:w="90" w:type="dxa"/></w:tblCellMar></w:tblPr>
<w:tblStylePr w:type="firstRow"><w:rPr><w:b/><w:color w:val="000000"/></w:rPr><w:tcPr><w:vAlign w:val="bottom"/></w:tcPr></w:tblStylePr></w:style>'''
s = s.replace(tbl, newtbl)
# stile Formula
s = s.replace("</w:styles>", '''<w:style w:type="paragraph" w:customStyle="1" w:styleId="Formula"><w:name w:val="Formula"/><w:basedOn w:val="Normal"/><w:qFormat/>
<w:pPr><w:keepLines/><w:spacing w:before="40" w:after="40" w:line="276" w:lineRule="auto"/><w:ind w:left="567" w:right="340"/></w:pPr>
<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math" w:eastAsia="Cambria Math" w:cs="Cambria Math"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:style></w:styles>''')
open(sp, "w", encoding="utf-8").write(s)
os.remove(ref)
with zipfile.ZipFile(ref, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(refdir):
        for f in files:
            full = os.path.join(root, f); z.write(full, os.path.relpath(full, refdir))

# ---------------------------------------------------------------- 3. pandoc
raw = os.path.join(work, "raw.docx")
subprocess.run(["pandoc", md, "-f", "markdown-implicit_figures", "-o", raw, "--reference-doc", ref,
                "-M", "title=" + title, "-M", "subtitle=" + subtitle, "-M", "lang=it-IT"], check=True)

# ---------------------------------------------------------------- 4. A4, margini, piè di pagina, tabelle
od = os.path.join(work, "out"); os.mkdir(od)
zipfile.ZipFile(raw).extractall(od)
dp = os.path.join(od, "word", "document.xml")
d = open(dp, encoding="utf-8").read()
sect = ('<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter1"/>'
        '<w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1247" w:right="1134" w:bottom="1247" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr>')
d = re.sub(r'<w:sectPr\s*/>|<w:sectPr.*?</w:sectPr>', '', d, flags=re.S)
d = d.replace("</w:body>", sect + "</w:body>")
# tabelle a piena larghezza
d = re.sub(r'<w:tblW [^>]*/>', '<w:tblW w:w="5000" w:type="pct"/>', d)
d = re.sub(r'<w:tblLayout [^>]*/>', '', d)
open(dp, "w", encoding="utf-8").write(d)
footer = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
          '<w:p><w:pPr><w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="000000"/></w:pBdr><w:tabs><w:tab w:val="right" w:pos="9638"/></w:tabs></w:pPr>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:t xml:space="preserve">%s</w:t></w:r>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:tab/><w:t xml:space="preserve">Pag. </w:t></w:r>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:fldChar w:fldCharType="separate"/></w:r>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:t>1</w:t></w:r>'
          '<w:r><w:rPr><w:color w:val="000000"/><w:sz w:val="20"/></w:rPr><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>') % footer_text
open(os.path.join(od, "word", "footer1.xml"), "w", encoding="utf-8").write(footer)
rp = os.path.join(od, "word", "_rels", "document.xml.rels")
r = open(rp, encoding="utf-8").read()
r = r.replace("</Relationships>", '<Relationship Id="rIdFooter1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
open(rp, "w", encoding="utf-8").write(r)
cp = os.path.join(od, "[Content_Types].xml")
c = open(cp, encoding="utf-8").read()
c = c.replace("</Types>", '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
open(cp, "w", encoding="utf-8").write(c)

# ---------------------------------------------------------------- 5. pulizia conforme allo schema
from lxml import etree
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
q = lambda n: "{%s}%s" % (W, n)
PPR = "pStyle keepNext keepLines pageBreakBefore framePr widowControl numPr suppressLineNumbers pBdr shd tabs suppressAutoHyphens kinsoku wordWrap overflowPunct topLinePunct autoSpaceDE autoSpaceDN bidi adjustRightInd snapToGrid spacing ind contextualSpacing mirrorIndents suppressOverlap jc textDirection textAlignment textboxTightWrap outlineLvl divId cnfStyle rPr sectPr pPrChange".split()
TBLPR = "tblStyle tblpPr tblOverlap bidiVisual tblStyleRowBandSize tblStyleColBandSize tblW jc tblCellSpacing tblInd tblBorders shd tblLayout tblCellMar tblLook tblCaption tblDescription".split()
SETTINGS = """writeProtection view zoom removePersonalInformation removeDateAndTime doNotDisplayPageBoundaries displayBackgroundShape printPostScriptOverText printFractionalCharacterWidth printFormsData embedTrueTypeFonts embedSystemFonts saveSubsetFonts saveFormsData mirrorMargins alignBordersAndEdges bordersDoNotSurroundHeader bordersDoNotSurroundFooter gutterAtTop hideSpellingErrors hideGrammaticalErrors activeWritingStyle proofState formsDesign attachedTemplate linkStyles stylePaneFormatFilter stylePaneSortMethod documentType mailMerge revisionView trackRevisions doNotTrackMoves doNotTrackFormatting documentProtection autoFormatOverride styleLockTheme styleLockQFSet defaultTabStop autoHyphenation consecutiveHyphenLimit hyphenationZone doNotHyphenateCaps showEnvelope summaryLength clickAndTypeStyle defaultTableStyle evenAndOddHeaders bookFoldRevPrinting bookFoldPrinting bookFoldPrintingSheets drawingGridHorizontalSpacing drawingGridVerticalSpacing displayHorizontalDrawingGridEvery displayVerticalDrawingGridEvery doNotUseMarginsForDrawingGridOrigin drawingGridHorizontalOrigin drawingGridVerticalOrigin doNotShadeFormData noPunctuationKerning characterSpacingControl printTwoOnOne strictFirstAndLastChars noLineBreaksAfter noLineBreaksBefore savePreviewPicture doNotValidateAgainstSchema saveInvalidXml ignoreMixedContent alwaysShowPlaceholderText doNotDemarcateInvalidXml saveXmlDataOnly useXSLTWhenSaving saveThroughXslt showXMLTags alwaysMergeEmptyNamespace updateFields hdrShapeDefaults footnotePr endnotePr compat docVars rsids mathPr attachedSchema themeFontLang clrSchemeMapping doNotIncludeSubdocsInStats doNotAutoCompressPictures forceUpgrade captions readModeInkLockDown smartTagType schemaLibrary shapeDefaults doNotEmbedSmartTags decimalSymbol listSeparator""".split()
def reorder(el, order):
    kids = list(el)
    rank = {n: i for i, n in enumerate(order)}
    kids.sort(key=lambda k: rank.get(etree.QName(k).localname, len(order)) if isinstance(k.tag, str) else len(order))
    for k in list(el): el.remove(k)
    for k in kids: el.append(k)
def clean(path, black=False, settings=False):
    tree = etree.parse(path); root = tree.getroot()
    for e in root.iter(q("pPr")): reorder(e, PPR)
    for e in root.iter(q("tblPr")): reorder(e, TBLPR)
    for e in root.iter(q("rPr")):
        e.text = None
        for k in e: k.tail = None
    for e in root.iter(q("nsid")):
        v = e.get(q("val")); e.set(q("val"), "%08X" % (int(v, 16) & 0xFFFFFFFF))
    if black:
        for e in root.iter(q("color")):
            for a in list(e.attrib):
                if a != q("val"): del e.attrib[a]
            e.set(q("val"), "000000")
    if settings:
        reorder(root, SETTINGS)
    tree.write(path, xml_declaration=True, encoding="UTF-8", standalone=True)
clean(os.path.join(od, "word", "document.xml"), black=True)
def size_tables(path, total=9638):
    tree = etree.parse(path); root = tree.getroot()
    for tbl in root.iter(q("tbl")):
        rows = tbl.findall(q("tr"))
        ncol = max(len(r.findall(q("tc"))) for r in rows)
        lens = [[] for _ in range(ncol)]
        for r in rows:
            for j, tc in enumerate(r.findall(q("tc"))):
                txt = "".join(x.text or "" for x in tc.iter(q("t")))
                lens[j].append(len(txt))
        minword = [3] * ncol
        for r in rows:
            for j, tc in enumerate(r.findall(q("tc"))):
                txt = "".join(x.text or "" for x in tc.iter(q("t")))
                minword[j] = max(minword[j], max([len(w) for w in txt.split()] or [1]) + 2)
        weights = []
        for j, L in enumerate(lens):
            mx, avg = max(L or [1]), sum(L or [1]) / max(1, len(L))
            cap = 16.0 if ncol >= 7 else 55.0
            mw = minword[j] * (1.6 if ncol >= 7 else 1.5)
            weights.append(max(7.0, mw, min(0.5 * mx + 0.5 * avg, cap)))
        widths = [int(total * w / sum(weights)) for w in weights]
        widths[-1] += total - sum(widths)
        tblPr = tbl.find(q("tblPr"))
        tw = tblPr.find(q("tblW"))
        tw.set(q("w"), str(total)); tw.set(q("type"), "dxa")
        grid = tbl.find(q("tblGrid"))
        for g in list(grid): grid.remove(g)
        for w in widths:
            gc = etree.SubElement(grid, q("gridCol")); gc.set(q("w"), str(w))
        for r in rows:
            for j, tc in enumerate(r.findall(q("tc"))):
                tcPr = tc.find(q("tcPr"))
                if tcPr is None:
                    tcPr = etree.Element(q("tcPr")); tc.insert(0, tcPr)
                tcw = tcPr.find(q("tcW"))
                if tcw is None:
                    tcw = etree.Element(q("tcW")); tcPr.insert(0, tcw)
                tcw.set(q("w"), str(widths[j])); tcw.set(q("type"), "dxa")
                if ncol >= 7:
                    for run in tc.iter(q("r")):
                        rpr = run.find(q("rPr"))
                        if rpr is None:
                            rpr = etree.Element(q("rPr")); run.insert(0, rpr)
                        for tag in ("sz", "szCs"):
                            e = rpr.find(q(tag))
                            if e is None:
                                e = etree.SubElement(rpr, q(tag))
                            e.set(q("val"), "20")
        # righe mai divise fra due pagine
        for r in rows:
            trp = r.find(q("trPr"))
            if trp is None:
                trp = etree.Element(q("trPr")); idx = 1 if r.find(q("tblPrEx")) is not None else 0; r.insert(idx, trp)
            if trp.find(q("cantSplit")) is None:
                trp.insert(0, etree.Element(q("cantSplit")))
        # intestazione ripetuta su ogni pagina
        trPr = rows[0].find(q("trPr"))
        if trPr is None:
            trPr = etree.Element(q("trPr")); rows[0].insert(0, trPr)
        if trPr.find(q("tblHeader")) is None:
            etree.SubElement(trPr, q("tblHeader"))
    tree.write(path, xml_declaration=True, encoding="UTF-8", standalone=True)
size_tables(os.path.join(od, "word", "document.xml"))
clean(os.path.join(od, "word", "document.xml"))
clean(os.path.join(od, "word", "styles.xml"), black=True)
clean(os.path.join(od, "word", "numbering.xml"))
clean(os.path.join(od, "word", "settings.xml"), settings=True)
if os.path.exists(out):
    os.remove(out)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(cp, "[Content_Types].xml")
    for root, _, files in os.walk(od):
        for f in files:
            full = os.path.join(root, f); rel = os.path.relpath(full, od)
            if rel != "[Content_Types].xml":
                z.write(full, rel)
shutil.rmtree(work)
print("scritto", out)
