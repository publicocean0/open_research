# BCA — Economia di mercato con Banca Centrale Algoritmica

## Versione 1.0 · 2 novembre 2026 (aggiornata con le regole del credito)

**Ipotesi di scenario.** Si parte dall'economia di mercato attuale: imprese private, lavoro salariato, Stato, prezzi di mercato, azioni. Cambia una sola istituzione: **non esistono banche private**. Un'unica Banca Centrale Algoritmica (BCA) tiene tutti i conti correnti e concede mutui, finanziamenti alle imprese e credito al consumo, con regole pubbliche e deterministiche eseguite da più sistemi di IA indipendenti. Non esiste alcun tasso di interesse fissato da banche private: il costo del credito è un **tasso pubblico algoritmico**, senza margine di profitto. La BCA applica ai mutui e ai finanziamenti **le stesse regole e la stessa analisi del rischio delle banche**, e le applica anche allo Stato quando chiede credito.

**Stato scientifico.** Modello teorico con dimostrazioni algebriche e simulazioni riproducibili su parametri dimostrativi. Non è calibrato su un'economia reale e non è una teoria validata empiricamente.

| Sigla | Significato |
|---|---|
| [D] | Proposizione derivata dalle equazioni, con ipotesi esplicitate |
| [N] | Risultato numerico riprodotto da uno script, non previsione |
| [P] | Principio istituzionale di progetto, non teorema |
| [A] | Assunzione tecnica introdotta per chiudere il modello |

---

## Sintesi esecutiva

| Domanda | Risposta del modello | Dove |
|---|---|---|
| Una banca centrale automatica può sostituire le banche private? | Sì per conti, pagamenti, creazione di moneta e credito: il registro conserva la moneta, non può subire corse agli sportelli ed è verificabile da chiunque | D-1, D-2, D-3 |
| Senza tasso privato il credito deve costare zero? | No. "Nessun tasso privato" non significa "tasso zero". A tasso zero l'inflazione non torna all'obiettivo; funziona solo razionando in modo permanente circa il 17% del credito domandato | D-8, D-9 |
| Quale disegno adotta il modello? | Tasso pubblico fissato da una regola algoritmica: tasso di politica contro l'inflazione + costo operativo + perdita attesa della classe di rischio, senza margine di profitto | D-4, D-5, D-7, D-14 |
| Con quali regole presta la BCA? | Le stesse delle banche: verifica del reddito, rata/reddito, prestito/valore, garanzie, classi di rischio, accantonamenti. Essere pubblica non significa prestare con criteri più morbidi | §9 |
| Lo Stato può farsi prestare senza limiti? | No: chiede credito alla BCA con analisi del rischio e limite di sostenibilità, come ogni debitore. Così la moneta creata per lo Stato resta limitata | D-15 |
| Dove vanno gli interessi? | Allo Stato: la BCA è pubblica e non ha guadagno proprio; gli interessi netti sono entrate pubbliche (1,9% del PIL nell'esempio) | D-5, D-6 |
| I depositi danno interessi? | Sì, con una regola sostenibile e bassa: al massimo l'inflazione obiettivo e sempre almeno un punto sotto il tasso di politica. I risparmi conservano il potere d'acquisto; per farli crescere bisogna investire | D-16 |
| Il sistema è più stabile? | Sì nelle crisi del credito: scompare il taglio dei prestiti dovuto alle perdite delle banche. Nell'ondata di insolvenze simulata la perdita di prodotto scende da 11,2 a 4,0 | D-10, N-2 |
| Che cosa resta da governare? | Le perdite sui prestiti diventano un costo pubblico; il credito senza margine spinge i prezzi delle case; senza regole deterministiche la BCA rischia di finanziare imprese in perdita | D-10, D-11, D-12 |

Il modello economico risulta coerente sotto **sette condizioni esplicite** (B1–B7, §11). Non sono dimostrate la stabilità globale, il funzionamento in economia aperta né la superiorità rispetto all'ordinamento attuale su dati reali.

---

## 1. Obiettivo e punto di partenza

Oggi la maggior parte della moneta è costituita da depositi bancari, creati dalle banche private quando concedono prestiti [4]. La banca centrale fissa un tasso di politica; le banche aggiungono uno spread che copre costi, perdite attese e profitto, e decidono a chi prestare. L'offerta di credito dipende dal loro capitale: quando subiscono perdite riducono i prestiti e amplificano le recessioni [7].

La BCA studia cosa accade se la creazione di moneta e il credito passano interamente a un'istituzione pubblica gestita da sistemi automatici. L'idea ha precedenti nel "100% money" di Fisher [1] e nel *Chicago Plan* riesaminato da Benes e Kumhof [2]. La differenza è che qui la banca pubblica non si limita a tenere riserve al 100%: **concede direttamente il credito**, con regole algoritmiche pubbliche.

## 2. Ipotesi

- **A1 — Economia chiusa** con moneta nazionale [A]. L'economia aperta è un limite dichiarato (§12).
- **A2 — Nessuna banca privata** [P]. Nessun soggetto privato può tenere depositi altrui, emettere mezzi di pagamento o creare moneta concedendo prestiti.
- **A3 — Banca unica** [P]. La BCA tiene i conti di famiglie, imprese e Stato; esegue i pagamenti; concede mutui, prestiti alle imprese e credito al consumo; fissa il tasso di politica.
- **A4 — Regole deterministiche** [P]. Ogni decisione della BCA (tassi, approvazione dei prestiti, quote, arresti) segue regole pubbliche, calcolate da più sistemi di IA indipendenti; le regole si cambiano solo per via legislativa, mai caso per caso.
- **A5 — Finanza non bancaria** [A]. Restano azioni e prestiti fra privati di moneta già esistente (per esempio obbligazioni). Non creano moneta (D-1) e il loro rendimento è vincolato dall'alternativa offerta dalla BCA.
- **A6 — Stato** [A]. Il Tesoro ha un conto presso la BCA come ogni altro soggetto; il risultato annuo della BCA gli viene trasferito o è coperto da lui. Quando chiede credito, lo Stato è un debitore come gli altri e segue le stesse regole di analisi del rischio (§9.6).
- **A7 — Contante** [A]. L'eventuale contante è emesso uno a uno contro i saldi e non cambia i risultati.
- **A8 — Depositi** [P]. I conti presso la BCA sono conti di pagamento, remunerati con la regola della D-16: sostenibile per la BCA e non superiore all'inflazione obiettivo.

## 3. Istituzioni

| Soggetto | Compito | Limite |
|---|---|---|
| BCA | Conti, pagamenti, credito, tasso di politica | Esegue solo regole pubbliche; nessuna discrezionalità caso per caso |
| Sistemi di IA della BCA | Calcolano il registro e le stime di rischio | Più sistemi indipendenti; decide la maggioranza o la mediana |
| Parlamento | Approva le regole e i parametri | Non interviene sulle singole pratiche |
| Tesoro | Riceve gli interessi netti incassati dalla BCA (entrate pubbliche) e copre le perdite oltre l'attesa | Secondo una regola annua fissa |
| Controllo indipendente | Audit del registro, ricorsi dei clienti | Può ricalcolare ogni stato del registro |
| Famiglie e imprese | Usano conti e credito; possiedono le imprese | Accesso al credito secondo regole uguali per tutti |

## 4. Registro e creazione di moneta

### 4.1 Il registro con prestiti [P]

Ogni soggetto non bancario j ha un conto di deposito dⱼ ≥ 0 e un conto di prestito ℓⱼ ≥ 0. La BCA ha un patrimonio netto E_b, che può essere positivo o negativo. Le operazioni ammesse sono:

| Operazione | Effetto sul registro |
|---|---|
| Pagamento da j a k di x | valido solo se dⱼ ≥ x; dⱼ − x, dₖ + x |
| Erogazione di un prestito x a j | ℓⱼ + x, dⱼ + x (crea moneta) |
| Rimborso x da j | ℓⱼ − x, dⱼ − x (distrugge moneta) |
| Interessi x pagati da j | dⱼ − x, E_b + x |
| Interessi sui depositi, spese della BCA x a k | E_b − x, dₖ + x |
| Svalutazione di un prestito insolvente x | ℓⱼ − x, E_b − x |
| Risultato della BCA allo Stato | E_b → 0, d_Tesoro + E_b |

### 4.2 D-1 Conservazione della moneta [D]

    [D] D = L − E_b   in ogni istante,   con D = Σⱼ dⱼ  e  L = Σⱼ ℓⱼ

**Dimostrazione.** All'inizio D = L = E_b = 0. Ogni riga della tabella lascia invariata la quantità D − L + E_b: il pagamento sposta depositi; l'erogazione e il rimborso cambiano D e L della stessa quantità; interessi, spese e svalutazioni spostano valore fra depositi o prestiti e patrimonio della BCA con segni opposti; il trasferimento allo Stato sposta E_b nei depositi. Per induzione sul numero di operazioni, D − L + E_b = 0 sempre. Q.E.D.

- **L'unica fonte di moneta è il credito della BCA.** Senza banche private non esiste moneta creata da altri. La quantità di moneta è una variabile di politica pubblica, controllata dalle regole sul credito.
- **Un patrimonio negativo della BCA non blocca nulla.** Se le perdite rendono E_b < 0, i depositi superano i prestiti; i pagamenti continuano (D-2). La perdita è un trasferimento implicito dal settore pubblico ai debitori insolventi e va contabilizzata come costo fiscale (D-10).
- **Verifica numerica N-1.** Lo script `simulazioni/bca_1_0_registro.py` esegue 200.000 operazioni casuali su 500 conti, comprese erogazioni, rimborsi, interessi, svalutazioni e trasferimenti. L'identità D = L − E_b e la non negatività di depositi e prestiti sono rispettate a ogni operazione, anche con patrimonio della BCA fortemente negativo.

### 4.3 D-2 Nessuna corsa agli sportelli [D]

In una banca a riserva frazionaria con depositi D e riserve r·D, con r < 1, le richieste di prelievo simultanee superiori a r·D non possono essere pagate tutte: l'esito di ciascun depositante dipende da cosa fanno gli altri, ed è questa la radice delle corse agli sportelli [3]. Nella BCA:

    [D] la validità di un pagamento dipende solo dal saldo di chi paga

**Dimostrazione.** Segue dalla regola "valido solo se dⱼ ≥ x". Un insieme di pagamenti in cui le uscite di ciascun conto non superano il suo saldo è eseguibile per intero e in qualunque ordine, perché ogni pagamento riduce soltanto il conto che lo emette. Il deposito non è un credito verso una banca da convertire in moneta: è la moneta. Q.E.D.

Conseguenza: non servono garanzia dei depositi, prestatore di ultima istanza né requisiti di liquidità. Il rischio di liquidità bancario scompare; resta il rischio di credito, che diventa pubblico.

### 4.4 D-3 Esecuzione deterministica verificabile [D]

Il registro evolve con una funzione deterministica pubblica, Sₜ₊₁ = Φ(Sₜ, operazioni). Lo calcolano n sistemi indipendenti; un nuovo stato è accettato solo se la maggioranza produce lo stesso stato, altrimenti il registro si arresta e ricalcola. Con probabilità di guasto q per sistema e guasti indipendenti:

    [D] Pr[stato errato accettato] ≤ Σ_{j > n/2} C(n, j) qʲ (1 − q)ⁿ⁻ʲ

**Dimostrazione.** Φ è deterministica, quindi tutti i sistemi corretti producono esattamente lo stesso stato. Uno stato errato può essere accettato solo se una maggioranza di sistemi è guasta e produce lo stesso stato errato; la probabilità che una maggioranza sia guasta è la somma binomiale, che è quindi un limite superiore. Q.E.D.

Con q = 0,01 il limite vale 3,0·10⁻⁴ per n = 3 e 9,9·10⁻⁶ per n = 5. Fra sistemi corretti non esiste disaccordo legittimo, quindi ogni differenza segnala un guasto, e chiunque può ricalcolare lo stato dai registri pubblici delle operazioni. La garanzia richiede guasti indipendenti: i guasti comuni (stesso codice errato) si riducono con implementazioni diverse della stessa Φ.

## 5. Prezzo del credito: interessi come entrate pubbliche

**Perché esiste un tasso di interesse.** La BCA è pubblica: non ha azionisti e non ha un guadagno proprio. Gli interessi che incassa sono **soldi pubblici** e vanno allo Stato (D-5). Il tasso sui prestiti ha tre componenti, ciascuna con una sola funzione:

| Componente | Funzione | Dove |
|---|---|---|
| Tasso di politica i | Evitare l'inflazione: rende il credito abbastanza caro da non far crescere la domanda oltre la capacità dell'economia. È fissato da una regola algoritmica che lo alza quando l'inflazione supera l'obiettivo e lo abbassa quando scende. Ciò che incassa è un'entrata pubblica | D-7, D-5 |
| Costo operativo c | Coprire il costo di gestione della BCA | D-4 |
| Perdita attesa PD·LGD | Coprire le insolvenze della propria classe di rischio, senza farle pagare agli altri debitori | D-4, D-14 |

Senza la prima componente il credito costerebbe troppo poco e i prezzi salirebbero senza fermarsi (D-8); l'unica alternativa sarebbe rifiutare in modo permanente una parte del credito richiesto (D-9).

**Depositi [P].** I conti presso la BCA sono conti di pagamento: custodiscono la moneta e non sono un investimento. Ricevono un interesse basso, fissato dalla regola della D-16, che ne protegge il potere d'acquisto senza farlo crescere; chi cerca un rendimento reale investe in imprese, azioni o obbligazioni (A5).

### 5.1 D-4 Composizione del tasso sui prestiti [D]

La BCA sostiene un costo operativo c per unità di credito e perde una frazione LGD del prestito con probabilità di insolvenza PD. Il tasso che copre costi e perdite attese e in più rende in media il tasso di politica i è:

    [D] iᴸ = (1 + i + c) / (1 − PD · LGD) − 1   ≈   i + c + PD · LGD

**Dimostrazione.** Su un prestito unitario la BCA incassa in media (1 + iᴸ)(1 − PD·LGD). Imponendo che, tolti il capitale restituito e il costo c, resti in media i, cioè (1 + iᴸ)(1 − PD·LGD) = 1 + i + c, si ottiene la formula; l'approssimazione vale per PD·LGD piccolo. Q.E.D.

Esempio con i = 3,9%, c = 0,2%, PD = 2%, LGD = 45%: tasso esatto 5,05%, approssimato 5,0%. La perdita attesa PD·LGD si calcola sulla media del ciclo (*through the cycle*), non sul momento: il tasso non sale nelle recessioni.

### 5.2 D-5 Gli interessi sono entrate pubbliche [D]

Con i prestiti al tasso della D-4 e i depositi remunerati al tasso i_D, l'incasso netto atteso della BCA è:

    [D] Π_b = iᴸ L − i_D D − c L − PD·LGD·L = i · L − i_D · D ;    con D = L:  Π_b = (i − i_D) · L

**Dimostrazione.** Sostituendo iᴸ = i + c + PD·LGD i termini in c e in PD·LGD si annullano e resta i·L − i_D·D. Se l'incasso netto è versato ogni anno allo Stato, il patrimonio della BCA resta zero e per la D-1 D = L. Q.E.D.

L'intero incasso netto è versato ogni anno allo Stato (B6): la BCA non trattiene nulla. Esempio: con credito pari al 100% del PIL, tasso di politica del 3,9% e tasso sui depositi del 2,0% (D-16), gli interessi netti sono **l'1,9% del PIL all'anno di entrate pubbliche**. Le perdite oltre l'attesa riducono questo versamento o, se lo superano, sono coperte dallo Stato (D-10).

### 5.3 D-6 Dove vanno gli interessi pagati dai debitori [D]

Il tasso sui prestiti che lascia la domanda in equilibrio (tasso neutrale iᴸₙ) è un dato dell'economia, non del sistema bancario. In stato stazionario, con spread privato s_P e spread della BCA s_B:

    [D] i_BCA − i_privato = s_P − s_B

**Dimostrazione.** In entrambi gli ordinamenti lo stato stazionario richiede iᴸ = iᴸₙ, quindi i + s = iᴸₙ e la differenza dei tassi di politica è la differenza degli spread. Q.E.D.

Esempio dimostrativo: spread privato 2,7 punti (costo 0,8, margine di profitto 1,0, perdita attesa 0,9), spread della BCA 1,1 punti (costo 0,2, perdita attesa 0,9). I debitori pagano in entrambi i casi il 5%, ma i soldi finiscono in posti diversi (punti di PIL all'anno, con credito pari al 100% del PIL):

| Destinazione degli interessi | Banche private | BCA |
|---|---|---|
| Depositanti | 2,3 | 2,0 |
| Costi di gestione | 0,8 | 0,2 |
| Copertura delle insolvenze | 0,9 | 0,9 |
| Profitti degli azionisti delle banche | 1,0 | 0 |
| Entrate pubbliche | 0 | 1,9 |
| **Totale pagato dai debitori** | **5,0** | **5,0** |

*Tabella 1. A parità di tasso pagato dai debitori, con la BCA i profitti bancari diventano entrate pubbliche e i depositanti ricevono un interesse simile a quello attuale, fissato dalla D-16; i minori costi di gestione (0,6 punti) sono un'ipotesi sulla gestione automatica, da verificare.*

I depositanti ricevono il 2,0% invece del 2,3%: con inflazione al 2% conservano il potere d'acquisto. Lo Stato incassa l'1,9% del PIL, che può ridurre altre imposte o finanziare servizi.

Il risultato ha anche un effetto macroeconomico: con un tasso di politica più alto la BCA ha **più margine prima di arrivare a zero** nelle recessioni (N-2).

### 5.4 D-16 Interessi sui depositi: sostenibili e bassi [D]

Il tasso sui depositi è fissato da una regola algoritmica pubblica, con il margine m e l'inflazione obiettivo π* fissati per legge:

    [P] i_D = max(0, min(π*, i − m))

    [D] (a) Π_b = (i − i_D)·L ≥ min(i, m)·L ≥ 0
        (b) i_D − π* ≤ 0
        (c) i_D ≤ i < iᴸ

**Dimostrazione.** (a) Se i ≥ m, allora i_D ≤ i − m e quindi i − i_D ≥ m; se i < m, allora i − m < 0 e i_D = 0, quindi i − i_D = i. In entrambi i casi i − i_D ≥ min(i, m) ≥ 0, e per la D-5 Π_b = (i − i_D)·L. (b) i_D ≤ π* per costruzione. (c) i_D ≤ i − m < i se i ≥ m, i_D = 0 ≤ i altrimenti; iᴸ = i + c + PD·LGD > i. Q.E.D.

- **Sostenibile (a).** Pagare i depositi non porta mai la BCA in perdita attesa: resta sempre un incasso netto di almeno m per unità di credito, versato allo Stato. Il margine m copre le perdite oltre l'attesa degli anni normali; nelle crisi (fino a 2,7 punti di PIL in un anno nell'ondata di insolvenze della N-2) le copre lo Stato secondo B6.
- **Non alto, per favorire gli investimenti (b).** All'inflazione obiettivo il rendimento reale dei depositi è al massimo zero: i risparmi conservano il potere d'acquisto ma non crescono. Qualunque investimento con rendimento reale atteso positivo (imprese, azioni, obbligazioni) è più conveniente del deposito.
- **Nessun arbitraggio (c).** Chi prende un prestito per depositarlo paga iᴸ e riceve meno di i: ci perde sempre.
- **Automatico nel ciclo.** Il tasso sui depositi segue il tasso di politica: scende nelle recessioni, quando conviene spendere e investire, e arriva a zero quando il tasso di politica scende sotto m.
- **Inflazione.** Lo strumento contro l'inflazione resta il tasso sui prestiti (D-7). Il tasso sui depositi, legato all'obiettivo e non all'inflazione corrente, non la alimenta.

Esempio con i = 3,9%, π* = 2% e m = 1 punto: i_D = min(2,0; 2,9) = 2,0%. Entrate pubbliche: (3,9 − 2,0)·L = 1,9% del PIL con credito pari al PIL. In una recessione con i = 1%: i_D = 0.

## 6. Politica monetaria algoritmica

### 6.1 Modello

Modello ridotto a periodi annuali, variabili in punti percentuali. y è il divario di prodotto, π l'inflazione, i il tasso di politica, iᴸ il tasso sui prestiti, g il razionamento del credito (differenza percentuale fra credito concesso e domandato, mai positiva).

    yₜ = ρ yₜ₋₁ − σ (iᴸₜ − πₜ − rᴸₙ) + ψ gₜ + εₜ
    πₜ = (1 − a) πₜ₋₁ + a π* + κ yₜ₋₁
    iₜ = max(0, i_ss + (1 + φ_π)(πₜ − π*) + φ_y yₜ₋₁)
    iᴸₜ = iₜ + s

a è la quota di aspettative ancorate all'obiettivo π*; rᴸₙ il tasso reale neutrale sui prestiti; s lo spread. Parametri dimostrativi: ρ = 0,5; σ = 0,5; ψ = 0,15; κ = 0,2; a = 0,2; φ_π = 0,5; φ_y = 0,5; π* = 2%; rᴸₙ = 3%.

### 6.2 D-7 Stabilità della regola algoritmica del tasso [D]

Siano x = π − π* e b = ρ − σφ_y, con |b| < 1. Lontano dal limite dello zero, il sistema è stabile se e solo se:

    [D] − a (1 − b) / (κ σ)  <  φ_π  <  (2 − a)(1 + b) / (κ σ)

**Dimostrazione.** Sostituendo la regola, iᴸ − π − rᴸₙ = φ_π x + φ_y yₜ₋₁, quindi yₜ = b yₜ₋₁ − σφ_π xₜ e xₜ₊₁ = (1 − a − κσφ_π) xₜ + κ b yₜ₋₁. La matrice del sistema nello stato (xₜ, yₜ₋₁) ha traccia 1 − a − κσφ_π + b e determinante (1 − a) b. Le condizioni di Jury per una matrice 2×2 sono |det| < 1, 1 − tr + det > 0, 1 + tr + det > 0. La prima vale per |b| < 1. La seconda dà a(1 − b) + κσφ_π > 0, la terza (2 − a)(1 + b) − κσφ_π > 0. Q.E.D.

- Con aspettative non ancorate (a = 0) la condizione inferiore diventa φ_π > 0: il tasso nominale deve reagire più che proporzionalmente all'inflazione. È il principio di Taylor [6].
- Con i parametri dell'esempio: −1,5 < φ_π < 22,5; il valore scelto φ_π = 0,5 dà autovalori 0,72 e 0,28.
- Una regola automatica non elimina il vincolo dello zero: è un limite reale, che la D-6 rende meno stringente.

### 6.3 D-8 A tasso zero senza quote l'inflazione non torna all'obiettivo [D]

Se tutti i prestiti sono a tasso nominale zero e il credito è pari alla domanda (g = 0), allora iᴸ − π − rᴸₙ = −(x + π* + rᴸₙ) e:

    [D] se κσ ≥ a(1 − ρ) l'inflazione diverge;
        altrimenti converge a  π* + κσ(π* + rᴸₙ) / [a(1 − ρ) − κσ]  > π*

**Dimostrazione.** La matrice del sistema è [[1 − a + κσ, κρ], [σ, ρ]], con traccia 1 − a + κσ + ρ e determinante (1 − a)ρ, quindi 1 − tr + det = a(1 − ρ) − κσ. Se questa quantità è ≤ 0 la condizione di Jury è violata e il sistema ha un autovalore ≥ 1. Altrimenti il punto fisso si ottiene imponendo y = σ(x + π* + rᴸₙ)/(1 − ρ) e a x = κ y, da cui x = κσ(π* + rᴸₙ)/[a(1 − ρ) − κσ] > 0. Q.E.D.

Con i parametri dell'esempio a(1 − ρ) = κσ = 0,1: autovalore esattamente 1 e inflazione che sale di circa 0,8 punti all'anno senza fermarsi (N-3: 2,0 → 10,6% in 11 anni). Il tasso zero rende il credito troppo conveniente: la domanda eccede la capacità dell'economia e i prezzi salgono.

### 6.4 D-9 Tasso zero con quote di credito [D]

Il tasso zero funziona solo se la BCA sostituisce il prezzo del credito con la quantità: una quota algoritmica gₜ = −Q̄ − φ_q xₜ. Lo stato stazionario all'obiettivo richiede:

    [D] Q̄ = σ (π* + rᴸₙ) / ψ ;     stabilità:  − a(1 − ρ)/κ  <  ψ φ_q − σ  <  (2 − a)(1 + ρ)/κ

**Dimostrazione.** Con iᴸ = 0 e la quota, yₜ = ρ yₜ₋₁ + σ(xₜ + π* + rᴸₙ) − ψQ̄ − ψφ_q xₜ. Il termine costante si annulla se e solo se ψQ̄ = σ(π* + rᴸₙ). Resta yₜ = ρ yₜ₋₁ − (ψφ_q − σ) xₜ, cioè il sistema della D-7 con σφ_π sostituito da ψφ_q − σ e φ_y = 0; le condizioni di Jury danno l'intervallo. Q.E.D.

- Nell'esempio Q̄ = 16,7%: **un sesto del credito domandato deve essere rifiutato in modo permanente**, anche in condizioni normali. Con φ_q = 8 il sistema è stabile (ψφ_q − σ = 0,7, autovalori di modulo 0,63).
- La quota ha un proprio limite: non può concedere più credito di quello domandato (g ≤ 0). Questo limite si raggiunge quando l'inflazione scende di più di Q̄/φ_q ≈ 2,1 punti sotto l'obiettivo, ed è l'analogo del limite dello zero per i tassi.
- Il razionamento a prezzo zero lascia alla BCA un potere allocativo molto ampio: decide a chi dare un bene che vale più di quanto costa. È il principale argomento contro il regime a tasso zero.

![](figure/figura_2.png)

*Figura 2. A sinistra, inflazione senza shock: con tasso zero e credito libero (Z0) sale senza fermarsi, con tasso pubblico (A) e con quote (Z) resta all’obiettivo (le due linee coincidono). A destra, razionamento del credito nell’ondata di insolvenze: le banche private (P) tagliano il credito quando perdono capitale, la BCA a tasso zero (Z) rifiuta in modo permanente circa un sesto del credito domandato, la BCA con tasso pubblico (A) non raziona. Simulazioni con parametri dimostrativi, non previsioni.*

**Conclusione della §6.** "Nessun tasso privato" non implica "tasso zero". Il modello adotta un **tasso pubblico fissato da una regola algoritmica** (D-7), con prezzo dei prestiti per classe di rischio (D-4, D-14) e interessi netti versati allo Stato come entrate pubbliche (D-5). Il regime a tasso zero con quote resta solo come termine di confronto.

## 7. Stabilità finanziaria

### 7.1 D-10 Scompare il canale del capitale bancario [D]

Una banca privata con capitale E e requisito minimo κ_cap può prestare al massimo L ≤ E/κ_cap. Una perdita ℓ riduce il credito massimo di:

    [D] banche private: ΔLˢ = − ℓ / κ_cap ;      BCA: ΔLˢ = 0

**Dimostrazione.** Per le banche private segue dal vincolo L ≤ E/κ_cap con ΔE = −ℓ. La BCA non ha vincolo di capitale: per la D-2 un patrimonio negativo non impedisce i pagamenti, e la quantità di credito è fissata dalle regole (domanda ammessa dal controllo del rischio, o quota). Q.E.D.

Con requisito dell'8% ogni unità di perdita può togliere fino a 12,5 unità di credito all'economia. Questo meccanismo, che amplifica le crisi (acceleratore finanziario [7]), nella BCA non esiste.

**Il costo da dichiarare.** Le perdite non scompaiono: diventano pubbliche, perché riducono E_b e il Tesoro le copre (A6). E una banca senza vincolo di capitale può continuare a prestare a imprese in perdita: è il vincolo di bilancio "soffice" di Kornai [5]. La difesa è la condizione B5 (§11): regole deterministiche di approvazione, nessuna rinegoziazione discrezionale e arresto automatico dei finanziamenti che superano le soglie di rischio.

### 7.2 N-2 Crisi a confronto [N]

Tre ordinamenti, stessi parametri della §6.1 e stesso tasso sui prestiti in stato stazionario (5%):

- **P — banche private**: spread 2,7 punti più un premio di rischio che sale di 0,3 punti per ogni punto di recessione; capitale 8,8% del credito con requisito dell'8%; insolvenze PD = 2% − 1·y.
- **A — BCA con tasso pubblico**: spread 1,1 punti costante; nessun vincolo di capitale.
- **Z — BCA a tasso zero con quote**: quota con Q̄ = 16,7% e φ_q = 8.

| Scenario | Regime | Prodotto minimo | Perdita cumulata di prodotto | Razionamento massimo del credito | Inflazione minima | Anni a tasso zero | Capitale bancario minimo | Perdite oltre l'attesa |
|---|---|---|---|---|---|---|---|---|
| Shock di domanda −4 (2 anni) | P | −5,85 | −16,32 | 0,0% | −0,18% | 7 | 8,80 | 7,20 (banche) |
| | A | −4,80 | −8,45 | 0,0% | 0,40% | 1 | — | 3,93 (Stato) |
| | Z | −5,44 | −6,67 | −17,1% | 0,27% | — | — | 3,05 (Stato) |
| Insolvenze +4 punti e domanda −2 (2 anni) | P | −3,13 | −11,21 | −14,0% | 0,43% | 5 | 6,90 | 8,38 (banche) |
| | A | −2,40 | −4,00 | 0,0% | 1,20% | 0 | — | 5,46 (Stato) |
| | Z | −2,72 | −3,33 | −16,9% | 1,14% | — | — | 4,79 (Stato) |

*Tabella 2. Periodi 5–40. Prodotto in punti percentuali di scarto dal potenziale; perdita cumulata = somma degli scarti; perdite in punti di PIL. Nel regime Z il razionamento comprende il 16,7% permanente. Parametri dimostrativi.*

**Scomposizione della differenza fra P e A** (perdita cumulata di prodotto):

| Scenario | Vincolo di capitale | Premio di rischio ciclico | Spread più alto (meno margine sopra lo zero) | Totale P − A |
|---|---|---|---|---|
| Shock di domanda | 0,00 | −5,34 | −2,53 | −7,87 |
| Ondata di insolvenze | −6,16 | −1,01 | −0,05 | −7,21 |

*Tabella 3. Ogni colonna è la differenza ottenuta togliendo un meccanismo alla volta dal regime P.*

![](figure/figura_1.png)

*Figura 1. Divario di prodotto nelle due crisi con banche private (P), BCA con tasso pubblico (A) e BCA a tasso zero con quote (Z). Banda: periodi di shock. Simulazioni con parametri dimostrativi, non previsioni.*

- **Nelle crisi del credito la BCA dimezza o meglio la perdita di prodotto.** Nell'ondata di insolvenze il capitale delle banche private scende da 8,8 a 6,9, il credito viene tagliato del 14% e la perdita di prodotto è 11,2 contro 4,0. Più dell'80% della differenza viene dal vincolo di capitale (D-10).
- **Nelle crisi di domanda contano spread e premio di rischio.** Le banche private alzano il costo del credito proprio in recessione e partono da un tasso di politica più basso, quindi restano a zero per 7 anni contro 1.
- **Le perdite cambiano proprietario.** Con la BCA le perdite oltre l'attesa sono minori (la recessione è più breve) ma diventano un costo pubblico: 3,9–5,5 punti di PIL distribuiti negli anni.
- **Il regime Z stabilizza un po' meglio di A**, perché la quantità di credito non ha il limite dello zero. Il prezzo è il razionamento permanente di un sesto del credito domandato (D-9).

## 8. Mutui e prezzi delle case

### 8.1 D-11 Il tasso sui mutui si capitalizza nei prezzi [D]

Il prezzo di una casa con rendita (affitto) R che cresce al tasso g, costi di proprietà e manutenzione θ e tasso di sconto pari al tasso sui mutui iᴹ è:

    [D] P / R = 1 / (iᴹ + θ − g),   per iᴹ + θ > g

**Dimostrazione.** Il prezzo è il valore attuale della rendita crescente, scontata al tasso iᴹ + θ: Σₜ₌₀^∞ R(1 + g)ᵗ / (1 + iᴹ + θ)ᵗ⁺¹. È una serie geometrica di ragione (1 + g)/(1 + iᴹ + θ) < 1, la cui somma è R/(iᴹ + θ − g): la formula di Gordon [8]. Q.E.D.

| Tasso sui mutui | 5% | 4% | 2% | 1% | 0% |
|---|---|---|---|---|---|
| Prezzo / affitto annuo (θ = 1,5%, g = 1%) | 18,2 | 22,2 | 40,0 | 66,7 | 200,0 |

*Tabella 4. Abbassare i tassi sui mutui verso zero moltiplica i prezzi di equilibrio delle case.*

### 8.2 D-12 Il limite al mutuo va legato al reddito, non al tasso [D]

Se il limite è una rata massima pari a una quota m del reddito Y per T anni, il mutuo massimo è m·Y·aₜ(iᴹ), con aₜ(i) = [1 − (1 + i)⁻ᵀ]/i e aₜ(0) = T. Con m = 30% e T = 25 anni:

| Tasso sui mutui | 4% | 2% | 0% |
|---|---|---|---|
| Mutuo massimo / reddito annuo | 4,69 | 5,86 | 7,50 |

Un tasso più basso aumenta il credito concedibile del 25–60% e quindi i prezzi delle case per chi compra a debito. La regola algoritmica corretta fissa invece il mutuo massimo come **multiplo del reddito indipendente dal tasso** (per esempio ℓ̄ = 4,5 volte), insieme a un rapporto massimo fra prestito e valore della casa:

    [D] con mutuo ≤ ℓ̄ · Y e anticipo A, il prezzo pagabile da chi compra a debito è ≤ ℓ̄ · Y + A, per ogni iᴹ

**Dimostrazione.** Il prezzo pagato non può superare il credito ottenibile più l'anticipo; nessuno dei due termini dipende dal tasso. Q.E.D.

## 9. Regole del credito: le stesse delle banche

[P] La BCA applica a mutui, finanziamenti e credito al consumo **le stesse regole di merito creditizio e di analisi del rischio usate dalle banche**. Le differenze sono tre: le regole sono pubbliche, sono eseguite in modo automatico e uguale per tutti, e il tasso non contiene margine di profitto. Essere una banca pubblica non significa prestare con criteri più morbidi: un prestito concesso a chi non può restituirlo è una perdita pubblica (D-10).

### 9.1 Mutui [P]

| Regola | Contenuto | Valore tipico, da fissare per legge |
|---|---|---|
| Verifica del reddito | Reddito documentato e stabile, letto dai registri fiscali e previdenziali | — |
| Rata / reddito | Rata di tutti i debiti in corso non oltre una quota m del reddito netto | m = 30–35% |
| Mutuo / reddito | Mutuo massimo come multiplo del reddito annuo, indipendente dal tasso (D-12) | ℓ̄ = 4,5 |
| Prestito / valore | Mutuo non oltre una quota del valore di perizia | 80% |
| Perizia | Valore dell'immobile stimato da modelli pubblici e verificato in modo indipendente | — |
| Garanzia | Ipoteca di primo grado sull'immobile | — |
| Durata ed età | Durata massima; fine del mutuo entro un'età massima | 30 anni; 75 anni |
| Storia creditizia | Debiti in corso e regolarità dei pagamenti, letti dal registro della BCA | — |
| Assicurazione | Polizza obbligatoria sull'immobile | — |

**Tasso fisso o variabile.** Il tasso variabile è il tasso di politica corrente più costo e perdita attesa della classe. Il tasso fisso è la media attesa del tasso di politica sulla durata più costo e perdita attesa: rende in media il tasso di politica, e il rischio che i tassi salgano oltre l'attesa è assorbito dal patrimonio della BCA come oggi da quello delle banche.

### 9.2 Imprese e credito al consumo [P]

- **Imprese.** Bilanci letti dai registri contabili; piano d'impresa per i nuovi progetti; rating calcolato dai modelli; garanzie e clausole contrattuali (*covenant*) controllate in modo automatico; per i progetti nuovi o grandi, finanziamento a tranche legato al raggiungimento di risultati verificati.
- **Credito al consumo.** Stesso limite rata/reddito complessivo dei mutui, importi e durate massimi per prodotto.

### 9.3 Analisi del rischio [P]

1. **Stima.** La probabilità di insolvenza PD̂ di ogni richiesta è la mediana delle stime di n modelli indipendenti, con dati, metodi e sviluppatori diversi. Le variabili ammesse sono pubbliche (reddito, debiti, storia dei pagamenti, garanzie, settore) ed escludono caratteristiche protette.
2. **Classi.** Le richieste sono raggruppate in classi di rischio k; ogni classe ha la sua PD_k e la sua LGD_k, stimate sugli esiti effettivi dei prestiti.
3. **Decisione.** La richiesta è approvata se e solo se PD̂ non supera la soglia PD_max del prodotto e sono rispettate tutte le regole delle §9.1–9.2.
4. **Prezzo.** Il tasso è quello della D-4 calcolato per la classe (D-14).
5. **Accantonamenti.** All'erogazione la BCA accantona la perdita attesa PD·LGD·importo e la aggiorna quando il rischio cambia, come prevede per le banche il principio contabile IFRS 9 [10]. Le perdite oltre gli accantonamenti seguono la regola fiscale (B6).
6. **Monitoraggio e insolvenza.** Segnali di allarme automatici sui ritardi; ristrutturazioni secondo regole pubbliche; escussione delle garanzie con le procedure di legge. Nessuna rinegoziazione discrezionale.
7. **Motivazione e ricorso.** Ogni rifiuto indica le variabili che lo hanno determinato e può essere contestato.

La BCA ha un vantaggio informativo rispetto a una banca privata: vede l'intera storia dei pagamenti di ogni richiedente, quindi può stimare il rischio con meno errori. È lo stesso fatto che rende centrale la questione della riservatezza (§12).

### 9.4 D-14 Tasso per classe di rischio: nessun sussidio incrociato [D]

    [D] iᴸ_k = (1 + i + c) / (1 − PD_k · LGD_k) − 1   per ogni classe k

**Dimostrazione.** Per la D-4 applicata a ogni classe, ciascuna classe copre da sola le proprie perdite attese, quindi nessuna finanzia le perdite di un'altra. Con un tasso unico calcolato sulla perdita media, invece, la copertura vale solo nel complesso: nell'approssimazione lineare iᴸ ≈ i + c + EL, la classe k trasferisce (EL̄ − EL_k)·L_k, e la somma dei trasferimenti pesata per il credito è zero. Le classi meno rischiose pagano le perdite delle più rischiose. Q.E.D.

Esempio con i = 3,9%, c = 0,2%, LGD = 45%: il 70% del credito in classe A (PD 1%), il 30% in classe B (PD 4,33%), PD media 2%. Tassi per classe: 4,57% e 6,17%; tasso unico: 5,05%. Con il tasso unico la classe A paga 0,48 punti in più e la classe B 1,13 punti in meno.

Il tasso per classe serve anche alla stabilità: se esiste credito fra privati (A5), i debitori meno rischiosi abbandonerebbero un tasso unico, lasciando alla BCA solo i più rischiosi (selezione avversa). Le banche prezzano il rischio per la stessa ragione.

### 9.5 D-13 Errore del giudizio a maggioranza [D]

Se n modelli decidono "approva / rifiuta" e ciascuno sbaglia con probabilità p, con errori indipendenti, la decisione a maggioranza sbaglia con probabilità Σ_{k > n/2} C(n, k) pᵏ(1 − p)ⁿ⁻ᵏ. Con n = 5 e p = 10%: **0,86%** invece del 10%. La riduzione dipende dall'indipendenza degli errori: modelli addestrati sugli stessi dati sbagliano insieme, e allora il consesso non corregge. L'indipendenza va misurata su casi di verifica pubblici, sostituendo i modelli i cui errori sono troppo correlati.

### 9.6 Lo Stato come debitore: stesse regole [P]

Il Tesoro chiede credito alla BCA come qualunque debitore: nessuno scoperto automatico, analisi del rischio e limite di sostenibilità. Le regole del mutuo hanno un equivalente diretto:

| Regola per famiglie e imprese | Equivalente per lo Stato |
|---|---|
| Verifica del reddito | Entrate fiscali documentate e previste |
| Rata / reddito | Disavanzo primario / PIL entro il limite della D-15 (gli interessi pagati alla BCA tornano allo Stato) |
| Mutuo / reddito | Debito / PIL non oltre un limite b_max |
| Merito creditizio | Sostenibilità del debito (D-15) |
| Finanziamento a tranche | Credito concesso anno per anno, solo se il piano è rispettato |

### 9.7 D-15 Sostenibilità del debito pubblico [D]

Gli interessi che lo Stato paga alla BCA tornano allo Stato come entrata pubblica (D-5): per il settore pubblico nel suo insieme sono una partita di giro. Il vincolo che conta è quindi la **quantità** di credito allo Stato, perché è moneta creata (D-1). Sia b il credito della BCA allo Stato in rapporto al PIL, d il disavanzo primario dello Stato in rapporto al PIL (spese meno entrate, esclusi gli interessi pagati alla BCA e compresi i versamenti della BCA sugli interessi dei prestiti privati) e g la crescita nominale del PIL:

    bₜ₊₁ = bₜ / (1 + g) + dₜ

    [D] bₜ₊₁ ≤ bₜ   ⇔   dₜ ≤ g/(1 + g) · bₜ

**Dimostrazione.** In valori nominali il debito dello Stato verso la BCA cresce degli interessi i·Bₜ e del disavanzo primario, e diminuisce del versamento degli stessi interessi i·Bₜ, che la BCA restituisce allo Stato: Bₜ₊₁ = Bₜ + Dₜ. Dividendo per il PIL dell'anno successivo, pari a (1 + g) volte quello dell'anno t, si ottiene l'equazione. Sottraendo bₜ, bₜ₊₁ − bₜ = dₜ − g/(1 + g)·bₜ, non positivo se e solo se vale la condizione. Q.E.D.

Esempio con b = 100% del PIL e crescita nominale del 3%: il rapporto non cresce finché il disavanzo primario non supera il 2,91% del PIL. In altri termini la moneta creata per lo Stato può crescere al massimo come il PIL nominale.

**Regola [P].** Il credito allo Stato è concesso se il rapporto b resta sotto b_max e, quando lo raggiunge, solo se il bilancio rispetta la condizione della D-15. Altrimenti la richiesta è rifiutata, come per ogni debitore.

**Perché conta per la moneta.** Per la D-1 la moneta è D = L_privati + L_Stato − E_b. Se lo Stato potesse indebitarsi senza limiti presso la BCA, la moneta crescerebbe senza limiti e la regola sul tasso (D-7) non potrebbe più controllare l'inflazione. Con la regola, L_Stato ≤ b_max · PIL: la moneta creata per lo Stato è limitata e la politica monetaria resta indipendente dalle esigenze di bilancio.

## 10. Transizione dall'ordinamento attuale [P]

1. **Conti.** Ogni deposito bancario diventa, uno a uno, un deposito presso la BCA. La quantità di moneta non cambia.
2. **Prestiti.** La BCA acquisisce i prestiti delle banche al loro valore di bilancio L_bank, accreditando alle banche L_bank e addebitando i depositi D_bank che ha preso in carico. Alle banche resta in deposito la differenza L_bank − D_bank, cioè il loro capitale: gli azionisti non sono espropriati.
3. **Contabilità.** Dopo l'operazione i depositi totali sono D_bank + (L_bank − D_bank) = L_bank e il patrimonio della BCA è zero, come richiede la D-1.
4. **Uscita delle banche.** Le banche private chiudono o diventano intermediari non bancari (A5) senza poter creare moneta.

Il percorso è analogo a quello del *Chicago Plan* [1, 2], con la differenza che la BCA tiene anche i prestiti invece di lasciarli a intermediari privati.

## 11. Il modello sta in piedi? Valutazione

**Sì, a sette condizioni esplicite:**

- **B1 Registro**: conti, pagamenti e credito su un registro pubblico deterministico calcolato da sistemi indipendenti (D-1, D-2, D-3).
- **B2 Tasso pubblico algoritmico**: regola del tasso entro i limiti della D-7; in alternativa, tasso zero solo con quote di credito (D-9) e razionamento dichiarato.
- **B3 Prezzo senza profitto**: tasso sui prestiti pari al tasso di politica più costo e perdita attesa, senza margine; depositi remunerati con la regola sostenibile e bassa della D-16; gli interessi netti sono entrate pubbliche (D-4, D-5, D-16).
- **B4 Regole macroprudenziali**: mutuo massimo come multiplo del reddito indipendente dal tasso e limite prestito/valore (D-11, D-12).
- **B5 Regole bancarie e vincolo di bilancio duro**: stesse regole di merito creditizio e analisi del rischio delle banche, tasso per classe di rischio, accantonamenti; approvazione, ristrutturazione e arresto dei prestiti solo secondo regole pubbliche, mai caso per caso (§9, D-10, D-13, D-14).
- **B6 Regola fiscale**: gli interessi netti incassati dalla BCA sono versati ogni anno allo Stato; le perdite oltre l'attesa sono registrate come costo pubblico e coperte dallo Stato (D-5, D-10).
- **B7 Stato debitore con le stesse regole**: credito allo Stato solo entro il limite b_max e la condizione di sostenibilità della D-15; gli interessi pagati dallo Stato alla BCA tornano allo Stato.

| Domanda | Risposta nella versione 1.0 | Prova ancora mancante |
|---|---|---|
| La moneta resta coerente senza banche private? | Sì per costruzione: D = L − E_b sempre (D-1, N-1) | — |
| Possono esserci corse agli sportelli? | No (D-2) | — |
| Il credito può costare zero? | Solo con razionamento permanente (D-8, D-9) | — |
| Dove vanno gli interessi? | Allo Stato, come entrate pubbliche, al netto di un interesse basso sui depositi (D-5, D-6, D-16) | Costo operativo reale della BCA; effetto del tasso sui depositi su risparmio e investimenti |
| La politica monetaria è stabile? | Sì localmente, entro i limiti della D-7 | Stabilità globale; limite dello zero |
| Le crisi sono meno gravi? | Sì nelle crisi del credito (N-2) | Calibrazione su dati reali |
| Che cosa succede alle case? | I prezzi salgono se il limite al mutuo dipende dal tasso (D-11, D-12) | Mercato immobiliare con offerta endogena |
| La BCA può finanziare imprese in perdita? | Sì, senza la condizione B5 (D-10) | Esperimenti sulle regole di arresto |
| Lo Stato può farsi creare moneta senza limiti? | No: credito allo Stato solo entro i limiti di sostenibilità (D-15, B7) | Scelta di b_max e del limite sugli interessi |

Nella sostanza la BCA è un'economia di mercato in cui la moneta e il credito sono un servizio pubblico automatico: le imprese restano private, i prezzi restano di mercato, ma la creazione di moneta, il prezzo del credito e la scelta di chi lo riceve seguono regole pubbliche, e gli interessi pagati dai debitori, prima divisi fra depositanti e azionisti delle banche, sono entrate pubbliche.

## 12. Limiti e programma di verifica

- **Economia aperta.** Con banche private all'estero, residenti e imprese possono spostare depositi e credito fuori dal sistema. Servono accordi internazionali o controlli sui movimenti di capitale; il modello non li studia.
- **Concentrazione di potere e riservatezza.** Un solo soggetto vede tutte le transazioni e decide tutto il credito. Le regole deterministiche e l'audit riducono l'arbitrio ma non risolvono la questione della riservatezza, che appartiene alla governance e non è trattata qui.
- **Errori comuni dei modelli.** Le garanzie D-3 e D-13 richiedono errori indipendenti.
- **Finanza non bancaria.** Se i rendimenti privati superano quelli della BCA, il credito può spostarsi verso intermediari non bancari (A5). Non creano moneta, ma possono ricreare rischi di liquidità fuori dal registro.
- **Calibrazione.** Tutti i parametri sono dimostrativi. Il modello macroeconomico è ridotto e lineare, salvo il limite dello zero.
- **Fattibilità politica.** Proposte di moneta solo pubblica sono già state sottoposte a voto e respinte (referendum svizzero "Vollgeld", 2018).

| Fase | Obiettivo | Stato nella versione 1.0 |
|---|---|---|
| V1 Registro | Coerenza di moneta e pagamenti | Chiuso a livello teorico (D-1–D-3, N-1) |
| V2 Prezzo del credito | Composizione del tasso, interessi sui depositi e destinazione degli interessi | Chiuso a livello teorico (D-4–D-6, D-16) |
| V3 Politica monetaria | Stabilità con regola algoritmica o quote | Chiuso localmente (D-7–D-9); aperta la stabilità globale |
| V4 Crisi | Confronto con le banche private | Simulazione dimostrativa (N-2); manca la calibrazione |
| V5 Case | Prezzi e regole macroprudenziali | Risultati di equilibrio (D-11, D-12); manca la dinamica |
| V6 Economia aperta | Fuga di capitali e cambio | Aperto |
| V7 Modello stock-flow completo | Famiglie, imprese, Stato e BCA con bilanci espliciti | Aperto |

## 13. Registro delle dimostrazioni

| Codice | Risultato | Portata |
|---|---|---|
| D-1 | D = L − E_b in ogni istante | Registro della BCA |
| D-2 | Pagamento indipendente dagli altri conti: nessuna corsa agli sportelli | Copertura 1 |
| D-3 | Stato errato accettato ≤ Σ_{j>n/2} C(n,j) qʲ(1−q)ⁿ⁻ʲ | Guasti indipendenti |
| D-4 | iᴸ = (1 + i + c)/(1 − PD·LGD) − 1 | Copertura di costi e perdite attese |
| D-5 | Π_b = i·L − i_D·D; con i_D = 0 interessi netti = i·L, tutti allo Stato | Prestiti al tasso della D-4 |
| D-6 | i_BCA − i_privato = s_P − s_B; destinazione degli interessi (Tabella 1) | Stato stazionario, stesso tasso neutrale |
| D-7 | −a(1−b)/(κσ) < φ_π < (2−a)(1+b)/(κσ) | Locale, lontano dal limite dello zero |
| D-8 | Tasso zero senza quote: inflazione divergente o sopra l'obiettivo | Modello della §6.1 |
| D-9 | Tasso zero con quote: razionamento permanente Q̄ = σ(π* + rᴸₙ)/ψ | Modello della §6.1 |
| D-10 | Perdita ℓ: −ℓ/κ_cap di credito con banche private, 0 con la BCA | Vincolo di capitale |
| D-11 | P/R = 1/(iᴹ + θ − g) | Equilibrio di lungo periodo |
| D-12 | Mutuo ≤ ℓ̄·Y ⇒ prezzo a debito ≤ ℓ̄·Y + A per ogni tasso | Acquirenti a debito |
| D-13 | Errore a maggioranza 0,86% con n = 5, p = 10% | Errori indipendenti |
| D-14 | iᴸ_k = (1 + i + c)/(1 − PD_k·LGD_k) − 1: nessun sussidio incrociato fra classi | Perdite coperte per classe |
| D-15 | Credito allo Stato / PIL non cresce ⇔ d ≤ g/(1 + g)·b | Interessi dello Stato come partita di giro |
| D-16 | i_D = max(0, min(π*, i − m)): incasso netto ≥ min(i, m)·L, rendimento reale dei depositi ≤ 0 all'obiettivo, nessun arbitraggio | Regola dei depositi |
| N-1 | Identità D = L − E_b su 200.000 operazioni | `simulazioni/bca_1_0_registro.py` |
| N-2 | Crisi del credito: perdita di prodotto 11,2 (P) contro 4,0 (A) | `simulazioni/bca_1_0_macro.py`, parametri dimostrativi |
| N-3 | Tasso zero senza quote: inflazione da 2,0% a 10,6% in 11 anni | `simulazioni/bca_1_0_macro.py` |

## 14. Riferimenti

1. Fisher, I. (1936), *100% Money*, Adelphi.
2. Benes, J. e Kumhof, M. (2012), "The Chicago Plan Revisited", IMF Working Paper 12/202.
3. Diamond, D. W. e Dybvig, P. H. (1983), "Bank Runs, Deposit Insurance, and Liquidity", *Journal of Political Economy*, 91(3).
4. McLeay, M., Radia, A. e Thomas, R. (2014), "Money creation in the modern economy", *Bank of England Quarterly Bulletin*, 2014 Q1.
5. Kornai, J. (1986), "The Soft Budget Constraint", *Kyklos*, 39(1).
6. Taylor, J. B. (1993), "Discretion versus policy rules in practice", *Carnegie-Rochester Conference Series on Public Policy*, 39.
7. Bernanke, B., Gertler, M. e Gilchrist, S. (1999), "The Financial Accelerator in a Quantitative Business Cycle Framework", *Handbook of Macroeconomics*, vol. 1C.
8. Gordon, M. J. (1959), "Dividends, Earnings, and Stock Prices", *Review of Economics and Statistics*, 41(2).
9. Godley, W. e Lavoie, M. (2007), *Monetary Economics*, Palgrave Macmillan.
10. IASB (2014), *IFRS 9 Financial Instruments*, International Accounting Standards Board.

## 15. Provenienza dei risultati numerici

I risultati [N] sono riprodotti dagli script nella cartella `simulazioni/` (Python con NumPy, semi fissi):

- `bca_1_0_registro.py` — registro della BCA con prestiti, verifica di D-1 e D-2 (N-1);
- `bca_1_0_macro.py` — modello della §6.1 nei regimi P, A, Z e Z0, crisi a confronto, scomposizione e tasso zero (N-2, N-3). Prima di simulare verifica che senza shock ogni regime resti nello stato stazionario.
- `bca_1_0_figure.py` — Figure 1 e 2, ricavate dalle stesse simulazioni.

I valori numerici di D-3, D-7, D-9 (autovalori), D-11–D-16 sono calcoli diretti delle formule con i parametri indicati.
