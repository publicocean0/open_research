# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""BCA 1.0 — Figure 1 e 2 del documento (stile delle figure del paper).

Figura 1: divario di prodotto nelle due crisi (N-2) con banche private (P), BCA con tasso pubblico (A)
e BCA a tasso zero con quote (Z).
Figura 2: inflazione senza shock con tasso zero e credito libero (Z0), tasso pubblico (A) e quote (Z) (N-3);
razionamento del credito nell'ondata di insolvenze (N-2).
Uso (dalla cartella bca/):  python3 simulazioni/bca_1_0_figure.py [--en]   (NumPy e Matplotlib; --en: etichette in inglese, file *_en.png)
"""
import os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bca_1_0_macro import simula, verifica

if any("Inter" in f.name for f in font_manager.fontManager.ttflist):
    plt.rcParams["font.family"] = "Inter"
plt.rcParams.update({"font.size": 8, "axes.linewidth": 0.8})
EN = "--en" in sys.argv
T_ = (lambda it, en: en if EN else it)
SUF = "_en" if EN else ""
COL = {"P": "#A84A43", "A": "#138D75", "Z": "#2E6DB4", "Z0": "#D99A43"}
NOME = {"P": T_("P banche private", "P private banks"), "A": T_("A BCA, tasso pubblico", "A BCA, public rate"),
        "Z": T_("Z BCA, tasso zero con quote", "Z BCA, zero rate with quotas"), "Z0": T_("Z0 tasso zero, credito libero", "Z0 zero rate, unrestricted credit")}
OUTDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "figure")
verifica()

def stile(ax, xl, yl):
    ax.grid(True, color="#E3E3E3", lw=0.6); ax.set_xlabel(xl); ax.set_ylabel(yl)

domanda = lambda t: -4.0 if t in (5, 6) else 0.0
dom2 = lambda t: -2.0 if t in (5, 6) else 0.0
insolv = lambda t: 4.0 if t in (5, 6) else 0.0

# Figura 1
fig, axs = plt.subplots(1, 2, figsize=(6.17, 2.47), dpi=231)
for ax, titolo, kw in ((axs[0], T_("Shock di domanda −4 (periodi 5–6)", "Demand shock −4 (periods 5–6)"), dict(eps=domanda)),
                       (axs[1], T_("Insolvenze +4 punti e domanda −2 (periodi 5–6)", "Defaults +4 points and demand −2 (periods 5–6)"), dict(eps=dom2, pd_shock=insolv))):
    for r in ("P", "A", "Z"):
        s = simula(r, T=31, **kw)
        ax.plot(range(31), s["y"], color=COL[r], lw=1.6, label=NOME[r])
    ax.axvspan(5, 7, color="#F3E6D6", alpha=0.7, lw=0)
    ax.axhline(0, color="#999999", lw=0.6)
    ax.set_xlim(0, 30); stile(ax, T_("Periodo simulato", "Simulated period"), T_("Divario di prodotto (%)", "Output gap (%)"))
    ax.set_title(titolo, fontsize=7.5, loc="left")
axs[1].legend(fontsize=5.8, loc="lower right", frameon=True, framealpha=0.95, edgecolor="#CCCCCC")
fig.tight_layout(pad=0.6, w_pad=1.6); fig.savefig(os.path.join(OUTDIR, "figura_1%s.png" % SUF), dpi=231); plt.close(fig)

# Figura 2
fig, axs = plt.subplots(1, 2, figsize=(6.17, 2.47), dpi=231)
for r in ("Z0", "A", "Z"):
    s = simula(r, T=16)
    axs[0].plot(range(16), s["pi"], color=COL[r], lw=1.6, label=NOME[r])
axs[0].set_xlim(0, 15); stile(axs[0], T_("Periodo simulato", "Simulated period"), T_("Inflazione (%)", "Inflation (%)"))
axs[0].set_xticks(range(0, 16, 5))
axs[0].set_title(T_("Senza shock", "No shock"), fontsize=7.5, loc="left")
axs[0].legend(fontsize=5.8, loc="upper left", frameon=True, framealpha=0.95, edgecolor="#CCCCCC")
for r in ("P", "A", "Z"):
    s = simula(r, T=31, eps=dom2, pd_shock=insolv)
    axs[1].plot(range(31), s["g"], color=COL[r], lw=1.6, label=NOME[r])
axs[1].axvspan(5, 7, color="#F3E6D6", alpha=0.7, lw=0)
axs[1].set_xlim(0, 30); stile(axs[1], T_("Periodo simulato", "Simulated period"), T_("Credito concesso − domandato (%)", "Credit granted − demanded (%)"))
axs[1].set_title(T_("Ondata di insolvenze", "Default wave"), fontsize=7.5, loc="left")
axs[1].legend(fontsize=5.8, loc="center right", frameon=True, framealpha=0.95, edgecolor="#CCCCCC")
fig.tight_layout(pad=0.6, w_pad=1.6); fig.savefig(os.path.join(OUTDIR, "figura_2%s.png" % SUF), dpi=231); plt.close(fig)
print("scritte figure/figura_1%s.png e figure/figura_2%s.png" % (SUF, SUF))
