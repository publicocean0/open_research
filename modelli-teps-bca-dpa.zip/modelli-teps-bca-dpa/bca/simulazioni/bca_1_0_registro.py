# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""BCA 1.0 — verifica del registro della Banca Centrale Algoritmica con prestiti (D-1, D-2).

Operazioni: pagamento fra conti, erogazione di un prestito (crea depositi), rimborso
(distrugge depositi), pagamento di interessi alla BCA, interessi sui depositi e spese della
BCA, svalutazione di un prestito insolvente, trasferimento del risultato allo Stato.
A ogni operazione si controlla l'identità  Σ depositi = Σ prestiti − patrimonio BCA  (D-1),
la non negatività di depositi e prestiti e che la validità di un pagamento dipenda solo dal
saldo di chi paga (D-2). Importi interi: nessun errore di arrotondamento.

Uso (dalla cartella bca/):  python3 simulazioni/bca_1_0_registro.py      (solo NumPy)
"""
import numpy as np

STATO = 0          # conto del Tesoro (agente non bancario come gli altri)


def verifica(n_conti=500, n_operazioni=200_000, seme=3):
    rng = np.random.default_rng(seme)
    d = np.zeros(n_conti, dtype=np.int64)    # depositi presso la BCA
    l = np.zeros(n_conti, dtype=np.int64)    # prestiti della BCA
    E = 0                                    # patrimonio netto della BCA
    conteggi = dict.fromkeys(["pagamento", "erogazione", "rimborso", "interessi", "spese",
                              "svalutazione", "trasferimento", "rifiutata"], 0)
    for _ in range(n_operazioni):
        j, k = (int(v) for v in rng.integers(0, n_conti, 2))
        x = int(rng.integers(1, 500))
        u = rng.random()
        if u < 0.40:                                   # pagamento j -> k
            valido = d[j] >= x
            altri = d.copy(); altri[k] += 10**6        # D-2: i saldi altrui non cambiano l'esito
            assert valido == (altri[j] >= x) or j == k
            if valido:
                d[j] -= x; d[k] += x; conteggi["pagamento"] += 1
            else:
                conteggi["rifiutata"] += 1
        elif u < 0.55:                                 # erogazione: la BCA crea un deposito
            l[j] += x; d[j] += x; conteggi["erogazione"] += 1
        elif u < 0.70:                                 # rimborso
            y = min(x, l[j], d[j])
            l[j] -= y; d[j] -= y; conteggi["rimborso"] += 1
        elif u < 0.82:                                 # interessi pagati alla BCA
            y = min(x // 10 + 1, d[j])
            d[j] -= y; E += y; conteggi["interessi"] += 1
        elif u < 0.92:                                 # interessi sui depositi e spese della BCA
            y = x // 10 + 1
            E -= y; d[k] += y; conteggi["spese"] += 1
        elif u < 0.96:                                 # svalutazione di un prestito insolvente
            y = min(x, l[j])
            l[j] -= y; E -= y; conteggi["svalutazione"] += 1
        else:                                          # risultato della BCA trasferito allo Stato (o coperto)
            if E > 0:
                d[STATO] += E; E = 0
            elif E < 0 and d[STATO] >= -E:
                d[STATO] += E; E = 0
            conteggi["trasferimento"] += 1
        assert d.sum() == l.sum() - E                  # D-1
        assert (d >= 0).all() and (l >= 0).all()
    return d.sum(), l.sum(), E, conteggi


if __name__ == "__main__":
    D, L, E, c = verifica()
    print(f"200.000 operazioni su 500 conti: identità D = L − E rispettata a ogni operazione")
    print(f"depositi {D}, prestiti {L}, patrimonio BCA {E}  (verifica: {L} − ({E}) = {L - E})")
    print("operazioni:", c)
