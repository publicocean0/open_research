# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""BCA 1.0 — Economia di mercato con Banca Centrale Algoritmica e senza banche private.

Modello macroeconomico ridotto (periodi annuali, variabili in punti percentuali) che
confronta tre ordinamenti del credito:

  P   banche private: tasso sui prestiti = tasso di politica + costi + margine + perdita attesa
      + premio di rischio ciclico; offerta di credito vincolata dal capitale (L ≤ E/κ).
  A   Banca Centrale Algoritmica con tasso pubblico: tasso sui prestiti = tasso di politica
      + costo operativo + perdita attesa media (nessun margine); nessun vincolo di capitale.
  Z   BCA a tasso zero con quote di credito: tutti i prestiti a tasso nominale 0; la quantità
      di credito è fissata da una regola algoritmica (razionamento).
  Z0  BCA a tasso zero senza quote: credito pari alla domanda.

Equazioni (per ogni regime):
  yₜ = ρ yₜ₋₁ − σ (iᴸₜ − πₜ − rᴸₙ) + ψ gₜ + εₜ             divario di prodotto
  πₜ = (1 − a) πₜ₋₁ + a π* + κ_π yₜ₋₁                       inflazione (aspettative ancorate per la quota a)
  iₜ = max(0, i_ss + (1 + φ_π)(πₜ − π*) + φ_y yₜ₋₁)          regola del tasso di politica (P, A)
  Lᵈₜ = L̄ [1 + (ζ yₜ₋₁ − η (iᴸₜ − iᴸₙ)) / 100]               domanda di credito
  gₜ = 100 (Lₜ − Lᵈₜ) / Lᵈₜ ≤ 0                              razionamento del credito
  PDₜ = max(0, PD̄ − χ yₜ₋₁) + shock                          tasso di insolvenza
Uso (dalla cartella bca/):  python3 simulazioni/bca_1_0_macro.py      (solo NumPy)
Parametri inventati a scopo dimostrativo: nessuna calibrazione su un'economia reale.
"""
import numpy as np

# ---------------------------------------------------------------- parametri
RHO, SIGMA, PSI, KAPPA_PI, ANCORA = 0.5, 0.5, 0.15, 0.2, 0.2
PHI_PI, PHI_Y = 0.5, 0.5
PI_STAR, RL_N = 2.0, 3.0                  # inflazione obiettivo, tasso reale neutrale sui prestiti
IL_N = RL_N + PI_STAR                     # tasso nominale neutrale sui prestiti (5%)
L_BAR, ZETA, ETA = 100.0, 1.0, 2.0        # credito in % del PIL; sensibilità della domanda
PD_BAR, LGD, CHI = 2.0, 0.45, 1.0         # insolvenze (%), perdita in caso di insolvenza, ciclicità
EL_BAR = PD_BAR * LGD                     # perdita attesa media 0,9%
# banche private
C_P, M_P, CHI_S = 0.8, 1.0, 0.3           # costo operativo, margine di profitto, premio di rischio ciclico
KAPPA_CAP, E_TARGET = 0.08, 8.8           # requisito di capitale 8%, capitale obiettivo
# BCA
C_B = 0.2                                 # costo operativo con gestione automatica

SPREAD = {"P": C_P + M_P + EL_BAR, "A": C_B + EL_BAR}
I_SS = {r: IL_N - s for r, s in SPREAD.items()}        # tasso di politica di stato stazionario
Q_BAR = -SIGMA * (0 - PI_STAR - RL_N) / PSI            # razionamento permanente necessario a tasso zero


def simula(regime, T=40, eps=None, pd_shock=None, phi_q=8.0, chi_s=CHI_S, vincolo_capitale=True, i_ss=None):
    """i_ss, chi_s e vincolo_capitale permettono di scomporre le differenze fra P e A."""
    i_ss = I_SS.get(regime, 0.0) if i_ss is None else i_ss
    eps = eps or (lambda t: 0.0)
    pd_shock = pd_shock or (lambda t: 0.0)
    y, pi, E = 0.0, PI_STAR, E_TARGET
    out = {k: [] for k in "y pi i iL L Ld g PD E perdite".split()}
    for t in range(T):
        pi_t = (1 - ANCORA) * pi + ANCORA * PI_STAR + KAPPA_PI * y if t > 0 else PI_STAR
        PD = max(0.0, PD_BAR - CHI * y) + pd_shock(t)
        if regime in ("P", "A"):
            i = max(0.0, i_ss + (1 + PHI_PI) * (pi_t - PI_STAR) + PHI_Y * y)
            if regime == "P":
                iL = i + C_P + M_P + EL_BAR + chi_s * max(0.0, -y)
            else:
                iL = i + C_B + EL_BAR
        else:
            i = iL = 0.0
        Ld = L_BAR * (1 + (ZETA * y - ETA * (iL - IL_N)) / 100)
        if regime == "P":
            L = min(Ld, E / KAPPA_CAP) if vincolo_capitale else Ld
        elif regime == "Z":
            # quota algoritmica: razionamento permanente Q̄ più reazione all'inflazione
            q = -Q_BAR - phi_q * (pi_t - PI_STAR)
            L = min(Ld, Ld * (1 + q / 100))
        else:
            L = Ld
        g = 100 * (L - Ld) / Ld
        y_new = RHO * y - SIGMA * (iL - pi_t - RL_N) + PSI * g + eps(t)
        # perdite oltre la perdita attesa media
        perdite = (PD - PD_BAR) * LGD * L / 100
        if regime == "P":
            utile = (M_P + chi_s * max(0.0, -y)) * L / 100 - perdite
            E = E + utile
            E = min(E, E_TARGET) if E > E_TARGET else E      # utili oltre l'obiettivo distribuiti
        for k, v in zip("y pi i iL L Ld g PD E perdite".split(), [y_new, pi_t, i, iL, L, Ld, g, PD, E, perdite]):
            out[k].append(v)
        y, pi = y_new, pi_t
    return {k: np.array(v) for k, v in out.items()}


def verifica():
    """Senza shock ogni regime stabile resta nello stato stazionario."""
    for r in ("P", "A", "Z"):
        s = simula(r)
        assert np.abs(s["y"]).max() < 1e-9 and np.abs(s["pi"] - PI_STAR).max() < 1e-9, r


def sintesi(nome, s, da=5):
    sl = slice(da, None)
    zlb = int((s["i"][sl] <= 1e-9).sum()) if s["i"][:5].max() > 0 else "—"
    return (f"{nome:<34} {s['y'][sl].min():7.2f} {s['y'][sl].sum():8.2f} {s['g'][sl].min():8.2f} "
            f"{s['pi'][sl].min():6.2f} {s['pi'][sl].max():6.2f} {zlb:>4} {s['E'][sl].min():6.2f} {s['perdite'][sl].sum():7.2f}")


if __name__ == "__main__":
    verifica()
    print("Stato stazionario: tasso di politica  P %.1f%%   A %.1f%%   Z 0%%;  interessi netti allo Stato con la BCA %.1f%% del PIL"
          % (I_SS["P"], I_SS["A"], I_SS["A"] * L_BAR / 100))
    print("Tasso sui prestiti  P %.1f%%   A %.1f%%   Z 0%%;  razionamento permanente a tasso zero %.1f%% del credito domandato"
          % (IL_N, IL_N, Q_BAR))
    domanda = lambda t: -4.0 if t in (5, 6) else 0.0
    insolv = lambda t: 4.0 if t in (5, 6) else 0.0
    dom2 = lambda t: -2.0 if t in (5, 6) else 0.0
    print(f"\n{'Scenario':<34} {'y min':>7} {'Σ y':>8} {'raz.max':>8} {'π min':>6} {'π max':>6} {'ZLB':>4} {'E min':>6} {'perdite':>7}")
    for titolo, kw in [("Shock di domanda −4 (t = 5–6)", dict(eps=domanda)),
                       ("Ondata di insolvenze +4 pp, domanda −2", dict(eps=dom2, pd_shock=insolv))]:
        print(titolo)
        for r, nome in [("P", "  P banche private"), ("A", "  A BCA, tasso pubblico"), ("Z", "  Z BCA, tasso zero con quote")]:
            print(sintesi(nome, simula(r, **kw)))
    print("\nScomposizione della differenza P − A (somma del divario di prodotto)")
    for titolo, kw in [("Shock di domanda", dict(eps=domanda)), ("Ondata di insolvenze", dict(eps=dom2, pd_shock=insolv))]:
        P = simula("P", **kw)["y"][5:].sum(); A = simula("A", **kw)["y"][5:].sum()
        no_cap = simula("P", vincolo_capitale=False, **kw)["y"][5:].sum()
        no_cap_chi = simula("P", vincolo_capitale=False, chi_s=0.0, **kw)["y"][5:].sum()
        print(f"  {titolo:<22} P {P:7.2f} | vincolo di capitale {P - no_cap:6.2f} | premio di rischio ciclico {no_cap - no_cap_chi:6.2f} "
              f"| spread più alto (meno margine sopra lo zero) {no_cap_chi - A:6.2f} | A {A:7.2f}")
    z0 = simula("Z0", T=12)
    print("\nZ0 tasso zero senza quote: inflazione per periodo", np.round(z0["pi"], 1))
