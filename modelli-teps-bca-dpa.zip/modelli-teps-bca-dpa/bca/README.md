# BCA — Economia di mercato con Banca Centrale Algoritmica

Modello economico che parte dall'economia di mercato attuale e toglie le banche private. Un'unica **Banca Centrale Algoritmica** (BCA) tiene tutti i conti correnti e concede mutui, finanziamenti alle imprese e credito al consumo, con regole pubbliche e deterministiche eseguite da più sistemi di IA indipendenti. Non esiste alcun tasso di interesse privato: il credito costa un tasso pubblico algoritmico senza margine di profitto, e la BCA presta con le stesse regole e la stessa analisi del rischio delle banche, anche allo Stato.

## Struttura della cartella

| Cartella / file | Contenuto |
|---|---|
| [`pdf/`](pdf/) | **Documenti finali in PDF**: [BCA_1_0_IT.pdf](pdf/BCA_1_0_IT.pdf) (paper a colori, italiano, 18 pagine), [BCA_1_0_EN.pdf](pdf/BCA_1_0_EN.pdf) (colour paper, English, 17 pages) |
| [`word/`](word/) | Gli stessi documenti in Word: [BCA_1_0_IT.docx](word/BCA_1_0_IT.docx), [BCA_1_0_EN.docx](word/BCA_1_0_EN.docx) |
| [`BCA_1_0_Modello_Economico.md`](BCA_1_0_Modello_Economico.md) | Testo sorgente italiano: ipotesi, istituzioni, dimostrazioni D-1–D-16, simulazioni N-1–N-3, condizioni B1–B7, limiti |
| [`BCA_1_0_Economic_Model_EN.md`](BCA_1_0_Economic_Model_EN.md) | English source text |
| [`figure/`](figure/) | Figure 1–2 (crisi a confronto, tasso zero), in italiano e in inglese (`*_en.png`) |
| [`simulazioni/`](simulazioni/) | Script Python: registro della BCA (N-1), modello macroeconomico (N-2, N-3), figure |
| [`ZENODO.md`](ZENODO.md) | Titolo, descrizione e parole chiave per Zenodo |

I documenti si rigenerano con `bash strumenti/genera_documenti.sh` dalla radice del repository. Gli script richiedono NumPy (le figure anche Matplotlib) e si lanciano dalla cartella `bca/`, per esempio `python3 simulazioni/bca_1_0_macro.py`.

## Risultati principali

- **La BCA può fare la banca.** Depositi = prestiti − patrimonio della BCA in ogni istante (D-1); un pagamento dipende solo dal saldo di chi paga, quindi le corse agli sportelli sono impossibili (D-2); il registro è ricalcolabile da chiunque (D-3).
- **Nessun tasso privato non significa tasso zero.** A tasso zero l'inflazione non torna all'obiettivo (D-8); funziona solo rifiutando in modo permanente circa un sesto del credito domandato (D-9). Il disegno raccomandato è un tasso pubblico algoritmico: tasso di politica + costo + perdita attesa, senza margine (D-4, D-7).
- **Stesse regole delle banche**: verifica del reddito, rata/reddito, prestito/valore, garanzie, classi di rischio con tasso calcolato per classe (nessun sussidio incrociato, D-14), accantonamenti (§9).
- **Lo Stato è un debitore come gli altri**: credito solo entro i limiti di sostenibilità del debito (D-15), così la moneta creata per lo Stato resta limitata.
- **Gli interessi sono soldi pubblici**: la BCA non ha guadagno proprio; gli interessi netti vanno allo Stato. A parità di tasso pagato dai debitori, i profitti bancari diventano entrate pubbliche: 1,9% del PIL nell'esempio (D-5, D-6).
- **Interessi sui depositi sostenibili e bassi**: i_D = max(0, min(π*, i − m)). La BCA non va mai in perdita per pagarli e i risparmi conservano il potere d'acquisto senza crescere, così conviene investire (D-16). Nell'esempio 2,0%.
- **Le crisi del credito sono meno gravi**: scompare il taglio dei prestiti dovuto alle perdite delle banche (D-10). Nella simulazione di un'ondata di insolvenze la perdita di prodotto scende da 11,2 a 4,0 (N-2). Le perdite però diventano un costo pubblico.
- **Case**: tassi bassi sui mutui fanno salire i prezzi (D-11); il limite al mutuo va legato al reddito, non al tasso (D-12).

Parametri dimostrativi, nessuna calibrazione su un'economia reale.
