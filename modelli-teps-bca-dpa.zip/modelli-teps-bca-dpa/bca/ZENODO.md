# Scheda Zenodo — BCA 1.0

**Titolo**
BCA — Economia di mercato con Banca Centrale Algoritmica (versione 1.0)

**Tipo di risorsa:** Pubblicazione → Working paper (oppure Preprint)
**Lingua:** italiano
**Versione:** 1.0
**Data di pubblicazione:** 2026-11-02
**File:** `pdf/BCA_1_0_IT.pdf` (documento principale), `word/BCA_1_0_IT.docx`, script Python `bca_1_0_registro.py` e `bca_1_0_macro.py`
**Versione inglese:** `pdf/BCA_1_0_EN.pdf` (stesso contenuto; si può caricare nello stesso record o in un record collegato)
**Licenza suggerita:** Creative Commons Attribution 4.0 International (CC BY 4.0)

## Descrizione (italiano)

Il documento presenta la BCA, un modello teorico di economia di mercato in cui non esistono banche private. Imprese private, lavoro salariato, Stato e prezzi di mercato restano quelli attuali; cambia una sola istituzione: un'unica Banca Centrale Algoritmica, pubblica e gestita da più sistemi di intelligenza artificiale indipendenti con regole pubbliche e deterministiche, tiene tutti i conti correnti e concede mutui, finanziamenti alle imprese e credito al consumo. Non esistono tassi di interesse privati.

Il costo del credito è un tasso pubblico fissato da una regola algoritmica: tasso di politica contro l'inflazione, più costo operativo e perdita attesa della classe di rischio, senza margine di profitto. Gli interessi netti sono entrate pubbliche; i depositi ricevono un interesse basso e sostenibile, non superiore all'inflazione obiettivo, per favorire gli investimenti. La banca applica le stesse regole di merito creditizio e di analisi del rischio delle banche, anche allo Stato quando chiede credito.

Il modello contiene 16 proposizioni dimostrate e 3 risultati numerici riproducibili. Fra i principali: la moneta coincide in ogni istante con i prestiti meno il patrimonio della banca e le corse agli sportelli sono impossibili; un tasso zero non riporta l'inflazione all'obiettivo, se non con un razionamento permanente del credito; la regola algoritmica del tasso è stabile entro limiti espliciti; a parità di tasso pagato dai debitori, i profitti bancari diventano entrate pubbliche; nelle crisi del credito scompare il taglio dei prestiti dovuto alle perdite delle banche, con una perdita di prodotto molto minore nelle simulazioni; il limite ai mutui va legato al reddito e non al tasso; il credito allo Stato resta limitato da una regola di sostenibilità. Il modello è coerente sotto sette condizioni esplicite.

Stato scientifico: modello teorico con dimostrazioni algebriche e simulazioni su parametri dimostrativi; non è calibrato su un'economia reale. Restano aperti l'economia aperta, la stabilità globale e la calibrazione empirica.

## Description (English)

This working paper presents BCA, a theoretical model of a market economy without private banks. Private firms, wage labour, government and market prices are unchanged; a single public Algorithmic Central Bank, run by several independent AI systems under public, deterministic rules, holds all current accounts and grants mortgages, business loans and consumer credit. There are no private interest rates.

Credit is priced by an algorithmic public rate (anti-inflation policy rate plus operating cost and expected loss of the risk class, with no profit margin). Net interest income is public revenue; deposits earn a low, sustainable rate capped at the inflation target to encourage investment. The bank applies standard bank credit and risk-assessment rules, including to the State as a borrower.

The paper proves 16 propositions and reports 3 reproducible numerical results: money always equals loans minus bank equity and bank runs are impossible; a zero interest rate fails to bring inflation back to target unless credit is permanently rationed; the algorithmic rate rule is stable within explicit bounds; bank profits become public revenue at an unchanged borrowing rate; credit crunches caused by bank capital losses disappear; mortgage limits should be tied to income rather than to the rate; lending to the State is bounded by a sustainability rule. The model is consistent under seven explicit conditions. It is a theoretical model with illustrative parameters and is not empirically calibrated.

## Parole chiave / Keywords

banca centrale algoritmica; moneta pubblica; sistema bancario; intelligenza artificiale; politica monetaria; tasso di interesse pubblico; stabilità finanziaria; credito; algorithmic central bank; sovereign money; public banking; monetary policy; financial stability; artificial intelligence
