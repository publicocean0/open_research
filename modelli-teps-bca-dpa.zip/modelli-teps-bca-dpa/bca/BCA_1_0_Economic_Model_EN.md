# BCA — Market Economy with an Algorithmic Central Bank

## Version 1.0 · 2 November 2026 (updated with the credit rules)

**Scenario assumptions.** The starting point is today's market economy: private firms, wage labour, the State, market prices, shares. Only one institution changes: **there are no private banks**. A single Algorithmic Central Bank (BCA) holds all current accounts and grants mortgages, business loans and consumer credit, under public and deterministic rules executed by several independent AI systems. There is no interest rate set by private banks: the cost of credit is an **algorithmic public rate**, with no profit margin. The BCA applies to mortgages and loans **the same rules and the same risk analysis as banks**, and it applies them to the State as well when the State asks for credit.

**Scientific status.** Theoretical model with algebraic proofs and reproducible simulations on illustrative parameters. It is not calibrated on a real economy and is not an empirically validated theory.

| Tag | Meaning |
|---|---|
| [D] | Proposition derived from the equations, with explicit assumptions |
| [N] | Numerical result reproduced by a script, not a forecast |
| [P] | Institutional design principle, not a theorem |
| [A] | Technical assumption introduced to close the model |

---

## Executive summary

| Question | Answer of the model | Where |
|---|---|---|
| Can an automated central bank replace private banks? | Yes for accounts, payments, money creation and credit: the ledger conserves money, cannot suffer bank runs and can be verified by anyone | D-1, D-2, D-3 |
| Without a private rate, must credit cost zero? | No. "No private rate" does not mean "zero rate". At a zero rate inflation does not return to target; it works only by permanently rationing about 17% of the credit demanded | D-8, D-9 |
| Which design does the model adopt? | A public rate set by an algorithmic rule: policy rate against inflation + operating cost + expected loss of the risk class, with no profit margin | D-4, D-5, D-7, D-14 |
| By what rules does the BCA lend? | The same as banks: income verification, debt service-to-income, loan-to-value, collateral, risk classes, provisions. Being public does not mean lending on softer criteria | §9 |
| Can the State borrow without limits? | No: it asks the BCA for credit with risk analysis and a sustainability limit, like every borrower. In this way the money created for the State remains limited | D-15 |
| Where does the interest go? | To the State: the BCA is public and has no profit of its own; net interest is public revenue (1.9% of GDP in the example) | D-5, D-6 |
| Do deposits pay interest? | Yes, under a sustainable and low rule: at most the inflation target and always at least one point below the policy rate. Savings keep their purchasing power; to make them grow one has to invest | D-16 |
| Is the system more stable? | Yes in credit crises: the lending cut caused by bank losses disappears. In the simulated wave of defaults the output loss falls from 11.2 to 4.0 | D-10, N-2 |
| What remains to be governed? | Loan losses become a public cost; credit without a margin pushes up house prices; without deterministic rules the BCA risks financing loss-making firms | D-10, D-11, D-12 |

The economic model is consistent under **seven explicit conditions** (B1–B7, §11). Global stability, operation in an open economy and superiority over the current arrangement on real data are not proven.

---

## 1. Objective and starting point

Today most money consists of bank deposits, created by private banks when they grant loans [4]. The central bank sets a policy rate; banks add a spread that covers costs, expected losses and profit, and decide whom to lend to. The supply of credit depends on their capital: when they suffer losses they cut lending and amplify recessions [7].

The BCA studies what happens if money creation and credit pass entirely to a public institution run by automated systems. The idea has precedents in Fisher's "100% money" [1] and in the *Chicago Plan* re-examined by Benes and Kumhof [2]. The difference is that here the public bank does not merely hold 100% reserves: **it grants credit directly**, under public algorithmic rules.

## 2. Assumptions

- **A1 — Closed economy** with a national currency [A]. The open economy is a declared limitation (§12).
- **A2 — No private banks** [P]. No private party may hold other people's deposits, issue means of payment or create money by granting loans.
- **A3 — Single bank** [P]. The BCA holds the accounts of households, firms and the State; executes payments; grants mortgages, business loans and consumer credit; sets the policy rate.
- **A4 — Deterministic rules** [P]. Every decision of the BCA (rates, loan approvals, quotas, stops) follows public rules, computed by several independent AI systems; the rules are changed only by legislation, never case by case.
- **A5 — Non-bank finance** [A]. Shares and private loans of already existing money (for example bonds) remain. They do not create money (D-1) and their return is constrained by the alternative offered by the BCA.
- **A6 — State** [A]. The Treasury has an account at the BCA like any other party; the BCA's annual result is transferred to it or covered by it. When it asks for credit, the State is a borrower like the others and follows the same risk-analysis rules (§9.6).
- **A7 — Cash** [A]. Any cash is issued one-for-one against balances and does not change the results.
- **A8 — Deposits** [P]. Accounts at the BCA are payment accounts, remunerated under the rule of D-16: sustainable for the BCA and not above the inflation target.

## 3. Institutions

| Party | Task | Limit |
|---|---|---|
| BCA | Accounts, payments, credit, policy rate | Executes only public rules; no case-by-case discretion |
| AI systems of the BCA | Compute the ledger and the risk estimates | Several independent systems; the majority or the median decides |
| Parliament | Approves the rules and parameters | Does not intervene in individual cases |
| Treasury | Receives the net interest collected by the BCA (public revenue) and covers unexpected losses | According to a fixed annual rule |
| Independent oversight | Audit of the ledger, customer appeals | Can recompute every state of the ledger |
| Households and firms | Use accounts and credit; own the firms | Access to credit under rules equal for all |

## 4. Ledger and money creation

### 4.1 The ledger with loans [P]

Each non-bank party j has a deposit account dⱼ ≥ 0 and a loan account ℓⱼ ≥ 0. The BCA has a net worth E_b, which may be positive or negative. The permitted operations are:

| Operation | Effect on the ledger |
|---|---|
| Payment of x from j to k | valid only if dⱼ ≥ x; dⱼ − x, dₖ + x |
| Disbursement of a loan x to j | ℓⱼ + x, dⱼ + x (creates money) |
| Repayment x by j | ℓⱼ − x, dⱼ − x (destroys money) |
| Interest x paid by j | dⱼ − x, E_b + x |
| Interest on deposits, BCA expenses x to k | E_b − x, dₖ + x |
| Write-off of a defaulted loan x | ℓⱼ − x, E_b − x |
| BCA result to the State | E_b → 0, d_Treasury + E_b |

### 4.2 D-1 Conservation of money [D]

    [D] D = L − E_b   at every instant,   with D = Σⱼ dⱼ  and  L = Σⱼ ℓⱼ

**Proof.** At the start D = L = E_b = 0. Every row of the table leaves the quantity D − L + E_b unchanged: a payment moves deposits; disbursement and repayment change D and L by the same amount; interest, expenses and write-offs move value between deposits or loans and the BCA's net worth with opposite signs; the transfer to the State moves E_b into deposits. By induction on the number of operations, D − L + E_b = 0 always. Q.E.D.

- **The only source of money is BCA credit.** Without private banks there is no money created by others. The quantity of money is a public policy variable, controlled by the credit rules.
- **A negative BCA net worth blocks nothing.** If losses make E_b < 0, deposits exceed loans; payments continue (D-2). The loss is an implicit transfer from the public sector to defaulting borrowers and must be recorded as a fiscal cost (D-10).
- **Numerical check N-1.** The script `simulazioni/bca_1_0_registro.py` executes 200,000 random operations on 500 accounts, including disbursements, repayments, interest, write-offs and transfers. The identity D = L − E_b and the non-negativity of deposits and loans hold at every operation, even with a strongly negative BCA net worth.

### 4.3 D-2 No bank runs [D]

In a fractional-reserve bank with deposits D and reserves r·D, with r < 1, simultaneous withdrawal requests exceeding r·D cannot all be paid: the outcome for each depositor depends on what the others do, and this is the root of bank runs [3]. In the BCA:

    [D] the validity of a payment depends only on the payer's balance

**Proof.** It follows from the rule "valid only if dⱼ ≥ x". A set of payments in which the outflows of each account do not exceed its balance can be executed in full and in any order, because each payment reduces only the account that issues it. The deposit is not a claim on a bank to be converted into money: it is the money. Q.E.D.

Consequence: no deposit insurance, lender of last resort or liquidity requirements are needed. Bank liquidity risk disappears; credit risk remains, and it becomes public.

### 4.4 D-3 Verifiable deterministic execution [D]

The ledger evolves according to a public deterministic function, Sₜ₊₁ = Φ(Sₜ, operations). It is computed by n independent systems; a new state is accepted only if the majority produce the same state, otherwise the ledger stops and recomputes. With failure probability q per system and independent failures:

    [D] Pr[wrong state accepted] ≤ Σ_{j > n/2} C(n, j) qʲ (1 − q)ⁿ⁻ʲ

**Proof.** Φ is deterministic, so all correct systems produce exactly the same state. A wrong state can be accepted only if a majority of systems are faulty and produce the same wrong state; the probability that a majority is faulty is the binomial sum, which is therefore an upper bound. Q.E.D.

With q = 0.01 the bound is 3.0·10⁻⁴ for n = 3 and 9.9·10⁻⁶ for n = 5. Among correct systems there is no legitimate disagreement, so every difference signals a failure, and anyone can recompute the state from the public records of operations. The guarantee requires independent failures: common-mode failures (the same faulty code) are reduced with different implementations of the same Φ.

## 5. The price of credit: interest as public revenue

**Why an interest rate exists.** The BCA is public: it has no shareholders and no profit of its own. The interest it collects is **public money** and goes to the State (D-5). The lending rate has three components, each with a single function:

| Component | Function | Where |
|---|---|---|
| Policy rate i | Preventing inflation: it makes credit expensive enough that demand does not grow beyond the capacity of the economy. It is set by an algorithmic rule that raises it when inflation exceeds the target and lowers it when inflation falls. What it collects is public revenue | D-7, D-5 |
| Operating cost c | Covering the BCA's running costs | D-4 |
| Expected loss PD·LGD | Covering the defaults of its own risk class, without making the other borrowers pay for them | D-4, D-14 |

Without the first component credit would cost too little and prices would rise without stopping (D-8); the only alternative would be to permanently refuse part of the credit requested (D-9).

**Deposits [P].** Accounts at the BCA are payment accounts: they hold money and are not an investment. They receive a low interest rate, set by the rule of D-16, which protects their purchasing power without making it grow; whoever seeks a real return invests in firms, shares or bonds (A5).

### 5.1 D-4 Composition of the lending rate [D]

The BCA bears an operating cost c per unit of credit and loses a fraction LGD of the loan with default probability PD. The rate that covers costs and expected losses and in addition yields on average the policy rate i is:

    [D] iᴸ = (1 + i + c) / (1 − PD · LGD) − 1   ≈   i + c + PD · LGD

**Proof.** On a unit loan the BCA collects on average (1 + iᴸ)(1 − PD·LGD). Requiring that, after deducting the repaid principal and the cost c, i remains on average, that is (1 + iᴸ)(1 − PD·LGD) = 1 + i + c, gives the formula; the approximation holds for small PD·LGD. Q.E.D.

Example with i = 3.9%, c = 0.2%, PD = 2%, LGD = 45%: exact rate 5.05%, approximate 5.0%. The expected loss PD·LGD is computed on the cycle average (*through the cycle*), not at a point in time: the rate does not rise in recessions.

### 5.2 D-5 Interest is public revenue [D]

With loans at the rate of D-4 and deposits remunerated at the rate i_D, the expected net income of the BCA is:

    [D] Π_b = iᴸ L − i_D D − c L − PD·LGD·L = i · L − i_D · D ;    with D = L:  Π_b = (i − i_D) · L

**Proof.** Substituting iᴸ = i + c + PD·LGD, the terms in c and in PD·LGD cancel out and i·L − i_D·D remains. If the net income is paid to the State every year, the BCA's net worth remains zero and by D-1 D = L. Q.E.D.

The entire net income is paid to the State every year (B6): the BCA retains nothing. Example: with credit equal to 100% of GDP, a policy rate of 3.9% and a deposit rate of 2.0% (D-16), net interest amounts to **1.9% of GDP per year in public revenue**. Unexpected losses reduce this payment or, if they exceed it, are covered by the State (D-10).

### 5.3 D-6 Where the interest paid by borrowers goes [D]

The lending rate that keeps demand in equilibrium (neutral rate iᴸₙ) is a feature of the economy, not of the banking system. In steady state, with private spread s_P and BCA spread s_B:

    [D] i_BCA − i_private = s_P − s_B

**Proof.** In both arrangements the steady state requires iᴸ = iᴸₙ, hence i + s = iᴸₙ and the difference between the policy rates is the difference between the spreads. Q.E.D.

Illustrative example: private spread 2.7 points (cost 0.8, profit margin 1.0, expected loss 0.9), BCA spread 1.1 points (cost 0.2, expected loss 0.9). In both cases borrowers pay 5%, but the money ends up in different places (points of GDP per year, with credit equal to 100% of GDP):

| Destination of interest | Private banks | BCA |
|---|---|---|
| Depositors | 2.3 | 2.0 |
| Running costs | 0.8 | 0.2 |
| Coverage of defaults | 0.9 | 0.9 |
| Profits of bank shareholders | 1.0 | 0 |
| Public revenue | 0 | 1.9 |
| **Total paid by borrowers** | **5.0** | **5.0** |

*Table 1. For the same rate paid by borrowers, with the BCA bank profits become public revenue and depositors receive interest similar to today's, set by D-16; the lower running costs (0.6 points) are an assumption about automated management, still to be verified.*

Depositors receive 2.0% instead of 2.3%: with inflation at 2% they keep their purchasing power. The State collects 1.9% of GDP, which can reduce other taxes or finance services.

The result also has a macroeconomic effect: with a higher policy rate the BCA has **more room before reaching zero** in recessions (N-2).

### 5.4 D-16 Interest on deposits: sustainable and low [D]

The deposit rate is set by a public algorithmic rule, with the margin m and the inflation target π* set by law:

    [P] i_D = max(0, min(π*, i − m))

    [D] (a) Π_b = (i − i_D)·L ≥ min(i, m)·L ≥ 0
        (b) i_D − π* ≤ 0
        (c) i_D ≤ i < iᴸ

**Proof.** (a) If i ≥ m, then i_D ≤ i − m and therefore i − i_D ≥ m; if i < m, then i − m < 0 and i_D = 0, therefore i − i_D = i. In both cases i − i_D ≥ min(i, m) ≥ 0, and by D-5 Π_b = (i − i_D)·L. (b) i_D ≤ π* by construction. (c) i_D ≤ i − m < i if i ≥ m, i_D = 0 ≤ i otherwise; iᴸ = i + c + PD·LGD > i. Q.E.D.

- **Sustainable (a).** Paying interest on deposits never puts the BCA into expected loss: there always remains a net income of at least m per unit of credit, paid to the State. The margin m covers unexpected losses in normal years; in crises (up to 2.7 points of GDP in one year in the wave of defaults of N-2) the State covers them according to B6.
- **Not high, to encourage investment (b).** At the inflation target the real return on deposits is at most zero: savings keep their purchasing power but do not grow. Any investment with a positive expected real return (firms, shares, bonds) is more attractive than the deposit.
- **No arbitrage (c).** Whoever borrows in order to deposit pays iᴸ and receives less than i: they always lose.
- **Automatic over the cycle.** The deposit rate follows the policy rate: it falls in recessions, when it pays to spend and invest, and reaches zero when the policy rate falls below m.
- **Inflation.** The instrument against inflation remains the lending rate (D-7). The deposit rate, tied to the target and not to current inflation, does not fuel it.

Example with i = 3.9%, π* = 2% and m = 1 point: i_D = min(2.0, 2.9) = 2.0%. Public revenue: (3.9 − 2.0)·L = 1.9% of GDP with credit equal to GDP. In a recession with i = 1%: i_D = 0.

## 6. Algorithmic monetary policy

### 6.1 Model

Reduced model with annual periods, variables in percentage points. y is the output gap, π inflation, i the policy rate, iᴸ the lending rate, g credit rationing (percentage difference between credit granted and credit demanded, never positive).

    yₜ = ρ yₜ₋₁ − σ (iᴸₜ − πₜ − rᴸₙ) + ψ gₜ + εₜ
    πₜ = (1 − a) πₜ₋₁ + a π* + κ yₜ₋₁
    iₜ = max(0, i_ss + (1 + φ_π)(πₜ − π*) + φ_y yₜ₋₁)
    iᴸₜ = iₜ + s

a is the share of expectations anchored to the target π*; rᴸₙ the neutral real lending rate; s the spread. Illustrative parameters: ρ = 0.5; σ = 0.5; ψ = 0.15; κ = 0.2; a = 0.2; φ_π = 0.5; φ_y = 0.5; π* = 2%; rᴸₙ = 3%.

### 6.2 D-7 Stability of the algorithmic rate rule [D]

Let x = π − π* and b = ρ − σφ_y, with |b| < 1. Away from the zero lower bound, the system is stable if and only if:

    [D] − a (1 − b) / (κ σ)  <  φ_π  <  (2 − a)(1 + b) / (κ σ)

**Proof.** Substituting the rule, iᴸ − π − rᴸₙ = φ_π x + φ_y yₜ₋₁, hence yₜ = b yₜ₋₁ − σφ_π xₜ and xₜ₊₁ = (1 − a − κσφ_π) xₜ + κ b yₜ₋₁. The system matrix in the state (xₜ, yₜ₋₁) has trace 1 − a − κσφ_π + b and determinant (1 − a) b. The Jury conditions for a 2×2 matrix are |det| < 1, 1 − tr + det > 0, 1 + tr + det > 0. The first holds for |b| < 1. The second gives a(1 − b) + κσφ_π > 0, the third (2 − a)(1 + b) − κσφ_π > 0. Q.E.D.

- With unanchored expectations (a = 0) the lower condition becomes φ_π > 0: the nominal rate must react more than proportionally to inflation. This is the Taylor principle [6].
- With the parameters of the example: −1.5 < φ_π < 22.5; the chosen value φ_π = 0.5 gives eigenvalues 0.72 and 0.28.
- An automatic rule does not eliminate the zero lower bound: it is a real limit, which D-6 makes less binding.

### 6.3 D-8 At a zero rate without quotas inflation does not return to target [D]

If all loans are at a zero nominal rate and credit equals demand (g = 0), then iᴸ − π − rᴸₙ = −(x + π* + rᴸₙ) and:

    [D] if κσ ≥ a(1 − ρ) inflation diverges;
        otherwise it converges to  π* + κσ(π* + rᴸₙ) / [a(1 − ρ) − κσ]  > π*

**Proof.** The system matrix is [[1 − a + κσ, κρ], [σ, ρ]], with trace 1 − a + κσ + ρ and determinant (1 − a)ρ, hence 1 − tr + det = a(1 − ρ) − κσ. If this quantity is ≤ 0 the Jury condition is violated and the system has an eigenvalue ≥ 1. Otherwise the fixed point is obtained by imposing y = σ(x + π* + rᴸₙ)/(1 − ρ) and a x = κ y, whence x = κσ(π* + rᴸₙ)/[a(1 − ρ) − κσ] > 0. Q.E.D.

With the parameters of the example a(1 − ρ) = κσ = 0.1: eigenvalue exactly 1 and inflation rising by about 0.8 points a year without stopping (N-3: 2.0 → 10.6% in 11 years). The zero rate makes credit too cheap: demand exceeds the capacity of the economy and prices rise.

### 6.4 D-9 Zero rate with credit quotas [D]

The zero rate works only if the BCA replaces the price of credit with its quantity: an algorithmic quota gₜ = −Q̄ − φ_q xₜ. The steady state at target requires:

    [D] Q̄ = σ (π* + rᴸₙ) / ψ ;     stability:  − a(1 − ρ)/κ  <  ψ φ_q − σ  <  (2 − a)(1 + ρ)/κ

**Proof.** With iᴸ = 0 and the quota, yₜ = ρ yₜ₋₁ + σ(xₜ + π* + rᴸₙ) − ψQ̄ − ψφ_q xₜ. The constant term vanishes if and only if ψQ̄ = σ(π* + rᴸₙ). What remains is yₜ = ρ yₜ₋₁ − (ψφ_q − σ) xₜ, that is the system of D-7 with σφ_π replaced by ψφ_q − σ and φ_y = 0; the Jury conditions give the interval. Q.E.D.

- In the example Q̄ = 16.7%: **one sixth of the credit demanded must be permanently refused**, even in normal conditions. With φ_q = 8 the system is stable (ψφ_q − σ = 0.7, eigenvalues of modulus 0.63).
- The quota has a limit of its own: it cannot grant more credit than is demanded (g ≤ 0). This limit is reached when inflation falls more than Q̄/φ_q ≈ 2.1 points below target, and it is the analogue of the zero lower bound for rates.
- Rationing at a zero price leaves the BCA very wide allocative power: it decides who gets a good worth more than it costs. This is the main argument against the zero-rate regime.

![](figure/figura_2_en.png)

*Figure 2. Left, inflation without shocks: with a zero rate and unrestricted credit (Z0) it rises without stopping, with the public rate (A) and with quotas (Z) it stays at target (the two lines coincide). Right, credit rationing in the wave of defaults: private banks (P) cut credit when they lose capital, the zero-rate BCA (Z) permanently refuses about one sixth of the credit demanded, the BCA with the public rate (A) does not ration. Simulations with illustrative parameters, not forecasts.*

**Conclusion of §6.** "No private rate" does not imply "zero rate". The model adopts a **public rate set by an algorithmic rule** (D-7), with loans priced by risk class (D-4, D-14) and net interest paid to the State as public revenue (D-5). The zero-rate regime with quotas remains only as a benchmark for comparison.

## 7. Financial stability

### 7.1 D-10 The bank capital channel disappears [D]

A private bank with capital E and minimum requirement κ_cap can lend at most L ≤ E/κ_cap. A loss ℓ reduces the maximum credit by:

    [D] private banks: ΔLˢ = − ℓ / κ_cap ;      BCA: ΔLˢ = 0

**Proof.** For private banks it follows from the constraint L ≤ E/κ_cap with ΔE = −ℓ. The BCA has no capital constraint: by D-2 a negative net worth does not prevent payments, and the quantity of credit is set by the rules (demand admitted by risk control, or quota). Q.E.D.

With an 8% requirement each unit of loss can remove up to 12.5 units of credit from the economy. This mechanism, which amplifies crises (the financial accelerator [7]), does not exist in the BCA.

**The cost to be declared.** Losses do not disappear: they become public, because they reduce E_b and the Treasury covers them (A6). And a bank without a capital constraint can keep lending to loss-making firms: this is Kornai's "soft" budget constraint [5]. The defence is condition B5 (§11): deterministic approval rules, no discretionary renegotiation and automatic stop of financing that exceeds the risk thresholds.

### 7.2 N-2 Crises compared [N]

Three arrangements, same parameters as in §6.1 and same steady-state lending rate (5%):

- **P — private banks**: spread of 2.7 points plus a risk premium that rises by 0.3 points for each point of recession; capital 8.8% of credit with an 8% requirement; defaults PD = 2% − 1·y.
- **A — BCA with public rate**: constant spread of 1.1 points; no capital constraint.
- **Z — zero-rate BCA with quotas**: quota with Q̄ = 16.7% and φ_q = 8.

| Scenario | Regime | Minimum output | Cumulative output loss | Maximum credit rationing | Minimum inflation | Years at zero rate | Minimum bank capital | Losses beyond expected |
|---|---|---|---|---|---|---|---|---|
| Demand shock −4 (2 years) | P | −5.85 | −16.32 | 0.0% | −0.18% | 7 | 8.80 | 7.20 (banks) |
| | A | −4.80 | −8.45 | 0.0% | 0.40% | 1 | — | 3.93 (State) |
| | Z | −5.44 | −6.67 | −17.1% | 0.27% | — | — | 3.05 (State) |
| Defaults +4 points and demand −2 (2 years) | P | −3.13 | −11.21 | −14.0% | 0.43% | 5 | 6.90 | 8.38 (banks) |
| | A | −2.40 | −4.00 | 0.0% | 1.20% | 0 | — | 5.46 (State) |
| | Z | −2.72 | −3.33 | −16.9% | 1.14% | — | — | 4.79 (State) |

*Table 2. Periods 5–40. Output in percentage points of deviation from potential; cumulative loss = sum of the deviations; losses in points of GDP. In regime Z rationing includes the permanent 16.7%. Illustrative parameters.*

**Decomposition of the difference between P and A** (cumulative output loss):

| Scenario | Capital constraint | Cyclical risk premium | Higher spread (less margin above zero) | Total P − A |
|---|---|---|---|---|
| Demand shock | 0.00 | −5.34 | −2.53 | −7.87 |
| Wave of defaults | −6.16 | −1.01 | −0.05 | −7.21 |

*Table 3. Each column is the difference obtained by removing one mechanism at a time from regime P.*

![](figure/figura_1_en.png)

*Figure 1. Output gap in the two crises with private banks (P), BCA with public rate (A) and zero-rate BCA with quotas (Z). Band: shock periods. Simulations with illustrative parameters, not forecasts.*

- **In credit crises the BCA halves the output loss or does better.** In the wave of defaults the capital of private banks falls from 8.8 to 6.9, credit is cut by 14% and the output loss is 11.2 against 4.0. More than 80% of the difference comes from the capital constraint (D-10).
- **In demand crises spread and risk premium matter.** Private banks raise the cost of credit precisely in a recession and start from a lower policy rate, so they stay at zero for 7 years against 1.
- **Losses change owner.** With the BCA the losses beyond expected are smaller (the recession is shorter) but they become a public cost: 3.9–5.5 points of GDP spread over the years.
- **Regime Z stabilises slightly better than A**, because the quantity of credit is not subject to the zero bound. The price is the permanent rationing of one sixth of the credit demanded (D-9).

## 8. Mortgages and house prices

### 8.1 D-11 The mortgage rate is capitalised into prices [D]

The price of a house with rent R growing at rate g, ownership and maintenance costs θ and a discount rate equal to the mortgage rate iᴹ is:

    [D] P / R = 1 / (iᴹ + θ − g),   for iᴹ + θ > g

**Proof.** The price is the present value of the growing rent, discounted at rate iᴹ + θ: Σₜ₌₀^∞ R(1 + g)ᵗ / (1 + iᴹ + θ)ᵗ⁺¹. It is a geometric series with ratio (1 + g)/(1 + iᴹ + θ) < 1, whose sum is R/(iᴹ + θ − g): the Gordon formula [8]. Q.E.D.

| Mortgage rate | 5% | 4% | 2% | 1% | 0% |
|---|---|---|---|---|---|
| Price / annual rent (θ = 1.5%, g = 1%) | 18.2 | 22.2 | 40.0 | 66.7 | 200.0 |

*Table 4. Lowering mortgage rates towards zero multiplies equilibrium house prices.*

### 8.2 D-12 The mortgage limit must be tied to income, not to the rate [D]

If the limit is a maximum instalment equal to a share m of income Y for T years, the maximum mortgage is m·Y·aₜ(iᴹ), with aₜ(i) = [1 − (1 + i)⁻ᵀ]/i and aₜ(0) = T. With m = 30% and T = 25 years:

| Mortgage rate | 4% | 2% | 0% |
|---|---|---|---|
| Maximum mortgage / annual income | 4.69 | 5.86 | 7.50 |

A lower rate increases the credit that can be granted by 25–60% and therefore house prices for those who buy with debt. The correct algorithmic rule instead sets the maximum mortgage as a **multiple of income independent of the rate** (for example ℓ̄ = 4.5 times), together with a maximum loan-to-value ratio:

    [D] with mortgage ≤ ℓ̄ · Y and down payment A, the price payable by a debt-financed buyer is ≤ ℓ̄ · Y + A, for every iᴹ

**Proof.** The price paid cannot exceed the obtainable credit plus the down payment; neither term depends on the rate. Q.E.D.

## 9. Credit rules: the same as the banks'

[P] The BCA applies to mortgages, business loans and consumer credit **the same creditworthiness and risk analysis rules used by banks**. There are three differences: the rules are public, they are executed automatically and equally for everyone, and the rate contains no profit margin. Being a public bank does not mean lending on softer criteria: a loan granted to someone who cannot repay it is a public loss (D-10).

### 9.1 Mortgages [P]

| Rule | Content | Typical value, to be set by law |
|---|---|---|
| Income verification | Documented and stable income, read from tax and social security records | — |
| Debt service-to-income | Instalments on all outstanding debts no higher than a share m of net income | m = 30–35% |
| Mortgage-to-income | Maximum mortgage as a multiple of annual income, independent of the rate (D-12) | ℓ̄ = 4.5 |
| Loan-to-value | Mortgage no higher than a share of the appraised value | 80% |
| Appraisal | Property value estimated by public models and verified independently | — |
| Collateral | First-lien mortgage on the property | — |
| Term and age | Maximum term; end of the mortgage by a maximum age | 30 years; 75 years |
| Credit history | Outstanding debts and payment regularity, read from the BCA ledger | — |
| Insurance | Mandatory insurance policy on the property | — |

**Fixed or variable rate.** The variable rate is the current policy rate plus the cost and expected loss of the class. The fixed rate is the expected average of the policy rate over the term plus cost and expected loss: on average it yields the policy rate, and the risk that rates rise beyond expectations is absorbed by the net worth of the BCA, as it is today by that of the banks.

### 9.2 Firms and consumer credit [P]

- **Firms.** Financial statements read from accounting records; business plan for new projects; rating computed by the models; collateral and contractual clauses (*covenants*) checked automatically; for new or large projects, financing in tranches tied to the achievement of verified results.
- **Consumer credit.** Same overall debt service-to-income limit as for mortgages, maximum amounts and terms per product.

### 9.3 Risk analysis [P]

1. **Estimation.** The probability of default PD̂ of each application is the median of the estimates of n independent models, with different data, methods and developers. The admissible variables are public (income, debts, payment history, collateral, sector) and exclude protected characteristics.
2. **Classes.** Applications are grouped into risk classes k; each class has its own PD_k and LGD_k, estimated on the actual outcomes of the loans.
3. **Decision.** The application is approved if and only if PD̂ does not exceed the threshold PD_max of the product and all the rules of §9.1–9.2 are met.
4. **Price.** The rate is that of D-4 computed for the class (D-14).
5. **Provisions.** At disbursement the BCA sets aside the expected loss PD·LGD·amount and updates it when the risk changes, as the IFRS 9 accounting standard [10] requires of banks. Losses beyond provisions follow the fiscal rule (B6).
6. **Monitoring and default.** Automatic warning signals on arrears; restructurings according to public rules; enforcement of collateral through the legal procedures. No discretionary renegotiation.
7. **Reasons and appeal.** Every refusal states the variables that determined it and can be challenged.

The BCA has an informational advantage over a private bank: it sees the entire payment history of every applicant, so it can estimate risk with fewer errors. This is the same fact that makes the question of privacy central (§12).

### 9.4 D-14 Rate by risk class: no cross-subsidy [D]

    [D] iᴸ_k = (1 + i + c) / (1 − PD_k · LGD_k) − 1   for every class k

**Proof.** By D-4 applied to each class, each class covers its own expected losses by itself, so none finances the losses of another. With a single rate computed on the average loss, instead, coverage holds only in aggregate: in the linear approximation iᴸ ≈ i + c + EL, class k transfers (EL̄ − EL_k)·L_k, and the credit-weighted sum of the transfers is zero. The less risky classes pay the losses of the riskier ones. Q.E.D.

Example with i = 3.9%, c = 0.2%, LGD = 45%: 70% of credit in class A (PD 1%), 30% in class B (PD 4.33%), average PD 2%. Rates by class: 4.57% and 6.17%; single rate: 5.05%. With the single rate class A pays 0.48 points more and class B 1.13 points less.

The rate by class also serves stability: if credit between private parties exists (A5), the less risky borrowers would abandon a single rate, leaving the BCA only the riskiest ones (adverse selection). Banks price risk for the same reason.

### 9.5 D-13 Error of majority judgement [D]

If n models decide "approve / reject" and each errs with probability p, with independent errors, the majority decision errs with probability Σ_{k > n/2} C(n, k) pᵏ(1 − p)ⁿ⁻ᵏ. With n = 5 and p = 10%: **0.86%** instead of 10%. The reduction depends on the independence of the errors: models trained on the same data err together, and then the panel does not correct. Independence must be measured on public test cases, replacing the models whose errors are too correlated.

### 9.6 The State as borrower: same rules [P]

The Treasury requests credit from the BCA like any borrower: no automatic overdraft, risk analysis and a sustainability limit. The mortgage rules have a direct equivalent:

| Rule for households and firms | Equivalent for the State |
|---|---|
| Income verification | Documented and projected tax revenue |
| Debt service-to-income | Primary deficit / GDP within the limit of D-15 (interest paid to the BCA returns to the State) |
| Mortgage-to-income | Debt / GDP no higher than a limit b_max |
| Creditworthiness | Debt sustainability (D-15) |
| Financing in tranches | Credit granted year by year, only if the plan is respected |

### 9.7 D-15 Sustainability of public debt [D]

The interest that the State pays to the BCA returns to the State as public revenue (D-5): for the public sector as a whole it is a pass-through item. The constraint that matters is therefore the **quantity** of credit to the State, because it is created money (D-1). Let b be the BCA's credit to the State as a ratio to GDP, d the State's primary deficit as a ratio to GDP (expenditure minus revenue, excluding interest paid to the BCA and including the BCA's payments of interest on private loans) and g the nominal growth of GDP:

    bₜ₊₁ = bₜ / (1 + g) + dₜ

    [D] bₜ₊₁ ≤ bₜ   ⇔   dₜ ≤ g/(1 + g) · bₜ

**Proof.** In nominal terms the State's debt to the BCA grows by the interest i·Bₜ and by the primary deficit, and decreases by the payment of the same interest i·Bₜ, which the BCA returns to the State: Bₜ₊₁ = Bₜ + Dₜ. Dividing by the following year's GDP, equal to (1 + g) times that of year t, gives the equation. Subtracting bₜ, bₜ₊₁ − bₜ = dₜ − g/(1 + g)·bₜ, which is non-positive if and only if the condition holds. Q.E.D.

Example with b = 100% of GDP and nominal growth of 3%: the ratio does not grow as long as the primary deficit does not exceed 2.91% of GDP. In other words, the money created for the State can grow at most as fast as nominal GDP.

**Rule [P].** Credit to the State is granted if the ratio b remains below b_max and, once it reaches it, only if the budget meets the condition of D-15. Otherwise the request is refused, as for any borrower.

**Why it matters for money.** By D-1 money is D = L_private + L_State − E_b. If the State could borrow without limits from the BCA, money would grow without limits and the rate rule (D-7) could no longer control inflation. With the rule, L_State ≤ b_max · GDP: the money created for the State is limited and monetary policy remains independent of budgetary needs.

## 10. Transition from the current arrangement [P]

1. **Accounts.** Every bank deposit becomes, one for one, a deposit at the BCA. The quantity of money does not change.
2. **Loans.** The BCA acquires the banks' loans at their book value L_bank, crediting the banks with L_bank and debiting the deposits D_bank it has taken over. The banks are left with the difference L_bank − D_bank on deposit, that is their capital: shareholders are not expropriated.
3. **Accounting.** After the operation total deposits are D_bank + (L_bank − D_bank) = L_bank and the net worth of the BCA is zero, as D-1 requires.
4. **Exit of the banks.** Private banks close or become non-bank intermediaries (A5) without the ability to create money.

The path is analogous to that of the *Chicago Plan* [1, 2], with the difference that the BCA also holds the loans instead of leaving them to private intermediaries.

## 11. Does the model hold up? Assessment

**Yes, under seven explicit conditions:**

- **B1 Ledger**: accounts, payments and credit on a deterministic public ledger computed by independent systems (D-1, D-2, D-3).
- **B2 Algorithmic public rate**: rate rule within the limits of D-7; alternatively, a zero rate only with credit quotas (D-9) and declared rationing.
- **B3 Price without profit**: lending rate equal to the policy rate plus cost and expected loss, with no margin; deposits remunerated with the sustainable, low rule of D-16; net interest is public revenue (D-4, D-5, D-16).
- **B4 Macroprudential rules**: maximum mortgage as a multiple of income independent of the rate, and a loan-to-value limit (D-11, D-12).
- **B5 Banking rules and hard budget constraint**: the same creditworthiness and risk analysis rules as banks, rate by risk class, provisions; approval, restructuring and stopping of loans only according to public rules, never case by case (§9, D-10, D-13, D-14).
- **B6 Fiscal rule**: the net interest collected by the BCA is paid to the State every year; losses beyond expected are recorded as a public cost and covered by the State (D-5, D-10).
- **B7 The State as borrower under the same rules**: credit to the State only within the limit b_max and the sustainability condition of D-15; the interest paid by the State to the BCA returns to the State.

| Question | Answer in version 1.0 | Evidence still missing |
|---|---|---|
| Does money remain consistent without private banks? | Yes by construction: D = L − E_b always (D-1, N-1) | — |
| Can there be bank runs? | No (D-2) | — |
| Can credit cost zero? | Only with permanent rationing (D-8, D-9) | — |
| Where does the interest go? | To the State, as public revenue, net of a low interest on deposits (D-5, D-6, D-16) | Actual operating cost of the BCA; effect of the deposit rate on saving and investment |
| Is monetary policy stable? | Yes locally, within the limits of D-7 | Global stability; zero bound |
| Are crises less severe? | Yes in credit crises (N-2) | Calibration on real data |
| What happens to houses? | Prices rise if the mortgage limit depends on the rate (D-11, D-12) | Housing market with endogenous supply |
| Can the BCA finance loss-making firms? | Yes, without condition B5 (D-10) | Experiments on stopping rules |
| Can the State have money created without limits? | No: credit to the State only within the sustainability limits (D-15, B7) | Choice of b_max and of the limit on interest |

In substance the BCA is a market economy in which money and credit are an automatic public service: firms remain private, prices remain market prices, but the creation of money, the price of credit and the choice of who receives it follow public rules, and the interest paid by borrowers, formerly divided between depositors and bank shareholders, is public revenue.

## 12. Limitations and verification programme

- **Open economy.** With private banks abroad, residents and firms can move deposits and credit out of the system. International agreements or capital controls are needed; the model does not study them.
- **Concentration of power and privacy.** A single entity sees all transactions and decides all credit. Deterministic rules and auditing reduce arbitrariness but do not resolve the question of privacy, which belongs to governance and is not treated here.
- **Common model errors.** The guarantees D-3 and D-13 require independent errors.
- **Non-bank finance.** If private returns exceed those of the BCA, credit can shift towards non-bank intermediaries (A5). They do not create money, but they can recreate liquidity risks outside the ledger.
- **Calibration.** All parameters are illustrative. The macroeconomic model is reduced and linear, except for the zero bound.
- **Political feasibility.** Proposals for purely public money have already been put to a vote and rejected (Swiss "Vollgeld" referendum, 2018).

| Phase | Objective | Status in version 1.0 |
|---|---|---|
| V1 Ledger | Consistency of money and payments | Closed at the theoretical level (D-1–D-3, N-1) |
| V2 Price of credit | Composition of the rate, interest on deposits and destination of interest | Closed at the theoretical level (D-4–D-6, D-16) |
| V3 Monetary policy | Stability with algorithmic rule or quotas | Closed locally (D-7–D-9); global stability open |
| V4 Crises | Comparison with private banks | Illustrative simulation (N-2); calibration missing |
| V5 Houses | Prices and macroprudential rules | Equilibrium results (D-11, D-12); dynamics missing |
| V6 Open economy | Capital flight and exchange rate | Open |
| V7 Full stock-flow model | Households, firms, State and BCA with explicit balance sheets | Open |

## 13. Register of proofs

| Code | Result | Scope |
|---|---|---|
| D-1 | D = L − E_b at every instant | BCA ledger |
| D-2 | Payment independent of other accounts: no bank runs | 100% coverage |
| D-3 | Accepted erroneous state ≤ Σ_{j>n/2} C(n,j) qʲ(1−q)ⁿ⁻ʲ | Independent failures |
| D-4 | iᴸ = (1 + i + c)/(1 − PD·LGD) − 1 | Coverage of costs and expected losses |
| D-5 | Π_b = i·L − i_D·D; with i_D = 0 net interest = i·L, all to the State | Loans at the D-4 rate |
| D-6 | i_BCA − i_private = s_P − s_B; destination of interest (Table 1) | Steady state, same neutral rate |
| D-7 | −a(1−b)/(κσ) < φ_π < (2−a)(1+b)/(κσ) | Local, away from the zero bound |
| D-8 | Zero rate without quotas: inflation diverging or above target | Model of §6.1 |
| D-9 | Zero rate with quotas: permanent rationing Q̄ = σ(π* + rᴸₙ)/ψ | Model of §6.1 |
| D-10 | Loss ℓ: −ℓ/κ_cap of credit with private banks, 0 with the BCA | Capital constraint |
| D-11 | P/R = 1/(iᴹ + θ − g) | Long-run equilibrium |
| D-12 | Mortgage ≤ ℓ̄·Y ⇒ debt-financed price ≤ ℓ̄·Y + A for every rate | Debt-financed buyers |
| D-13 | Majority error 0.86% with n = 5, p = 10% | Independent errors |
| D-14 | iᴸ_k = (1 + i + c)/(1 − PD_k·LGD_k) − 1: no cross-subsidy between classes | Losses covered by class |
| D-15 | Credit to the State / GDP does not grow ⇔ d ≤ g/(1 + g)·b | State interest as a pass-through item |
| D-16 | i_D = max(0, min(π*, i − m)): net receipts ≥ min(i, m)·L, real return on deposits ≤ 0 at target, no arbitrage | Deposit rule |
| N-1 | Identity D = L − E_b over 200,000 operations | `simulazioni/bca_1_0_registro.py` |
| N-2 | Credit crisis: output loss 11.2 (P) against 4.0 (A) | `simulazioni/bca_1_0_macro.py`, illustrative parameters |
| N-3 | Zero rate without quotas: inflation from 2.0% to 10.6% in 11 years | `simulazioni/bca_1_0_macro.py` |

## 14. References

1. Fisher, I. (1936), *100% Money*, Adelphi.
2. Benes, J. and Kumhof, M. (2012), "The Chicago Plan Revisited", IMF Working Paper 12/202.
3. Diamond, D. W. and Dybvig, P. H. (1983), "Bank Runs, Deposit Insurance, and Liquidity", *Journal of Political Economy*, 91(3).
4. McLeay, M., Radia, A. and Thomas, R. (2014), "Money creation in the modern economy", *Bank of England Quarterly Bulletin*, 2014 Q1.
5. Kornai, J. (1986), "The Soft Budget Constraint", *Kyklos*, 39(1).
6. Taylor, J. B. (1993), "Discretion versus policy rules in practice", *Carnegie-Rochester Conference Series on Public Policy*, 39.
7. Bernanke, B., Gertler, M. and Gilchrist, S. (1999), "The Financial Accelerator in a Quantitative Business Cycle Framework", *Handbook of Macroeconomics*, vol. 1C.
8. Gordon, M. J. (1959), "Dividends, Earnings, and Stock Prices", *Review of Economics and Statistics*, 41(2).
9. Godley, W. and Lavoie, M. (2007), *Monetary Economics*, Palgrave Macmillan.
10. IASB (2014), *IFRS 9 Financial Instruments*, International Accounting Standards Board.

## 15. Provenance of the numerical results

The [N] results are reproduced by the scripts in the `simulazioni/` folder (Python with NumPy, fixed seeds):

- `bca_1_0_registro.py` — BCA ledger with loans, verification of D-1 and D-2 (N-1);
- `bca_1_0_macro.py` — model of §6.1 in regimes P, A, Z and Z0, crises compared, decomposition and zero rate (N-2, N-3). Before simulating it checks that without shocks every regime remains in the steady state.
- `bca_1_0_figure.py` — Figures 1 and 2, derived from the same simulations.

The numerical values of D-3, D-7, D-9 (eigenvalues), D-11–D-16 are direct calculations of the formulas with the parameters indicated.
