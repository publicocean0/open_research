# DPA — Adaptive Weighted Democracy

## Version 1.0 · 9 November 2026

**Scenario assumptions.** The DPA treats democratic decision-making as a **collective neural network**: people are the units, certified competences by issue are the weights, technical constraints produce an error signal that returns to the proposals, and the re-vote is the correction step. Public decisions are broken down into issues: objectives, technical constraints, strategies, universal rights. Every person has recognised competences, derived from education and work experience and certified by several independent AI systems, without human intervention. On each issue, those who exceed the competence threshold relevant to that issue vote, with a weight that grows with competence up to a cap; universal rights are voted by equal vote. The rules of admission, weight and minimum base are those of TEPS 1.5 [12]. Public registers record who is summoned and who votes, never the content of the vote.

**Scientific status.** Theoretical model with proven propositions and reproducible simulations on synthetic populations, with illustrative parameters. It is not calibrated on real institutions and is not an empirically validated theory.

| Tag | Meaning |
|---|---|
| [D] | Proposition derived from the definitions, with explicit assumptions |
| [N] | Numerical result reproduced by a script, not a forecast |
| [P] | Institutional design principle, not a theorem |
| [A] | Technical assumption introduced to close the model |

---

## Executive summary

| Question | Answer of the model | Where |
|---|---|---|
| What is the DPA? | A collective neural network for democratic decisions: people as units, competences by issue as weights, constraint error back-propagated to the proposals, re-vote as the update. To our knowledge it is probably the first proposal of its kind | §1.1, §1.2 |
| Who votes on an issue? | Those who exceed the competence threshold relevant to that issue; below the threshold one does not vote on that issue. Universal rights are voted by everyone, by equal vote | §3, §5 |
| Who certifies competences? | Several isolated AI agents, which assess education and experience; what counts is the median of the assessments minus their dispersion. The panel holds as long as fewer than half of the agents are deceived | §4, D-5, N-6 |
| Can the weight of the competent become domination? | No: the weight ranges from 1 to w_max = 3; the most competent 10% weighs at most 25%; with at least 101 voters no one exceeds 2.9% | D-2, D-3 |
| Is voting on constraints among the competent useful? | Yes: truly feasible plans rise from 61% to 96% if non-experts share a systematic error; otherwise the gain is about 3 points | N-1, N-3 |
| What if the experts lie? | The forecasting track record takes weight away from them: feasibility from 77% to 92%, weight of the corrupt from about 30% to 5% | N-4 |
| Does voting on objectives by competence harm the majority? | No if competences are spread across groups with different interests; yes if they are concentrated in a group that benefits from it. The second case is detected and corrected | N-5, §10 |
| How is the base widened? | According to what is measured: vertically if voters are lacking, horizontally (adjacent disciplines) if the effects of the decision are concentrated on those who voted for it | D-6, D-7, N-6 |
| When is voting by competence really worthwhile? | When the competent diverge because they know consequences that matter: then the real outcomes are better than with the equal vote, for the majority as well | N-7 |

The model is consistent under **seven explicit conditions** (C1–C7, §13). Operation with real people and institutions and superiority over the equal vote on real data are not proven.

**Verification outcome.** In the simulations the DPA keeps plans within the real limits much more often than everyone voting on everything, protects minority rights and resists the main forms of manipulation studied, provided that competences are certified independently and that the effects of decisions are measurable. How much it is worthwhile compared with the equal vote depends on two quantities to be measured in the field: the systematic error of non-experts and the severity of the consequences that only the competent see.

---

## 1. Objective and starting point

Democracies decide with the same vote questions of value ("how many dwellings do we want") and technical questions ("how much water can the network supply"). On the former every person is competent by definition; on the latter not. Condorcet's jury theorem [1, 2] shows that the majority decides well if voters are on average more accurate than chance and independent; when errors are shared the guarantee falls. The literature on epistemic democracy discusses whether competence should carry weight [3, 4, 5] and whether diversity is worth more than ability [6].

The DPA takes a position on this question with a precise rule: **each issue has its own electorate**, made up of those with recognised competences for that issue, with a limited weight; universal rights remain under equal vote. The rules of admission, weight and minimum base are those of TEPS 1.5 (§11, §12, §17.7–17.8) [12], applied here to a general decision-making order and verified with simulations.

### 1.1 A collective neural network for democratic decisions

The starting idea of the DPA, born under the name "neural democracy with deliberative back-propagation", is that **democratic decision-making can work as a neural network made of people**: citizens are the units of the network, certified competences are the weights of the connections, technical constraints produce an error signal that travels back to the proposals, and the network corrects itself by voting again. It is not a decorative metaphor: every element has a precise and verifiable rule.

| Neural network | DPA | Rule |
|---|---|---|
| Units (neurons) | Citizens | Each casts a vote on an issue |
| Connection weights | Voting weights by issue | Certified competence relevant to the issue, between 1 and w_max (§5) |
| Activation threshold | Competence threshold τ | Below the threshold the weight is zero: one does not vote on that issue |
| Saturation | Cap w_max | No weight exceeds w_max (D-2) |
| Specialised layers | Issue electorates | Each issue has its own electorate (§3) |
| Forward pass | Vote on objectives and constraints, construction of the plan | Weighted median (D-1), plan within the certified limits |
| Error function | Violation of constraints, distance from objectives | Measured by estimates (before) and monitoring (after) |
| Back-propagation | Deliberative back-propagation | The signal of the violated constraint indicates which parts of the proposal to correct (below) |
| Update | Alternatives and re-vote | People vote on the corrections; none applies itself |
| Weight learning | Certification and forecasting track record | Those who estimate well keep weight on questions of measurement (§9) |
| Growing architecture | Vertical and horizontal widening | More units when votes are lacking or when there is self-allocation (§10) |
| Fixed weights | Universal rights | Equal weight for all, not modifiable (§8) |

**Deliberative back-propagation [P].** Let x be the proposal (for example the levels of housing, water network and transport) and g(x) the vector of technical constraints, with gₖ(x) ≤ 0 when constraint k is satisfied. The experts of each domain estimate gₖ and its sensitivity to the parameters of the proposal, that is the interdisciplinary Jacobian J(x), with Jₖⱼ = ∂gₖ/∂xⱼ. The signal that returns to the proposal is:

    b(x) = J(x)ᵀ · max(0, g(x))

The component bⱼ says how much parameter j of the proposal contributes to the violations, weighting each constraint by how much it is violated. From b, alternatives are built that reduce the violations (for example x − α·b(x), then brought back within the estimated limits), and citizens vote on them. It is the same calculation as error back-propagation in neural networks [21], with one essential difference: **here the gradient changes nothing by itself**, it only produces correction proposals that go through the vote. If a series of local corrections gets stuck, the initial proposal is reopened and the whole package is re-voted (global rollback).

**What the DPA does not take from neural networks.** People's preferences are not "trained": no gradient modifies what people want. Learning concerns only the proposals (which improve at each cycle) and the weights on questions of measurement (which follow demonstrated reliability). The final decision always remains a vote.

### 1.2 Related work and originality

A literature search (November 2026) found works that touch on individual aspects of the DPA, but none that proposes democratic decision-making itself as a collective neural network in the sense of §1.1.

| Work | What it proposes | Difference from the DPA |
|---|---|---|
| Condorcet's jury theorem and epistemic democracy [1, 2, 3, 5] | The majority decides well if voters are competent and independent | Analysis of majority rule, without weights by issue or iterative correction |
| Epistocracy [4] | Giving more voting power to the more competent | Normative proposal; no algorithm, no guarantee for minorities and no cap |
| Futarchy [14] | "Vote on values, bet on beliefs": the vote sets the objectives, prediction markets choose the policies | Separates values and facts like the DPA, but entrusts facts to markets, not to electorates of the competent |
| Artificial swarm intelligence [15] | Groups of people connected in real time who converge like a swarm or a brain | Brain-inspired collective decision-making, but without certified competences, weights by issue, technical constraints or re-vote |
| Hilbert's "deep democratic neural network" [16] | AI summarises citizens' written opinions into a political platform | The network is an AI that aggregates; in the DPA the network is the people |
| Democratic AI [17] and the "Habermas Machine" [18] | AI designs redistribution mechanisms approved by the majority; AI mediates deliberation | AI assists or designs; there is no decision-making structure with learned weights and back-propagation |
| Collective learning in groups of neural networks [19] | Groups of artificial neural networks that decide by weighted average learn better than "despotic" ones | Study of artificial networks and animal behaviour, not an order for people |
| Weighted voter model [20] | Consensus rule for robot swarms | Robot control, not democratic decisions |

**Assessment.** As far as we know, the DPA is **probably the first proposal of a collective neural network for democratic decisions**: an algorithm in which people are the units of the network, certified competences by issue are the weights, technical constraints generate an error signal back-propagated to the proposals, the re-vote is the update step and the structure widens with automatic rules, while universal rights remain at equal weight. Priority cannot be proven: works that are not indexed or are in other languages may have partly anticipated it. The correct formulation is therefore "to our knowledge".

### 1.3 Development path

| Code versions | What was added or verified |
|---|---|
| V0–V1 | Concept and first prototype: deliberative back-propagation, alternatives, re-vote, global rollback |
| V2–V10 | Learning from consequences, weighted vote in all phases, negotiation, diagnosis, reliability, feedback over time, conditional mandates, robust planning, conditional sequences |
| V11–V16 | Portfolios of interventions, resilience to shocks, capacity reserves, value of information |
| V21 | Critical review and refinement: cap on weights, equal vote on rights, exact feasibility check, manipulation tests |
| V22–V23 | Vote by issue and TEPS premises: competences certified by AI, minimum base, dynamics and forecasting track record |
| V24–V27 | Everything by competence, widening according to what is measured, self-allocation test, knowledge or interest |

Each version has its own code, tests and results (§18). The errors found were corrected in new versions, without rewriting the previous ones.

**Necessary distinction.** The political vote provided for by the Italian Constitution is personal and equal (art. 48) [13]. The DPA concerns the thematic and technical decisions of an order that adopts them; replacing equal political suffrage with differentiated weights is not compatible with that principle in the current legal order.

## 2. Assumptions

### 2.1 Institutional assumptions

| Assumption | What it means | Why it is needed | If it does not hold |
|---|---|---|---|
| **A1 — Decisions decomposable into issues** [A] | Every decision is articulated into objectives, technical constraints, strategies, allocations and universal rights; each issue has a relevance map rₖ(q) towards the disciplines | Without distinct issues one cannot say who is competent on what: every vote would become a vote on everything | The DPA degenerates into a generic weighted vote, in which the weight hardly matters (verified in V21) |
| **A2 — Measurable competences** [A] | Education and work experience can be documented and are linked to the quality of estimates in the discipline | It is what gives meaning to the weight: the more competent estimate better | If certification does not measure real quality, the weight amplifies the noise; the forecasting track record (§9) limits the damage |
| **A3 — Independent AI agents** [A] | Certification is carried out by several agents with different architectures, data and operators, which do not communicate | The median holds only if fewer than half of the agents can be deceived together (D-5) | With agents with shared errors, certification is worth as much as a single agent (TEPS §12.2) |
| **A4 — Public registers** [A] | Register of participation (who is summoned, who votes), of residence or of recipients, of the allocations decided; separate and secret ballot box | Minimum base, abstention and the self-allocation test are computed only from these registers | Without registers self-allocation is not detected; without a secret ballot box the vote is not free |
| **A5 — Monitoring** [A] | After each period the real limits are measured, with error | It provides the error signal for the targeted re-vote and the track record | Without monitoring the DPA decides only once: feasibility from 87% (baseline) to 58% (after a shock) in V22 |
| **A6 — Single-peaked preferences** [A] | On a numerical question everyone has a preferred level and prefers closer values | It guarantees that the weighted median is the Condorcet winner (D-1) | With multi-peaked preferences a winner may not exist; votes between discrete alternatives are needed (used in V21) |
| **A7 — Linear constraints** [A] | In the verification model the technical limits are linear | It allows an exact check of whether a feasible plan exists | With non-linear constraints the check becomes approximate: "not found" does not imply "impossible" |

### 2.2 Assumptions of the verification model

The simulations use a deliberately simple synthetic world, to isolate the effects of the rules.

- **Decision.** Three levels to choose: housing h, water network w, transport t, each between 0 and 15. Four linear technical constraints Ax ≤ b (water, transport, budget, environment), with different coefficients in each world; the budget is always binding, so preferences are in conflict.
- **Population.** 600 people in three groups: majority (60%, mean preferred levels 9, 4, 4), minority (25%; 5, 3, 8), technicians (15%; 6, 5, 3). True competence by domain with a Beta(2,4) distribution for majority and minority and Beta(5,2) for technicians. In the variants: spread competences (same distribution, assigned at random), competent group at 40%, adjacent disciplines (urban planning, social policy) with competent people outside the technical group.
- **Preferences.** Utility −Σⱼ ωᵢⱼ (xⱼ − idealᵢⱼ)² with importances ωᵢⱼ between 0.5 and 1.5: quadratic preferences, hence single-peaked (A6).
- **Estimates of the limits.** Each person estimates a limit with an error that decreases with true competence: an error common to all (new at each period), an individual error and, for non-experts, a **common systematic error** (optimism, on average +0.8 × (1 − competence)). The sensitivities without systematic error are reported (§9).
- **Manipulations.** Corrupt experts (half of the technicians loosen their estimates by 1.5); a lobby (10% of the population) that deceives 2 or 3 AI agents out of 5 by inflating its own dossier; direct interest in the allocation between zones.
- **Time.** 10 periods (20 in V27); the real limits move with a random walk; in one scenario a limit drops by 1.2 at period 5; the plan changes by at most 2 units per period.
- **Hidden consequences (V27).** Housing beyond the safe level 5 consumes 0.30 of water capacity per unit and per period; the lost capacity harms everyone (0, 2 or 5 per unit lost).

## 3. Structure of decisions [P]

| Issue | Who votes | Weight | Outcome |
|---|---|---|---|
| Constraints (technical limits: water, transport, budget, environment) | those competent in the domain | competence in the domain, with cap | weighted median of the estimates, minus a margin |
| Objectives (desired levels) | those competent relevant to the issue | relevant competence, with cap | weighted median of the proposed levels |
| Allocations between recipients (zones, sectors) | as for objectives | as for objectives | weighted mean of the proposed allocations |
| Universal rights | everyone | equal | majority by head count |

**Logic.** A person can be competent on water and not on the budget: a single weight for all questions would mix different competences and, as shown in V21, would end up counting for almost nothing. Dividing the decision into issues makes it possible to give each question the electorate that knows it. Technical constraints are also a vote, among those who know that domain: estimating a limit is a question of knowledge, not of preference.

The plan of each period is the one closest to the voted objectives within the certified limits. No one votes with weight on their own case: whoever has a registered direct interest in an issue does not vote on that issue (TEPS §11.2 [12]).

## 4. Certified competences

Each person i has, for each discipline k, documented education Fᵢ,ₖ and experience Eᵢ,ₖ. Each of m isolated AI agents assesses the dossier; the recognised competence is prudential (TEPS §12.1 [12]):

    Cᵢ,ₖ⁽ᵃ⁾ = assessment by agent a,  a = 1, …, m
    Ĉᵢ,ₖ = medianₐ Cᵢ,ₖ⁽ᵃ⁾ ;   MADᵢ,ₖ = medianₐ |Cᵢ,ₖ⁽ᵃ⁾ − Ĉᵢ,ₖ|
    C*ᵢ,ₖ = max(0, Ĉᵢ,ₖ − λ · MADᵢ,ₖ)

The competence relevant to a question q is C\*ᵢ(q) = Σₖ rₖ(q) C\*ᵢ,ₖ, with rₖ(q) ≥ 0 and Σₖ rₖ(q) = 1.

### 4.1 D-5 Robustness of the agents' median [D]

If fewer than half of the m agents are manipulated, the median Ĉ remains between the minimum and the maximum assessment of the honest agents. If the majority is manipulated, the median can be shifted by any amount.

**Proof.** With h > m/2 honest agents, every value above the maximum honest assessment is exceeded by at least h values, that is by the majority; the median therefore cannot exceed it. The same holds downwards. With a manipulated majority the h' > m/2 manipulated values determine the central order. Q.E.D.

With m = 5 the manipulation of 2 agents does not shift competence beyond the honest judgements; that of 3 does. In the simulations a lobby that deceives 2 agents out of 5 weighs 4.7% in the vote on the budget, one that deceives 3 weighs 29% (N-6). The guarantee requires agents with independent errors and vulnerabilities (A3).

## 5. Admission, weight and minimum base

The voting function is that of TEPS 1.5 (§11.1) [12]:

    wᵢ(q) = 0                                         if C*ᵢ(q) < τ(q)
    wᵢ(q) = 1 + (w_max − 1) · [C*ᵢ(q) − τ(q)] / [1 − τ(q)]   otherwise

In the verification model τ₀ = 0.6 and w_max = 3. Explicit abstention does not enter the outcome (TEPS §11.3).

**Logic.** The threshold excludes those who on that issue would bring only noise; the increasing weight rewards competence; the cap prevents competence from becoming domination. Among those admitted every weight is at least 1, so no admitted voter counts less than a full vote. Like an activation function with saturation, the weight is zero below the threshold, grows linearly and stops at w_max.

### 5.1 D-2 Cap on the power of groups [D]

Among voters every weight lies between 1 and w_max. A fraction f of the voters holds at most:

    weight share ≤ f · w_max / [f · w_max + (1 − f)]

**Proof.** It is D-14 of TEPS 1.5 (§17.7) [12]: the share increases with the weight of the members and decreases with that of the others; the maximum is reached with the members at w_max and the others at 1. Q.E.D.

With w_max = 3 the most competent 10% weighs at most 25%; to have a majority a group must be at least 25% of the voters.

### 5.2 D-3 Minimum base of voters [D]

If the voters above the threshold are fewer than N_min, the threshold drops as much as needed (TEPS D-15, §17.8) [12]:

    τ*(q) = min(τ₀(q), C₍N_min₎(q))

If the votes cast remain below N_min, the next people in the ranking are summoned until N_min is reached. A person holds at most w_max / (w_max + N_min − 1) of the weight: with N_min = 101 and w_max = 3, 2.9%.

**Proof.** It follows from D-2 with one member at w_max and the other N_min − 1 at weight 1, as in TEPS. Q.E.D.

The base has no cap: everyone above the threshold votes. N_min is only a floor. A minimum base too high relative to the available competences lowers the threshold: with N_min = 201 the effective threshold drops to 0.38 and feasibility falls by 5 points (N-3).

## 6. Outcome of the vote

### 6.1 D-1 The weighted median is the Condorcet winner [D]

On a numerical question with single-peaked preferences (A6), let v₍ₘ₎ be the weighted median of the levels preferred by the voters. No other value beats it in a weighted majority comparison.

**Proof.** Let x > v₍ₘ₎. All voters with preferred level ≤ v₍ₘ₎ prefer v₍ₘ₎ to x, by the single-peaked form; by definition of the weighted median their weight is at least half of the total. The case x < v₍ₘ₎ is symmetric. Q.E.D.

It is Black's median voter theorem [7] with weights. It follows that voting on the level as a weighted median is equivalent to a series of weighted yes/no votes, as in the TEPS outcome formula (§11.1). For allocations between recipients the weighted mean of the proposed allocations is used, which is the TEPS outcome applied to each share.

## 7. Certified constraints and margin

The certified limit of a constraint is the weighted median of the estimates of the competent minus a margin m:

    b_cert = weighted median(b̂ᵢ) − m

**Logic.** The median resists those who exaggerate in one direction or the other (an expert who declares an enormous limit shifts the mean, not the median); the margin covers the error that all experts share, which no median can eliminate (D-8).

Before adopting a plan, it is checked exactly (linear programming) that at least one plan exists within the certified limits; "impossible according to the estimates" is distinguished from "solution not found by the computation" [P].

### 7.1 D-8 The margin must cover the common error [D]

Let b̂ᵢ = b + e_c + eᵢ, with e_c an error common to all estimators (mean μ_c, deviation σ_c) and eᵢ independent. For large N the median of the estimates converges to b + e_c + median(e), so the probability that the certified limit exceeds the real one tends to:

    P(b_cert > b) → 1 − Φ((m − μ_c − median(e)) / σ_c)

**Proof.** The sample median of the eᵢ converges to the median of their distribution; the common error remains, and it does not decrease by increasing the number of voters. Q.E.D.

Widening the base reduces only the independent error; the common error must be covered by the margin. The margin is therefore a choice between safety and welfare to be decided as an objective, not a neutral technical parameter.

| Margin | Truly feasible plans | Mean welfare |
|---|---:|---:|
| 0.15 | 61.5% | −23.26 |
| 0.50 | 89.5% | −25.27 |
| 0.80 | 98.0% | −27.14 |

*Table 1. N-1: effect of the certification margin (200 synthetic worlds, weighted vote with cap). Welfare is the distance between the plan and the desired levels: closer to zero is better.*

## 8. Universal rights

### 8.1 D-4 The equal vote on rights does not overturn the majority [D]

With the equal vote the outcome coincides with the majority by head count. With the weighted vote the outcome is overturned when the weighted share of those in favour and the head-count share lie on opposite sides of 1/2, that is when those in favour and those against have different mean weights.

**Proof.** With wᵢ = 1 the weighted share coincides with the head-count share. With arbitrary weights the weighted share is (W_F · n_F)/(W_F · n_F + W_C · n_C), with W_F, W_C the mean weights of those in favour and those against; it differs from n_F/(n_F + n_C) if and only if W_F ≠ W_C. Q.E.D.

N-2: with uncapped weights and a weighted vote on rights as well, the head-count decision is overturned in 57.5% of the worlds (69.5% with a lobby with inflated competences) and the minority loses 8.2 points of welfare; with the equal vote on rights the overturning is zero by construction.

## 9. Dynamics: monitoring, targeted re-vote, forecasting track record

- **Inertia** [P]: each variable of the plan changes by a limited amount per period.
- **Monitoring and targeted re-vote** [P]: after each period the real limit is measured; only the constraint whose limit has moved beyond a threshold is re-voted.
- **Logic of monitoring.** As in a network that receives an error after each example, the DPA compares the certified limits with the measured ones and corrects only where it is wrong. Re-voting only what monitoring flags reduces the number of votes without losing precision.
- **Forecasting track record** [P, variant]: those who estimated a limit badly lose weight in the questions of measurement of that domain. The recognised competence does not change; only the weight on measurement is reduced. It is the form compatible with the TEPS rule according to which there are no automatic penalties on competence (§11.2) [12].

| Regime | Baseline | Corrupt experts | Lobby deceiving 3 agents out of 5 | Shock | Ballots per period |
|---|---:|---:|---:|---:|---:|
| Everyone votes on everything | 60.7% | 46.3% | 61.1% | 58.9% | 4,260 |
| DPA, everything re-voted every period | 93.2% | 66.4% | 91.4% | 93.8% | 2,264 |
| DPA, monitoring and targeted re-vote | 96.3% | 76.8% | 94.6% | 95.0% | 394 |
| DPA + forecasting track record | 97.4% | 91.7% | 95.4% | 95.6% | 391 |

*Table 2. N-3 and N-4: share of periods in which the plan respects the real limits (200 worlds, 10 periods, objectives by equal vote as in the V23 configuration of the code).*

![](figure/figura_1_en.png)

*Figure 1. Periods with a truly feasible plan by scenario. The DPA votes on constraints among the competent with the TEPS rules; the forecasting track record takes weight away from those who estimate badly. Simulations on synthetic populations, not forecasts.*

**Reading.** The advantage of the vote among the competent on constraints is +35.6 points [95% CI: +31.5, +39.9] when non-experts share a systematic error (optimism); if they err only at random it is +2.7 points [+1.5, +4.0], because the average of many independent errors cancels out. After a shock the targeted re-vote reacts with a delay of one period.

## 10. Widening according to what is measured

The base is widened for two different reasons, with two different rules, both automatic and fixed in advance [P]:

| What is measured | Problem | Widening |
|---|---|---|
| Votes cast below N_min | base too small | vertical: one goes further down the same ranking (D-3) |
| Effects of the decision concentrated on those who voted for it | self-allocation | horizontal: those competent in adjacent disciplines enter, fixed in advance for each issue |

**Self-allocation index (SAI).** For an allocation a = (a₁, …, a_Z) between recipients (zones) with population shares s_z, the benefit of a person resident in z is a_z / s_z (1 = proportional share). The index is:

    SAI = mean benefit of those who voted − mean benefit of those who did not vote

Only the participation register, the residence register and the allocation decided are needed: neither the content of the votes nor people's preferences are needed.

**Activation rule.** The base is widened if (1) the composition of the electorate by recipient differs from that of the population more than 95% of randomly drawn electorates of the same size (permutation test) and (2) SAI > 0.

### 10.1 D-6 Level of the test [D]

If the electorate is a randomly drawn subset of the population, the rule is activated with probability not greater than the level α of the test (5%).

**Proof.** Under this assumption the observed electorate and the electorates drawn for comparison are exchangeable; the permutation p-value p = (1 + #{nulls ≥ observed})/(1 + B) satisfies P(p ≤ α) ≤ α. The rule also requires SAI > 0, so its probability is at most that of the test. Q.E.D.

N-5: with spread competences the rule is activated in 5–7% of cases. A first version, which compared the index with random electorates with a fixed allocation, was activated in 26–33%, because any electorate tends to favour its own recipients; it was replaced.

### 10.2 D-7 Limit of vertical widening [D]

If the first r places of the competence ranking are occupied by group G and the electorate contains the first k < r, every vertical widening of n ≤ r − k places adds only members of G and does not reduce their share.

**Proof.** Vertical widening adds places k + 1, …, k + n of the same ranking, all occupied by G by assumption; the share of G goes from g/k to (g + n)/(k + n) ≥ g/k because g ≤ k. Q.E.D.

For this reason, when the problem is interest and not numbers, the widening is horizontal.

**Logic.** The two measures answer different questions: "do we have enough votes?" and "are those who decide allocating the benefits to themselves?". The first problem requires more people from the same ranking; the second requires different people, competent in adjacent disciplines. Both rules are automatic and fixed in advance: no one chooses case by case whom to add, and the right to vote remains tied to clear and impartial criteria.

| World | Vertical − no control | Horizontal − no control | Horizontal − vertical |
|---|---|---|---|
| Competent group 15% | +2.18 [+2.07, +2.29] | +3.67 [+3.53, +3.79] | +1.49 [+1.39, +1.58] |
| Competent group 40% | +0.58 [+0.50, +0.66] | +2.57 [+2.46, +2.67] | +1.99 [+1.90, +2.07] |
| Spread competences | +0.02 [−0.04, +0.07] | −0.01 [−0.08, +0.06] | −0.02 [−0.09, +0.05] |

*Table 3. N-6: welfare of the majority, with the same number of people added in the two widenings (200 worlds; 95% bootstrap intervals).*

![](figure/figura_2_en.png)

*Figure 2. Vertical and horizontal widening with the same number of people added. With a large competent group vertical widening hardly helps, because the next people in the ranking still belong to the group (D-7). With spread competences no rule changes the outcome.*

## 11. Knowledge or interest

The competent group often wants different things from the base. It may do so because it knows more (knowledge) or because it gains from it (interest). To distinguish the two cases, the verification model introduces a consequence that only the competent know: building housing beyond a safe level consumes water capacity in the following periods, and the lost capacity harms everyone. Those competent in water or urban planning know this and ask for less housing. Plans are assessed on their **real consequences over 20 periods**, not on the initial wishes.

| Scarcity harm | Concentrated competences | Spread competences |
|---:|---|---|
| 0 | −0.19 [−0.24, −0.14] | −0.30 [−0.35, −0.24] |
| 2 | +0.08 [+0.00, +0.15] | +0.37 [+0.27, +0.46] |
| 5 | +0.48 [+0.32, +0.63] | +1.36 [+1.16, +1.57] |

*Table 4. N-7: realised welfare, vote by competence minus equal vote on objectives, when the competent differ only in knowledge (200 worlds; 95% bootstrap intervals).*

![](figure/figura_3_en.png)

*Figure 3. Realised welfare over 20 periods: vote by competence minus equal vote on objectives, as the harm caused by the consequences that only the competent know increases. Band: 95% bootstrap interval.*

**Reading.**

- If the consequences that the competent know really harm people, voting by competence gives better results than the equal vote, for the majority as well (+0.44 and +1.08 with harm 5). If they harm no one, their knowledge is of no use.
- The self-allocation control **is not activated** when there is only knowledge, and therefore does not block it.
- When there is also interest (competent people concentrated in a zone that they favour), the control is always activated and gives back about 3 points to the majority; with harm 5, "everything by competence + control" is the best configuration (+1.54 over the equal vote) and the majority does not lose out (+0.08, not significant).

## 12. Recommended configuration [P]

1. Competences certified by several independent AI agents (§4).
2. Each issue voted on by those who exceed the relevant competence threshold, with TEPS weight and cap w_max = 3 (§5).
3. Universal rights by equal vote (§8).
4. Certified constraints with a margin decided as an objective and an exact feasibility check (§7).
5. Monitoring and targeted re-vote; forecasting track record on questions of measurement (§9).
6. Minimum base with vertical widening; self-allocation control with horizontal widening (§10).

## 13. Does the model hold up? Assessment

The DPA is consistent under seven conditions:

- **C1 Certifiable competences**: education and experience that can be documented and are linked to the quality of estimates (A2).
- **C2 Independent AI agents**: fewer than half of the agents can be manipulated by the same party (D-5).
- **C3 Public registers**: participation, residence or recipients, allocations decided; secret ballot (A4).
- **C4 Margin as an objective**: the certification margin is decided explicitly, because it covers the common error that no base eliminates (D-8).
- **C5 Competences not concentrated in an interest group**, or self-allocation control active (N-5, N-6).
- **C6 Minimum base proportionate** to the available competences: wide enough to limit individual weight, not so wide as to lower the threshold beyond what is necessary (D-3, N-3).
- **C7 Relevant consequences**: the vote by competence on objectives is worthwhile when the competent see consequences that really cause harm; otherwise the equal vote is equivalent or better (N-7).

**General conclusion.** Under these conditions the DPA decides more reliably than everyone voting on everything on technical questions, does not allow the competent to dominate (cap, minimum base, equal vote on rights) and automatically corrects the cases in which a group allocates the benefits to itself. The behaviour of real people and institutions, resistance to coordinated manipulation and the social legitimacy of a weighted vote remain unproven.

## 14. Limits and verification programme

- **Real data.** The systematic error of non-experts and the severity of hidden consequences must be measured: how worthwhile the DPA is compared with the equal vote depends on them.
- **Strategic behaviour.** Coalitions, front men and coordinated manipulation of the AI agents are not modelled beyond the simple scenarios.
- **Indirect effects.** The self-allocation index measures direct allocations; indirect benefits (for example the value of houses near a public work) are not measured.
- **Mandates and reserves.** Conditional mandates and capacity reserves, studied in earlier versions of the code, are not yet integrated into the recommended configuration.
- **Adjacent disciplines.** The map of adjacent disciplines must be built and verified for each issue.

| Phase | Objective | Status in version 1.0 |
|---|---|---|
| V1 Voting rules | Admission, weight, minimum base, rights | Closed at the theoretical level (D-1–D-4) |
| V2 Certification | Robustness of the AI panel | Closed at the theoretical level (D-5); to be verified on real agents |
| V3 Constraints and margin | Real feasibility of plans | Simulations (N-1, N-3, N-4) |
| V4 Self-allocation | Detection and correction | Closed at the theoretical level (D-6, D-7); simulations (N-5, N-6) |
| V5 Knowledge and interest | When voting by competence is worthwhile | Simulations (N-7) |
| V6 Pilot case | Measurement of the error of non-experts and of the quality of experts' estimates | Open |
| V7 Strategic behaviour | Coalitions and coordinated manipulation | Open |

## 15. Parameters of the verification model

| Symbol | Value | Meaning | Where |
|---|---|---|---|
| τ₀ | 0.6 | Ordinary competence threshold for voting on an issue | §5 |
| w_max | 3 | Maximum weight of a voter (sensitivity: 2, 5, 10 in V21) | D-2 |
| N_min | 101 | Minimum base of votes cast (sensitivity: 25, 201) | D-3 |
| Participation | 80% | Probability that a summoned person votes instead of abstaining | §5 |
| m (agents) | 5 | AI agents that certify competences | D-5 |
| λ | 1 | Prudence of certification (median − λ·dispersion) | §4 |
| Margin | 0.5 | Certification margin of the limits (0.15, 0.5, 0.8 in V21) | D-8 |
| Systematic error of non-experts | mean 0.8, s.d. 0.4, × (1 − competence) | Common optimism in the estimates of the limits | §2.2 |
| Common model error | s.d. 0.2 per period | Error shared by all estimators | D-8 |
| Drift of the limits | s.d. 0.12 per period | Random walk of the real limits | §9 |
| Inertia | 2 | Maximum change of each level per period | §9 |
| Re-vote threshold | 0.35 | Measured deviation that triggers the re-vote of a constraint | §9 |
| Direct-interest threshold | share 0.40 to one's own zone | Preference for one's own zone in the allocation (scenarios with interest) | §10 |
| Self-allocation test | 500 permutations, α = 5% | Random comparison electorates and level of the test | D-6 |
| Worlds | 200 per scenario | Independent synthetic worlds; bootstrap intervals with 2,000 resamples [10] | all |

## 16. Register of results

| Code | Result | Scope |
|---|---|---|
| D-1 | The weighted median is the weighted Condorcet winner | Single-peaked preferences |
| D-2 | Share of a group ≤ f·w_max/[f·w_max + (1 − f)] | Weights between 1 and w_max (TEPS D-14) |
| D-3 | At least N_min voters; individual weight ≤ w_max/(w_max + N_min − 1) | Deterministic rule (TEPS D-15) |
| D-4 | Equal vote on rights: outcome = majority by head count; with weights, overturning if and only if the mean weights differ | Yes/no questions |
| D-5 | Median of the agents within the honest judgements if fewer than half are manipulated | m agents, order statistics |
| D-6 | Self-allocation rule active with probability ≤ α for random electorates | Permutation test |
| D-7 | Vertical widening does not reduce a group that occupies the top places | Competence ranking |
| D-8 | The margin must cover the common error; the base reduces only the independent error | Common + independent error |
| N-1 | Margin 0.15 / 0.50 / 0.80: feasible plans 61.5% / 89.5% / 98.0% | Table 1 |
| N-2 | Uncapped weights on rights as well: overturning in 57.5% of the worlds; equal vote: 0% | Universal rights |
| N-3 | Constraints among the competent: +35.6 points of feasibility (+2.7 without common error of non-experts); N_min 201: −4.8 | Table 2 |
| N-4 | Forecasting track record with corrupt experts: feasibility from 77% to 92% | Table 2 |
| N-5 | Objectives by competence: no difference with spread competences; −5.7 for the majority with concentrated competences; self-allocation rule active in 5–7% with spread competences | §10 |
| N-6 | Horizontal − vertical with the same number of people: +1.5 (group 15%), +2.0 (group 40%) | Table 3 |
| N-7 | Knowledge only: vote by competence − equal vote from −0.2 (harm 0) to +0.5/+1.4 (harm 5) | Table 4 |

## 17. References

1. Condorcet, N. de (1785), *Essai sur l'application de l'analyse à la probabilité des décisions rendues à la pluralité des voix*, Imprimerie Royale, Paris.
2. List, C. and Goodin, R. E. (2001), "Epistemic Democracy: Generalizing the Condorcet Jury Theorem", *Journal of Political Philosophy*, 9(3).
3. Estlund, D. (2008), *Democratic Authority: A Philosophical Framework*, Princeton University Press.
4. Brennan, J. (2016), *Against Democracy*, Princeton University Press.
5. Landemore, H. (2013), *Democratic Reason: Politics, Collective Intelligence, and the Rule of the Many*, Princeton University Press.
6. Hong, L. and Page, S. E. (2004), "Groups of diverse problem solvers can outperform groups of high-ability problem solvers", *Proceedings of the National Academy of Sciences*, 101(46).
7. Black, D. (1948), "On the Rationale of Group Decision-making", *Journal of Political Economy*, 56(1).
8. Galton, F. (1907), "Vox Populi", *Nature*, 75.
9. Arrow, K. J. (1951), *Social Choice and Individual Values*, Wiley.
10. Efron, B. and Tibshirani, R. J. (1993), *An Introduction to the Bootstrap*, Chapman & Hall.
11. Good, P. (2005), *Permutation, Parametric, and Bootstrap Tests of Hypotheses*, 3rd ed., Springer.
12. Lorenzetto, C. (2026), *TEPS — Theory of Post-Wage Economic Equilibrium*, version 1.5 (30 October 2026, updated 2 November 2026): §11 Competence and universal weighted democracy, §11.3 Participation rule, §12 A panel of isolated AIs and independence of judgements, §17.7 D-14, §17.8 D-15.
13. Constitution of the Italian Republic, art. 48.
14. Hanson, R. (2013), "Shall We Vote on Values, But Bet on Beliefs?", *Journal of Political Philosophy*, 21(2).
15. Rosenberg, L. (2016), "Artificial Swarm Intelligence, a Human-in-the-Loop Approach to A.I.", *Proceedings of the AAAI Conference on Artificial Intelligence*, 30.
16. Hilbert, M. (2009), "The Maturing Concept of E-Democracy: From E-Voting and Online Consultations to Democratic Value Out of Jumbled Online Chatter", *Journal of Information Technology & Politics*, 6(2).
17. Koster, R. et al. (2022), "Human-centred mechanism design with Democratic AI", *Nature Human Behaviour*, 6.
18. Tessler, M. H. et al. (2024), "AI can help humans find common ground in democratic deliberation", *Science*, 386(6719).
19. Morford, J., Lewin, P., Biro, D., Guilford, T., Padget, O. and Collet, J. (2022), "Neural networks reveal emergent properties of collective learning in democratic but not despotic groups", *Animal Behaviour*, 194.
20. Valentini, G., Hamann, H. and Dorigo, M. (2014), "Self-organized collective decision making: the weighted voter model", *Proceedings of AAMAS 2014*.
21. Rumelhart, D. E., Hinton, G. E. and Williams, R. J. (1986), "Learning representations by back-propagating errors", *Nature*, 323.

## 18. Provenance of the numerical results

The [N] results are reproduced by the code in the `democrazia-ponderata-adattiva/` folder of the repository (Python with NumPy and SciPy, fixed seeds), which contains for each version code, automated tests, results per world and a README with limits and negative outcomes:

- `v21_dpa_raffinata/` — cap on weights, equal vote on rights, margin (N-1, N-2);
- `v22_dpa_dinamica_tematica/` — dynamics, monitoring, forecasting track record;
- `v23_dpa_premesse_teps/` — competences certified by AI agents, TEPS rules, minimum base (N-3, N-4; numerical D-5);
- `v24_dpa_tutto_per_competenza/` — objectives by competence, concentrated and spread competences (N-5);
- `v25_dpa_allargamento_misurato/` and `v26_dpa_test_corretto/` — self-allocation index and test, vertical and horizontal widening (N-5, N-6);
- `v27_dpa_conoscenza_interesse/` — knowledge or interest, real consequences over 20 periods (N-7).

The figures are produced by `dpa/simulazioni/dpa_1_0_figure.py` from the saved results.
