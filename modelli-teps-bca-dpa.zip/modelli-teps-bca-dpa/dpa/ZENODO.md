# Scheda Zenodo — DPA 1.0

**Titolo**
DPA — Democrazia Ponderata Adattiva (versione 1.0)

**Autore:** Lorenzetto, Cristian (ORCID 0009-0001-4925-4728)
**Tipo di risorsa:** Pubblicazione → Working paper (oppure Preprint)
**Lingua:** italiano
**Versione:** 1.0
**Data di pubblicazione:** 2026-11-09
**File:** `pdf/DPA_1_0_IT.pdf` (documento principale), `word/DPA_1_0_IT.docx`; codice delle simulazioni nella cartella `democrazia-ponderata-adattiva/` del repository (versioni V21–V27)
**Versione inglese:** `pdf/DPA_1_0_EN.pdf` (stesso contenuto; si può caricare nello stesso record o in un record collegato)
**Licenza suggerita:** Creative Commons Attribution 4.0 International (CC BY 4.0) per il documento; MIT per il codice
**Opere collegate:** TEPS 1.5 (regole di ammissione, peso e base minima: §11, §12, §17.7–17.8)

## Descrizione (italiano)

La DPA tratta la decisione democratica come una rete neurale collettiva: le persone sono le unità, le competenze certificate per tema sono i pesi delle connessioni, i vincoli tecnici producono un segnale di errore che viene retropropagato alle proposte (retropropagazione deliberativa) e il rivoto è il passo di aggiornamento. A nostra conoscenza, dopo una ricerca bibliografica, è probabilmente la prima proposta di questo tipo. Ogni tema è votato da chi ha competenze riconosciute per quel tema. Le competenze derivano da formazione ed esperienza lavorativa e sono certificate da più agenti di intelligenza artificiale indipendenti; vale la mediana delle loro valutazioni meno la dispersione. Su ogni questione vota chi supera la soglia di competenza rilevante, con un peso che cresce fino a un tetto; la base ha un numero minimo di votanti; i diritti universali si votano a voto eguale. Le regole di ammissione, peso e base minima riprendono quelle della TEPS 1.5.

La base si allarga in base a ciò che si misura: in verticale quando mancano votanti, in orizzontale (competenti delle discipline vicine) quando gli effetti della decisione si concentrano su chi l'ha votata. Questa autoattribuzione si rileva con registri pubblici di partecipazione e di residenza e con un test di permutazione, senza conoscere il contenuto dei voti né le preferenze. Il modello include dinamica nel tempo, monitoraggio dei limiti reali, rivoto mirato e uno storico delle previsioni.

Il documento presenta otto proposizioni dimostrate (fra cui: la mediana pesata è il vincitore di Condorcet; tetto al potere dei gruppi; base minima; robustezza della mediana degli agenti; livello del test di autoattribuzione; limite dell'allargamento verticale; margine contro l'errore comune) e sette risultati numerici su popolazioni sintetiche. Votare i vincoli fra competenti porta i piani davvero fattibili dal 61% al 96% se i non esperti condividono un errore sistematico; quando i competenti si discostano dalla base per conoscenza di conseguenze che danneggiano davvero, votare per competenza dà risultati reali migliori del voto eguale anche per la maggioranza. Il modello è coerente sotto sette condizioni esplicite (C1–C7). Non è calibrato su istituzioni reali e non è una teoria validata empiricamente.

## Description (English)

DPA (Adaptive Weighted Democracy) treats democratic decision-making as a collective neural network: people are the units, competences certified per issue are the connection weights, technical constraints generate an error signal that is back-propagated to proposals (deliberative back-propagation), and re-voting is the update step. To our knowledge, after a literature search, it is probably the first proposal of this kind. Each issue is voted on by those with recognised competence in that issue. Competences derive from education and work experience and are certified by several independent AI agents (median assessment minus dispersion). On each question, those above the relevant competence threshold vote, with a weight that grows up to a cap; the voting base has a minimum size; universal rights are decided by equal vote. Admission, weighting and minimum-base rules follow TEPS 1.5.

The base widens according to what is measured: vertically when voters are too few, horizontally (to competent people in adjacent disciplines) when the effects of a decision concentrate on those who voted for it. Self-allocation is detected from public participation and residence registers with a permutation test, without access to ballot contents or preferences. The model includes dynamics over time, monitoring of real limits, targeted re-votes and a forecasting track record. The paper presents eight proved propositions and seven numerical results on synthetic populations, under seven explicit conditions. It is not calibrated on real institutions and is not an empirically validated theory.

## Parole chiave / Keywords

rete neurale collettiva; retropropagazione deliberativa; democrazia ponderata; democrazia epistemica; voto per competenza; competenze certificate; intelligenza artificiale; teorema di Condorcet; elettore mediano; autoattribuzione; allargamento della base di voto; diritti universali; collective neural network; deliberative back-propagation; weighted democracy; epistemic democracy; competence-weighted voting; AI certification; median voter; self-allocation test; universal rights
