# DPA — Democrazia Ponderata Adattiva

Modello decisionale che tratta la decisione democratica come una **rete neurale collettiva**: le persone sono le unità, le competenze certificate per tema sono i pesi, l'errore dei vincoli tecnici è retropropagato alle proposte e il rivoto è il passo di aggiornamento (a nostra conoscenza, probabilmente la prima proposta di questo tipo; §1.1–1.2 del documento). Ogni tema (vincoli tecnici, obiettivi, ripartizioni) è votato da chi ha competenze riconosciute per quel tema, certificate da più agenti di IA indipendenti, con un peso limitato (tetto `w_max = 3`) e una base minima di votanti; i diritti universali si votano a voto eguale. Le regole di ammissione, peso e base minima riprendono quelle della [TEPS 1.5](../teps/README.md) (§11, §12, §17.7–17.8). La base si allarga in verticale quando mancano votanti e in orizzontale (discipline vicine) quando gli effetti di una decisione si concentrano su chi l'ha votata.

## Struttura della cartella

| Cartella / file | Contenuto |
|---|---|
| [`pdf/`](pdf/) | **Documenti finali**: [DPA_1_0_IT.pdf](pdf/DPA_1_0_IT.pdf) (paper a colori, italiano, 17 pagine), [DPA_1_0_EN.pdf](pdf/DPA_1_0_EN.pdf) (colour paper, English, 17 pages) |
| [`word/`](word/) | Gli stessi documenti in Word: [DPA_1_0_IT.docx](word/DPA_1_0_IT.docx), [DPA_1_0_EN.docx](word/DPA_1_0_EN.docx) |
| [`DPA_1_0_Modello_Democratico.md`](DPA_1_0_Modello_Democratico.md) | Testo sorgente: ipotesi, regole, dimostrazioni D-1–D-8, risultati N-1–N-7, condizioni C1–C7, limiti |
| [`DPA_1_0_Democratic_Model_EN.md`](DPA_1_0_Democratic_Model_EN.md) | English source text |
| [`figure/`](figure/) | Figure 1–3 (fattibilità reale per regime, allargamento verticale e orizzontale, conoscenza o interesse), in italiano e in inglese (`*_en.png`) |
| [`simulazioni/`](simulazioni/) | Script delle figure; il codice delle simulazioni è in [`../democrazia-ponderata-adattiva/`](../democrazia-ponderata-adattiva/README.md) (versioni V21–V27) |
| [`ZENODO.md`](ZENODO.md) | Titolo, descrizione e parole chiave per Zenodo |

I documenti si rigenerano con `bash strumenti/genera_documenti.sh` dalla radice del repository. Le figure si rigenerano dalla cartella `dpa/` con `python3 simulazioni/dpa_1_0_figure.py`.

## Risultati principali

- **Vincoli votati fra competenti**: piani davvero fattibili dal 61% al 96% se i non esperti condividono un errore sistematico; +3 punti se sbagliano solo a caso (N-3).
- **Nessun dominio dei competenti**: il 10% più competente pesa al massimo il 25%; con almeno 101 votanti nessuno supera il 2,9% (D-2, D-3). Diritti universali a voto eguale: nessun ribaltamento della maggioranza per teste (D-4).
- **Certificazione robusta**: la mediana di 5 agenti IA resiste finché meno di metà è ingannata (D-5).
- **Storico delle previsioni**: con esperti corrotti la fattibilità sale dal 77% al 92% (N-4).
- **Autoattribuzione**: rilevata con registri pubblici e test di permutazione (falsi allarmi al livello dichiarato, D-6); l'allargamento orizzontale supera il verticale, soprattutto con un gruppo in conflitto grande (+2,0 punti di benessere per la maggioranza, N-6).
- **Conoscenza o interesse**: quando i competenti si discostano per conoscenza di conseguenze che danneggiano davvero, votare per competenza dà risultati reali migliori del voto eguale, anche per la maggioranza (N-7).

Popolazioni sintetiche e parametri dimostrativi: nessuna calibrazione su istituzioni reali.
