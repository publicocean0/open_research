# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Figure del documento DPA 1.0, ricavate dai risultati delle simulazioni.

Si lancia dalla cartella dpa/:  python3 simulazioni/dpa_1_0_figure.py
Legge i CSV in ../democrazia-ponderata-adattiva/ (V23, V26, V27).
Scrive figure/figura_N.png (italiano) e figure/figura_N_en.png (inglese).
"""
import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib import font_manager  # noqa: E402

QUI = os.path.dirname(os.path.abspath(__file__))
RADICE = os.path.abspath(os.path.join(QUI, "..", ".."))
SIM = os.path.join(RADICE, "democrazia-ponderata-adattiva")
OUTDIR = os.path.join(QUI, "..", "figure")
os.makedirs(OUTDIR, exist_ok=True)

if any("Inter" in f.name for f in font_manager.fontManager.ttflist):
    plt.rcParams["font.family"] = "Inter"
plt.rcParams.update({"font.size": 8, "axes.linewidth": 0.8})
# tavolozza categoriale in ordine fisso (validata per la visione dei colori)
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#E3E3E3"


def leggi(percorso):
    with open(percorso, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def stile(ax, yl):
    ax.grid(True, axis="y", color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_ylabel(yl, color=INK2)
    ax.tick_params(colors=INK2, length=0)


LINGUA = {"it": "", "en": "_en"}
LINGUA_CORRENTE = "it"


def T(it, en):
    return en if LINGUA_CORRENTE == "en" else it


def genera(lingua):
    global LINGUA_CORRENTE
    LINGUA_CORRENTE = lingua
    suf = LINGUA[lingua]
    # Figura 1 — fattibilita' reale per regime e scenario (V23)
    r23 = leggi(os.path.join(SIM, "v23_dpa_premesse_teps", "risultati", "riepilogo.csv"))
    scen = [("base", T("Base", "Baseline")), ("esperti_corrotti", T("Esperti corrotti", "Corrupt experts")),
            ("credenziali_gonfiate_3su5", T("Lobby che inganna\n3 agenti IA su 5", "Lobby deceiving\n3 of 5 AI agents")), ("shock", "Shock")]
    reg = [("uguale_tutti", T("Tutti votano su tutto", "Everyone votes on everything")), ("dpa_teps", T("DPA (regole TEPS)", "DPA (TEPS rules)")),
           ("dpa_teps_storico", T("DPA + storico delle previsioni", "DPA + forecasting track record"))]
    fig, ax = plt.subplots(figsize=(6.17, 2.6), dpi=231)
    x = np.arange(len(scen))
    w = 0.26
    for i, (rk, nome) in enumerate(reg):
        v = [100 * float(next(r for r in r23 if r["scenario"] == s and r["regime"] == rk)["fattibile"]) for s, _ in scen]
        ax.bar(x + (i - 1) * w, v, w * 0.92, color=C[i], label=nome)
    ax.set_xticks(x, [n for _, n in scen])
    ax.set_ylim(0, 100)
    stile(ax, T("Periodi con piano\ndavvero fattibile (%)", "Periods with a truly\nfeasible plan (%)"))
    ax.legend(fontsize=6.5, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, frameon=False)
    fig.tight_layout(pad=0.6)
    fig.savefig(os.path.join(OUTDIR, "figura_1%s.png" % suf), dpi=231)
    plt.close(fig)

    # Figura 2 — allargamento verticale e orizzontale a parita' di persone aggiunte (V26)
    c26 = leggi(os.path.join(SIM, "v26_dpa_test_corretto", "risultati", "confronti_accoppiati.csv"))
    mondi = [("concentrate", T("Gruppo competente 15%", "Competent group 15%")), ("concentrate_grande", T("Gruppo competente 40%", "Competent group 40%")),
             ("diffuse", T("Competenze diffuse", "Spread competences"))]
    serie = [("allarga_verticale - dpa_v24", T("Allargamento verticale", "Vertical widening")),
             ("allarga_misurato - dpa_v24", T("Allargamento orizzontale", "Horizontal widening"))]
    fig, ax = plt.subplots(figsize=(6.17, 2.5), dpi=231)
    x = np.arange(len(mondi))
    w = 0.34
    for i, (conf, nome) in enumerate(serie):
        righe = [next(r for r in c26 if r["competenze"] == m and r["scenario"] == "base" and r["confronto"] == conf
                      and r["metrica"] == "benessere_maggioranza") for m, _ in mondi]
        mu = np.array([float(r["differenza"]) for r in righe])
        lo = mu - np.array([float(r["ic95_basso"]) for r in righe])
        hi = np.array([float(r["ic95_alto"]) for r in righe]) - mu
        ax.bar(x + (i - 0.5) * w, mu, w * 0.92, color=C[i], label=nome)
        ax.errorbar(x + (i - 0.5) * w, mu, yerr=[lo, hi], fmt="none", ecolor=INK, lw=0.8, capsize=2)
    ax.axhline(0, color="#999999", lw=0.6)
    ax.set_xticks(x, [n for _, n in mondi])
    stile(ax, T("Benessere della maggioranza\nrispetto a nessun controllo", "Majority welfare\nvs no control"))
    ax.legend(fontsize=6.5, loc="upper right", frameon=True, framealpha=0.95, edgecolor="#CCCCCC")
    fig.tight_layout(pad=0.6)
    fig.savefig(os.path.join(OUTDIR, "figura_2%s.png" % suf), dpi=231)
    plt.close(fig)

    # Figura 3 — conoscenza: voto per competenza meno voto eguale sugli obiettivi (V27)
    fig, ax = plt.subplots(figsize=(6.17, 2.5), dpi=231)
    danni = [0, 2, 5]
    for i, (dist, nome) in enumerate([("concentrate", T("Competenze concentrate", "Concentrated competences")), ("diffuse", T("Competenze diffuse", "Spread competences"))]):
        mu, lo, hi = [], [], []
        for d in danni:
            c27 = leggi(os.path.join(SIM, "v27_dpa_conoscenza_interesse", "risultati", "scarsita_%d" % d,
                                     "confronti_accoppiati.csv"))
            r = next(r for r in c27 if r["competenze"] == dist and r["scenario"] == "solo_conoscenza"
                     and r["confronto"] == "dpa_v24_tutto_competenza - dpa_v23_obiettivi_eguali"
                     and r["metrica"] == "benessere_realizzato")
            mu.append(float(r["differenza"])); lo.append(float(r["ic95_basso"])); hi.append(float(r["ic95_alto"]))
        ax.fill_between(danni, lo, hi, color=C[i], alpha=0.18, lw=0)
        ax.plot(danni, mu, color=C[i], lw=2, marker="o", ms=4, label=nome)
    ax.axhline(0, color="#999999", lw=0.6)
    ax.set_xticks(danni)
    ax.set_xlabel(T("Danno da scarsità per unità di capacità idrica persa", "Scarcity harm per unit of water capacity lost"), color=INK2)
    stile(ax, T("Benessere realizzato:\ncompetenza − voto eguale", "Realised welfare:\ncompetence − equal vote"))
    ax.legend(fontsize=6.5, loc="upper left", frameon=True, framealpha=0.95, edgecolor="#CCCCCC")
    fig.tight_layout(pad=0.6)
    fig.savefig(os.path.join(OUTDIR, "figura_3%s.png" % suf), dpi=231)
    plt.close(fig)


for lg in LINGUA:
    genera(lg)
print("Figure scritte in", os.path.abspath(OUTDIR))
