# DPA — Democrazia Ponderata Adattiva

## Versione 1.0 · 9 novembre 2026

**Ipotesi di scenario.** La DPA tratta la decisione democratica come una **rete neurale collettiva**: le persone sono le unità, le competenze certificate per tema sono i pesi, i vincoli tecnici producono un segnale di errore che torna alle proposte, il rivoto è il passo di correzione. Le decisioni pubbliche sono scomposte in temi: obiettivi, vincoli tecnici, strategie, diritti universali. Ogni persona ha competenze riconosciute, derivate dalla formazione e dall'esperienza lavorativa e certificate da più sistemi di IA indipendenti, senza intervento umano. Su ogni tema vota chi supera la soglia di competenza rilevante per quel tema, con un peso che cresce con la competenza fino a un tetto; i diritti universali si votano a voto eguale. Le regole di ammissione, peso e base minima sono quelle della TEPS 1.5 [12]. Registri pubblici tengono traccia di chi è convocato e di chi vota, mai del contenuto del voto.

**Stato scientifico.** Modello teorico con proposizioni dimostrate e simulazioni riproducibili su popolazioni sintetiche, con parametri dimostrativi. Non è calibrato su istituzioni reali e non è una teoria validata empiricamente.

| Sigla | Significato |
|---|---|
| [D] | Proposizione derivata dalle definizioni, con ipotesi esplicitate |
| [N] | Risultato numerico riprodotto da uno script, non previsione |
| [P] | Principio istituzionale di progetto, non teorema |
| [A] | Assunzione tecnica introdotta per chiudere il modello |

---

## Sintesi esecutiva

| Domanda | Risposta del modello | Dove |
|---|---|---|
| Che cos'è la DPA? | Una rete neurale collettiva per le decisioni democratiche: persone come unità, competenze per tema come pesi, errore dei vincoli retropropagato alle proposte, rivoto come aggiornamento. A nostra conoscenza è probabilmente la prima proposta di questo tipo | §1.1, §1.2 |
| Chi vota su un tema? | Chi supera la soglia di competenza rilevante per quel tema; sotto soglia non si vota quel tema. I diritti universali li votano tutti, a voto eguale | §3, §5 |
| Chi certifica le competenze? | Più agenti IA isolati, che valutano formazione ed esperienza; vale la mediana delle valutazioni meno la loro dispersione. Il consesso resiste finché meno di metà degli agenti è ingannata | §4, D-5, N-6 |
| Il peso dei competenti può diventare dominio? | No: il peso va da 1 a w_max = 3; il 10% più competente pesa al massimo il 25%; con almeno 101 votanti nessuno supera il 2,9% | D-2, D-3 |
| Votare i vincoli fra competenti serve? | Sì: i piani davvero fattibili passano dal 61% al 96% se chi non è esperto condivide un errore sistematico; altrimenti il guadagno è di circa 3 punti | N-1, N-3 |
| E se gli esperti mentono? | Lo storico delle previsioni toglie loro peso: fattibilità dal 77% al 92%, peso dei corrotti da circa il 30% al 5% | N-4 |
| Votare gli obiettivi per competenza danneggia la maggioranza? | No se le competenze sono diffuse fra gruppi con interessi diversi; sì se sono concentrate in un gruppo che ne trae vantaggio. Il secondo caso si rileva e si corregge | N-5, §10 |
| Come si allarga la base? | In base a ciò che si misura: verticale se mancano votanti, orizzontale (discipline vicine) se gli effetti della decisione si concentrano su chi l'ha votata | D-6, D-7, N-6 |
| Quando conviene davvero votare per competenza? | Quando i competenti si discostano per conoscenza di conseguenze che contano: allora i risultati reali sono migliori del voto eguale, anche per la maggioranza | N-7 |

Il modello risulta coerente sotto **sette condizioni esplicite** (C1–C7, §13). Non sono dimostrati il funzionamento con persone e istituzioni reali né la superiorità rispetto al voto eguale su dati reali.

**Esito della verifica.** Nelle simulazioni la DPA tiene i piani entro i limiti reali molto più spesso del voto di tutti su tutto, protegge i diritti delle minoranze e resiste alle principali forme di manipolazione studiate, a condizione che le competenze siano certificate in modo indipendente e che gli effetti delle decisioni siano misurabili. Quanto convenga rispetto al voto eguale dipende da due grandezze da misurare sul campo: l'errore sistematico dei non esperti e la gravità delle conseguenze che solo i competenti vedono.

---

## 1. Obiettivo e punto di partenza

Le democrazie decidono con lo stesso voto questioni di valore («quante abitazioni vogliamo») e questioni tecniche («quanta acqua può fornire la rete»). Sulle prime ogni persona è competente per definizione; sulle seconde no. Il teorema della giuria di Condorcet [1, 2] mostra che la maggioranza decide bene se gli elettori sono in media più accurati del caso e indipendenti; quando gli errori sono comuni la garanzia cade. La letteratura sulla democrazia epistemica discute se la competenza debba pesare [3, 4, 5] e se la diversità valga più dell'abilità [6].

La DPA prende posizione su questa domanda con una regola precisa: **ogni tema ha il proprio elettorato**, formato da chi ha competenze riconosciute per quel tema, con un peso limitato; i diritti universali restano a voto eguale. Le regole di ammissione, peso e base minima sono quelle della TEPS 1.5 (§11, §12, §17.7–17.8) [12], qui applicate a un ordinamento decisionale generale e verificate con simulazioni.

### 1.1 Una rete neurale collettiva per le decisioni democratiche

L'idea di partenza della DPA, nata con il nome di «democrazia neurale con retropropagazione deliberativa», è che **la decisione democratica possa funzionare come una rete neurale fatta di persone**: i cittadini sono le unità della rete, le competenze certificate sono i pesi delle connessioni, i vincoli tecnici producono un segnale di errore che torna indietro fino alle proposte, e la rete si corregge votando di nuovo. Non è una metafora decorativa: ogni elemento ha una regola precisa e verificabile.

| Rete neurale | DPA | Regola |
|---|---|---|
| Unità (neuroni) | Cittadini | Ognuno esprime un voto su un tema |
| Pesi delle connessioni | Pesi di voto per tema | Competenza certificata rilevante per il tema, fra 1 e w_max (§5) |
| Soglia di attivazione | Soglia di competenza τ | Sotto soglia il peso è zero: non si vota quel tema |
| Saturazione | Tetto w_max | Nessun peso supera w_max (D-2) |
| Strati specializzati | Elettorati tematici | Ogni tema ha il proprio elettorato (§3) |
| Passo in avanti | Voto su obiettivi e vincoli, costruzione del piano | Mediana pesata (D-1), piano entro i limiti certificati |
| Funzione di errore | Violazione dei vincoli, distanza dagli obiettivi | Misurata da stime (prima) e monitoraggio (dopo) |
| Retropropagazione | Retropropagazione deliberativa | Il segnale del vincolo violato indica quali parti della proposta correggere (sotto) |
| Aggiornamento | Alternative e rivoto | Le persone votano le correzioni; nessuna si applica da sola |
| Apprendimento dei pesi | Certificazione e storico delle previsioni | Chi stima bene mantiene peso sulle questioni di misura (§9) |
| Architettura che cresce | Allargamento verticale e orizzontale | Più unità quando mancano voti o quando c'è autoattribuzione (§10) |
| Pesi fissi | Diritti universali | Peso eguale per tutti, non modificabile (§8) |

**Retropropagazione deliberativa [P].** Sia x la proposta (per esempio i livelli di abitazioni, rete idrica e trasporti) e g(x) il vettore dei vincoli tecnici, con gₖ(x) ≤ 0 quando il vincolo k è rispettato. Gli esperti di ciascun dominio stimano gₖ e la sua sensibilità ai parametri della proposta, cioè lo jacobiano interdisciplinare J(x), con Jₖⱼ = ∂gₖ/∂xⱼ. Il segnale che torna alla proposta è:

    b(x) = J(x)ᵀ · max(0, g(x))

La componente bⱼ dice quanto il parametro j della proposta contribuisce alle violazioni, pesando ogni vincolo per quanto è violato. Da b si costruiscono alternative che riducono le violazioni (per esempio x − α·b(x), poi riportate entro i limiti stimati), e i cittadini le votano. È lo stesso calcolo della retropropagazione dell'errore nelle reti neurali [21], con una differenza essenziale: **qui il gradiente non cambia nulla da solo**, produce solo proposte di correzione che passano per il voto. Se una serie di correzioni locali si blocca, la proposta iniziale viene riaperta e si rivota l'intero pacchetto (rollback globale).

**Cosa la DPA non prende dalle reti neurali.** Le preferenze delle persone non vengono «addestrate»: nessun gradiente modifica ciò che le persone vogliono. L'apprendimento riguarda solo le proposte (che migliorano a ogni ciclo) e i pesi sulle questioni di misura (che seguono l'affidabilità dimostrata). La decisione finale resta sempre un voto.

### 1.2 Lavori vicini e originalità

Una ricerca bibliografica (novembre 2026) ha trovato lavori che toccano singoli aspetti della DPA, ma nessuno che proponga la decisione democratica stessa come una rete neurale collettiva nel senso del §1.1.

| Lavoro | Che cosa propone | Differenza dalla DPA |
|---|---|---|
| Teorema della giuria di Condorcet e democrazia epistemica [1, 2, 3, 5] | La maggioranza decide bene se gli elettori sono competenti e indipendenti | Analisi della regola di maggioranza, senza pesi per tema né correzione iterativa |
| Epistocrazia [4] | Dare più potere di voto a chi è più competente | Proposta normativa; nessun algoritmo, nessuna garanzia per le minoranze né tetto |
| Futarchia [14] | «Votare i valori, scommettere sulle convinzioni»: il voto fissa gli obiettivi, i mercati di previsione scelgono le politiche | Separa valori e fatti come la DPA, ma affida i fatti ai mercati, non a elettorati di competenti |
| Intelligenza artificiale a sciame [15] | Gruppi di persone collegate in tempo reale che convergono come uno sciame o un cervello | Decisione collettiva ispirata al cervello, ma senza competenze certificate, pesi per tema, vincoli tecnici né rivoto |
| «Rete neurale democratica profonda» di Hilbert [16] | L'IA riassume le opinioni scritte dei cittadini in una piattaforma politica | La rete è un'IA che aggrega; nella DPA la rete sono le persone |
| IA democratica [17] e «Habermas Machine» [18] | L'IA progetta meccanismi di ridistribuzione approvati dalla maggioranza; l'IA media la deliberazione | L'IA assiste o progetta; non c'è una struttura decisionale con pesi appresi e retropropagazione |
| Apprendimento collettivo in gruppi di reti neurali [19] | Gruppi di reti neurali artificiali che decidono con media pesata imparano meglio di quelli «dispotici» | Studio su reti artificiali e comportamento animale, non un ordinamento per persone |
| Modello del votante pesato [20] | Regola di consenso per sciami di robot | Controllo di robot, non decisioni democratiche |

**Valutazione.** Per quanto ci risulta, la DPA è **probabilmente la prima proposta di una rete neurale collettiva per le decisioni democratiche**: un algoritmo in cui le persone sono le unità della rete, le competenze certificate per tema sono i pesi, i vincoli tecnici generano un segnale di errore retropropagato alle proposte, il rivoto è il passo di aggiornamento e la struttura si allarga con regole automatiche, mentre i diritti universali restano a peso eguale. Il primato non si può dimostrare: lavori non indicizzati o in altre lingue potrebbero averla anticipata in parte. La formulazione corretta è quindi «a nostra conoscenza».

### 1.3 Percorso di sviluppo

| Versioni del codice | Che cosa è stato aggiunto o verificato |
|---|---|
| V0–V1 | Concetto e primo prototipo: retropropagazione deliberativa, alternative, rivoto, rollback globale |
| V2–V10 | Apprendimento dalle conseguenze, voto ponderato in tutte le fasi, negoziazione, diagnosi, affidabilità, retroazione nel tempo, mandati condizionali, pianificazione robusta, sequenze condizionali |
| V11–V16 | Portafogli di interventi, resilienza agli shock, riserve di capacità, valore dell'informazione |
| V21 | Revisione critica e raffinamento: tetto ai pesi, voto eguale sui diritti, verifica esatta di ammissibilità, prove di manipolazione |
| V22–V23 | Voto per tema e premesse TEPS: competenze certificate da IA, base minima, dinamica e storico delle previsioni |
| V24–V27 | Tutto per competenza, allargamento in base a ciò che si misura, test di autoattribuzione, conoscenza o interesse |

Ogni versione ha codice, test e risultati propri (§18). Gli errori trovati sono stati corretti in versioni nuove, senza riscrivere le precedenti.

**Distinzione necessaria.** Il voto politico previsto dalla Costituzione italiana è personale ed eguale (art. 48) [13]. La DPA riguarda le decisioni tematiche e tecniche di un ordinamento che le adotti; la sostituzione del suffragio politico eguale con pesi differenziati non è compatibile con quel principio nell'ordinamento vigente.

## 2. Ipotesi

### 2.1 Assunti istituzionali

| Assunto | Che cosa significa | Perché serve | Se non vale |
|---|---|---|---|
| **A1 — Decisioni scomponibili in temi** [A] | Ogni decisione si articola in obiettivi, vincoli tecnici, strategie, ripartizioni e diritti universali; ogni tema ha una mappa di rilevanza rₖ(q) verso le discipline | Senza temi distinti non si può dire chi è competente su che cosa: ogni voto diventerebbe un voto su tutto | La DPA degenera in un voto pesato generico, in cui il peso quasi non conta (verificato nella V21) |
| **A2 — Competenze misurabili** [A] | Formazione ed esperienza lavorativa sono documentabili e legate alla qualità delle stime nella disciplina | È ciò che dà senso al peso: chi è più competente stima meglio | Se la certificazione non misura la qualità reale, il peso amplifica il rumore; lo storico delle previsioni (§9) limita il danno |
| **A3 — Agenti IA indipendenti** [A] | La certificazione è svolta da più agenti con architetture, dati e gestori diversi, che non comunicano | La mediana resiste solo se meno di metà degli agenti è ingannabile insieme (D-5) | Con agenti dagli errori comuni la certificazione vale quanto un solo agente (TEPS §12.2) |
| **A4 — Registri pubblici** [A] | Registro di partecipazione (chi è convocato, chi vota), di residenza o dei destinatari, delle ripartizioni decise; urna separata e segreta | Base minima, astensione e test di autoattribuzione si calcolano solo da questi registri | Senza registri non si rileva l'autoattribuzione; senza urna segreta il voto non è libero |
| **A5 — Monitoraggio** [A] | Dopo ogni periodo si misurano i limiti reali, con errore | Fornisce il segnale di errore per il rivoto mirato e lo storico | Senza monitoraggio la DPA decide una volta sola: fattibilità dall'87% (base) al 58% (dopo uno shock) nella V22 |
| **A6 — Preferenze a picco singolo** [A] | Su una questione numerica ognuno ha un livello preferito e preferisce i valori più vicini | Garantisce che la mediana pesata sia il vincitore di Condorcet (D-1) | Con preferenze a più picchi può non esistere un vincitore; servono voti fra alternative discrete (usati nella V21) |
| **A7 — Vincoli lineari** [A] | Nel modello di verifica i limiti tecnici sono lineari | Permette di verificare in modo esatto se un piano ammissibile esiste | Con vincoli non lineari la verifica diventa approssimata: «non trovato» non implica «impossibile» |

### 2.2 Assunti del modello di verifica

Le simulazioni usano un mondo sintetico deliberatamente semplice, per isolare gli effetti delle regole.

- **Decisione.** Tre livelli da scegliere: abitazioni h, rete idrica w, trasporti t, ciascuno fra 0 e 15. Quattro vincoli tecnici lineari Ax ≤ b (acqua, trasporti, bilancio, ambiente), con coefficienti diversi in ogni mondo; il bilancio è sempre vincolante, quindi le preferenze sono in conflitto.
- **Popolazione.** 600 persone in tre gruppi: maggioranza (60%, livelli preferiti medi 9, 4, 4), minoranza (25%; 5, 3, 8), tecnici (15%; 6, 5, 3). Competenza vera per dominio con distribuzione Beta(2,4) per maggioranza e minoranza e Beta(5,2) per i tecnici. Nelle varianti: competenze diffuse (stessa distribuzione, assegnata a caso), gruppo competente al 40%, discipline vicine (urbanistica, politiche sociali) con competenti fuori dal gruppo tecnico.
- **Preferenze.** Utilità −Σⱼ ωᵢⱼ (xⱼ − idealeᵢⱼ)² con importanze ωᵢⱼ fra 0,5 e 1,5: preferenze quadratiche, quindi a picco singolo (A6).
- **Stime dei limiti.** Ogni persona stima un limite con un errore che decresce con la competenza vera: errore comune a tutti (nuovo a ogni periodo), errore individuale e, per i non esperti, un **errore sistematico comune** (ottimismo, in media +0,8 × (1 − competenza)). Le sensibilità senza errore sistematico sono riportate (§9).
- **Manipolazioni.** Esperti corrotti (metà dei tecnici allenta le stime di 1,5); lobby (10% della popolazione) che inganna 2 o 3 agenti IA su 5 gonfiando il proprio dossier; interesse diretto sulla ripartizione fra zone.
- **Tempo.** 10 periodi (20 nella V27); i limiti reali si spostano con una passeggiata casuale; in uno scenario un limite cade di 1,2 al periodo 5; il piano cambia di al massimo 2 unità per periodo.
- **Conseguenze nascoste (V27).** Le abitazioni oltre il livello sicuro 5 consumano 0,30 di capacità idrica per unità e per periodo; la capacità persa danneggia tutti (0, 2 o 5 per unità persa).

## 3. Struttura delle decisioni [P]

| Tema | Chi vota | Peso | Esito |
|---|---|---|---|
| Vincoli (limiti tecnici: acqua, trasporti, bilancio, ambiente) | competenti nel dominio | competenza nel dominio, con tetto | mediana pesata delle stime, meno un margine |
| Obiettivi (livelli desiderati) | competenti rilevanti per il tema | competenza rilevante, con tetto | mediana pesata dei livelli proposti |
| Ripartizioni fra destinatari (zone, settori) | come gli obiettivi | come gli obiettivi | media pesata delle ripartizioni proposte |
| Diritti universali | tutti | eguale | maggioranza per teste |

**Logica.** Una persona può essere competente sull'acqua e non sul bilancio: un peso unico per tutte le questioni mescolerebbe competenze diverse e, come mostrato nella V21, finirebbe per non contare quasi nulla. Dividere la decisione in temi permette di dare a ogni questione l'elettorato che la conosce. I vincoli tecnici sono anch'essi una votazione, fra chi conosce quel dominio: la stima di un limite è una questione di conoscenza, non di preferenza.

Il piano di ogni periodo è il più vicino agli obiettivi votati entro i limiti certificati. Nessuno vota con peso sulla propria pratica: chi ha un interesse diretto registrato su un tema non vota quel tema (TEPS §11.2 [12]).

## 4. Competenze certificate

Ogni persona i ha, per ogni disciplina k, una formazione Fᵢ,ₖ e un'esperienza Eᵢ,ₖ documentate. Ciascuno di m agenti IA isolati valuta il dossier; la competenza riconosciuta è prudenziale (TEPS §12.1 [12]):

    Cᵢ,ₖ⁽ᵃ⁾ = valutazione dell'agente a,  a = 1, …, m
    Ĉᵢ,ₖ = medianaₐ Cᵢ,ₖ⁽ᵃ⁾ ;   MADᵢ,ₖ = medianaₐ |Cᵢ,ₖ⁽ᵃ⁾ − Ĉᵢ,ₖ|
    C*ᵢ,ₖ = max(0, Ĉᵢ,ₖ − λ · MADᵢ,ₖ)

La competenza rilevante per una questione q è C\*ᵢ(q) = Σₖ rₖ(q) C\*ᵢ,ₖ, con rₖ(q) ≥ 0 e Σₖ rₖ(q) = 1.

### 4.1 D-5 Robustezza della mediana degli agenti [D]

Se meno di metà degli m agenti è manipolata, la mediana Ĉ resta compresa fra la valutazione minima e la massima degli agenti onesti. Se è manipolata la maggioranza, la mediana può essere spostata di quanto si vuole.

**Dimostrazione.** Con h > m/2 agenti onesti, ogni valore sopra la massima valutazione onesta è superato da almeno h valori, cioè dalla maggioranza; la mediana non può quindi superarla. Lo stesso vale verso il basso. Con una maggioranza manipolata gli h' > m/2 valori manipolati determinano l'ordine centrale. Q.E.D.

Con m = 5 la manipolazione di 2 agenti non sposta la competenza oltre i giudizi onesti; quella di 3 sì. Nelle simulazioni una lobby che inganna 2 agenti su 5 pesa il 4,7% nel voto sul bilancio, una che ne inganna 3 il 29% (N-6). La garanzia richiede agenti con errori e vulnerabilità indipendenti (A3).

## 5. Ammissione, peso e base minima

La funzione del voto è quella della TEPS 1.5 (§11.1) [12]:

    wᵢ(q) = 0                                         se C*ᵢ(q) < τ(q)
    wᵢ(q) = 1 + (w_max − 1) · [C*ᵢ(q) − τ(q)] / [1 − τ(q)]   altrimenti

Nel modello di verifica τ₀ = 0,6 e w_max = 3. L'astensione esplicita non entra nell'esito (TEPS §11.3).

**Logica.** La soglia esclude chi su quel tema porterebbe solo rumore; il peso crescente premia la competenza; il tetto impedisce che la competenza diventi dominio. Fra gli ammessi ogni peso è almeno 1, quindi nessun ammesso conta meno di un voto pieno. Come una funzione di attivazione con saturazione, il peso è nullo sotto soglia, cresce in modo lineare e si ferma a w_max.

### 5.1 D-2 Tetto al potere dei gruppi [D]

Fra i votanti ogni peso è compreso fra 1 e w_max. Una frazione f dei votanti detiene al massimo:

    quota di peso ≤ f · w_max / [f · w_max + (1 − f)]

**Dimostrazione.** È la D-14 della TEPS 1.5 (§17.7) [12]: la quota cresce con il peso dei membri e diminuisce con quello degli altri; il massimo si ha con i membri a w_max e gli altri a 1. Q.E.D.

Con w_max = 3 il 10% più competente pesa al massimo il 25%; per avere la maggioranza un gruppo deve essere almeno il 25% dei votanti.

### 5.2 D-3 Base minima di votanti [D]

Se i votanti sopra soglia sono meno di N_min, la soglia scende quanto basta (TEPS D-15, §17.8) [12]:

    τ*(q) = min(τ₀(q), C₍N_min₎(q))

Se i voti espressi restano sotto N_min, si convocano i successivi nella graduatoria finché si raggiunge N_min. Una persona detiene al massimo w_max / (w_max + N_min − 1) del peso: con N_min = 101 e w_max = 3, il 2,9%.

**Dimostrazione.** Segue dalla D-2 con un membro a w_max e gli altri N_min − 1 a peso 1, come nella TEPS. Q.E.D.

La base non ha tetto: votano tutti quelli sopra soglia. N_min è solo un pavimento. Una base minima troppo alta rispetto alle competenze disponibili abbassa la soglia: con N_min = 201 la soglia effettiva scende a 0,38 e la fattibilità cala di 5 punti (N-3).

## 6. Esito del voto

### 6.1 D-1 La mediana pesata è il vincitore di Condorcet [D]

Su una questione numerica con preferenze a picco singolo (A6), sia v₍ₘ₎ la mediana pesata dei livelli preferiti dai votanti. Nessun altro valore la batte in un confronto a maggioranza pesata.

**Dimostrazione.** Sia x > v₍ₘ₎. Tutti i votanti con livello preferito ≤ v₍ₘ₎ preferiscono v₍ₘ₎ a x, per la forma a picco singolo; per definizione di mediana pesata il loro peso è almeno metà del totale. Il caso x < v₍ₘ₎ è simmetrico. Q.E.D.

È il teorema dell'elettore mediano di Black [7] con pesi. Ne segue che votare il livello come mediana pesata equivale a una serie di voti sì/no pesati, come nella formula dell'esito della TEPS (§11.1). Per le ripartizioni fra destinatari si usa la media pesata delle ripartizioni proposte, che è l'esito TEPS applicato a ogni quota.

## 7. Vincoli certificati e margine

Il limite certificato di un vincolo è la mediana pesata delle stime dei competenti meno un margine m:

    b_cert = mediana pesata(b̂ᵢ) − m

**Logica.** La mediana resiste a chi esagera in un senso o nell'altro (un esperto che dichiara un limite enorme sposta la media, non la mediana); il margine copre l'errore che tutti gli esperti condividono, che nessuna mediana può eliminare (D-8).

Prima di adottare un piano si verifica in modo esatto (programmazione lineare) che esista almeno un piano entro i limiti certificati; si distingue «impossibile secondo le stime» da «soluzione non trovata dal calcolo» [P].

### 7.1 D-8 Il margine deve coprire l'errore comune [D]

Sia b̂ᵢ = b + e_c + eᵢ, con e_c errore comune a tutti gli stimatori (media μ_c, deviazione σ_c) ed eᵢ indipendenti. Per N grande la mediana delle stime converge a b + e_c + mediana(e), quindi la probabilità che il limite certificato superi quello reale tende a:

    P(b_cert > b) → 1 − Φ((m − μ_c − mediana(e)) / σ_c)

**Dimostrazione.** La mediana campionaria degli eᵢ converge alla mediana della loro distribuzione; resta l'errore comune, che non si riduce aumentando i votanti. Q.E.D.

Allargare la base riduce solo l'errore indipendente; l'errore comune va coperto con il margine. Il margine è quindi una scelta fra sicurezza e benessere da decidere come obiettivo, non un parametro tecnico neutro.

| Margine | Piani davvero fattibili | Benessere medio |
|---|---:|---:|
| 0,15 | 61,5% | −23,26 |
| 0,50 | 89,5% | −25,27 |
| 0,80 | 98,0% | −27,14 |

*Tabella 1. N-1: effetto del margine di certificazione (200 mondi sintetici, voto pesato con tetto). Il benessere è la distanza fra il piano e i livelli desiderati: più vicino a zero è meglio.*

## 8. Diritti universali

### 8.1 D-4 Il voto eguale sui diritti non ribalta la maggioranza [D]

Con voto eguale l'esito coincide con la maggioranza per teste. Con voto pesato l'esito si ribalta quando la quota pesata dei favorevoli e quella per teste stanno da parti opposte di 1/2, cioè quando favorevoli e contrari hanno pesi medi diversi.

**Dimostrazione.** Con wᵢ = 1 la quota pesata coincide con la quota per teste. Con pesi qualsiasi la quota pesata è (W_F · n_F)/(W_F · n_F + W_C · n_C), con W_F, W_C pesi medi dei favorevoli e dei contrari; si discosta da n_F/(n_F + n_C) se e solo se W_F ≠ W_C. Q.E.D.

N-2: con pesi senza tetto e voto pesato anche sui diritti, la decisione per teste è ribaltata nel 57,5% dei mondi (69,5% con una lobby dalle competenze gonfiate) e la minoranza perde 8,2 punti di benessere; con il voto eguale sui diritti il ribaltamento è nullo per costruzione.

## 9. Dinamica: monitoraggio, rivoto mirato, storico delle previsioni

- **Inerzia** [P]: ogni variabile del piano cambia di una quantità limitata per periodo.
- **Monitoraggio e rivoto mirato** [P]: dopo ogni periodo si misura il limite reale; si rivota solo il vincolo il cui limite si è spostato oltre una soglia.
- **Logica del monitoraggio.** Come in una rete che riceve un errore dopo ogni esempio, la DPA confronta i limiti certificati con quelli misurati e corregge solo dove sbaglia. Rivotare solo ciò che il monitoraggio segnala riduce le votazioni senza perdere precisione.
- **Storico delle previsioni** [P, variante]: chi ha stimato male un limite perde peso nelle questioni di misura di quel dominio. La competenza riconosciuta non cambia; si riduce solo il peso sulla misura. È la forma compatibile con la regola della TEPS secondo cui non esistono penalizzazioni automatiche della competenza (§11.2) [12].

| Regime | Base | Esperti corrotti | Lobby che inganna 3 agenti su 5 | Shock | Schede per periodo |
|---|---:|---:|---:|---:|---:|
| Tutti votano su tutto | 60,7% | 46,3% | 61,1% | 58,9% | 4 260 |
| DPA, si rivota tutto ogni periodo | 93,2% | 66,4% | 91,4% | 93,8% | 2 264 |
| DPA, monitoraggio e rivoto mirato | 96,3% | 76,8% | 94,6% | 95,0% | 394 |
| DPA + storico delle previsioni | 97,4% | 91,7% | 95,4% | 95,6% | 391 |

*Tabella 2. N-3 e N-4: quota di periodi in cui il piano rispetta i limiti reali (200 mondi, 10 periodi, obiettivi a voto eguale come nella configurazione V23 del codice).*

![](figure/figura_1.png)

*Figura 1. Periodi con piano davvero fattibile per scenario. La DPA vota i vincoli fra i competenti con le regole TEPS; lo storico delle previsioni toglie peso a chi stima male. Simulazioni su popolazioni sintetiche, non previsioni.*

**Lettura.** Il vantaggio del voto fra competenti sui vincoli è di +35,6 punti [IC 95%: +31,5, +39,9] quando i non esperti condividono un errore sistematico (ottimismo); se sbagliano solo a caso è di +2,7 punti [+1,5, +4,0], perché la media di molti errori indipendenti si compensa. Dopo uno shock il rivoto mirato reagisce con un periodo di ritardo.

## 10. Allargamento in base a ciò che si misura

La base si allarga per due ragioni diverse, con due regole diverse, entrambe automatiche e fissate prima [P]:

| Cosa si misura | Problema | Allargamento |
|---|---|---|
| Voti espressi sotto N_min | base troppo piccola | verticale: si scende nella stessa graduatoria (D-3) |
| Effetti della decisione concentrati su chi l'ha votata | autoattribuzione | orizzontale: entrano i competenti delle discipline vicine, fissate prima per ogni tema |

**Indice di autoattribuzione.** Per una ripartizione a = (a₁, …, a_Z) fra destinatari (zone) con quote di popolazione s_z, il beneficio di una persona residente in z è a_z / s_z (1 = parte proporzionale). L'indice è:

    IA = beneficio medio di chi ha votato − beneficio medio di chi non ha votato

Servono solo il registro di partecipazione, quello di residenza e la ripartizione decisa: non servono né il contenuto dei voti né le preferenze delle persone.

**Regola di attivazione.** Si allarga se (1) la composizione per destinatario dell'elettorato si discosta da quella della popolazione più del 95% degli elettorati estratti a caso della stessa dimensione (test di permutazione) e (2) IA > 0.

### 10.1 D-6 Livello del test [D]

Se l'elettorato è un sottoinsieme estratto a caso della popolazione, la regola si attiva con probabilità non superiore al livello α del test (5%).

**Dimostrazione.** Sotto questa ipotesi l'elettorato osservato e gli elettorati estratti per il confronto sono scambiabili; il p-value di permutazione p = (1 + #{nulli ≥ osservato})/(1 + B) soddisfa P(p ≤ α) ≤ α. La regola richiede anche IA > 0, quindi la sua probabilità è al più quella del test. Q.E.D.

N-5: con competenze diffuse la regola si attiva nel 5–7% dei casi. Una prima versione, che confrontava l'indice con elettorati casuali a ripartizione fissa, si attivava nel 26–33%, perché qualunque elettorato tende a favorire i propri destinatari; è stata sostituita.

### 10.2 D-7 Limite dell'allargamento verticale [D]

Se i primi r posti della graduatoria di competenza sono occupati dal gruppo G e l'elettorato contiene i primi k < r, ogni allargamento verticale di n ≤ r − k posti aggiunge solo membri di G e non riduce la loro quota.

**Dimostrazione.** L'allargamento verticale aggiunge i posti k + 1, …, k + n della stessa graduatoria, tutti occupati da G per ipotesi; la quota di G passa da g/k a (g + n)/(k + n) ≥ g/k perché g ≤ k. Q.E.D.

Per questo, quando il problema è l'interesse e non il numero, si allarga in orizzontale.

**Logica.** Le due misure rispondono a domande diverse: «abbiamo abbastanza voti?» e «chi decide si sta attribuendo i benefici?». Al primo problema serve più gente dalla stessa graduatoria; al secondo serve gente diversa, competente in discipline vicine. Entrambe le regole sono automatiche e fissate prima: nessuno sceglie caso per caso chi aggiungere, e il diritto di voto resta legato a criteri chiari e imparziali.

| Mondo | Verticale − nessun controllo | Orizzontale − nessun controllo | Orizzontale − verticale |
|---|---|---|---|
| Gruppo competente 15% | +2,18 [+2,07, +2,29] | +3,67 [+3,53, +3,79] | +1,49 [+1,39, +1,58] |
| Gruppo competente 40% | +0,58 [+0,50, +0,66] | +2,57 [+2,46, +2,67] | +1,99 [+1,90, +2,07] |
| Competenze diffuse | +0,02 [−0,04, +0,07] | −0,01 [−0,08, +0,06] | −0,02 [−0,09, +0,05] |

*Tabella 3. N-6: benessere della maggioranza, con lo stesso numero di persone aggiunte nei due allargamenti (200 mondi; intervalli bootstrap al 95%).*

![](figure/figura_2.png)

*Figura 2. Allargamento verticale e orizzontale a parità di persone aggiunte. Con un gruppo competente grande il verticale quasi non serve, perché i successivi in graduatoria sono ancora del gruppo (D-7). Con competenze diffuse nessuna regola cambia l'esito.*

## 11. Conoscenza o interesse

Il gruppo competente vuole spesso cose diverse dalla base. Può farlo perché sa di più (conoscenza) o perché ci guadagna (interesse). Per distinguere i due casi, il modello di verifica introduce una conseguenza che solo i competenti conoscono: costruire abitazioni oltre un livello sicuro consuma la capacità idrica nei periodi successivi, e la capacità persa danneggia tutti. Chi è competente in acqua o urbanistica lo sa e chiede meno abitazioni. I piani sono valutati sulle **conseguenze reali in 20 periodi**, non sui desideri iniziali.

| Danno da scarsità | Competenze concentrate | Competenze diffuse |
|---:|---|---|
| 0 | −0,19 [−0,24, −0,14] | −0,30 [−0,35, −0,24] |
| 2 | +0,08 [+0,00, +0,15] | +0,37 [+0,27, +0,46] |
| 5 | +0,48 [+0,32, +0,63] | +1,36 [+1,16, +1,57] |

*Tabella 4. N-7: benessere realizzato, voto per competenza meno voto eguale sugli obiettivi, quando i competenti differiscono solo per conoscenza (200 mondi; intervalli bootstrap al 95%).*

![](figure/figura_3.png)

*Figura 3. Benessere realizzato in 20 periodi: voto per competenza meno voto eguale sugli obiettivi, al crescere del danno causato dalle conseguenze che solo i competenti conoscono. Banda: intervallo bootstrap al 95%.*

**Lettura.**

- Se le conseguenze che i competenti conoscono danneggiano davvero le persone, votare per competenza dà risultati migliori del voto eguale, anche per la maggioranza (+0,44 e +1,08 con danno 5). Se non danneggiano nessuno, il loro sapere non serve.
- Il controllo di autoattribuzione **non si attiva** quando c'è solo conoscenza, e quindi non la blocca.
- Quando c'è anche interesse (competenti concentrati in una zona che favoriscono), il controllo si attiva sempre e restituisce alla maggioranza circa 3 punti; con danno 5, «tutto per competenza + controllo» è la configurazione migliore (+1,54 sul voto eguale) e la maggioranza non ci perde (+0,08, non significativo).

## 12. Configurazione raccomandata [P]

1. Competenze certificate da più agenti IA indipendenti (§4).
2. Ogni tema votato da chi supera la soglia di competenza rilevante, con peso TEPS e tetto w_max = 3 (§5).
3. Diritti universali a voto eguale (§8).
4. Vincoli certificati con margine deciso come obiettivo e verifica esatta di ammissibilità (§7).
5. Monitoraggio e rivoto mirato; storico delle previsioni sulle questioni di misura (§9).
6. Base minima con allargamento verticale; controllo di autoattribuzione con allargamento orizzontale (§10).

## 13. Il modello sta in piedi? Valutazione

La DPA è coerente sotto sette condizioni:

- **C1 Competenze certificabili**: formazione ed esperienza documentabili e legate alla qualità delle stime (A2).
- **C2 Agenti IA indipendenti**: meno di metà degli agenti manipolabile da uno stesso soggetto (D-5).
- **C3 Registri pubblici**: partecipazione, residenza o destinatari, ripartizioni decise; voto segreto (A4).
- **C4 Margine come obiettivo**: il margine di certificazione è deciso esplicitamente, perché copre l'errore comune che nessuna base elimina (D-8).
- **C5 Competenze non concentrate in un gruppo di interesse**, oppure controllo di autoattribuzione attivo (N-5, N-6).
- **C6 Base minima proporzionata** alle competenze disponibili: abbastanza ampia da limitare il peso individuale, non tanto da abbassare la soglia oltre il necessario (D-3, N-3).
- **C7 Conseguenze rilevanti**: il voto per competenza sugli obiettivi conviene quando i competenti vedono conseguenze che danneggiano davvero; altrimenti il voto eguale è equivalente o migliore (N-7).

**Conclusione generale.** Con queste condizioni la DPA decide in modo più affidabile del voto di tutti su tutto sulle questioni tecniche, non permette ai competenti di dominare (tetto, base minima, voto eguale sui diritti) e corregge automaticamente i casi in cui un gruppo si attribuisce i benefici. Restano non dimostrati il comportamento di persone e istituzioni reali, la resistenza a manipolazioni coordinate e la legittimità sociale di un voto pesato.

## 14. Limiti e programma di verifica

- **Dati reali.** L'errore sistematico dei non esperti e la gravità delle conseguenze nascoste vanno misurati: da essi dipende quanto convenga la DPA rispetto al voto eguale.
- **Comportamento strategico.** Coalizioni, prestanome, manipolazione coordinata degli agenti IA non sono modellati oltre gli scenari semplici.
- **Effetti indiretti.** L'indice di autoattribuzione misura allocazioni dirette; benefici indiretti (per esempio il valore delle case vicino a un'opera) non sono misurati.
- **Mandati e riserve.** Mandati condizionali e riserve di capacità, studiati in versioni precedenti del codice, non sono ancora integrati nella configurazione raccomandata.
- **Discipline vicine.** La mappa delle discipline vicine va costruita e verificata per ogni tema.

| Fase | Obiettivo | Stato nella versione 1.0 |
|---|---|---|
| V1 Regole di voto | Ammissione, peso, base minima, diritti | Chiuso a livello teorico (D-1–D-4) |
| V2 Certificazione | Robustezza del consesso di IA | Chiuso a livello teorico (D-5); da verificare su agenti reali |
| V3 Vincoli e margine | Fattibilità reale dei piani | Simulazioni (N-1, N-3, N-4) |
| V4 Autoattribuzione | Rilevazione e correzione | Chiuso a livello teorico (D-6, D-7); simulazioni (N-5, N-6) |
| V5 Conoscenza e interesse | Quando conviene votare per competenza | Simulazioni (N-7) |
| V6 Caso pilota | Misura dell'errore dei non esperti e della qualità delle stime degli esperti | Aperto |
| V7 Comportamento strategico | Coalizioni e manipolazioni coordinate | Aperto |

## 15. Parametri del modello di verifica

| Simbolo | Valore | Significato | Dove |
|---|---|---|---|
| τ₀ | 0,6 | Soglia ordinaria di competenza per votare un tema | §5 |
| w_max | 3 | Peso massimo di un votante (sensibilità: 2, 5, 10 nella V21) | D-2 |
| N_min | 101 | Base minima di voti espressi (sensibilità: 25, 201) | D-3 |
| Partecipazione | 80% | Probabilità che un convocato voti invece di astenersi | §5 |
| m (agenti) | 5 | Agenti IA che certificano le competenze | D-5 |
| λ | 1 | Prudenza della certificazione (mediana − λ·dispersione) | §4 |
| Margine | 0,5 | Margine di certificazione dei limiti (0,15, 0,5, 0,8 nella V21) | D-8 |
| Errore sistematico dei non esperti | media 0,8, dev. 0,4, × (1 − competenza) | Ottimismo comune sulle stime dei limiti | §2.2 |
| Errore comune di modello | dev. 0,2 per periodo | Errore condiviso da tutti gli stimatori | D-8 |
| Deriva dei limiti | dev. 0,12 per periodo | Passeggiata casuale dei limiti reali | §9 |
| Inerzia | 2 | Variazione massima di ogni livello per periodo | §9 |
| Soglia di rivoto | 0,35 | Scostamento misurato che fa rivotare un vincolo | §9 |
| Soglia di interesse diretto | quota 0,40 alla propria zona | Preferenza per la propria zona nella ripartizione (scenari con interesse) | §10 |
| Test di autoattribuzione | 500 permutazioni, α = 5% | Elettorati casuali di confronto e livello del test | D-6 |
| Mondi | 200 per scenario | Mondi sintetici indipendenti; intervalli bootstrap con 2000 ricampionamenti [10] | tutti |

## 16. Registro dei risultati

| Codice | Risultato | Portata |
|---|---|---|
| D-1 | La mediana pesata è il vincitore di Condorcet pesato | Preferenze a picco singolo |
| D-2 | Quota di un gruppo ≤ f·w_max/[f·w_max + (1 − f)] | Pesi fra 1 e w_max (TEPS D-14) |
| D-3 | Almeno N_min votanti; peso individuale ≤ w_max/(w_max + N_min − 1) | Regola deterministica (TEPS D-15) |
| D-4 | Voto eguale sui diritti: esito = maggioranza per teste; con pesi, ribaltamento se e solo se i pesi medi differiscono | Questioni sì/no |
| D-5 | Mediana degli agenti entro i giudizi onesti se meno di metà è manipolata | m agenti, ordine statistico |
| D-6 | Regola di autoattribuzione attiva con probabilità ≤ α per elettorati casuali | Test di permutazione |
| D-7 | L'allargamento verticale non riduce un gruppo che occupa i primi posti | Graduatoria di competenza |
| D-8 | Il margine deve coprire l'errore comune; la base riduce solo l'errore indipendente | Errore comune + indipendente |
| N-1 | Margine 0,15 / 0,50 / 0,80: piani fattibili 61,5% / 89,5% / 98,0% | Tabella 1 |
| N-2 | Pesi senza tetto anche sui diritti: ribaltamento nel 57,5% dei mondi; voto eguale: 0% | Diritti universali |
| N-3 | Vincoli fra competenti: +35,6 punti di fattibilità (+2,7 senza errore comune dei non esperti); N_min 201: −4,8 | Tabella 2 |
| N-4 | Storico delle previsioni con esperti corrotti: fattibilità dal 77% al 92% | Tabella 2 |
| N-5 | Obiettivi per competenza: nessuna differenza con competenze diffuse; −5,7 per la maggioranza con competenze concentrate; regola di autoattribuzione attiva nel 5–7% con competenze diffuse | §10 |
| N-6 | Orizzontale − verticale a parità di persone: +1,5 (gruppo 15%), +2,0 (gruppo 40%) | Tabella 3 |
| N-7 | Solo conoscenza: voto per competenza − voto eguale da −0,2 (danno 0) a +0,5/+1,4 (danno 5) | Tabella 4 |

## 17. Riferimenti

1. Condorcet, N. de (1785), *Essai sur l'application de l'analyse à la probabilité des décisions rendues à la pluralité des voix*, Imprimerie Royale, Parigi.
2. List, C. e Goodin, R. E. (2001), "Epistemic Democracy: Generalizing the Condorcet Jury Theorem", *Journal of Political Philosophy*, 9(3).
3. Estlund, D. (2008), *Democratic Authority: A Philosophical Framework*, Princeton University Press.
4. Brennan, J. (2016), *Against Democracy*, Princeton University Press.
5. Landemore, H. (2013), *Democratic Reason: Politics, Collective Intelligence, and the Rule of the Many*, Princeton University Press.
6. Hong, L. e Page, S. E. (2004), "Groups of diverse problem solvers can outperform groups of high-ability problem solvers", *Proceedings of the National Academy of Sciences*, 101(46).
7. Black, D. (1948), "On the Rationale of Group Decision-making", *Journal of Political Economy*, 56(1).
8. Galton, F. (1907), "Vox Populi", *Nature*, 75.
9. Arrow, K. J. (1951), *Social Choice and Individual Values*, Wiley.
10. Efron, B. e Tibshirani, R. J. (1993), *An Introduction to the Bootstrap*, Chapman & Hall.
11. Good, P. (2005), *Permutation, Parametric, and Bootstrap Tests of Hypotheses*, 3ª ed., Springer.
12. Lorenzetto, C. (2026), *TEPS — Teoria dell'Equilibrio Economico Post-Salariale*, versione 1.5 (30 ottobre 2026, aggiornata al 2 novembre 2026): §11 Competenza e democrazia ponderata universale, §11.3 Regola di partecipazione, §12 Consesso di IA isolate, §17.7 D-14, §17.8 D-15.
13. Costituzione della Repubblica Italiana, art. 48.
14. Hanson, R. (2013), "Shall We Vote on Values, But Bet on Beliefs?", *Journal of Political Philosophy*, 21(2).
15. Rosenberg, L. (2016), "Artificial Swarm Intelligence, a Human-in-the-Loop Approach to A.I.", *Proceedings of the AAAI Conference on Artificial Intelligence*, 30.
16. Hilbert, M. (2009), "The Maturing Concept of E-Democracy: From E-Voting and Online Consultations to Democratic Value Out of Jumbled Online Chatter", *Journal of Information Technology & Politics*, 6(2).
17. Koster, R. et al. (2022), "Human-centred mechanism design with Democratic AI", *Nature Human Behaviour*, 6.
18. Tessler, M. H. et al. (2024), "AI can help humans find common ground in democratic deliberation", *Science*, 386(6719).
19. Morford, J., Lewin, P., Biro, D., Guilford, T., Padget, O. e Collet, J. (2022), "Neural networks reveal emergent properties of collective learning in democratic but not despotic groups", *Animal Behaviour*, 194.
20. Valentini, G., Hamann, H. e Dorigo, M. (2014), "Self-organized collective decision making: the weighted voter model", *Proceedings of AAMAS 2014*.
21. Rumelhart, D. E., Hinton, G. E. e Williams, R. J. (1986), "Learning representations by back-propagating errors", *Nature*, 323.

## 18. Provenienza dei risultati numerici

I risultati [N] sono riprodotti dal codice nella cartella `democrazia-ponderata-adattiva/` del repository (Python con NumPy e SciPy, semi fissi), che contiene per ogni versione codice, test automatici, risultati per mondo e un README con limiti ed esiti negativi:

- `v21_dpa_raffinata/` — tetto ai pesi, voto eguale sui diritti, margine (N-1, N-2);
- `v22_dpa_dinamica_tematica/` — dinamica, monitoraggio, storico delle previsioni;
- `v23_dpa_premesse_teps/` — competenze certificate da agenti IA, regole TEPS, base minima (N-3, N-4; D-5 numerica);
- `v24_dpa_tutto_per_competenza/` — obiettivi per competenza, competenze concentrate e diffuse (N-5);
- `v25_dpa_allargamento_misurato/` e `v26_dpa_test_corretto/` — indice e test di autoattribuzione, allargamento verticale e orizzontale (N-5, N-6);
- `v27_dpa_conoscenza_interesse/` — conoscenza o interesse, conseguenze reali in 20 periodi (N-7).

Le figure sono prodotte da `dpa/simulazioni/dpa_1_0_figure.py` a partire dai risultati salvati.
