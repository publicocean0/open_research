# Democrazia Ponderata Adattiva V7 — retropropagazione in fase di attuazione

**Stato:** prototipo computazionale; tutti i dati, gli elettori e gli obiettivi sono sintetici. I risultati non convalidano un sistema democratico reale e non forniscono previsioni sulle preferenze di popolazioni reali.

## Domanda sperimentale

Una rete che riceve misure durante la realizzazione di un piano, aggiorna i modelli tecnici e permette nuovi voti ponderati raggiunge più spesso obiettivi di medio termine, rispetto a un piano approvato una volta sola?

### Regole fisse

1. Qualsiasi cittadino può proporre un obiettivo; la preselezione del sostegno e il voto definitivo sugli obiettivi usano i pesi di competenza specifici della questione (**V3**).
2. Le metriche sono proposte e votate **soltanto da cittadini con competenza certificata pertinente** (V3).
3. Tutti i voti sulle strategie e sulle loro revisioni sono ponderati per competenza (V3 + V4).
4. Gli obiettivi approvati restano **identici nei tre metodi e durante i 12 periodi**. Questa versione isola l'adattamento delle strategie; la V3/V4 contiene già le procedure ponderate per le revisioni degli obiettivi, volutamente non attivate nella V7.
5. Una correzione delle stime non autorizza automaticamente a modificare il piano: occorre una nuova proposta tecnica e un nuovo voto ponderato.
6. Il voto finale non massimizza la soddisfazione media: la ricerca tecnica dei piani mira prima al raggiungimento dei target soggetti ai vincoli; il voto rappresenta un requisito indipendente di approvazione. Gli oneri possono essere scaglionati o redistribuiti, senza inventare nuove risorse.
7. Allarmi basati su scostamenti **dalla traiettoria prevista**, non dalla distanza dal target finale a metà del percorso. Il rumore del sensore deve produrre due segnalazioni consecutive per attivare la procedura.

### Metodi abbinati

- **Bloccato**: un solo piano votato all'inizio, attuato senza revisioni.
- **Periodico**: apprendimento RLS e possibilità di revisione nei periodi 1, 4, 7 e 10 (contando da 1).
- **Attivato**: revisione periodica **più** un rivoto aggiuntivo quando il monitoraggio rileva scostamenti persistenti rispetto alle previsioni. Cooldown minimo tra i tentativi.

Tutti i metodi vedono lo stesso elettorato, stesse proposte iniziali, stessi vincoli reali, stesso shock, rumore osservativo e misure iniziali. Gli aggiornamenti RLS dei metodi adattivi sono alimentati soltanto dalle osservazioni e da piccoli test-pilota eseguiti progressivamente, senza accesso anticipato ai valori futuri.

### Dati simulati

- 24 mondi per ciascuno dei quattro scenari: **stabile**, **shock**, **shock + rumore**, **shock + conflitto**.
- 300 cittadini per mondo, con quattro competenze specifiche e pesi eterogenei.
- 12 periodi di attuazione; cambio dei parametri tecnici a metà nei casi di shock.
- Due obiettivi: abitazioni e ambiente (nel campione corrente i target approvati sono 8,35 e 4,80 in unità sintetiche).
- Quattro vincoli interdisciplinari: acqua, trasporti, bilancio, ambiente.
- Indicatori valutati sullo **stato reale a fine periodo**, non sul semplice annuncio del piano; i limiti tecnici finali sono verificati sul piano realizzato.
- Criterio binario di successo: scostamento totale dai due target <=0,11 e massimo vincolo tecnico reale violato <=0,02. Le soglie sono convenzioni esplicite del test, non valori empirici.

### Risultati sintetici (24 mondi per scenario)

| Scenario | Bloccato | Periodico | Attivato |
|---|---:|---:|---:|
| Stabile | 87,5% | 87,5% | 87,5% |
| Shock | 0% | 0% | 0% |
| Shock rumoroso | 0% | 0% | 0% |
| Shock con conflitto | 0% | 0% | 0% |

Le nuove procedure **non risolvono lo shock** nel campione misurato. Nei 24 mondi dello scenario shock l'errore medio finale rispetto ai target scende da circa **0,540** (bloccato) a **0,495** (attivato), ma i criteri congiunti di successo non sono soddisfatti.

### Cause osservate di blocco

Nello scenario shock, limitandoci ai tentativi di rivoto DOPO il cambio delle condizioni (periodo >6):

| Metodo | Tentativi | Approvati | Respinti dal voto | Nessuna proposta tecnica |
|---|---:|---:|---:|---:|
| Periodico | 48 | 7 | 38 | 3 |
| Attivato | 88 | 7 | 75 | 6 |

Il riferimento tecnico **oracolo dinamico** trova un piano che raggiunge gli obiettivi in tutti e 24 i mondi: conosce però i veri vincoli tecnici al momento in cui interviene e non effettua alcuna votazione. Perciò rappresenta una verifica di esistenza **limitata al risolutore e alle semplificazioni del simulatore**, non un confronto politico equo.

**Interpretazione:** le proposte correttive vengono spesso respinte e alcune diventano inammissibili secondo le stime disponibili; più tentativi di voto non equivalgono a una migliore deliberazione. Occorrono un meccanismo che espliciti il costo collettivo del mancato obiettivo, migliori proposte tecniche e prove specifiche sulla formazione delle coalizioni, senza alterare le priorità democraticamente votate.

### Limiti del prototipo

- Il comportamento del voto è definito da una funzione sintetica semplificata; non rappresenta osservazioni di elettori reali.
- Competenza, tempi di esecuzione, costi e risorse sono semplificati.
- Le misure tecniche indipendenti sono generate dal simulatore; non sono dati di laboratorio reali.
- RLS lineare con cambiamento brusco: la velocità di adattamento dipende dai parametri fissati.
- I criteri di successo sono booleani e non misurano tutte le dimensioni possibili.
- La fattibilità del pianificatore di riferimento non è una dimostrazione di ottimalità globale; ignora delibera, legittimazione e negoziazione dei sacrifici.
- Campione di 24 mondi per scenario: incertezza statistica elevata. Non inferire superiorità generale da differenze piccole.
- La revisione formale degli obiettivi è presente nella V3/V4 ma non è esercitata in questo specifico test V7, per evitare di confondere la modifica dei target con un miglioramento delle strategie.

## Riproduzione

Installare `numpy`, `scipy`, `pandas` (per analizzare CSV), `matplotlib` (per grafici). Dal percorso della cartella madre `democrazia-ponderata-adattiva`:

```bash
python v7_feedback_temporale/simulazione_v7.py --test
python v7_feedback_temporale/simulazione_v7.py --mondi 24 --cittadini 300 --periodi 12
```

File prodotti in `risultati/`: `periodi.csv`, `voti.csv`, `audit_metriche.csv`, `fattibilita_ideale.csv`, `agenda_e_obiettivi.csv`, `riepilogo.csv`, `parametri.json`, grafici. La simulazione contiene semi fissi e genera risultati riproducibili nello stesso ambiente.

## Evoluzione da testare

Aggiungere **pacchetti di strategia comprensivi di contingenze** votati inizialmente con ponderazione per competenza, in modo che una correzione prevista entro parametri approvati non debba essere trattata come un nuovo programma politico da zero. Ogni modifica al di fuori dell'inviluppo approvato richiederebbe comunque un nuovo voto ponderato. Questa ipotesi NON è stata testata nella V7.