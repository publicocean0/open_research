#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V7: monitoraggio attuativo e retropropagazione temporale per una democrazia ponderata.

Studio sintetico, non prova dell'efficacia di alcun assetto politico reale.
Riutilizza: sistemi/competenze/voti V3; proposte vincolate e oneri V4;
modello di errore e apprendimento RLS V2.

Metodi abbinati sulle stesse società/rumori/shock:
  bloccato   : un solo voto ponderato iniziale, piano invariato.
  periodico  : RLS + controllo ogni 3 periodi + rivoto ponderato.
  attivato   : RLS + controllo periodico e allarme dai dati + rivoto ponderato.
  ideale_tecnico (diagnosi separata): ottimizzatore vede i veri vincoli; NON vota.

Risultati finali misurati contro gli obiettivi ORIGINALI e vincoli reali; i
voti e il riscontro delle metriche non usano mai la verità nascosta.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from dataclasses import dataclass
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
for p in (ROOT, ROOT/'v2_adattiva', ROOT/'v3_ponderata', ROOT/'v4_negoziazione'):
    sys.path.insert(0,str(p))
import simulazione as base
import simulazione_ponderata as v3
import simulazione_v4 as v4
from simulazione_adattiva import OnlineRLS, as_model

METHODS=('bloccato','periodico','attivato')
SCENARIOS=('stabile','shock','shock_rumoroso','shock_conflitto')
START_PROBES=np.array([[7.0,.6,.6],[8.0,1.4,1.0],[8.9,1.8,2.2],
                       [7.5,2.5,1.5],[8.4,.8,2.8],[9.0,2.2,1.2]])
AUDIT_PROBES=np.array([[8.15,1.2,1.5],[8.6,2.1,1.9],[7.8,1.8,2.7]])

@dataclass
class Result:
    approved:bool
    reason:str
    bundle:object=None
    share:float=float('nan')
    local_shares:tuple=()
    feedback:float=0.
    considered:int=0


def generate_world(j,scenario,periods,n):
    seed=112000+41*j
    rng=np.random.default_rng(seed)
    pop=v3.build_electorate(rng,n,'conflitto' if scenario=='shock_conflitto' else 'stabile')
    theta,panel=v3.make_world(rng,periods,'cambiamento' if 'shock' in scenario else 'stabile')
    # La prima fase è una vera procedura ponderata di agenda e votazione.
    proposals=[v3.Proposal('alloggi',8.35,(seed+3)%n),
               v3.Proposal('alloggi',8.65,(seed+5)%n),
               v3.Proposal('ambiente',4.80,(seed+7)%n),
               v3.Proposal('ambiente',4.65,(seed+11)%n)]
    goals,gev=v3.select_goals(pop,proposals,periods)
    metrics={q:v3.metric_vote(pop,q)[0] for q in goals}
    # Unici stream di misure condivisi da tutti i metodi; nessuna informazione futura.
    monitoring_noise=rng.normal(0,.10,(periods,4))
    metric_noise=rng.normal(0,.06,(periods,2))
    pilot_noise=rng.normal(0,.075,(periods,4))
    start_noise=rng.normal(0,.075,(len(START_PROBES),4))
    contamination=np.zeros((periods,4))
    if scenario=='shock_rumoroso':
        indices=rng.choice(np.arange(1,periods),size=max(1,periods//5),replace=False)
        contamination[indices]=rng.normal(0,.70,(len(indices),4))
    return dict(seed=seed,pop=pop,theta=theta,panel=panel,goals=goals,
                goal_events=gev,metrics=metrics,monitoring_noise=monitoring_noise,
                metric_noise=metric_noise,pilot_noise=pilot_noise,
                start_noise=start_noise,contamination=contamination)


def common_initial_model(w):
    """Calibrazione iniziale identica e realistica per TUTTI gli algoritmi.
    Le misure di laboratorio sono rumorose; il modello vero rimane nascosto.
    """
    lr=OnlineRLS.from_panel(w['panel'],uncertainty=.35,noise=.10,forgetting=.94)
    theta=as_model(w['theta'][0])
    for point,noise in zip(START_PROBES,w['start_noise']):
        lr.update(point,theta.g(point)+noise)
    return lr


def goal_gap(state,truth,goals):
    vals=v3.actual_values(state,truth)
    gap=0.
    for k,g in goals.items():
        gap+=max(0.,g.target-vals[k]) if g.direction=='min' else max(0.,vals[k]-g.target)
    return float(gap),vals


def propose_and_vote(pop,goals,estimated,lr,state,plan,t,periods,obligations,
                     allow_gradual=True):
    """Feedback interdisciplinare -> piani tecnici -> votazioni ponderate.
    Un vincolo tecnico non dà un veto unilaterale; deve poter diventare una
    proposta nuova e sottoposta a voto globale. L'obiettivo NON viene rivisto.
    """
    if not {'alloggi','ambiente'}.issubset(goals):
        return Result(False,'obiettivi_non_approvati')
    # Residui dei quattro ambiti retropropagati in variabili strategiche.
    residual=np.maximum(estimated.g(plan),0.)
    back=estimated.jac(plan).T@residual
    anchor=np.clip(plan-.35*back/(np.linalg.norm(back)+1e-10),base.LOW,base.HIGH)
    # Evita che la situazione attuale sia usata come desideratum politico.
    anchor=np.maximum(anchor,np.array([goals['alloggi'].target,0,0]))
    alternatives=v4.candidate_plans(goals,estimated,lr,anchor)
    chosen=None; count=0
    periods_left=periods-t
    # Candidati distinguibili per tempi e sacrifici; non si ottimizza il gradimento.
    schedules=('rapida','regolare','graduale') if allow_gradual else ('regolare',)
    for x in alternatives:
        if np.linalg.norm(x-plan)<.025:continue
        for schedule in schedules:
            if not v4.predicted_acceptable(x,goals,estimated,state,periods_left,schedule):continue
            for group,relief in [(-1,0.)]+[(g,.25) for g in range(4)]:
                bundle=v4.Bundle(x,schedule,group,relief,'v7_proposta')
                count+=1
                share=v4.fraction_for_bundle(pop,estimated,goals,bundle,plan,state,t,periods,
                                            obligations,mode='forward')
                if share<=.5:continue
                local=tuple(v4.fraction_for_bundle(pop,estimated,goals,bundle,plan,state,t,
                                 periods,obligations,mode='forward',domain=d)
                                 for d in range(4))
                score=v4.finance_equity_score(pop,bundle,plan)
                if chosen is None or score<chosen[0]:
                    chosen=(score,bundle,share,local)
    if chosen is None:
        return Result(False,'nessuna_proposta' if not count else 'voto_respinto',
                      feedback=float(np.linalg.norm(back)),considered=count)
    _,bundle,share,local=chosen
    return Result(True,'approvata',bundle,share,local,float(np.linalg.norm(back)),count)


def technical_oracle(w,periods):
    """Solo valutatore: verificare se esiste almeno un piano statico valido
    prima e dopo lo shock, conoscendo la realtà. NON vota, NON entra in V7.
    Non certifica la fattibilità dinamica né ottimalità globale.
    """
    if not {'alloggi','ambiente'}.issubset(w['goals']):return (False,False)
    g=w['goals'];t0=as_model(w['theta'][0]);tlast=as_model(w['theta'][-1])
    def check(truth):
        def cons(x):
            return np.r_[-truth.g(x),x[0]-g['alloggi'].target,
                         g['ambiente'].target-(5.+truth.g(x)[3])]
        for start in (np.array([8.8,1.9,2.0]),np.array([9.5,2.6,2.4]),np.array([9.,3.,3.])):
            op=minimize(v4.capital_cost,np.clip(start,base.LOW,base.HIGH),
                        method='SLSQP',bounds=list(zip(base.LOW,base.HIGH)),
                        constraints=[{'type':'ineq','fun':cons}],
                        options={'maxiter':80})
            if np.min(cons(op.x))>=-1e-4:return True
        return False
    return check(t0),check(tlast)



def oracle_dynamic(w,periods):
    """Limite superiore tecnico, senza voto e con informazione perfetta al
    periodo della decisione, NON nel futuro. Risolve nuovo piano a ogni shock.
    I target non sono cambiati. Non rappresenta una democrazia reale.
    """
    g=w['goals']
    if len(g)<2:return dict(dynamic_oracle_success=0,dynamic_oracle_gap=float('nan'))
    state=base.STATUS_QUO.copy();plan=state.copy()
    for t in range(periods):
        truth=as_model(w['theta'][t])
        if t==0 or (t>0 and not np.array_equal(w['theta'][t],w['theta'][t-1])):
            def con(x):
                return np.r_[-truth.g(x),x[0]-g['alloggi'].target,
                          g['ambiente'].target-(5.+truth.g(x)[3])]
            solutions=[]
            for start in (np.array([8.8,1.8,1.8]),np.array([9.4,2.6,2.1]),
                          np.array([9.0,2.4,2.8])):
                op=minimize(v4.capital_cost,np.clip(start,base.LOW,base.HIGH),
                            method='SLSQP',bounds=list(zip(base.LOW,base.HIGH)),
                            constraints=[{'type':'ineq','fun':con}],
                            options={'maxiter':90})
                if np.min(con(op.x))>=-1e-4:
                    solutions.append((v4.capital_cost(op.x),op.x))
            if solutions:
                plan=min(solutions,key=lambda item:item[0])[1]
        state=state+v4.SPEED['rapida']*(plan-state)
    gap,_=goal_gap(state,as_model(w['theta'][-1]),g)
    viol=float(np.maximum(as_model(w['theta'][-1]).g(plan),0.).max())
    return dict(dynamic_oracle_success=int(gap<=.11 and viol<=.02),
                dynamic_oracle_gap=round(gap,4),dynamic_oracle_violation=round(viol,4))


def simulate_method(w,scenario,method,periods):
    pop=w['pop'];goals=w['goals']
    if len(goals)<2:return [],[],[]
    lr=common_initial_model(w)
    fixed_model=lr.predictor()
    state=base.STATUS_QUO.copy();plan=base.STATUS_QUO.copy()
    schedule='regolare';obligations=[];actions=[];rows=[];audits=[]
    metrics=w['metrics'].copy();divergence={q:0 for q in goals}
    triggered=False;red_flags=0;last_attempt=-99;last_vote=float('nan');latest_decision='inizio'
    for t in range(periods):
        true=as_model(w['theta'][t])
        pred=fixed_model if method=='bloccato' else lr.predictor()
        must_vote=(t==0 or (method!='bloccato' and t in (3,6,9)) or
                   (method=='attivato' and triggered and t-last_attempt>=2))
        if must_vote:
            res=propose_and_vote(pop,goals,pred,lr,state,plan,t,periods,obligations)
            last_attempt=t
            last_vote=res.share
            latest_decision=res.reason
            if res.approved:
                updated_plan,enacted,capital=v4.maybe_enact(pop,{'approved':True,'bundle':res.bundle},
                                                             plan,obligations,t)
                plan=updated_plan
                if enacted:schedule=res.bundle.schedule
            actions.append(dict(seed=w['seed'],scenario=scenario,method=method,t=t+1,
                                approved=int(res.approved),reason=res.reason,
                                share=res.share,backprop_signal=res.feedback,
                                candidates=res.considered,
                                domain_weighted_votes=json.dumps(res.local_shares),
                                initial=int(t==0),event_triggered=int(triggered),
                                x=json.dumps(plan.tolist())))
            triggered=False
        # Azione reale avviene SOLO dopo la votazione; stato avanzato.
        state=state+v4.SPEED[schedule]*(plan-state)
        observation=true.g(state)+w['monitoring_noise'][t]+w['contamination'][t]
        gap,vals=goal_gap(state,true,goals)  # SOLO il valutatore conosce true
        observed_gap=0.;reported={}
        for j,(topic,g) in enumerate(goals.items()):
            metric=metrics[topic]
            measured=v3.measure(vals[topic],metric,w['metric_noise'][t,j])
            # Audit indipendente rumoroso: non usa il valore esatto nel voto.
            audited=vals[topic]+.04*np.sin(w['seed']*.01+t*1.3+j)
            reported[topic]=measured
            observed_gap+=max(0.,g.target-measured) if g.direction=='min' else max(0.,measured-g.target)
            divergence[topic]=divergence[topic]+1 if abs(measured-audited)>.20 else 0
            if divergence[topic]>=2:
                new,evt=v3.metric_vote(pop,topic,distortion=0.)
                if new is not None:metrics[topic]=new
                audits.append(dict(seed=w['seed'],scenario=scenario,method=method,t=t+1,
                                   topic=topic,metric_from=metric.name,
                                   metric_to=metrics[topic].name,
                                   expert_voters=evt.get('votanti_qualificati',0)))
                divergence[topic]=0
        expected_vals=v3.actual_values(state,pred)
        expected_gap=sum(max(0.,g.target-expected_vals[q]) if g.direction=='min'
                         else max(0.,expected_vals[q]-g.target) for q,g in goals.items())
        prior_gap=np.max(np.abs(observation-pred.g(state)))
        if method!='bloccato':
            # Osservazioni da attuazione + test/pilot indipendente ogni 2 periodi.
            lr.update(state,observation)
            if t%2==1:
                probe=AUDIT_PROBES[(t//2)%len(AUDIT_PROBES)]
                lr.update(probe,true.g(probe)+w['pilot_noise'][t])
        # L'allarme viene prodotto alla fine del periodo e può provocare soltanto
        # un voto al periodo successivo; mai accedere direttamente a true.
        if method=='attivato' and t>=1 and t+1<periods:
            # Non confrontare il progresso corrente con il TARGET FINALE:
            # è previsto uno scostamento durante una strategia pluriennale.
            # L'allarme riguarda la deviazione dalla traiettoria prevista.
            deviates=(prior_gap>.20 or observed_gap>expected_gap+.17)
            red_flags=red_flags+1 if deviates else 0
            if red_flags>=2 and t-last_attempt>=1:
                triggered=True
                red_flags=0
        true_violation=float(np.maximum(true.g(plan),0.).max())
        active_state_violation=float(np.maximum(true.g(state),0.).max())
        rows.append(dict(seed=w['seed'],scenario=scenario,method=method,t=t+1,
                         gap=gap,observed_gap=observed_gap,
                         both_goals=int(gap<=.11),
                         true_violation=true_violation,
                         state_violation=active_state_violation,
                         joint_success=int(gap<=.11 and true_violation<=.02),
                         approved_plan=int(np.linalg.norm(plan-base.STATUS_QUO)>.02),
                         x0=plan[0],x1=plan[1],x2=plan[2],
                         state0=state[0],state1=state[1],state2=state[2],
                         predicted_rmse_state=float(np.sqrt(np.mean((pred.g(state)-true.g(state))**2))),
                         last_vote=last_vote,last_decision=latest_decision,
                         outstanding_obligations=sum(o.payments[max(t+1-o.start,0):].sum()
                           for o in obligations if t+1-o.start<len(o.payments))))
    return rows,actions,audits


def run(n_worlds=12,n=300,periods=12,scenarios=SCENARIOS):
    allrows=[];votes=[];audits=[];oracles=[];agenda=[]
    for scenario in scenarios:
        for j in range(n_worlds):
            w=generate_world(j,scenario,periods,n)
            init,final=technical_oracle(w,periods)
            temporal=oracle_dynamic(w,periods)
            oracles.append(dict(seed=w['seed'],scenario=scenario,goals_approved=int(len(w['goals'])==2),
                                oracle_initial=init,oracle_final=final,**temporal,
                                goals=json.dumps({q:g.target for q,g in w['goals'].items()})))
            for ev in w['goal_events']:
                agenda.append({'seed':w['seed'],'scenario':scenario,**ev})
            for method in METHODS:
                rs,vs,a=simulate_method(w,scenario,method,periods)
                allrows.extend(rs);votes.extend(vs);audits.extend(a)
    summary=[]
    for scenario in scenarios:
        eligible=[d for d in oracles if d['scenario']==scenario and d['goals_approved']]
        for method in METHODS:
            finals=[r for r in allrows if r['scenario']==scenario and r['method']==method and r['t']==periods]
            d=[r for r in allrows if r['scenario']==scenario and r['method']==method]
            ballots=[v for v in votes if v['scenario']==scenario and v['method']==method]
            if not finals:
                summary.append(dict(scenario=scenario,method=method,worlds=0));continue
            summary.append(dict(scenario=scenario,method=method,worlds=len(finals),
                approved_goals_worlds=len(eligible),
                success_pct=round(100*np.mean([r['joint_success'] for r in finals]),1),
                goals_pct=round(100*np.mean([r['both_goals'] for r in finals]),1),
                mean_gap_final=round(float(np.mean([r['gap'] for r in finals])),3),
                mean_violation_final=round(float(np.mean([r['true_violation'] for r in finals])),3),
                mean_cumulative_gap=round(float(np.mean([sum(q['gap'] for q in d if q['seed']==r['seed'])
                                                          for r in finals])),3),
                approval_pct=round(100*np.mean([v['approved'] for v in ballots]),1) if ballots else 0,
                votes=len(ballots),
                no_approval=sum(r['approved_plan']==0 for r in finals),
                mean_prediction_error=round(float(np.mean([r['predicted_rmse_state'] for r in d])),3)))
    return allrows,votes,audits,oracles,agenda,summary


def write_csv(p,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with open(p,'w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows(rows)


def plot(rows,out,scenarios):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for scenario in scenarios:
        plt.figure(figsize=(9,5))
        for method in METHODS:
            subset=[r for r in rows if r['scenario']==scenario and r['method']==method]
            if not subset:continue
            x=sorted(set(r['t'] for r in subset))
            y=[np.mean([r['gap'] for r in subset if r['t']==t]) for t in x]
            plt.plot(x,y,marker='o',label=method)
        plt.xlabel('Periodo');plt.ylabel('Scostamento dai target originali (unità sintetiche)')
        plt.title('Retropropagazione attuativa: '+scenario);plt.grid(alpha=.2)
        plt.legend();plt.tight_layout()
        plt.savefig(out/f'andamento_{scenario}.png',dpi=160);plt.close()


def tests():
    rng=np.random.default_rng(47)
    pop=v3.build_electorate(rng,300,'stabile')
    assert np.std(v3.weights(pop,'strategia')[0])>.01
    assert np.std(v3.weights(pop,'alloggi')[0])>.01
    # Weighted ballot must differ from equal headcount.
    tiny=v3.Electorate(np.array([[1]*4,[.1]*4,[.1]*4],dtype=float),
                      np.array([0,0,0]),np.zeros(3),np.ones(3))
    assert v3.fraction(tiny,'strategia',[True,False,False])[0]>.5
    for sc in ('stabile','shock'):
        w=generate_world(1,sc,12,300)
        assert len(w['goals'])==2, f'Gli obiettivi non passano per {sc}'
        for m in w['metrics'].values():
            assert w['pop'].competence[m.proposer,m.domain]>=.65
        assert np.array_equal(w['theta'][0],w['theta'][1])
        if sc=='shock': assert not np.array_equal(w['theta'][0],w['theta'][-1])
        a=common_initial_model(w)
        assert np.all(np.isfinite(a.mu))
        original={k:v.target for k,v in w['goals'].items()}
        simulate_method(w,sc,'attivato',12)
        assert original=={k:v.target for k,v in w['goals'].items()}
    assert np.allclose(v4.schedule_payments(10,'regolare'),
                       v4.SCHEDULES['regolare']*10*(1+v4.INTEREST)**np.arange(6))
    print('V7 test: voti ponderati, metriche esperti, shock, controlli di integrità, costi OK')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--test',action='store_true')
    p.add_argument('--mondi',type=int,default=12)
    p.add_argument('--cittadini',type=int,default=300)
    p.add_argument('--periodi',type=int,default=12)
    p.add_argument('--scenari',nargs='*',choices=SCENARIOS,default=list(SCENARIOS))
    p.add_argument('--output',type=Path,default=HERE/'risultati')
    a=p.parse_args()
    if a.test:tests();return
    a.output.mkdir(parents=True,exist_ok=True)
    out=run(a.mondi,a.cittadini,a.periodi,a.scenari)
    for path,data in zip(['periodi.csv','voti.csv','audit_metriche.csv','fattibilita_ideale.csv',
                          'agenda_e_obiettivi.csv','riepilogo.csv'],out):
        write_csv(a.output/path,data)
    plot(out[0],a.output,a.scenari)
    (a.output/'parametri.json').write_text(json.dumps(vars(a),default=str,indent=2),encoding='utf8')
    print(json.dumps(out[-1],indent=2,ensure_ascii=False))

if __name__=='__main__':main()