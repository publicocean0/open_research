#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V5: diagnosi causale (nel solo mondo sintetico) della Democrazia Ponderata Adattiva.

Tutte le votazioni, incluse quelle sulle strategie, sono ponderate per competenza
pertinente (funzioni V3/V4). Qui gli obiettivi sono assunti GIA' approvati:
isoliamo intenzionalmente le fasi di fattibilita', progettazione e rivoto.

Per ogni mondo:
  1. un oracolo tecnico conoscendo la verita' calcola la FRONTIERA di fattibilita';
  2. generiamo obiettivi di difficolta' crescente dalla frontiera, senza comunicarla
     ai decisori: facili, medi, vicini al limite, impossibili;
  3. V4 con conoscenza imperfetta, V4 con tecnica perfetta, V5 ricerca ampliata
     e oracolo a costo minimo producono proposte e ricevono voti ponderati;
  4. il valutatore confronta piani proposti, voti ed esiti reali.

Sono esperimenti sintetici, non misure dell'efficacia della democrazia reale.
"""
from __future__ import annotations
import argparse, csv, json, sys, time
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[0]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'v2_adattiva'))
sys.path.insert(0,str(ROOT/'v3_ponderata'))
sys.path.insert(0,str(ROOT/'v4_negoziazione'))
import simulazione as base
import simulazione_ponderata as v3
import simulazione_v4 as v4
from simulazione_adattiva import as_model

DIFFICULTY={'facile':.35,'intermedia':.72,'al_limite':.965,'impossibile':None}
METHODS=('V4_stime_imperfette','V4_informazione_perfetta','V5_ricerca_ampliata','Oracolo_costo_minimo')
ENV_TARGET=4.50
TOL_GOALS=.10
TOL_CONSTRAINTS=1.e-4
SCHEDULES=('rapida','regolare','graduale')


def terminal(plan,schedule,T=10):
    return v4.final_state(base.STATUS_QUO,plan,T,schedule)


def real_check(plan,goal_h,truth,schedule,T=10):
    xend=terminal(plan,schedule,T)
    vals=v3.actual_values(xend,truth)
    worst=float(max(np.max(truth.g(plan)),np.max(truth.g(xend))))
    goal_ok=(vals['alloggi']>=goal_h-TOL_GOALS and vals['ambiente']<=ENV_TARGET+TOL_GOALS)
    return goal_ok, worst<=TOL_CONSTRAINTS, worst, vals


def constraints(plan,truth,h,env,schedule='rapida',margin=0):
    xend=terminal(plan,schedule)
    # Explicit engineering and time-to-target constraints; no hindsight on
    # final results except in the experimental oracle by construction.
    return np.concatenate(( -truth.g(plan)-margin,
                            -truth.g(xend)-margin,
                            [xend[0]-h, env-(5+truth.g(xend)[3])]))


def optimize_model(model,h,env,objective='cost',schedule='rapida',margin=.006):
    """Multistart local SLSQP. Negative returned residual = feasible certificate.

    Failure of numerical optimization is *not* a proof of impossibility.
    """
    lohi=list(zip(base.LOW,base.HIGH))
    starts=(np.array([9.0,2.0,2.6]),np.array([8.8,2.8,2.0]),
            np.array([9.4,3.5,3.2]),np.array([h+.15,1.6,2.5]))
    def objective_fn(x):
        if objective=='capacity': return -terminal(x,schedule)[0]
        if objective=='cost':return v4.capital_cost(x)
        if objective=='water':return 1.6*x[1]**2+.62*x[2]**2+.10*(x[0]-6.2)**2
        if objective=='transport':return .64*x[1]**2+1.7*x[2]**2+.10*(x[0]-6.2)**2
        if objective=='reserve':return v4.capital_cost(x)+5*np.sum(np.maximum(model.g(x)+.10,0)**2)
        raise ValueError(objective)
    c={'type':'ineq','fun':lambda x:constraints(x,model,h,env,schedule,margin)}
    found=[]
    for start in starts:
        opt=minimize(objective_fn,np.clip(start,base.LOW,base.HIGH),
                     method='SLSQP',bounds=lohi,constraints=[c],
                     options={'maxiter':95,'ftol':1e-7})
        x=np.clip(opt.x,base.LOW,base.HIGH)
        if np.min(constraints(x,model,h,env,schedule,margin))>=-2.e-4:
            found.append((objective_fn(x),x))
    if found:return min(found,key=lambda z:z[0])[1]
    return None


def frontier(truth):
    """Upper housing frontier under real technical constraints + env goal.
    For this concave/convex test landscape, multistart SLSQP is checked
    by slack feasibility. The result is an experimental numerical reference,
    not a universal mathematical proof.
    """
    upper=[]
    for sched in SCHEDULES:
        lohi=list(zip(base.LOW,base.HIGH))
        cons=[{'type':'ineq', 'fun':lambda z,sched=sched: np.concatenate([
                 -truth.g(z),-truth.g(terminal(z,sched)),
                 [ENV_TARGET-(5+truth.g(terminal(z,sched))[3])]])}]
        for start in (np.array([9.,2.,2.]), np.array([9.,3.,3.]),
                      np.array([8.3,1.4,2.5])):
            op=minimize(lambda z,sched=sched: -terminal(z,sched)[0],
                        start,bounds=lohi,method='SLSQP',constraints=cons,
                        options={'maxiter':130,'ftol':2e-9})
            x=np.clip(op.x,base.LOW,base.HIGH)
            if np.min(cons[0]['fun'](x))>=-1.e-4:
                upper.append((terminal(x,sched)[0],x,sched))
    if not upper:raise RuntimeError('Frontiera numerica non trovata: non dichiarare impossibilita')
    return max(upper,key=lambda z:z[0])


def propose_extended(estimate,h):
    """Add alternative cost/environment tradeoffs with imperfect data ONLY."""
    plans=[]
    for sched in ('rapida','regolare','graduale'):
      for objective in ('cost','water','transport','reserve'):
        x=optimize_model(estimate,h,ENV_TARGET,objective,sched,margin=.02)
        if x is not None and not any(np.linalg.norm(x-p)<1.e-3 for p in plans):plans.append(x)
    return plans


def candidate_groups(pop):
    # Financial redistribution remains zero-sum; no assumed free transfers.
    return v4.candidate_groups(pop,'negotiation')


def evaluate_method(pop,truth,estimated,h,method,periods):
    goals={'alloggi':v3.Goal('alloggi',h,'min',periods),
           'ambiente':v3.Goal('ambiente',ENV_TARGET,'max',periods)}
    if method=='Oracolo_costo_minimo':
        # Perfect technical information + ideal numerical candidate generator.
        plans=[optimize_model(truth,h,ENV_TARGET,'cost',s,margin=.006)
               for s in SCHEDULES]
        model=truth
    else:
        model=truth if method=='V4_informazione_perfetta' else estimated
        # Replicate V4's candidate search including its true-domain backprop anchor.
        anchor=np.array([max(h+.55,9.2),.28,.48]); anchor=np.clip(anchor,base.LOW,base.HIGH)
        for k in range(4):
            err=max(0.,float(model.g(anchor)[k]))
            b=model.jac(anchor)[k]*err
            if np.linalg.norm(b)>1e-10:
                anchor=np.clip(anchor-.30*b/(np.linalg.norm(b)+1e-12),base.LOW,base.HIGH)
        plans=v4.candidate_plans(goals,model,None,anchor)
        if method=='V5_ricerca_ampliata':plans+=propose_extended(model,h)
    plans=[np.asarray(p) for p in plans if p is not None]
    dedup=[]
    for p in plans:
        if all(np.linalg.norm(p-z)>1e-3 for z in dedup):dedup.append(p)
    plans=dedup
    # Voter is not allowed to see the true model unless arm has perfect info.
    evaluated=[]
    rejected=0;accepted=0;screened=0;true_feasible_proposals=0
    true_feasible_votable=0;true_feasible_approved=0
    best_possible_vote=-1.
    for plan in plans:
      for sched in SCHEDULES:
        if not v4.predicted_acceptable(plan,goals,model,base.STATUS_QUO,periods,sched):
            # V4's technical filter is used unchanged except for the planner's
            # imperfect/perfect information choice.
            continue
        screened+=1
        real_goal,real_tech,_,_=real_check(plan,h,truth,sched,periods)
        real_ok=real_goal and real_tech
        if real_ok:true_feasible_proposals+=1
        for relief_group,relief in candidate_groups(pop):
            bundle=v4.Bundle(plan,sched,relief_group,relief,'v5')
            share=v4.fraction_for_bundle(pop,model,goals,bundle,base.STATUS_QUO,
                base.STATUS_QUO,0,periods,[],mode='forward')
            best_possible_vote=max(best_possible_vote,share)
            if real_ok:true_feasible_votable+=1
            if share>.50:
                accepted+=1
                if real_ok:true_feasible_approved+=1
                evaluated.append((v4.finance_equity_score(pop,bundle,base.STATUS_QUO),
                                  bundle,share,real_ok))
            else:rejected+=1
    if evaluated:
        _,chosen,chosen_share,chosen_real_ok=min(evaluated,key=lambda t:t[0])
        real_goal,real_tech,violation,vals=real_check(chosen.x,h,truth,chosen.schedule,periods)
        status=('successo' if real_goal and real_tech else
                'vincolo_reale_violato' if not real_tech else 'obiettivo_non_raggiunto')
        selected_plan=chosen.x.tolist()
        chosen_schedule=chosen.schedule
    else:
        chosen_share=float('nan');violation=float('nan');selected_plan=[]
        chosen_schedule='';status=('nessuna_proposta_tecnica' if not screened else 'voto_respinto')
        real_goal=False;real_tech=False
    return dict(method=method,status=status,generated=len(plans),screened=screened,
        proposed_true_feasible=int(true_feasible_proposals>0),
        true_feasible_votable_count=true_feasible_votable,
        true_feasible_approved_count=true_feasible_approved,
        weighted_approved=int(accepted>0),approved_candidates=accepted,
        rejected_candidates=rejected,success=int(status=='successo'),
        chosen_weighted_share=round(chosen_share,5),best_weighted_share=round(best_possible_vote,5),
        violation=violation,selected_schedule=chosen_schedule,selected_plan=str(selected_plan),
        goal_ok=int(real_goal),technical_ok=int(real_tech))


def one_world(seed,periods,competence_n):
    # Separate RNG streams: SAME technical world across both electorates.
    rng_world=np.random.default_rng(seed+920_000)
    theta,panel=v3.make_world(rng_world,periods,'stabile')
    truth=as_model(theta[0]);estimated=as_model(panel)
    hmax,front_x,front_sched=frontier(truth)
    hmin=7.20
    if hmax<hmin+.5:raise RuntimeError('Imprevista frontiera troppo vicina al minimo')
    # For each technical world, create two contrasting electorates of the
    # same size, but NEVER alter the engineering challenge or proposed goals.
    out=[]
    for public_scenario in ('cooperativo','conflittuale'):
      electorate_rng=np.random.default_rng(seed+ (200_000 if public_scenario=='cooperativo' else 400_000))
      pop=v3.build_electorate(electorate_rng,competence_n,
                              'stabile' if public_scenario=='cooperativo' else 'conflitto')
      for level,q in DIFFICULTY.items():
        h=(hmin+q*(hmax-hmin)) if q is not None else hmax+.30
        oracle_x=(optimize_model(truth,h,ENV_TARGET,'cost',front_sched,margin=.002)
                  if level!='impossibile' else None)
        if level!='impossibile' and oracle_x is None:
            # Feasible frontier witness, even if a separate cost optimization
            # gets stuck in a local minimum.
            oracle_x=front_x
        witness_ok=False
        if oracle_x is not None:
            check=real_check(oracle_x,h,truth,front_sched,periods)
            witness_ok=check[0] and check[1]
        oracle_feasible=int(witness_ok)
        if level!='impossibile' and not witness_ok:
            raise AssertionError('Calibrated feasible case has no valid witness: '+str((seed,level)))
        if level=='impossibile' and h-hmax<=TOL_GOALS+.03:
            raise AssertionError('Impossible goal too close to permissive tolerance')
        for method in METHODS:
            result=evaluate_method(pop,truth,estimated,h,method,periods)
            result.update(seed=seed,electorate=public_scenario,difficulty=level,
                goal_h=round(h,5),environment_target=ENV_TARGET,
                frontier_h=round(hmax,5),oracle_feasible=oracle_feasible,
                model_discrepancy=round(float(np.sqrt(np.mean((truth.g(front_x)-estimated.g(front_x))**2))),5))
            out.append(result)
    return out


def summarize(rows):
    out=[]
    for electorate in ('cooperativo','conflittuale'):
      for difficulty in DIFFICULTY:
        for method in METHODS:
            group=[r for r in rows if r['difficulty']==difficulty
                   and r['method']==method and r['electorate']==electorate]
            if not group:continue
            n=len(group)
            def pc(field):return round(100*sum(int(r[field]) for r in group)/n,1)
            status={k:sum(r['status']==k for r in group) for k in
                    ['successo','nessuna_proposta_tecnica','voto_respinto',
                     'vincolo_reale_violato','obiettivo_non_raggiunto']}
            out.append(dict(electorate=electorate,difficulty=difficulty,method=method,worlds=n,
                 oracle_feasible_pct=pc('oracle_feasible'),
                 has_screened_plan_pct=round(100*sum(r['screened']>0 for r in group)/n,1),
                 found_true_feasible_pct=pc('proposed_true_feasible'),
                 voted_yes_pct=pc('weighted_approved'),
                 true_feasible_approved_pct=round(100*sum(r['true_feasible_approved_count']>0 for r in group)/n,1),
                 success_pct=pc('success'),
                 **{'n_'+k:v for k,v in status.items()}))
    return out


def write_csv(path,rows):
    if not rows:return
    with open(path,'w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)


def plot(summary,output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    levels=list(DIFFICULTY)
    for electorate in ('cooperativo','conflittuale'):
      for name,field in [('risultato_finale','success_pct'),('trovare_piani_fattibili','found_true_feasible_pct')]:
        plt.figure(figsize=(10,5.4))
        positions=np.arange(len(levels));width=.19
        for j,method in enumerate(METHODS):
            vals=[next(s[field] for s in summary if s['difficulty']==level
                 and s['method']==method and s['electorate']==electorate) for level in levels]
            plt.bar(positions+(j-1.5)*width,vals,width,label=method.replace('_',' '))
        plt.xticks(positions,levels)
        plt.ylim(0,105);plt.ylabel('Percentuale dei mondi (%)')
        plt.title('V5 — '+('successo reale' if name=='risultato_finale' else 'almeno un piano realmente fattibile')+' — '+electorate)
        plt.legend(fontsize=7,loc='upper right');plt.tight_layout()
        plt.savefig(output/(name+'_'+electorate+'.png'),dpi=160);plt.close()


def self_test():
    rng=np.random.default_rng(40)
    pop=v3.build_electorate(rng,300,'stabile')
    for topic in ['alloggi','ambiente','strategia']:
        weights,_=v3.weights(pop,topic)
        assert (weights>0).all() and np.std(weights)>0
    assert all(abs(np.sum(v4.SCHEDULES[s])-1)<1.e-10 for s in SCHEDULES)
    for rel in range(4):
        fractions=v4.distribution(pop,rel,.35)
        freq=np.bincount(pop.group,minlength=4)/len(pop)
        assert abs(float(np.dot(freq,fractions))-1)<1.e-10
    assert len(DIFFICULTY)==4
    v4.selftest()
    print('Test V5: competenza, redistribuzione, scadenze e controlli di integrità V4 OK')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--mondi',type=int,default=36)
    ap.add_argument('--offset',type=int,default=0,help='indice iniziale dei mondi per batch riproducibili')
    ap.add_argument('--cittadini',type=int,default=300)
    ap.add_argument('--periodi',type=int,default=10)
    ap.add_argument('--output',type=Path,default=HERE/'risultati')
    args=ap.parse_args()
    if args.test:self_test();return
    args.output.mkdir(parents=True,exist_ok=True)
    rows=[]
    started=time.monotonic()
    for j in range(args.mondi):
        seed=1000+37*(j+args.offset)
        rows.extend(one_world(seed,args.periodi,args.cittadini))
        if (j+1)%6==0:
            print(f'{j+1}/{args.mondi} mondi, tempo {time.monotonic()-started:.1f}s',flush=True)
    summary=summarize(rows)
    write_csv(args.output/'dettaglio_mondi.csv',rows)
    write_csv(args.output/'riepilogo.csv',summary)
    (args.output/'riepilogo.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf8')
    plot(summary,args.output)
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    print('TOTAL TIME',round(time.monotonic()-started,2))

if __name__=='__main__':main()