# Democrazia Ponderata Adattiva — V5 (diagnostica delle cause)

## Domanda testata

La percentuale di successo **58,3%** della V4 non permette di attribuire gli insuccessi a una causa unica. Il presente esperimento scompone, in condizioni sintetiche controllate:

1. **Fattibilità numerica**: esiste un piano che rispetti gli obiettivi e i vincoli effettivi?
2. **Scoperta tecnica**: l'algoritmo individua almeno un piano realmente fattibile, partendo da previsioni imperfette?
3. **Approvazione ponderata**: almeno un piano supera il voto pesato per competenza pertinente?
4. **Realizzazione**: il piano scelto con il voto, se attuato secondo la dinamica sintetica, raggiunge i target senza violare i vincoli reali?

Non si ricalcola il risultato V4 del 58,3%: **questa è una prova differente**, costruita per isolare le cause. Le percentuali V5 non vanno confrontate direttamente con quelle V4.

## Disegno sperimentale

- **36 mondi tecnici** indipendenti nei parametri sintetici, con le stesse realizzazioni nei metodi confrontati.
- **2 elettorati** per ogni mondo, 300 cittadini ciascuno: uno bilanciato nei gruppi (`cooperativo`), uno con forte concentrazione di interessi economici (`conflittuale`). Gli obiettivi e i vincoli tecnici sono *identici* nei due elettorati.
- **4 difficoltà** per mondo, calibrate da una frontiera di fattibilità ricavata dall'oracolo tecnico. Il target ecologico resta 4,50 (unità sintetiche); il target abitativo è il 35%, 72% o 96,5% del tratto dal riferimento 7,20 alla massima capacità del mondo; il caso impossibile supera la massima capacità di 0,30, ben oltre la tolleranza di accettazione di 0,10.
- **10 periodi** di attuazione sintetici; il presente test mantiene i parametri fisici stabili. Non testa shock, riapertura degli obiettivi e apprendimento su osservazioni successive.
- **4 metodi** sullo stesso caso: V4 con stime imperfette; V4 con informazioni tecniche perfette (controfattuale); V5 con più alternative ma stime imperfette; benchmark che cerca un piano a costo minimo con informazioni perfette. Persino il benchmark è sottoposto al **voto ponderato**.
- **1.152 valutazioni di metodo** (=36 mondi × 2 elettorati × 4 difficoltà × 4 metodi).

**Come vengono assegnati i voti:** il simulatore richiama direttamente `v3.fraction` e `v3.weights`, con pesi diversi per materia e cittadino. Le alternative e la decisione finale seguono le funzioni di voto ponderato `v4.fraction_for_bundle`. Nessuna votazione torna a un modello di voto uguale per tutti. La fase 1 (proposta, selezione, votazione degli obiettivi e metriche) è **assunta già conclusa** per isolare qui la scelta delle strategie; rimane implementata nei sorgenti V3/V4.

### Le quattro metriche di diagnosi

La fattibilità **non** è equiparata all'approvazione. Nel CSV:

- `oracle_feasible`: esiste un testimone ottenuto numericamente con dati veri, entro il termine.
- `proposed_true_feasible`: almeno una proposta sopravvive al filtro delle stime e, all'insaputa dei decisori, è anche realmente fattibile.
- `weighted_approved`: almeno una delle proposte supera un voto ponderato; può essere basata su stime errate.
- `success`: **la proposta selezionata** è approvata e raggiunge realmente target e vincoli.

La selezione finale considera tra i pacchetti approvati quello con minore indice finanziario sintetico. Più proposte non garantiscono un miglior risultato: con stime sbagliate possono aumentare la probabilità di scegliere una falsa soluzione fattibile.

## Risultati aggregati (36 mondi per riga)

### Elettorato bilanciato

| Difficoltà | Fattibile per oracolo | V4 stime imperfette | V4 conoscenza perfetta | V5 alternative ampliate | Benchmark oracolo |
|---|---:|---:|---:|---:|---:|
| Facile | 100% | 30,6% | 97,2% | 25,0% | 97,2% |
| Intermedia | 100% | 33,3% | 100% | 30,6% | 100% |
| Al limite | 100% | 2,8% | 86,1% | 5,6% | 100% |
| Impossibile | 0% | 0% | 0% | 0% | 0% |

### Elettorato fortemente conflittuale

| Difficoltà | Fattibile per oracolo | V4 stime imperfette | V4 conoscenza perfetta | V5 alternative ampliate | Benchmark oracolo |
|---|---:|---:|---:|---:|---:|
| Facile | 100% | 2,8% | 5,6% | 2,8% | 5,6% |
| Intermedia | 100% | 2,8% | 5,6% | 2,8% | 5,6% |
| Al limite | 100% | 0% | 5,6% | 0% | 5,6% |
| Impossibile | 0% | 0% | 0% | 0% | 0% |

Nell'elettorato conflittuale perfino il benchmark tecnico con votazione ponderata viene respinto in **34 casi su 36**. Non significa che sia così nella realtà: riflette direttamente le regole sintetiche di conflitto e voto impostate dal modello.

### Esempi di attribuzione degli insuccessi

- `cooperativo, facile, V4_stime_imperfette`: **11/36** successi; **17** piani selezionati violano vincoli effettivi; **3** non raggiungono gli obiettivi; **5** sono respinti dal voto.
- `cooperativo, al_limite, V4_informazione_perfetta`: **31/36** successi, **5** casi senza proposte tecniche sufficienti. Qui il problema residuo è nel generatore di strategie, non nelle conoscenze o nelle votazioni del caso.
- `conflittuale, facile, Oracolo_costo_minimo`: **2/36** successi, **34** rifiuti al voto nonostante la possibilità tecnica.
- `cooperativo, impossibile, V4_stime_imperfette`: **3/36** casi approvano erroneamente una strategia che non raggiunge il risultato. Questo segnala un rischio di false rassicurazioni da stime errate.

## Limiti e avvertenze

- **Non è una validazione empirica** del sistema democratico; non ci sono dati sociali reali, verifiche sulle competenze certificate o distribuzioni di preferenze osservate.
- Il sistema artificiale definisce una politica con 3 variabili e 4 vincoli; gli esseri umani non possono essere rappresentati in questo modo senza forti approssimazioni.
- Gli obiettivi sono calibrati utilizzando la verità del mondo sintetico **soltanto per la costruzione del test**; non è una procedura realistica per fissare obiettivi politici.
- Il caso `impossibile` è attestato rispetto a una **frontiera numerica** di un particolare modello, non costituisce un teorema generale d'impossibilità in ogni modello.
- Il termine `cooperativo` è solo un'etichetta per l'elettorato bilanciato; non indica altruismo o consenso reale.
- L'informazione perfetta è un **controfattuale conoscitivo** reso disponibile anche ai votanti, non solo al risolutore: il suo miglioramento non isola il solo contributo del software di ottimizzazione.
- Il test dura un ciclo di scelta + attuazione decennale senza rivoti intermedi: isola la catena causale, mentre la V4 completa include più decisioni e apprendimento. Evitare confronti percentuali diretti.
- Il campione è di 36 mondi, non sufficiente a generalizzare; percentuali di 2,8 punti rappresentano **un solo mondo**.
- La scelta ottimizzata a costo minimo potrebbe non rappresentare compensazioni sociali davvero accettabili: la media ponderata e il veto dipendono dal modello di preferenze simulato.

## Come riprodurre

Richiede Python 3.10+, `numpy`, `scipy`, `matplotlib`. La struttura in archivio deve rimanere:

```
democrazia-ponderata-adattiva/
  simulazione.py
  v2_adattiva/simulazione_adattiva.py
  v3_ponderata/simulazione_ponderata.py
  v4_negoziazione/simulazione_v4.py
  v5_diagnostica/simulazione_v5.py
```

Eseguire dalla root `democrazia-ponderata-adattiva`:

```bash
python v5_diagnostica/simulazione_v5.py --test
python v5_diagnostica/simulazione_v5.py --mondi 36 --cittadini 300 --periodi 10
```

È possibile suddividere in blocchi riproducibili con `--mondi 12 --offset 0`, poi `--offset 12` e `--offset 24`, e unire `dettaglio_mondi.csv`. Le generazioni usano seed deterministici.

## File dei risultati

- `risultati/dettaglio_mondi.csv`: analisi di tutte le 1152 valutazioni, con cause di fallimento e indice di errore del modello.
- `risultati/riepilogo.csv` e `.json`: aggregati.
- `risultati/confronti_accoppiati.csv`: numero dei mondi in cui ogni intervento migliora o peggiora rispetto a un altro, a parità di caso sintetico.
- `risultati/risultato_finale_cooperativo.png` e `risultato_finale_conflittuale.png`: grafici delle approvazioni effettivamente fattibili.
- `risultati/trovare_piani_fattibili_*.png`: grafici delle soluzioni realmente identificate prima delle votazioni.

## Conclusione tecnica

In questo sistema sintetico tre colli di bottiglia sono distinguibili:

- **Qualità delle previsioni**: in elettorati bilanciati, dare agli agenti la conoscenza vera aumenta fortemente la riuscita anche a parità di metodo V4.
- **Ricerca delle strategie**: vicino alla frontiera, il risolutore V4 non trova sempre candidati anche con conoscenza esatta.
- **Conflitto deliberativo**: con elettorati ad alta concentrazione di interessi, le soluzioni fattibili possono restare sistematicamente prive dell'approvazione necessaria.

Aumentare indiscriminatamente il numero di alternative non è una cura: serve migliorare stima dell'incertezza, certificazione di fattibilità, ricerca robusta e meccanismi di negoziazione sottoposti a voto ponderato.