#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V15 – scelta marginale della flessibilita + monitoraggio rumoroso.

Esperimento solo sintetico. Target e voti sugli obiettivi/metriche assunti approvati;
voti sulle strategie e sulle modifiche fuori mandato pesati per competenza.
Prima del voto il programmatore conosce storici sintetici, mai lo shock futuro.
La stessa misura rumorosa e' usata dai diversi metodi nel confronto accoppiato.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from dataclasses import replace
from functools import lru_cache
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'v14_riserva_settoriale'))
import simulazione_v14 as v14
v13=v14.v13;v12=v14.v12;p=v14.p;v11=v14.v11

METHODS=('V14_globale','V14_settoriale','V15_marginale','V15_marginale_due_sensori','V15_marginale_con_soglia')
SHOCKS=v14.TEST_SCENARIOS
STRENGTHS=(None,.12,.32,.50) # None = globale; valori numerici = restrizioni settoriali
STABLE_PROB=.60
MEASUREMENT_STD=(0.,.08,.18)
TRAIN_SAMPLE=140

@lru_cache(maxsize=1)
def risk_training():
    return v14.synthetic_training(320,seed=83171)

@lru_cache(maxsize=1)
def risk_validation():
    # Eventi storici mai usati per costruire proxy_stress/covarianza.
    return v14.synthetic_training(TRAIN_SAMPLE,seed=165432)

@lru_cache(maxsize=10)
def trained_risk(strength):
    return v14.learn_risk(risk_training(),reserve_strength=.32 if strength is None else strength)


def select_candidates(seed, conflict=False):
    # Tutti i candidati sono votati prima della selezione, nello stesso elettorato.
    candidates={}
    for strength in STRENGTHS:
        risk=trained_risk(strength)
        method='V14_shock_appreso' if strength is None else 'V14_riserva_settoriale'
        world,prod0,policy,reason=v14.choose_policy(seed,method,risk,conflict)
        candidates[strength]=(world,prod0,policy,reason)
    return candidates


def evaluate_training_score(world,prod0,policy,historical,success_weight=.72):
    """Valuta piano su episodi passati, senza recupero e senza sensori futuri.

    Criterio: probabilita' storica di fattibilita' ex-ante + servizio erogato.
    L'ipotetica scelta di ramo dipende dalle produttivita' note NEGLI STORICI,
    non dall'esito del mondo di valutazione.
    """
    if policy is None:return -1e9
    fee=v11.transfer_admin(world,policy.transfer)
    proxy=prod0*trained_risk(None).proxy_stress
    usable=[]
    for factor in historical:
        prod=prod0*factor
        branch=choose_branch(prod,prod0,proxy,trained_risk(None).probability)
        plan=policy.stressed if branch=='shock' else policy.normal
        complete=float(v13.actually_feasible(plan,prod,fee))
        service=float(v13.intermediate_benefit(plan,prod))
        # Avere la soluzione con vincoli rispettati resta prioritario.
        usable.append(success_weight*complete+(1-success_weight)*service)
    return float(np.mean(usable))


def choose_policy_from_history(candidates):
    historical=risk_validation()
    # Policy selection based on observed past episodes rather than future truth.
    scores={}
    for strength,(world,prod0,policy,_reason) in candidates.items():
        scores[strength]=evaluate_training_score(world,prod0,policy,historical)
    best=max(STRENGTHS,key=lambda k:scores[k])
    return best, scores


def choose_branch(estimated,normal,proxy,shock_prior=.35):
    # Simple fixed discrimination rule, NOT an oracle on actual performance.
    a=np.linalg.norm((estimated-normal)/np.maximum(normal,.25))
    b=np.linalg.norm((estimated-proxy)/np.maximum(normal,.25))
    # Slight preference for the stable branch to avoid overreacting to noise.
    return 'shock' if b+.055<a else 'normal'


def observation(prod,seed,scenario,sd,sensor=0):
    # Deterministic common random numbers for all methods.
    scenario_id=list(SHOCKS).index(scenario)
    rng=np.random.default_rng(9_718_321+1009*seed+101*scenario_id+sensor)
    return np.clip(prod+rng.normal(0,sd,size=p.K),.10,1.45)


def evaluate(world,prod0,policy,truth_factor,estimated,risk,noise_sd=0.0,confidence_gate=False):
    """Strict information boundary: truth used ONLY for final audit.

    The technical solver and votes use estimated productivity only. The first two
    periods are immutable. Any new candidate triggers a competence-weighted vote.
    """
    true=prod0*truth_factor
    if policy is None:
        return dict(approved=0,success=0,revised=0,revote_required=0,
                    revote_approved=0,service=0.,gap=float(p.TARGET_ENERGY+p.TARGET_CO2),
                    constraints_ok=1,initial_branch='none',branch_true_ok=0,
                    measurements_disagree=0,early_spend=0.,confidence_deferred=0)
    fee=v11.transfer_admin(world,policy.transfer)
    proxy=prod0*risk.proxy_stress
    raw_selected=choose_branch(estimated,prod0,proxy,risk.probability)
    # Confidence gate: do not replace the stable mandate with a noisy alarm.
    # If the reading is consistent with stable productivity (within 2.4 sigma
    # in normalized Euclidean distance), keep normal plan and do not propose
    # revisions. This may miss small real shocks: evaluated explicitly.
    z=float(np.linalg.norm((estimated-prod0)/np.maximum(prod0,0.25)))
    threshold=max(0.045,2.4*noise_sd/np.sqrt(2.0)) if confidence_gate else 0.0
    not_confirmed=bool(confidence_gate and z<threshold)
    selected='normal' if not_confirmed else raw_selected
    branch=policy.stressed if selected=='shock' else policy.normal
    # Avoid hindsight: initial branch assessed only under observations.
    estimated_ok=v13.actually_feasible(branch,estimated,fee)
    final=branch.copy()
    revote_required=0;revote_approved=0
    if not estimated_ok and not not_confirmed:
        prefix=np.zeros_like(branch);prefix[:v12.PREFIX]=branch[:v12.PREFIX]
        candidate=v13.fast_recovery(estimated,prefix,branch)
        if (candidate is not None and np.allclose(candidate[:v12.PREFIX],prefix[:v12.PREFIX],atol=1e-10)
                and v13.actually_feasible(candidate,estimated,fee)):
            revote_required=1
            # Ex-ante vote, based on measured/estimated constraints.
            revote_approved=int(v11.vote(world,candidate,estimated,policy.transfer)>.5)
            if revote_approved:final=candidate
    assert np.array_equal(final[:v12.PREFIX],branch[:v12.PREFIX])
    m=p.indicators(final,true)
    budget=(m['spesa_totale']+fee<=p.TOTAL_BUDGET+v12.TOL and
            np.max(m['spesa_periodo'])<=p.PERIOD_BUDGET+v12.TOL and
            m['spesa_periodo'][0]+fee<=p.PERIOD_BUDGET+v12.TOL)
    constraints_ok=bool(budget and m['stress_rete']<=p.STRESS_LIMIT+v12.TOL)
    goals=bool(m['energia']>=p.TARGET_ENERGY-v12.TOL and m['emissioni_evitate']>=p.TARGET_CO2-v12.TOL)
    success=int(constraints_ok and goals)
    return dict(approved=1,success=success,revised=int(revote_approved),
                revote_required=revote_required,revote_approved=revote_approved,
                service=round(float(v13.intermediate_benefit(final,true)),5),
                gap=round(float(max(0.,p.TARGET_ENERGY-m['energia'])+max(0.,p.TARGET_CO2-m['emissioni_evitate'])),5),
                constraints_ok=int(constraints_ok),initial_branch=selected,
                branch_true_ok=int(v13.actually_feasible(branch,true,fee)),
                measurements_disagree=int(not estimated_ok and v13.actually_feasible(branch,true,fee)),
                early_spend=round(float(np.sum((final@p.COSTS)[:v12.PREFIX])),5),
                confidence_deferred=int(not_confirmed and not estimated_ok))


def simulate_seed(seed,scenario,sd=0.,conflict=False):
    candidates=select_candidates(seed,conflict)
    best,scores=choose_policy_from_history(candidates)
    truth_factor=SHOCKS[scenario]
    # Same underlying world & real shock across methods.
    prod0=candidates[None][1];true=prod0*truth_factor
    sensor_a=observation(true,seed,scenario,sd,0)
    sensor_b=observation(true,seed,scenario,sd,1)
    fused=(sensor_a+sensor_b)/2.
    rows=[]
    chosen={'V14_globale':None,'V14_settoriale':.32,
            'V15_marginale':best,'V15_marginale_due_sensori':best,
            'V15_marginale_con_soglia':best}
    for method in METHODS:
        strength=chosen[method]
        world,prod0,policy,reason=candidates[strength]
        fusion=method in ('V15_marginale_due_sensori','V15_marginale_con_soglia')
        measurement=fused if fusion else sensor_a
        result=evaluate(world,prod0,policy,truth_factor,measurement,trained_risk(strength),
                        noise_sd=sd,confidence_gate=(method=='V15_marginale_con_soglia'))
        result.update(seed=seed,scenario=scenario,noise=sd,method=method,
                      chosen_strength='global' if strength is None else strength,
                      training_score=round(scores[strength],5),
                      historical_shocks=len(risk_validation()),
                      selected_model_approved=int(policy is not None),
                      initial_reason=reason)
        rows.append(result)
    return rows


def summarise(rows):
    result=[]
    keys=sorted({(r['scenario'],r['noise'],r['method']) for r in rows})
    for scenario,noise,method in keys:
        q=[r for r in rows if (r['scenario'],r['noise'],r['method'])==(scenario,noise,method)]
        result.append(dict(scenario=scenario,noise=noise,method=method,n=len(q),
                           approved=sum(r['approved'] for r in q),
                           success=sum(r['success'] for r in q),
                           success_pct=round(100*np.mean([r['success'] for r in q]),1),
                           revotes=sum(r['revote_required'] for r in q),
                           revotes_approved=sum(r['revote_approved'] for r in q),
                           false_alarms=sum(r['measurements_disagree'] for r in q),
                           deferred=sum(r['confidence_deferred'] for r in q),
                           mean_service=round(float(np.mean([r['service'] for r in q])),4),
                           mean_gap=round(float(np.mean([r['gap'] for r in q])),4),
                           early_spend=round(float(np.mean([r['early_spend'] for r in q])),4)))
    return result


def paired_ci(rows,scenario,noise,reference='V14_globale',other='V15_marginale',rep=3000):
    a={r['seed']:r['success'] for r in rows if r['scenario']==scenario and r['noise']==noise and r['method']==reference}
    b={r['seed']:r['success'] for r in rows if r['scenario']==scenario and r['noise']==noise and r['method']==other}
    d=np.array([b[k]-a[k] for k in sorted(a)])
    rng=np.random.default_rng(200015)
    boot=np.mean(rng.choice(d,size=(rep,len(d)),replace=True),axis=1)
    return dict(scenario=scenario,noise=noise,reference=reference,other=other,n=len(d),
                delta_pp=round(100*float(np.mean(d)),2),
                ci_low_pp=round(float(np.quantile(boot,.025))*100,2),
                ci_high_pp=round(float(np.quantile(boot,.975))*100,2),
                wins=int(np.sum(d>0)),losses=int(np.sum(d<0)))


def csv_save(path, rows):
    with Path(path).open('w',newline='',encoding='utf8') as handle:
        w=csv.DictWriter(handle,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)


def test():
    assert len(risk_training())==320 and len(risk_validation())==TRAIN_SAMPLE
    assert not np.array_equal(risk_training()[:40],risk_validation()[:40])
    data=select_candidates(0)
    best,scores=choose_policy_from_history(data)
    assert best in STRENGTHS and len(scores)==len(STRENGTHS)
    for key,(world,prod0,policy,reason) in data.items():
        assert policy is not None,reason
        assert np.array_equal(policy.normal[:v12.PREFIX],policy.stressed[:v12.PREFIX])
        assert policy.weighted_vote>.5
        assert v11.net_zero(world,policy.transfer)
    normal=np.ones(p.K)
    assert choose_branch(normal,normal,.6*normal)=='normal'
    assert choose_branch(.6*normal,normal,.6*normal)=='shock'
    for noise in MEASUREMENT_STD:
        rr=simulate_seed(1,'doppio_moderato',noise)
        assert len(rr)==5
        assert all(r['success']<=r['approved'] for r in rr)
        assert all(not r['revote_approved'] or r['revote_required'] for r in rr)
        assert rr[0]['noise']==noise
        assert rr[2]['chosen_strength']==rr[3]['chosen_strength']==rr[4]['chosen_strength']
    assert np.allclose(observation(normal,4,'stabile',.08),observation(normal,4,'stabile',.08))
    print('OK V15: training separato, decisioni senza futuro, voto ponderato, due sensori, revisioni e passato immutabile')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--mondi',type=int,default=24)
    ap.add_argument('--seed-offset',type=int,default=0)
    ap.add_argument('--output',default=str(HERE/'risultati'))
    ap.add_argument('--noise',type=float,nargs='*',default=list(MEASUREMENT_STD))
    args=ap.parse_args()
    if args.test:return test()
    out=Path(args.output);out.mkdir(exist_ok=True,parents=True)
    rows=[]
    for seed in range(args.seed_offset,args.seed_offset+args.mondi):
        for scenario in SHOCKS:
            for noise in args.noise:
                rows.extend(simulate_seed(seed,scenario,noise))
        print('V15 mondo',seed+1,'/',args.mondi,flush=True)
    summary=summarise(rows)
    pair=[paired_ci(rows,sc,sd,other=m) for sc in SHOCKS for sd in args.noise for m in METHODS[1:]]
    csv_save(out/'dettaglio.csv',rows)
    csv_save(out/'riepilogo.csv',summary)
    csv_save(out/'confronti_accoppiati.csv',pair)
    (out/'modello.json').write_text(json.dumps(dict(training_n=320,selection_n=TRAIN_SAMPLE,
                           strengths=['global',.12,.32,.50],noise_levels=args.noise,
                           scenario_names=list(SHOCKS),train_seed=83171,selection_seed=165432,
                           train_risk_probability=trained_risk(None).probability,
                           test_worlds=args.mondi,seed_offset=args.seed_offset),indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()