# Democrazia Ponderata Adattiva — V15

**Selezione della riserva per utilità marginale e misurazioni post-shock imperfette**

Stato: ricerca simulativa sintetica. Non costituisce una verifica del modello di governo nel mondo reale. I target e le metriche sono già approvati nelle simulazioni V11–V15; *tutte le nuove strategie e revisioni esaminate dalla V15* sono votate con pesi di competenza pertinenti.

## Domanda

L'allocazione di riserve per settore, valutata in funzione del beneficio marginale che si perde rinviando interventi, supera una riserva complessiva di 7,5 unità? Se i dati misurati dopo lo shock sono inesatti, è utile usare osservazioni indipendenti e richiedere un segnale sufficientemente robusto prima di attivare un nuovo voto?

## Esperimento

- **Quattro interventi contemporanei** (rinnovabili, reti, accumuli, efficienza), sei periodi, budget e vincoli tecnici V11–V14 inalterati.
- **Dati di apprendimento**: 320 eventi sintetici, seed 83171, per frequenza, covarianza e gravità dei guasti; **selezione marginale** su altri 140 eventi, seed 165432. Le popolazioni di valutazione (seed 0..23) restano separate.
- **Candidati**: un tetto globale (V14-A) e tre tetti settoriali con intensità di riserva 0,12, 0,32 e 0,50. Tutti i candidati devono essere tecnicamente fattibili nelle ipotesi ed approvati dal voto ponderato *prima* della selezione.
- **Criterio di scelta ex ante**: 72% frequenza di soddisfacimento dei vincoli negli episodi storici, 28% beneficio medio erogato durante i sei periodi. I pesi sono parametri dell'esperimento, non valori sociali oggettivi; servono soltanto a testare la sensibilità.
- **Valutazione**: gli stessi 24 mondi con sei scenari (stabile, shock singolo, doppio moderato, doppio grave, triplo estremo, rischio in settori mai osservati nel training) e rumore sensoriale standard 0, 0,08 e 0,18, con numeri casuali comuni ai metodi.

Metodi accoppiati:

1. `V14_globale` — tetto globale e un sensore.
2. `V14_settoriale` — tetto settoriale 0,32 e un sensore.
3. `V15_marginale` — selezione ex ante della riserva, stesso sensore della baseline.
4. `V15_marginale_due_sensori` — stesso portafoglio selezionato e media di due misurazioni indipendenti.
5. `V15_marginale_con_soglia` — stessa fusione e filtro di confidenza sulle variazioni prima di autorizzare una correzione tecnica.

## Integrità delle decisioni

Il piano iniziale è approvato prima che l'evento si realizzi. I due rami (normale e shock ipotetico) condividono i primi due periodi. Dopo l'evento, l'osservazione stimata può attivare la ricerca di un nuovo piano per i periodi ancora modificabili. Se una correzione non è inclusa nel mandato, **deve ottenere un nuovo voto ponderato**. Il piano già eseguito non viene riscritto. Il modello non usa la produttività reale come argomento del risolutore; la usa soltanto a posteriori per valutare il successo effettivo.

La regola di confidenza è deliberatamente semplice: quando la differenza normalizzata tra le due misure medie e la condizione normale è sotto una soglia proporzionale al rumore, non si attiva un intervento correttivo. Riduce i falsi allarmi ma può anche perdere shock modesti: è un compromesso da verificare, non un teorema di affidabilità.

## Riproduzione

Da questa cartella, con i moduli V11–V14 nella directory madre:

```bash
python -m pip install numpy scipy matplotlib
python simulazione_v15.py --test
python test_integrita_v15.py
python simulazione_v15.py --mondi 24 --noise 0 .08 .18 --output risultati
python grafici_v15.py --input risultati
```

Gli indicatori nei CSV sono: esito congiunto obiettivi+vincoli, revisioni proposte/approvate, previsioni false, ritardo dei benefici, differenze bootstrap appaiate per mondo. Con dimensione di campione ridotta gli intervalli possono comprendere lo zero: non trarre conclusioni generalizzate.

## Limiti principali

La struttura tecnica, la distribuzione degli shock, le preferenze civiche, i pesi per competenza e le misure sono sintetici. La scelta 72%/28% è arbitraria. L'ottimizzazione SLSQP non certifica ottimalità globale. La media di due sensori presuppone errori indipendenti; errori sistematici correlati ne eliminerebbero parte del beneficio. Il filtro di confidenza usa una soglia euristica. Il vantaggio della V15 è da valutare solo rispetto a questi mondi costruiti.