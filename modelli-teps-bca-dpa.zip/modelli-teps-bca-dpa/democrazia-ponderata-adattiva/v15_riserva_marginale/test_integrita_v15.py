#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Controlli di regressione V15: senza fuga del futuro, allarmi e ponderazione."""
import numpy as np
import simulazione_v15 as v

def main():
    v.test()
    # Stesso rischio appreso, shock di valutazione sconosciuti al decisore.
    tr=v.risk_training();sel=v.risk_validation()
    assert tr.shape==(320,4) and sel.shape==(140,4)
    assert np.min(tr)>=.0 and np.max(tr)<=1.0
    assert not np.allclose(tr[:20],sel[:20])
    # Due sensori producono un errore quadratico medio piu' piccolo in media.
    truth=np.ones(v.p.K)
    a=[];both=[]
    for i in range(300):
        x=v.observation(truth,i,'stabile',0.14,sensor=0)
        y=v.observation(truth,i,'stabile',0.14,sensor=1)
        a.append(np.linalg.norm(x-truth)**2)
        both.append(np.linalg.norm((x+y)*.5-truth)**2)
    assert np.mean(both)<.68*np.mean(a)
    # Il filtro di confidenza non deve anticipare il futuro; a rumore nullo
    # soglia di 0.045 e piano correttivo dipendente solo da stima disponibile.
    world,prod,policy,_=v.select_candidates(0)[None]
    assert policy and policy.weighted_vote>.5
    risk=v.trained_risk(None)
    stable=v.evaluate(world,prod,policy,np.ones(v.p.K),prod.copy(),risk,0.18,True)
    assert stable['initial_branch']=='normal' and not stable['revote_required']
    # Il piano iniziale non puo' avere come stima informazioni dai test futuri.
    a=v.simulate_seed(2,'stabile',.08)
    b=v.simulate_seed(2,'triplo_estremo',.08)
    assert [r['chosen_strength'] for r in a]==[r['chosen_strength'] for r in b]
    assert [r['training_score'] for r in a]==[r['training_score'] for r in b]
    print('OK V15: sensori indipendenti, training separato, decisione ex ante, voto ponderato')

if __name__=='__main__':main()