# V15 — Risultati della verifica e controprova indipendente

**Data:** 7 novembre 2026. **Tipo di evidenza:** 100% sintetica, non un esperimento sociale.

## Che cosa si e' messo alla prova

A parita' di target, bilanci, interventi paralleli e voto ponderato, abbiamo confrontato le due componenti separatamente: (i) selezione di un margine di riserva mediante valore marginale in dati di addestramento separati, (ii) rumore delle osservazioni post-shock. Metodi: V14 globale, V14 settoriale, V15 scelta marginale, V15 con due sensori, V15 con due sensori e soglia di confidenza.

Il campione di sviluppo comprende **24 mondi** con seed 0–23, sei scenari, tre rumori (0, 0,08 e 0,18); **2.160 esiti**. Dopo il pilota, i parametri della soglia sono stati congelati; la controprova usa **16 nuovi mondi** con seed 24–39, sei scenari, due rumori (0,08 e 0,18); **960 esiti**, indipendenti dal pilota.

## La riserva differenziata non migliora

La procedura marginale ha scelto il tetto **globale** in tutti i 40 mondi. Questo comporta che V15_marginale e V14_globale generino il medesimo risultato per ciascun mondo quando ricevono la stessa misurazione. I vincoli settoriali aggiuntivi della V14 rallentano i benefici normali senza fornire miglioramenti sufficienti nelle storie sintetiche esaminate.

## Osservazione rumorosa: scoperta principale

### Mondi di sviluppo (24)

| Scenario | Rumore sd | V14, un sensore | V15, due sensori | V15, due sensori + soglia |
|---|---:|---:|---:|---:|
| Stabile | 0,08 | 4/24 | 4/24 | **20/24** |
| Stabile | 0,18 | 4/24 | 4/24 | **20/24** |
| Due guasti gravi | 0,08 | 7/24 | 8/24 | 8/24 |
| Due guasti gravi | 0,18 | 4/24 | 5/24 | 5/24 |
| Guasto singolo | 0,18 | **10/24** | 6/24 | 6/24 |

### Mondi di controprova (16)

| Scenario | Rumore sd | V14, un sensore | V15, due sensori | V15, due sensori + soglia |
|---|---:|---:|---:|---:|
| Stabile | 0,08 | 2/16 | 5/16 | **14/16** |
| Stabile | 0,18 | 4/16 | 5/16 | **14/16** |
| Due guasti gravi | 0,08 | **7/16** | 5/16 | 5/16 |
| Due guasti gravi | 0,18 | **7/16** | 4/16 | 4/16 |
| Guasto singolo | 0,18 | 6/16 | 7/16 | 7/16 |

**Conclusione:** La soglia conferma una riduzione importante dei falsi interventi nello scenario stabile, ma non garantisce migliori decisioni durante shock veri. Il guadagno nell'assenza di shock e la perdita quando lo shock e' grave vanno entrambi riportati.

### Intervalli bootstrap (accoppiati per societa')

Il miglioramento rispetto alla V14 globale nello scenario stabile e' di **+75 punti** (IC 95% bootstrap +50 a +93,8 punti) con rumore 0,08 nel campione indipendente; con rumore 0,18 e' **+62,5 punti** (IC +31,2 a +87,5). Con due guasti gravi e rumore 0,18 il cambiamento e' invece di **−18,8 punti** (IC −43,8 a +6,2), non conclusivo date le 16 societa'. Sono intervalli sulle simulazioni, non su una popolazione reale.

## Limiti da non nascondere

- La soglia V15 e' stata introdotta dopo un pilota su sei mondi. La verifica indipendente tiene separati i nuovi seed ma **gli scenari sono ancora dello stesso generatore artificiale**.
- La scelta marginale ha usato la composizione storico-simulata, non un criterio sociale oggettivo. I pesi 72% successo / 28% servizio sono arbitrari.
- L'errore di misura e' gaussiano e i due sensori sono indipendenti: errori sistematici congiunti potrebbero annullare il vantaggio.
- Gli elettori e il voto per competenza sono sintetici; la qualifica specialistica per obiettivi e metriche e' ereditata dalla teoria ma non e' rivotata in questo test.
- L'ottimizzazione SLSQP e la funzione di recupero locale possono non trovare soluzioni esistenti.
- I miglioramenti degli esiti finali non costituiscono evidenza che la forma di governo sia valida, equa o costituzionalmente attuabile.

## Riproduzione

```bash
python simulazione_v15.py --test
python test_integrita_v15.py
python simulazione_v15.py --mondi 24 --output risultati
python simulazione_v15.py --mondi 16 --seed-offset 24 --noise .08 .18 --output validazione_indipendente
python grafici_v15.py --input risultati
python grafici_v15.py --input validazione_indipendente
```

Sono disponibili i risultati per singola simulazione, aggregati, confronti bootstrap appaiati e grafici. Per la ricerca successiva si propone di imparare l'urgenza dell'azione dalla struttura delle dipendenze e di usare una decisione sequenziale basata sul valore delle ulteriori misure, invece di una soglia fissa.