#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
import argparse, csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def draw(folder):
    with (folder/'riepilogo.csv').open(encoding='utf8',newline='') as f:
        rows=list(csv.DictReader(f))
    modes=['V14_globale','V14_settoriale','V15_marginale','V15_marginale_due_sensori','V15_marginale_con_soglia']
    shades=plt.rcParams['axes.prop_cycle'].by_key()['color']
    for scenario in ('stabile','doppio_grave','rischio_non_addestrato'):
        fig,ax=plt.subplots(figsize=(9,4.5))
        noise=sorted({float(r['noise']) for r in rows if r['scenario']==scenario})
        x=np.arange(len(noise));width=.16
        for j,mode in enumerate(modes):
            y=[float(next(r['success_pct'] for r in rows if r['method']==mode and r['scenario']==scenario and abs(float(r['noise'])-n)<1e-8)) for n in noise]
            ax.bar(x+(j-2)*width,y,width,label=mode.replace('_',' '),color=shades[j])
        ax.set_xticks(x,[str(v) for v in noise]);ax.set_xlabel('Deviazione standard errore di misura (unita normalizzate)')
        ax.set_ylabel('Successi con obiettivi e vincoli (%)');ax.set_ylim(0,108)
        ax.set_title('V15: '+scenario.replace('_',' '))
        ax.legend(loc='upper center',bbox_to_anchor=(.5,-.20),ncol=2,fontsize=7)
        fig.tight_layout();fig.savefig(folder/('confronto_'+scenario+'.png'),dpi=150,bbox_inches='tight');plt.close(fig)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',default='risultati');a=ap.parse_args()
    draw(Path(a.input))