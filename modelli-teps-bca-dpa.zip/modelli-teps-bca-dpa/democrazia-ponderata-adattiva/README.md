# Democrazia Ponderata Adattiva — percorso V0 → V27

Progetto sperimentale di democrazia **sempre ponderata per competenza specifica della questione**, strutturata in obiettivi, metriche specialistiche, strategie interdisciplinari e monitoraggio.

## Cronologia
- **V0**: ricostruzione concettuale, nessun programma originale.
- **V1**: modello iniziale di retropropagazione deliberativa.
- **V2**: apprendimento dalle conseguenze e incertezza.
- **V3**: voto ponderato in tutte le fasi, agenda e metriche.
- **V4**: negoziazione dei sacrifici e rivoti.
- **V5**: diagnosi per difficoltà, oracolo tecnico e conflitto.
- **V6**: affidabilità delle previsioni e calibrazione.
- **V7**: feedback durante l'attuazione.
- **V8**: mandati condizionali approvati.
- **V9**: pianificazione robusta a orizzonte mobile.
- **V10**: sequenze condizionali coordinate.
- **V11**: portafoglio di interventi paralleli e negoziazione; fase sperimentale.
- **V12**: pianificazione con rami condizionali, riserva di capacità e rivoto ponderato dopo shock non previsto; prototipo sintetico.
- **V13**: dimensionamento della riserva, rischi stimati ed effettivi, benefici intermedi e guasti tecnici correlati.
- **V14**: riserva settoriale appresa e guasti correlati.
- **V15**: valore marginale della riserva e incertezza delle misure.
- **V16**: valore atteso dell'informazione (EVSI).
- La numerazione prosegue da V21: le versioni V17–V20 appartengono a un altro filone di ricerca e non fanno parte di questo repository.
- **V21**: DPA raffinata: tetto ai pesi, voto uguale sui diritti universali, competenza epistemicamente attiva, ammissibilità esatta, prove di manipolazione, 200 mondi con bootstrap accoppiato.
- **DPA V22**: voto ponderato per tema (vincoli compresi), non tutti votano su tutto; dinamica nel tempo con monitoraggio e storico delle previsioni.
- **DPA V23**: premesse TEPS: competenze riconosciute (formazione, esperienza, agenti IA), voto indirizzato per competenze con base minima N_min (D-15), obiettivi e diritti a voto eguale.
- **DPA V24**: tutte le questioni tematiche, obiettivi compresi, indirizzate per competenza; base senza tetto con pavimento N_min; competenze concentrate o diffuse.
- **DPA V25**: allargamento in base a ciò che si misura: verticale se mancano votanti, orizzontale (discipline vicine) se c'è autoattribuzione.
- **DPA V26**: test di autoattribuzione corretto (falsi allarmi al livello dichiarato); con un gruppo in conflitto grande l'allargamento orizzontale funziona, quello verticale no.
- **DPA V27**: conoscenza o interesse; valutazione sulle conseguenze reali in 20 periodi.

**Avvertenza:** simulazioni matematiche su popolazioni sintetiche, non prova dell'efficacia di un ordinamento reale. I risultati dipendono dalle regole e dai parametri scelti.

Le versioni sono caricate attraverso commit cronologici distinti, mantenendo la storia e i limiti di ogni iterazione.

## Stato V11 (verifica del 7 novembre 2026)

I moduli `v11_negoziazione/portafoglio_parallelo.py` e
`v11_negoziazione/negoziazione_portafoglio_v11.py` sono consultabili ed
eseguibili direttamente nel repository, insieme ai test e alla diagnostica.
I risultati corretti sono in `v11_negoziazione/risultati_validati/`.
I vecchi risultati V11 sono conservati come storico ma non rappresentano
la verifica attuale. Nei casi con shock distinguere sempre la fattibilita'
iniziale dalla disponibilita' di un piano di recupero dopo l'esecuzione
dei primi interventi. Il mancato reperimento da parte di un risolutore
locale non dimostra l'impossibilita' matematica.


## Aggiornamento V12

La cartella [`v12_resilienza_portafoglio`](v12_resilienza_portafoglio/) contiene codice Python, test, CSV e metodi di riproduzione. Un programma condizionale è approvato come insieme di interventi paralleli; i primi due periodi di attuazione sono irreversibili, mentre una correzione fuori mandato richiede un **nuovo voto ponderato**. Nel test fuori scenario con shock più grave del previsto, il risolutore trova correzioni approvate in 7/24 casi senza riserva e 24/24 con riserva. Risultati **solo sintetici**, dipendenti dal generatore e da ipotesi ottimistiche sulle misurazioni post-shock. La strategia non modifica gli obiettivi né le metriche già approvati.


## Aggiornamento V13

La cartella [`v13_riserva_rischio`](v13_riserva_rischio/) contiene codice Python e resoconto dello stress test della riserva di capacità: cinque tetti iniziali, tre probabilità di shock ipotetiche e quattro gravità, oltre a controlli con più settori danneggiati contemporaneamente. Risultati principali su 36 mondi sintetici: tetto iniziale 7.5, successo atteso 100% e beneficio intermedio 0.7634; tetto 10, successo atteso 91.2% e beneficio intermedio 0.8215, con probabilità di shock ipotizzata del 35%. Nei guasti correlati estremi quasi tutte le configurazioni falliscono. Tutte le percentuali sono risultati del simulatore, non evidenze empiriche. La V13 usa un risolutore di recupero più rapido rispetto alla V12, quindi confronti percentuali tra release non identificano un effetto causale della riserva.

## V14 — riserva settoriale appresa (7 novembre 2026)

La V14 aggiunge scenari di guasto correlato appresi da dati sintetici e
vincoli di spesa iniziale differenziati tra rinnovabili, reti, accumuli
ed efficienza. Le strategie sono sempre portafogli paralleli a sei periodi;
le correzioni oltre mandato richiedono nuovo voto ponderato.

Sui 24 mondi per scenario, la riserva settoriale **non aumenta il numero
di successi completi** rispetto al tetto unico V13 (7.5), e riduce i
benefici erogati presto. L'apprendimento del guasto correlato, senza tetti
settoriali, riduce invece alcuni rivoti nei guasti moderati.

Codice, documentazione e risultati: [v14_riserva_settoriale](v14_riserva_settoriale/README.md).

I test sono sintetici; sono esclusi da ogni conclusione su politica reale.

## V15 — valore marginale della riserva e incertezza delle misure

Codice Python, test, riepiloghi e rapporto: [`v15_riserva_marginale/`](v15_riserva_marginale/).
Il test di scelta ex ante tra riserva globale e settoriali seleziona quella globale in tutti i 40 mondi; non dimostra un vantaggio della riserva differenziata. L'uso di due sensori e di una soglia riduce i falsi interventi in condizioni stabili, ma non migliora sistematicamente i guasti reali. La validazione usa 24 mondi di sviluppo e 16 ulteriori, sempre sintetici. Si veda `RAPPORTO_V15.md`.

## V16 — Valore atteso dell'informazione (2026-11)

- Sceglie tra piano normale, ramo d'emergenza autorizzato e verifica con una seconda misura.
- Usa posterior discreta appresa da eventi sintetici passati, senza lettura dello shock reale futuro.
- Stima il valore informativo della seconda misura al netto dei costi di acquisizione e di ritardo.
- I vincoli tecnici e i limiti di mandato restano controllati; le correzioni non previste richiedono rivoto ponderato.
- Pubblica due campioni distinti (24 mondi di sviluppo e 24 di validazione), CSV individuali, bootstrap raggruppato per mondo e test eseguibili.
- Nella validazione: 166 successi su 288 con verifica selettiva contro 172 su 288 con seconda misura sistematica; 67 seconde misure invece di 288. Il dato e' sintetico, non dimostra superiorita' politica.

Vedi [V16 — codici e risultati](v16_valore_informazione/README.md).

## V21 — DPA raffinata (8 novembre 2026)

Raffinamento della DPA dopo la revisione del codice V0–V16. Introduce il **tetto
ai pesi** (`w_max = 3`, nessuno pesa meno di 1) e il **voto uguale sulle questioni
di diritto universale**; la competenza migliora la qualità delle stime e della
percezione dei vincoli; le stime degli esperti sono aggregate con mediana
robusta; l'ammissibilità è verificata in modo esatto (programmazione lineare),
distinguendo «impossibile secondo le stime» da «soluzione non trovata». Ogni
batteria confronta sempre voto uguale e ottimizzatore tecnico senza voto.

Su 200 mondi sintetici per scenario:

- il peso sul voto del piano quasi non cambia la scelta (1–2,5% dei mondi);
- senza tetto e con voto pesato sui diritti la decisione per teste è ribaltata
  nel 57,5% dei mondi (69,5% con una lobby dalle competenze gonfiate) e la
  minoranza perde 8–10 punti di benessere; con la V21 il ribaltamento è 0%;
- con esperti corrotti la mediana robusta mantiene davvero fattibile il 47% dei
  piani contro il 19,5% della media pesata;
- il margine di certificazione domina la fattibilità reale (61,5% → 98% passando
  da 0,15 a 0,80) al prezzo di benessere: va deciso come obiettivo, non come
  parametro tecnico.

Risultati sintetici, non prova su ordinamenti reali. Codice, test, CSV e limiti:
[V21](v21_dpa_raffinata/README.md).

## DPA V22 — dinamica e tematica (9 novembre 2026)

Corregge l'impostazione della V21: il voto ponderato è **per tema**, vincoli
compresi, e **non tutti votano su tutto**. I vincoli li vota chi è competente in
quel dominio, gli obiettivi chi è interessato al tema, il diritto universale
tutti a voto uguale. Dieci periodi con limiti che si spostano, shock, inerzia,
monitoraggio, rivoto mirato e storico delle previsioni.

Su 200 mondi sintetici per scenario il regime tematico dinamico tiene davvero
fattibili il 97,8% dei piani (95,5% con esperti corrotti), contro il 62% di
"tutti votano su tutto", con circa 240 schede per periodo invece di 4 260. Lo
storico delle previsioni porta a zero il peso degli esperti corrotti. Il
vantaggio del voto tematico sui vincoli dipende però dal fatto che i non esperti
condividano un errore sistematico: senza, scende a circa 2,5 punti. Dopo uno
shock il regime dinamico reagisce con un periodo di ritardo.
Dettagli: [DPA V22](v22_dpa_dinamica_tematica/README.md).

## DPA V23 — premesse TEPS (9 novembre 2026)

Le votazioni sono indirizzate per competenze riconosciute (formazione ed
esperienza lavorativa, valutate da cinque agenti IA isolati) e hanno una base
minima di votanti con allargamento automatico (D-15, N_min = 101). Peso TEPS
con soglia e tetto `w_max = 3`; diritti universali e obiettivi che toccano tutti
a voto eguale; nessuno vota con peso sulla propria pratica.

Su 200 mondi sintetici per scenario: +35,6 punti di piani davvero fattibili
rispetto a "tutti votano su tutto" (vantaggio che però si riduce a circa 3 punti
se i non esperti sbagliano solo a caso); votare gli obiettivi per competenza
invece che a voto eguale fa perdere 4,6 punti di benessere al gruppo più
svantaggiato; N_min troppo alto (201) abbassa la soglia e costa 5 punti di
fattibilità; il consesso di agenti IA resiste finché meno di metà degli agenti
è ingannata; lo storico delle previsioni porta la fattibilità con esperti
corrotti dal 77% al 92%. Dettagli: [DPA V23](v23_dpa_premesse_teps/README.md).

## DPA V24 — tutto per competenza (9 novembre 2026)

Vincoli e obiettivi li votano solo i competenti sopra soglia, certificati da
agenti IA; a voto eguale restano solo i diritti universali; la base è chi
supera la soglia, con N_min = 101 come solo pavimento. Su 200 mondi sintetici
per scenario la fattibilità resta al 96% come nella V23, con il 40% di schede
in meno. L'effetto sugli obiettivi dipende da come sono distribuite le
competenze: se sono **diffuse** fra gruppi con interessi diversi il risultato è
uguale al voto eguale; se sono **concentrate** in un gruppo con preferenze
proprie, la maggioranza perde 5,7 punti di benessere. Il punto da garantire è
il legame fra competenza certificata e interessi.
Dettagli: [DPA V24](v24_dpa_tutto_per_competenza/README.md).

## DPA V25 — allargamento in base a ciò che si misura (9 novembre 2026)

Se mancano votanti la base si allarga in verticale (D-15); se gli effetti della
decisione si concentrano su chi l'ha votata, si allarga in orizzontale ai
competenti delle discipline vicine. L'autoattribuzione si misura con il registro
di partecipazione e la ripartizione decisa, senza conoscere preferenze né voti.
Con competenze concentrate l'elettorato si attribuiva il 29% in più della sua
parte; il test lo rileva sempre e l'allargamento orizzontale riporta la
ripartizione proporzionale, recuperando 3,7 punti di benessere per la
maggioranza con 202 votanti (il verticale ne usa 303). Falsi allarmi più alti del
previsto (10–20%), con costo basso. Dettagli:
[DPA V25](v25_dpa_allargamento_misurato/README.md).

## DPA V26 — test corretto e gruppo in conflitto grande (9 novembre 2026)

Il test di autoattribuzione della V25 dava troppi falsi allarmi; ora confronta la
composizione per zona dell'elettorato con quella di elettorati casuali e
richiede che la ripartizione favorisca chi ha votato: falsi allarmi al 5–7%
invece del 26–33%. A parità di persone aggiunte, l'allargamento orizzontale
(discipline vicine) supera quello verticale: +1,5 punti di benessere per la
maggioranza con un gruppo competente del 15%, +2,0 con un gruppo del 40%, dove
il verticale quasi non serve perché i successivi in graduatoria sono ancora del
gruppo. Dettagli: [DPA V26](v26_dpa_test_corretto/README.md).

## DPA V27 — conoscenza o interesse? (9 novembre 2026)

I competenti possono discostarsi dalla base perché sanno di più (conoscenza) o
perché ci guadagnano (interesse). Con una conseguenza nascosta che solo loro
conoscono e una valutazione sulle conseguenze reali in 20 periodi: se le
conseguenze danneggiano davvero (danno da scarsità 2–5), votare per competenza
dà risultati migliori del voto eguale, anche per la maggioranza; il controllo di
autoattribuzione non scatta quando c'è solo conoscenza e, quando c'è anche
interesse, restituisce circa 3 punti alla maggioranza. Dettagli:
[DPA V27](v27_dpa_conoscenza_interesse/README.md).

## Stato complessivo

Cosa è dimostrato e cosa no: [STATO_DPA.md](STATO_DPA.md).
