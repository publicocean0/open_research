#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""
PROTOTIPO DI DEMOCRAZIA NEURALE - simulazione falsificabile, NON evidenza empirica.

* 3 variabili: centinaia di case, investimenti acqua, investimenti trasporti.
* 4 domini: acqua, trasporti, bilancio, ecologia (vincoli non lineari).
* 1 cittadino = 1 voto, separatamente dagli esperti che informano il voto.
* Informazioni intersettoriali arrivano in sequenza (4 revisioni possibili).
* Errori tecnici retropropagati con J.T @ max(0, g(x)).
* Ogni revisione richiede voto a maggioranza; nessuna modifica automatica.
* Approvazione finale: voto + certificazione di tutti i vincoli stimati.
* Valutazione esterna: controlla la validita' con vincoli veri, ignoti agli attori.

Esecuzione:
  python simulazione.py --prove 150 --cittadini 1500 --output risultati
Dipendenze: numpy scipy matplotlib
"""
from __future__ import annotations
import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

VARS=('abitazioni: centinaia','acqua: investimento','trasporti: investimento')
DOMAINS=('Acqua','Trasporti','Bilancio','Ambiente')
LOW=np.array([5.,0.,0.]);HIGH=np.array([12.,5.,5.])
SCALE=np.array([1.,1.,10.,1.])
BUDGET_CAP=100.0; ECO_CAP=5.0
WEIGHTS=np.array([.65,.72,.72])
STATUS_QUO=np.array([6.2,.0,.0])

@dataclass
class Model:
    shift:np.ndarray
    slope:np.ndarray

    def g(self,x):
        h,w,t=x
        base=np.array([
            h-7.-1.15*w+.045*w*w,
            h-6.8-1.05*t+.030*t*t,
            7.2*h+8.5*w+8.*t-BUDGET_CAP,
            .72*h-.55*t-.30*w-ECO_CAP,
        ])/SCALE
        return base+self.shift+self.slope@x

    def jac(self,x):
        _,w,t=x
        return np.array([
            [1.,-1.15+.09*w,0.],
            [1.,0.,-1.05+.060*t],
            [7.2,8.5,8.],
            [.72,-.30,-.55],
        ])/SCALE[:,None]+self.slope

TRUE=Model(np.zeros(4),np.zeros((4,3)))

@dataclass
class Voters:
    ideals:np.ndarray
    issue_weights:np.ndarray
    risk:np.ndarray
    mean_ideal:np.ndarray
    public_weights:np.ndarray


def citizens(rng,n,awareness):
    ideals=np.clip(np.column_stack((rng.normal(10.25,1.05,n),
        rng.normal(.9,.7,n),rng.normal(.85,.72,n))),LOW,HIGH)
    issue=np.tile(WEIGHTS,(n,1))
    groups=rng.integers(0,4,n)
    for d in range(3):issue[groups==d,d]*=1.8
    issue[groups==3,:]*=.85
    # awareness: how strongly participants internalize reported risks
    risk=rng.lognormal(0,.42,n)*awareness
    return Voters(ideals,issue,risk,np.sum(ideals*issue,axis=0)/issue.sum(axis=0),issue.mean(axis=0))


def panels(rng,technical_error,n_experts=16):
    # Every expert has independently varying knowledge. Competence weighting
    # applies to risk estimates, NOT to the equal civic ballot.
    c=rng.uniform(.6,1.5,(4,n_experts))
    q=c**2
    shift=rng.normal(size=(4,n_experts))*technical_error/c
    slope=rng.normal(size=(4,n_experts,3))*technical_error/(9*c[:,:,None])
    return Model(np.sum(shift*q,axis=1)/q.sum(axis=1),
                 np.sum(slope*q[:,:,None],axis=1)/q.sum(axis=1)[:,None])


def subjective(voters,model,x,active,perceived_harm=7.0):
    # Enforced technical messages have not all been revealed yet.
    # The voters retain their own (possibly very different) political priorities.
    ideology=-np.sum(voters.issue_weights*(voters.ideals-x)**2,axis=1)
    if not active:return ideology
    violation=np.maximum(model.g(x)[active],0)
    return ideology-perceived_harm*voters.risk*np.dot(violation,violation)


def pairwise(voters,model,candidate,previous,active):
    a=subjective(voters,model,candidate,active)
    b=subjective(voters,model,previous,active)
    share=float(np.mean(a>b+1e-8)+.5*np.mean(np.abs(a-b)<=1e-8))
    return share>.5,share


def initial_policy(voters,model):
    mu=voters.mean_ideal
    variants=[np.clip(mu+np.array([h,w,t]),LOW,HIGH)
              for h,w,t in ((0,0,0),(.3,0,0),(-.3,0,0),
                            (0,.3,0),(0,-.3,0),(0,0,.3),(0,0,-.3))]
    points=np.column_stack([subjective(voters,model,v,[]) for v in variants])
    # First ballot: each citizen chooses one candidate, with runoff between top two.
    first=np.argmax(points,axis=1)
    votes=np.bincount(first,minlength=len(variants))
    leading=np.argsort(votes)[-2:]
    a,b=leading
    return variants[a] if np.sum(points[:,a]>=points[:,b])>len(points)/2 else variants[b]


def sector_feedback(x,model,active):
    # Explicit backpropagation: the residual of each newly aware sector is
    # mapped to the original decision variables by the transposed Jacobian.
    violations=np.maximum(model.g(x)[active],0)
    return model.jac(x)[active].T@violations


def constrained_candidate(x,voters,model,active,priority,target=None,margin=.09):
    if target is None:target=voters.mean_ideal
    # Differentiable convex preference objective and four potentially nonlinear
    # domain constraints. SLSQP computes collaborative feasible alternatives.
    cons=[{'type':'ineq',
           'fun':lambda z,k=k: -model.g(z)[k]-margin,
           'jac':lambda z,k=k: -model.jac(z)[k]} for k in active]
    p=priority
    def f(z):return float(np.sum(p*(z-target)**2))
    def j(z):return 2*p*(z-target)
    res=minimize(f,np.clip(x,LOW,HIGH),method='SLSQP',jac=j,
        constraints=cons,bounds=list(zip(LOW,HIGH)),
        options={'ftol':1e-10,'maxiter':100})
    if np.max(model.g(res.x)[active]+margin)>1e-4:return None
    return res.x


def amendments(x,voters,model,active,margin):
    # Any domain can respond to the others; technical information is shared.
    backprop=sector_feedback(x,model,active)
    alternatives=[]
    targets=[voters.mean_ideal,
             voters.mean_ideal+np.array([.4,0,0]),
             voters.mean_ideal+np.array([-.4,0,0]),
             voters.mean_ideal+np.array([0,.35,.35])]
    priorities=[voters.public_weights,
                np.array([1.25,.5,.5]),
                np.array([.45,1.0,1.0]),
                np.array([.7,1.5,1.5])]
    # Local backprop candidate is a true gradient step; the technical projection
    # enforces the entire currently known feasible region.
    if np.linalg.norm(backprop)>1e-6:
        adjusted=np.clip(x-.5*backprop/(np.linalg.norm(backprop)+1e-9),LOW,HIGH)
        targets.append(adjusted)
        priorities.append(np.array([.7,.7,.7]))
    for target,p in zip(targets,priorities):
        proposal=constrained_candidate(x,voters,model,active,p,target,margin)
        if proposal is not None and np.linalg.norm(proposal-x)>1e-4:
            if not any(np.linalg.norm(proposal-old)<1e-5 for old in alternatives):
                alternatives.append(proposal)
    return alternatives,backprop


def policy_distance(x,voters):
    return float(np.sum(voters.public_weights*(x-voters.mean_ideal)**2))


def test_policy(x,voters):
    errors=TRUE.g(x)
    return {'x':x,'true_feasible':bool(np.max(errors)<=1e-5),
            'true_violation':float(np.max(np.maximum(errors,0))),
            'distance':policy_distance(x,voters),
            'true_constraints':errors}


def enactment(voters,tech,*,margin=.09,global_rollback=True):
    x=initial_policy(voters,tech)
    initial=x.copy()
    track=[x.copy()]
    events=[]
    blocked=False
    for k in range(4):
        active=list(range(k+1))
        before=tech.g(x)[k]
        # If already safe with uncertainty margin, no repeat ballot required.
        if np.max(tech.g(x)[active]+margin)<=1e-5:
            events.append({'domain':DOMAINS[k],'action':'nessuna modifica','share':np.nan,
                           'residual':float(before),'backprop':np.zeros(3)})
            continue
        alternatives,backprop=amendments(x,voters,tech,active,margin)
        eligible=[]
        for proposal in alternatives:
            approved,share=pairwise(voters,tech,proposal,x,active)
            if approved: eligible.append((share,policy_distance(proposal,voters),proposal))
        if not eligible:
            blocked=True
            events.append({'domain':DOMAINS[k],'action':'blocco del rivoto','share':0.,
                           'residual':float(before),'backprop':backprop})
            break
        # Max electoral approval over verified technically feasible amendments.
        share,_,x=max(eligible,key=lambda rec:(rec[0],-rec[1]))
        track.append(x.copy())
        events.append({'domain':DOMAINS[k],'action':'rivoto approvato','share':float(share),
                       'residual':float(before),'backprop':backprop})
    # Global rollback: an unsuccessful local amendment reopens the complete
    # original policy package. Citizens can reconsider all cross-domain impacts
    # together instead of being trapped by the path of earlier amendments.
    rollback_used=False
    if blocked and global_rollback:
        alternatives,backprop=amendments(initial,voters,tech,[0,1,2,3],margin)
        approved=[]
        for proposal in alternatives:
            ok,share=pairwise(voters,tech,proposal,initial,[0,1,2,3])
            if ok:
                approved.append((share,policy_distance(proposal,voters),proposal))
        if approved:
            share,_,x=max(approved,key=lambda r:(r[0],-r[1]))
            blocked=False
            rollback_used=True
            track.append(x.copy())
            events.append({'domain':'Tutti','action':'rivoto globale approvato',
                           'share':float(share),'residual':float(np.max(tech.g(initial))),
                           'backprop':backprop})
        else:
            events.append({'domain':'Tutti','action':'rivoto globale respinto',
                           'share':0.,'residual':float(np.max(tech.g(initial))),
                           'backprop':backprop})
    certified=bool(np.max(tech.g(x)+margin)<=1e-5)
    ratified,ratification_share=pairwise(voters,tech,x,STATUS_QUO,[0,1,2,3])
    legal_enactment=not blocked and certified and ratified
    diagnostics=test_policy(x,voters)
    diagnostics.update({'initial':initial,'track':np.array(track),'events':events,
        'technical_certified':certified,'ratified':ratified,
        'ratification_share':ratification_share,
        'enacted':legal_enactment,
        'enacted_and_feasible':legal_enactment and diagnostics['true_feasible'],
        'accepted_revotes':sum(e['action'] in ('rivoto approvato','rivoto globale approvato') for e in events),
        'rollback_used':rollback_used,
        'blocked':blocked})
    return diagnostics


def one_shot(voters,tech,margin):
    x=initial_policy(voters,tech)
    a=constrained_candidate(x,voters,tech,list(range(4)),voters.public_weights,
                            voters.mean_ideal,margin)
    if a is None:raise RuntimeError('One-shot optimizer infeasible')
    return test_policy(a,voters)


def oracle(voters):
    x=constrained_candidate(voters.mean_ideal,voters,TRUE,list(range(4)),
                            voters.public_weights,margin=0.)
    if x is None:raise RuntimeError('Exact oracle infeasible')
    return test_policy(x,voters)


def single(seed,n,noise,awareness,margin,global_rollback=True):
    rng=np.random.default_rng(seed)
    voters=citizens(rng,n,awareness)
    expert=panels(rng,noise)
    initial=initial_policy(voters,expert)
    return {'Iniziale':test_policy(initial,voters),
            'Tecnico, senza rivoto':one_shot(voters,expert,margin),
            'Retropropagazione + rivoto':enactment(voters,expert,margin=margin,global_rollback=global_rollback),
            'Ottimo teorico':oracle(voters)}


def simulate(trials,n,margin,out,global_rollback=True):
    out.mkdir(parents=True,exist_ok=True)
    # Noise is per individual expert in dimensionless constraint residuals.
    # Impact on committee mean is approx noise/sqrt(16), correlated slopes excluded.
    scenarios=[('Esperti accurati; voto informato',.25,1.),
               ('Esperti incerti; voto informato',2.2,1.),
               ('Esperti accurati; voto disinformato',.25,.04)]
    records=[]
    example=None
    for scenario,noise,awareness in scenarios:
        for seed in range(trials):
            data=single(4050+seed,n,noise,awareness,margin,global_rollback)
            if seed==0 and scenario==scenarios[0][0]:example=data
            for method,r in data.items():
                records.append({'scenario':scenario,'seed':seed,'metodo':method,
                    'fattibile_reale':int(r['true_feasible']),
                    'violazione_massima':r['true_violation'],
                    'distanza_preferenze':r['distance'],
                    'approvato':int(r.get('enacted',False)),
                    'certificato':int(r.get('technical_certified',False)),
                    'approvato_e_fattibile':int(r.get('enacted_and_feasible',False)),
                    'numero_rivoti':r.get('accepted_revotes',0),
                    'bloccato':int(r.get('blocked',False)),
                    'rollback_globale':int(r.get('rollback_used',False)),
                    'case_100':r['x'][0],'acqua':r['x'][1],'trasporti':r['x'][2]})
    with (out/'simulazioni.csv').open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=records[0].keys())
        writer.writeheader();writer.writerows(records)
    summaries=[]
    for scenario,_,_ in scenarios:
        for method in ('Iniziale','Tecnico, senza rivoto','Retropropagazione + rivoto','Ottimo teorico'):
            subset=[r for r in records if r['scenario']==scenario and r['metodo']==method]
            summaries.append({'scenario':scenario,'metodo':method,'prove':len(subset),
                'fattibili_pct':100*np.mean([r['fattibile_reale'] for r in subset]),
                'violazione_media':np.mean([r['violazione_massima'] for r in subset]),
                'distanza_media':np.mean([r['distanza_preferenze'] for r in subset]),
                'attuate_pct':100*np.mean([r['approvato'] for r in subset]),
                'certificate_pct':100*np.mean([r['certificato'] for r in subset]),
                'attuate_e_valide_pct':100*np.mean([r['approvato_e_fattibile'] for r in subset]),
                'bloccate_pct':100*np.mean([r['bloccato'] for r in subset]),
                'rollback_pct':100*np.mean([r['rollback_globale'] for r in subset]),
                'rivoti_medi':np.mean([r['numero_rivoti'] for r in subset])})
    with (out/'riepilogo.csv').open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=summaries[0].keys());writer.writeheader();writer.writerows(summaries)
    print('== MONTE CARLO ==')
    for row in summaries:
        print(f"{row['scenario'][:19]:20} {row['metodo']:27} "
              f"fattibili={row['fattibili_pct']:5.1f}% "
              f"attuate/valide={row['attuate_e_valide_pct']:5.1f}% "
              f"blocchi={row['bloccate_pct']:5.1f}% "
              f"distanza={row['distanza_media']:.2f} "
              f"rivoti={row['rivoti_medi']:.2f}")
    case=example['Retropropagazione + rivoto']
    print('\n== ESEMPIO SINGOLA SIMULAZIONE ==')
    print('Iniziale:',np.round(example['Iniziale']['x'],3))
    for event in case['events']:
        print(f" {event['domain']:11} {event['action']:22} cons={event['residual']:+.3f} "
              f"sostegno={event['share']:.1%}, backprop={np.round(event['backprop'],2)}")
    print('Finale:',np.round(case['x'],3),' residui veri:',np.round(case['true_constraints'],3))
    print('Approvato:',case['enacted'],'Fattibile:',case['true_feasible'])
    # Plot: no imposed colour, one plot per figure.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(9,5))
    for i,label in enumerate(('Case / 100','Acqua','Trasporti')):
        ax.plot(range(len(case['track'])),case['track'][:,i],marker='o',label=label)
    ax.set(xlabel='Proposta iniziale + rivoti approvati',ylabel='Valore della politica',
           title='Esempio di revisioni interdisciplinari')
    ax.set_xticks(range(len(case['track'])))
    ax.legend();ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(out/'andamento_proposta.png',dpi=170);plt.close(fig)
    methods=['Iniziale','Tecnico, senza rivoto','Retropropagazione + rivoto','Ottimo teorico']
    fig,ax=plt.subplots(figsize=(10,5))
    for scenario,_,_ in scenarios:
        rr=[r for r in summaries if r['scenario']==scenario]
        ax.plot(range(len(methods)),[r['fattibili_pct'] for r in rr],marker='o',label=scenario)
    ax.set(xticks=range(4),xticklabels=['Iniziale','Tecnico','Con rivoto','Ottimo'],
           ylabel='Proposte realmente fattibili (%)',ylim=(-5,105),
           title='Fattibilita delle proposte, non necessariamente approvate')
    ax.legend();ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(out/'fattibilita.png',dpi=170);plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    rr=[r for r in summaries if r['metodo']=='Retropropagazione + rivoto']
    x=np.arange(len(rr));width=.34
    ax.bar(x-width/2,[r['attuate_pct'] for r in rr],width,label='Approvate e certificate')
    ax.bar(x+width/2,[r['attuate_e_valide_pct'] for r in rr],width,label='Approvate e davvero fattibili')
    ax.set(xticks=x,xticklabels=['Informati, esperti\naccurati','Informati, esperti\nincerti','Disinformati, esperti\naccurati'],
           ylabel='Quota dei casi (%)',ylim=(0,105),title='Approvazione versus validita reale')
    ax.legend();fig.tight_layout();fig.savefig(out/'esiti_rivoto.png',dpi=170);plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--prove',type=int,default=150)
    p.add_argument('--cittadini',type=int,default=1200)
    p.add_argument('--margine',type=float,default=.22)
    p.add_argument('--budget',type=float,default=100.,help='Soglia bilancio, scala in milioni')
    p.add_argument('--ambiente',type=float,default=5.,help='Soglia del vincolo ambientale')
    p.add_argument('--output',type=Path,default=Path('risultati'))
    p.add_argument('--no-rollback',action='store_true',help='Disabilita il secondo voto sul pacchetto completo')
    a=p.parse_args()
    BUDGET_CAP=a.budget
    ECO_CAP=a.ambiente
    simulate(a.prove,a.cittadini,a.margine,a.output,global_rollback=not a.no_rollback)