# Prototipo Python — Democrazia Neurale con Retropropagazione Deliberativa

## Obiettivo

Verificare **in un ambiente artificiale** se è coerente un sistema democratico nel quale:

1. i cittadini votano una prima proposta;
2. gli ambiti di competenza identificano esternalità e vincoli;
3. la sensibilità di ciascun vincolo ai parametri della proposta viene propagata all'indietro;
4. vengono generate alternative tecnicamente ammissibili;
5. si rivota una modifica alla volta;
6. se un voto locale blocca il processo, la decisione iniziale viene riaperta e i cittadini rivotano **l'intero pacchetto**;
7. la proposta si promulga solo se supera il voto e i vincoli stimati.

Il programma usa voti con **peso uguale per ciascun cittadino**. La competenza pesa solo nella costruzione delle *stime tecniche*. Nessun voto può cancellare un limite tecnico identificato come vincolo inderogabile (salva la possibilità di cambiare la proposta).

## Modello

Proposta `x=(h,w,t)`:
- `h`: centinaia di nuove abitazioni;
- `w`: investimento nella rete idrica (unità arbitrarie);
- `t`: investimento nei trasporti (unità arbitrarie).

Vincoli sintetici, impostati con una soglia di 100 nel bilancio e 5 nell'ambiente:

```text
g_acqua = h - 7 - 1.15*w + 0.045*w*w <= 0
g_trasporti = h - 6.8 - 1.05*t + 0.030*t*t <= 0
g_bilancio = (7.2*h + 8.5*w + 8.0*t - 100) / 10 <= 0
g_ambiente = 0.72*h - 0.55*t - 0.30*w - 5 <= 0
```

Per rendere comparabili i vincoli, il residuo del bilancio è diviso per 10. Gli specialisti non conoscono esattamente queste formule, ma usano copie stimate e perturbate, aggregate con pesi di competenza.

**Segnale di retropropagazione:**

`b = J(x).T @ maximum(g_active(x), 0)`

`J` è il Jacobiano interdisciplinare: `J[k,j] = ∂g_k / ∂x_j`. Un segnale in un ambito determina quindi quali parametri della proposta iniziale lo hanno causato. Il segnale è usato per creare alternative; la loro ammissibilità è poi verificata con un ottimizzatore a vincoli (`scipy.optimize.minimize`, SLSQP). SLSQP è un supporto computazionale, **non un decisore politico**.

Ogni cittadino `i` possiede un ideale politico e un peso personale attribuito alle questioni. La sua valutazione sintetica è:

`U_i(x) = - Σ_j w_ij (x_j - ideale_ij)^2 - 7*a_i Σ_{k conosciuti} max(0, g_k(x))^2`

L'avversione `a_i` varia tra cittadini. Quando l'informazione viene comunicata, i cittadini rivalutano le proposte secondo questa funzione. Il voto tra la versione corrente e ciascun emendamento è **uno a testa**, con maggioranza stretta.

La decisione viene certificata se i **vincoli stimati** sono rispettati con margine di sicurezza. Un valutatore esterno alla procedura verifica separatamente se rispettava i **vincoli veri**, che i votanti e gli esperti non possono consultare. Questa separazione evita di confondere l'efficacia simulata delle stime con la verità effettiva.

## Installazione ed esecuzione

```bash
pip install numpy scipy matplotlib
python simulazione.py --prove 160 --cittadini 1200 --margine 0.22 --output risultati_base
python simulazione.py --prove 120 --cittadini 1200 --margine 0.22 --budget 85 --ambiente 4.5 --output risultati_stress
python simulazione.py --prove 120 --cittadini 1200 --margine 0.22 --budget 85 --ambiente 4.5 --no-rollback --output risultati_senza_rollback
python test_simulazione.py
```

Ogni esecuzione produce `simulazioni.csv`, `riepilogo.csv`, `andamento_proposta.png`, `fattibilita.png`, `esiti_rivoto.png`.

## Risultati ottenuti (semi fissati, impostazioni indicate sopra)

| Scenario | Con rollback: promulgate e realmente valide | Senza rollback: promulgate e realmente valide |
|---|---:|---:|
| Base, stime tecniche accurate, voto informato (160 prove) | **99,4%** | non confrontato qui |
| Base, stime tecniche incerte, voto informato (160 prove) | **63,7%** | non confrontato qui |
| Base, stime accurate, bassa consapevolezza degli effetti (160 prove) | **76,9%** | non confrontato qui |
| Vincoli stringenti, stime accurate, voto informato (120 prove) | **100,0%** | **0,0%** |
| Vincoli stringenti, stime incerte, voto informato (120 prove) | **56,7%** | **29,2%** |
| Vincoli stringenti, stime accurate, bassa consapevolezza (120 prove) | **78,3%** | **0,0%** |

*Nota:* le percentuali non sono tassi attesi nel mondo reale. Sono frequenze prodotte dal modello artificiale e dai parametri scelti. Il margine di sicurezza 0,22 è illustrativo e non è stato pre-registrato.

## Interpretazione

- **Il sistema è implementabile come processo computazionale**: stime tecniche → retropropagazione → alternative → voto → controllo → rivoto, senza privare le persone dell'ultima decisione politica.
- **Il rollback globale è cruciale nel caso di stress**: il voto locale si può bloccare vicino alla frontiera dei vincoli anche se gli elettori approverebbero una modifica completa dalla proposta originale (dipendenza dal percorso delle votazioni).
- **La qualità delle stime è il limite principale**: con esperti molto incerti, una proposta può essere approvata e certificata in base alle stime, ma violare un vincolo reale.
- L'**ottimo teorico**, che usa informazioni esatte non disponibili nella procedura, raggiunge la fattibilità nel 100% delle prove. È un benchmark ideale, non un modello di governo implementabile in questi termini.
- Il risultato **non dimostra** che il sistema sia democraticamente migliore di istituzioni esistenti: non abbiamo dati reali, lobbying, minoranze, informazione strategica, conflitto politico, errori correlati o evoluzione temporale delle politiche.

## Limiti metodologici prioritari

1. Solo tre parametri e quattro domini; molti problemi pubblici non sono lisci/differenziabili.
2. Le preferenze e le competenze sono artificiali; in particolare l'avversione ai vincoli è scelta dal modellatore.
3. Gli esperti producono stime indipendenti e sostanzialmente non manipolate; nella realtà gli errori possono essere correlati o strategici.
4. I vincoli sono trattati come rigidi, anche se alcuni (es. obiettivo ambientale) possono essere discussi politicamente; va separato il livello di diritti e limiti fisici da obiettivi negoziabili.
5. Il fallback è un solo voto globale; manca un processo di nuove proposte, emendamenti parlamentari, negoziazione e reale acquisizione di nuove evidenze.
6. Nel test non si misura la tutela delle minoranze né la robustezza contro manipolazione di informazioni e coalizioni.
7. Il confronto con l'ottimo matematico mostra che la fattibilità può essere ottenuta anche senza voto: il **valore aggiunto democratico**, se esiste, va misurato con metriche separate come legittimità, rappresentanza e qualità della deliberazione.

## Prossima estensione scientifica suggerita

Generalizzare a un **grafo dinamico di ambiti** con proposta `x` ad alta dimensionalità e vincoli `g_k(x, z_k)` dove `z_k` sono stati locali osservati con incertezza. Definire un protocollo di voto con quorum, revisioni ricorsive e arresto, quindi verificare su molte distribuzioni e strategie:

- percentuale di promulgazioni che rispettano i vincoli reali;
- livello di soddisfazione dei cittadini e delle minoranze;
- numero di rivoti, durata e stalli;
- compromessi raggiunti versus frontiera di Pareto;
- robustezza a esperti male informati, falsificazioni, gruppi coordinati e dipendenza dall'ordine degli ambiti.

La domanda fondamentale non è se ottimizzare un sistema di vincoli sia possibile (lo è), ma se il protocollo **mantenga rappresentatività e controllo democratico quando i settori si influenzano reciprocamente**.