# V0 — Origine concettuale (ricostruzione)

**Stato:** ricostruzione retrospettiva del dialogo di progettazione, non software V0 preesistente.

La Democrazia Ponderata Adattiva nasce dal principio che **ogni votazione è ponderata per competenza pertinente alla singola questione**. Il diritto di proposta appartiene a ogni cittadino; la capacità di portare una proposta in votazione dipende da una soglia di sostegno, sottoposta alle regole del processo ponderato.

Le decisioni sono distinte in:
1. Obiettivi comuni, approvati tramite voto ponderato.
2. Metriche tecniche, formulate e deliberate da persone con competenza pertinente.
3. Strategie attuative, composte da interventi contemporanei e sequenziali, approvate tramite voto ponderato.

Le verifiche interdisciplinari segnalano incompatibilità; le conseguenze sono retropropagate alle proposte, che possono essere corrette e sottoposte a rivoto. Il monitoraggio reale genera nuovi segnali di errore; obiettivi e metriche possono essere revisionati attraverso i rispettivi processi di voto ponderato. L'obiettivo primario è il raggiungimento dei target comuni approvati, non la soddisfazione immediata individuale. Disagi e sacrifici sono gestiti come vincoli e criteri secondari.

Questa versione storica serve solo a documentare la genesi delle successive V1–V11, che sono simulazioni **sintetiche, non validate empiricamente**.
