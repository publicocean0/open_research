# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test della DPA V21. Esecuzione: python test_v21.py  (oppure pytest)."""
import numpy as np

import simulazione_v21 as s

SEED = 2121


def test_peso_con_tetto():
    c = np.linspace(0, 1, 101)
    for w_max in (2.0, 3.0, 5.0, 10.0):
        w = s.peso_v21(c, w_max)
        assert w.min() == 1.0 and abs(w.max() - w_max) < 1e-12
        assert np.all(np.diff(w) >= 0)
        assert np.all(w[c <= s.PARAMETRI["tau"]] == 1.0)
    # il peso senza tetto (stile V3) puo' superare di molto il rapporto 3
    estremi = s.peso_senza_tetto(np.array([[1.0] * 4, [0.0] * 4]))
    assert estremi[0] / estremi[1] > 10


def test_limite_d14():
    m = s.crea_mondo(SEED, 0, "competenze_gonfiate")
    for regime in ("dpa_v21", "dpa_v21_w2", "dpa_v21_w5", "dpa_v21_w10"):
        w = s.pesi_regime(regime, m.pop)
        for g in np.unique(m.pop.gruppo):
            mask = m.pop.gruppo == g
            quota = w[mask].sum() / w.sum()
            assert quota <= s.limite_d14(mask.mean(), s.wmax_regime(regime)) + 1e-12


def test_impossibilita_esatta():
    A = np.array([[1.0, 0, 0], [-1.0, 0, 0]])
    b = np.array([1.0, -2.0])          # x <= 1 e x >= 2: nessuna soluzione
    stato, punto = s.verifica_ammissibilita(A, b, np.zeros(3))
    assert stato == "impossibile" and punto is None
    stato, punto = s.verifica_ammissibilita(A[:1], b[:1], np.zeros(3))
    assert stato == "ammissibile" and punto is not None


def test_proposte_ammissibili_sulle_stime():
    for scenario in s.SCENARI:
        for i in range(4):
            m = s.crea_mondo(SEED, i, scenario)
            for metodo in ("media", "mediana"):
                for diritto in (False, True):
                    p = s.genera_proposte(m, metodo, diritto)
                    if p["stato"] != "ammissibile":
                        continue
                    for x in p["proposte"]:
                        assert s.violazione_max(p["A_hat"], p["b_cert"], x, p["lb"]) <= 1e-7
                        if diritto:
                            assert x[2] >= m.t_min - 1e-9


def test_ottimo_tecnico_massimizza_preferenza():
    m = s.crea_mondo(SEED, 1, "base")
    p = s.genera_proposte(m, "mediana", True)
    assert p["tecnico_ok"]
    ben = s.preferenza(m.pop, p["proposte"]).mean(0)
    assert ben[0] >= ben.max() - 1e-6


def test_diritti_a_voto_uguale():
    righe = []
    for scenario in s.SCENARI:
        for i in range(4):
            righe += s.esegui_mondo(SEED, i, scenario)
    for r in righe:
        if r["regime"] != "senza_tetto":
            assert r["ribaltamento_diritto"] == 0
            assert r["diritto_adottato"] == r["diritto_per_teste"]


def test_mediana_robusta():
    rng = np.random.default_rng(0)
    onesti = rng.normal(10, 0.3, 60)
    corrotti = onesti[:40] + 1.5
    v = np.r_[onesti, corrotti]
    w = np.r_[np.ones(60), np.full(40, 1.2)]
    media = (w * v).sum() / w.sum()
    assert abs(s.mediana_pesata(v, w) - 10) < abs(media - 10)


def test_determinismo():
    a = s.esegui_mondo(SEED, 3, "esperti_corrotti")
    b = s.esegui_mondo(SEED, 3, "esperti_corrotti")
    assert len(a) == len(b)
    for x, y in zip(a, b):
        assert x.keys() == y.keys()
        for k in x:
            if isinstance(x[k], float) and np.isnan(x[k]):
                assert np.isnan(y[k])
            else:
                assert x[k] == y[k], k


if __name__ == "__main__":
    test = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in test:
        t()
        print("OK", t.__name__)
    print(f"OK V21: {len(test)} test superati")
