# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DPA V21 — Democrazia Ponderata Adattiva raffinata.

Raffinamenti rispetto alle versioni precedenti:

1. peso di voto con tetto ``w_max`` e soglia ``tau`` (nessun cittadino pesa meno di 1);
2. voto uguale (una testa, un voto) sulle questioni di diritto universale;
3. competenza epistemicamente attiva: chi e' piu' competente percepisce i vincoli
   con meno errore e, se esperto, li stima con meno rumore;
4. due riferimenti sempre presenti: voto uguale e ottimizzatore tecnico senza voto;
5. verifica esatta di ammissibilita' (vincoli lineari, programmazione lineare):
   si distingue "impossibile secondo le stime" da "soluzione non trovata";
6. prove di manipolazione (esperti corrotti, competenze gonfiate) e misure
   sulle minoranze;
7. molti mondi, parametri fissati prima dei risultati, intervalli bootstrap
   accoppiati, esecuzione deterministica.

Simulazione su popolazioni sintetiche: non e' una prova dell'efficacia di un
ordinamento reale.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import csv
import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from scipy.optimize import linprog, minimize

# ---------------------------------------------------------------------------
# Parametri (fissati prima dell'esecuzione delle batterie)
# ---------------------------------------------------------------------------
DOMINI = ("acqua", "trasporti", "bilancio", "ambiente")
VARIABILI = ("abitazioni", "rete_idrica", "trasporti")
A_BASE = np.array([
    [1.00, -1.00, 0.00],   # acqua: h - w <= 7
    [1.00, 0.00, -0.90],   # trasporti: h - 0.9 t <= 6.8
    [0.72, 0.85, 0.80],    # bilancio
    [0.72, -0.30, -0.55],  # ambiente
])
B_BASE = np.array([7.0, 6.8, 10.0, 5.0])
LIMITE_INF, LIMITE_SUP = 0.0, 15.0

PARAMETRI = {
    "cittadini": 600,
    "gruppi": {
        # quota, ideale medio (h, w, t), parametri Beta della competenza
        "maggioranza": [0.60, [9.0, 4.0, 4.0], [2, 4]],
        "minoranza": [0.25, [5.0, 3.0, 8.0], [2, 4]],
        "tecnico": [0.15, [6.0, 5.0, 3.0], [5, 2]],
    },
    "rumore_ideale": 1.2,
    "importanza": [0.5, 1.5],
    "avversione_rischio": [0.5, 3.0],
    "penalita_vincolo": 4.0,
    "rumore_percezione": 2.0,       # sd errore percezione = 2.0 * (1 - 0.85 c)
    "riduzione_percezione": 0.85,
    "soglia_esperto": 0.65,
    "rumore_esperto_A": 0.10,       # rumore moltiplicativo * (1 - c)
    "rumore_esperto_b": 1.00,       # rumore additivo * (1 - c)
    "errore_comune_A": 0.03,        # errore di modello condiviso dalla disciplina
    "errore_comune_b": 0.25,
    "margine_certificazione": 0.15,
    "rilevanza_domini": [0.25, 0.25, 0.25, 0.25],
    "tau": 0.40,
    "w_max": 3.0,
    "w_max_sensibilita": [2.0, 5.0, 10.0],
    "diritto_t_min": [5.0, 7.0],    # servizio minimo universale di trasporto
    "sostegno_diritto": {"maggioranza": [0.40, 0.65], "minoranza": 0.92,
                         "tecnico": 0.15, "lobby": 0.10},
    "corrotti_quota_tecnici": 0.50,
    "corrotti_allentamento_b": 1.50,
    "lobby_quota": 0.10,
    "lobby_ideale": [13.0, 2.0, 2.0],
    "lobby_gonfiamento": 0.50,
    "metrica_protezione": 6.0,
    "passo_retropropagazione": 0.5,
    "tolleranza_ammissibilita": 1e-7,
    "bootstrap": 2000,
}

SCENARI = ("base", "esperti_corrotti", "competenze_gonfiate")
REGIMI = ("uguale", "senza_tetto", "dpa_v21", "dpa_v21_media", "dpa_v21_w2",
          "dpa_v21_w5", "dpa_v21_w10", "tecnico")


def wmax_regime(regime: str) -> float | None:
    if regime in ("dpa_v21", "dpa_v21_media"):
        return PARAMETRI["w_max"]
    if regime.startswith("dpa_v21_w"):
        return float(regime.split("_w")[-1])
    return None


def metodo_stima(regime: str) -> str:
    """Il regime senza tetto aggrega le stime con media pesata c^2 (come V3);
    gli altri con mediana pesata a pesi limitati (raffinamento V21).
    ``dpa_v21_media`` e' l'ablazione: regole V21 ma media pesata c^2."""
    return "media" if regime in ("senza_tetto", "dpa_v21_media") else "mediana"


# ---------------------------------------------------------------------------
# Pesi
# ---------------------------------------------------------------------------
def peso_v21(competenza: np.ndarray, w_max: float, tau: float | None = None) -> np.ndarray:
    """Peso con soglia e tetto: 1 sotto tau, poi lineare fino a w_max per c=1."""
    tau = PARAMETRI["tau"] if tau is None else tau
    c = np.clip(np.asarray(competenza, dtype=float), 0.0, 1.0)
    return np.where(c <= tau, 1.0, 1.0 + (w_max - 1.0) * (c - tau) / (1.0 - tau))


def peso_senza_tetto(c_cert: np.ndarray) -> np.ndarray:
    """Peso in stile V3: 0.08 + somma_k r_k c_k^2 (nessun tetto)."""
    r = np.array(PARAMETRI["rilevanza_domini"])
    return 0.08 + (np.clip(c_cert, 0, 1) ** 2) @ r


def limite_d14(quota_teste: float, w_max: float) -> float:
    """Quota massima di peso di un gruppo con frazione f di teste."""
    f = quota_teste
    return f * w_max / (f * w_max + (1.0 - f)) if f > 0 else 0.0


def pesi_regime(regime: str, pop: "Popolazione") -> np.ndarray:
    if regime in ("uguale", "tecnico"):
        return np.ones(pop.n)
    if regime == "senza_tetto":
        return peso_senza_tetto(pop.c_cert)
    r = np.array(PARAMETRI["rilevanza_domini"])
    return peso_v21(pop.c_cert @ r, wmax_regime(regime))


# ---------------------------------------------------------------------------
# Mondo e popolazione
# ---------------------------------------------------------------------------
@dataclass
class Popolazione:
    gruppo: np.ndarray
    ideale: np.ndarray
    omega: np.ndarray
    avversione: np.ndarray
    c_vera: np.ndarray
    c_cert: np.ndarray
    eps: np.ndarray
    sostegno_diritto: np.ndarray
    allentamento_b: np.ndarray
    corrotto: np.ndarray
    zA: np.ndarray
    zb: np.ndarray

    @property
    def n(self) -> int:
        return len(self.gruppo)


@dataclass
class Mondo:
    indice: int
    A: np.ndarray
    b: np.ndarray
    bias_A: np.ndarray
    bias_b: np.ndarray
    t_min: float
    pop: Popolazione
    gruppo_sorvegliato: str = "tecnico"
    cache: dict = field(default_factory=dict)


def crea_mondo(seed: int, indice: int, scenario: str) -> Mondo:
    P = PARAMETRI
    rng = np.random.default_rng([seed, indice])
    A = A_BASE * rng.uniform(0.85, 1.15, A_BASE.shape)
    b = B_BASE * rng.uniform(0.9, 1.1, B_BASE.shape)
    bias_A = rng.normal(0, P["errore_comune_A"], 4)
    bias_b = rng.normal(0, P["errore_comune_b"], 4)
    t_min = rng.uniform(*P["diritto_t_min"])
    p_magg = rng.uniform(*P["sostegno_diritto"]["maggioranza"])

    n = P["cittadini"]
    nomi = list(P["gruppi"])
    quote = [P["gruppi"][g][0] for g in nomi]
    conteggi = np.floor(np.array(quote) * n).astype(int)
    conteggi[0] += n - conteggi.sum()
    gruppo = np.repeat(np.array(nomi, dtype=object), conteggi)
    ideale = np.vstack([np.array(P["gruppi"][g][1]) for g in gruppo])
    ideale = np.clip(ideale + rng.normal(0, P["rumore_ideale"], ideale.shape),
                     LIMITE_INF, LIMITE_SUP)
    omega = rng.uniform(*P["importanza"], (n, 3))
    avversione = rng.uniform(*P["avversione_rischio"], n)
    ab = np.array([P["gruppi"][g][2] for g in gruppo])
    c_vera = rng.beta(ab[:, :1], ab[:, 1:], (n, 4))
    u_diritto = rng.uniform(size=n)
    eps_std = rng.normal(size=(n, 4))
    zA = rng.normal(size=(n, 4, 3))
    zb = rng.normal(size=(n, 4))

    # modifiche di scenario (generatore separato: il mondo di base resta uguale)
    srng = np.random.default_rng([seed, indice, 100 + SCENARI.index(scenario)])
    c_cert = c_vera.copy()
    allentamento = np.zeros(n)
    corrotto = np.zeros(n, dtype=bool)
    sorvegliato = "tecnico"
    if scenario == "esperti_corrotti":
        tec = np.where(gruppo == "tecnico")[0]
        k = int(round(P["corrotti_quota_tecnici"] * len(tec)))
        scelti = srng.choice(tec, k, replace=False)
        corrotto[scelti] = True
        allentamento[scelti] = P["corrotti_allentamento_b"]
        avversione[scelti] = 0.0   # votano ignorando l'ammissibilita'
    elif scenario == "competenze_gonfiate":
        magg = np.where(gruppo == "maggioranza")[0]
        k = int(round(P["lobby_quota"] * n))
        scelti = srng.choice(magg, k, replace=False)
        gruppo[scelti] = "lobby"
        ideale[scelti] = np.clip(np.array(P["lobby_ideale"]) +
                                 srng.normal(0, P["rumore_ideale"], (k, 3)),
                                 LIMITE_INF, LIMITE_SUP)
        c_cert[scelti] = np.clip(c_vera[scelti] + P["lobby_gonfiamento"], 0, 1)
        sorvegliato = "lobby"

    p_sost = np.array([
        p_magg if g == "maggioranza" else P["sostegno_diritto"][g] for g in gruppo
    ])
    sostegno = u_diritto < p_sost
    eps = eps_std * P["rumore_percezione"] * (1 - P["riduzione_percezione"] * c_vera)

    pop = Popolazione(gruppo, ideale, omega, avversione, c_vera, c_cert, eps,
                      sostegno, allentamento, corrotto, zA, zb)
    return Mondo(indice, A, b, bias_A, bias_b, t_min, pop, sorvegliato)


# ---------------------------------------------------------------------------
# Stima tecnica dei vincoli
# ---------------------------------------------------------------------------
def mediana_pesata(valori: np.ndarray, pesi: np.ndarray) -> float:
    ordine = np.argsort(valori)
    v, w = valori[ordine], pesi[ordine]
    cum = np.cumsum(w)
    return float(v[np.searchsorted(cum, 0.5 * cum[-1])])


def stima_vincoli(m: Mondo, metodo: str) -> tuple[np.ndarray, np.ndarray, list[int]]:
    P, pop = PARAMETRI, m.pop
    A_hat = np.zeros_like(m.A)
    b_hat = np.zeros_like(m.b)
    n_esperti = []
    for k in range(4):
        cc = pop.c_cert[:, k]
        idx = np.where(cc >= P["soglia_esperto"])[0]
        if len(idx) < 5:
            idx = np.argsort(cc)[-5:]
        ct = pop.c_vera[idx, k]
        A_rep = (m.A[k] * (1 + m.bias_A[k]) *
                 (1 + P["rumore_esperto_A"] * (1 - ct)[:, None] * pop.zA[idx, k, :]))
        b_rep = (m.b[k] + m.bias_b[k] + P["rumore_esperto_b"] * (1 - ct) * pop.zb[idx, k]
                 + pop.allentamento_b[idx])
        if metodo == "media":
            w = cc[idx] ** 2
            A_hat[k] = (w[:, None] * A_rep).sum(0) / w.sum()
            b_hat[k] = (w * b_rep).sum() / w.sum()
        else:
            w = peso_v21(cc[idx], PARAMETRI["w_max"])
            A_hat[k] = [mediana_pesata(A_rep[:, j], w) for j in range(3)]
            b_hat[k] = mediana_pesata(b_rep, w)
        n_esperti.append(len(idx))
    return A_hat, b_hat, n_esperti


# ---------------------------------------------------------------------------
# Ammissibilita' esatta e proposte
# ---------------------------------------------------------------------------
def limiti_variabili(t_min: float | None) -> np.ndarray:
    lb = np.full(3, LIMITE_INF)
    if t_min is not None:
        lb[2] = t_min
    return lb


def violazione_max(A: np.ndarray, b: np.ndarray, x: np.ndarray, lb: np.ndarray) -> float:
    return float(max(np.max(A @ x - b), np.max(lb - x), np.max(x - LIMITE_SUP), 0.0))


def verifica_ammissibilita(A: np.ndarray, b: np.ndarray, lb: np.ndarray):
    """Programmazione lineare: ('ammissibile', punto) | ('impossibile', None) |
    ('non_trovato', None) se il risolutore non conclude."""
    res = linprog(np.zeros(3), A_ub=A, b_ub=b,
                  bounds=[(lb[j], LIMITE_SUP) for j in range(3)], method="highs")
    if res.status == 0:
        return "ammissibile", np.asarray(res.x)
    if res.status == 2:
        return "impossibile", None
    return "non_trovato", None


def proietta(x0, D, A, b, lb, punto_lp):
    """min (x-x0)' diag(D) (x-x0)  con  A x <= b,  lb <= x <= 15.
    Restituisce solo soluzioni verificate ammissibili."""
    tol = PARAMETRI["tolleranza_ammissibilita"]
    fun = lambda x: float(((x - x0) ** 2 * D).sum())
    jac = lambda x: 2 * D * (x - x0)
    vincoli = [{"type": "ineq", "fun": lambda x: b - A @ x, "jac": lambda x: -A}]
    migliore = None
    for s in (np.clip(x0, lb, LIMITE_SUP), punto_lp):
        r = minimize(fun, s, jac=jac, method="SLSQP",
                     bounds=[(lb[j], LIMITE_SUP) for j in range(3)],
                     constraints=vincoli, options={"ftol": 1e-12, "maxiter": 500})
        x = np.clip(r.x, lb, LIMITE_SUP)
        if violazione_max(A, b, x, lb) <= tol and (migliore is None or fun(x) < fun(migliore)):
            migliore = x
    if migliore is None and violazione_max(A, b, punto_lp, lb) <= tol:
        migliore = punto_lp.copy()
    return migliore


def genera_proposte(m: Mondo, metodo: str, diritto: bool):
    chiave = (metodo, diritto)
    if chiave in m.cache:
        return m.cache[chiave]
    P, pop = PARAMETRI, m.pop
    A_hat, b_hat, n_esperti = stima_vincoli(m, metodo)
    b_cert = b_hat - P["margine_certificazione"]
    lb = limiti_variabili(m.t_min if diritto else None)
    stato, punto = verifica_ammissibilita(A_hat, b_cert, lb)
    proposte = []
    tecnico_ok = False
    if stato == "ammissibile":
        W = pop.omega.sum(0)
        x_util = (pop.omega * pop.ideale).sum(0) / W
        # 0: ottimo utilitarista sulle stime (ottimizzatore tecnico)
        grezze = [proietta(x_util, W / W.mean(), A_hat, b_cert, lb, punto)]
        # proiezioni che proteggono una variabile alla volta
        for j in range(3):
            D = np.ones(3)
            D[j] = P["metrica_protezione"]
            grezze.append(proietta(x_util, D, A_hat, b_cert, lb, punto))
        # passo di retropropagazione deliberativa, poi proiezione
        v = np.maximum(0, A_hat @ x_util - b_cert)
        x_bp = x_util - P["passo_retropropagazione"] * A_hat.T @ v
        grezze.append(proietta(x_bp, np.ones(3), A_hat, b_cert, lb, punto))
        # proposte dei gruppi
        for g in np.unique(pop.gruppo):
            grezze.append(proietta(pop.ideale[pop.gruppo == g].mean(0), np.ones(3),
                                   A_hat, b_cert, lb, punto))
        tecnico_ok = grezze[0] is not None
        for x in grezze:
            if x is not None and all(np.linalg.norm(x - y) > 0.05 for y in proposte):
                proposte.append(x)
        if not proposte:
            stato = "non_trovato"
    out = {"stato": stato, "proposte": np.array(proposte), "A_hat": A_hat,
           "b_cert": b_cert, "lb": lb, "n_esperti": n_esperti,
           "tecnico_ok": tecnico_ok}
    m.cache[chiave] = out
    return out


# ---------------------------------------------------------------------------
# Utilita' e voto
# ---------------------------------------------------------------------------
def preferenza(pop: Popolazione, X: np.ndarray) -> np.ndarray:
    """Termine di preferenza (N x C)."""
    return -((X[None, :, :] - pop.ideale[:, None, :]) ** 2 * pop.omega[:, None, :]).sum(2)


def utilita_percepita(m: Mondo, X: np.ndarray) -> np.ndarray:
    pop = m.pop
    g_vero = X @ m.A.T - m.b                      # C x 4
    g_perc = g_vero[None, :, :] + pop.eps[:, None, :]
    pen = PARAMETRI["penalita_vincolo"] * pop.avversione[:, None] * \
        (np.maximum(0, g_perc) ** 2).sum(2)
    return preferenza(pop, X) - pen


def voto_copeland(U: np.ndarray, w: np.ndarray) -> int:
    C = U.shape[1]
    punti = np.zeros(C)
    for p in range(C):
        for q in range(p + 1, C):
            sp, sq = w[U[:, p] > U[:, q]].sum(), w[U[:, q] > U[:, p]].sum()
            if sp > sq:
                punti[p] += 1
            elif sq > sp:
                punti[q] += 1
            else:
                punti[p] += 0.5
                punti[q] += 0.5
    borda = (U.argsort(1).argsort(1) * w[:, None]).sum(0)
    return max(range(C), key=lambda c: (punti[c], borda[c], -c))


def decide_diritto(regime: str, pop: Popolazione) -> tuple[bool, bool]:
    """Restituisce (adottato, maggioranza_per_teste)."""
    per_teste = pop.sostegno_diritto.mean() > 0.5
    if regime == "senza_tetto":
        w = peso_senza_tetto(pop.c_cert)
        return bool((w * pop.sostegno_diritto).sum() > 0.5 * w.sum()), bool(per_teste)
    return bool(per_teste), bool(per_teste)   # voto uguale sui diritti universali


# ---------------------------------------------------------------------------
# Esecuzione di un mondo
# ---------------------------------------------------------------------------
def esegui_mondo(seed: int, indice: int, scenario: str) -> list[dict]:
    m = crea_mondo(seed, indice, scenario)
    pop = m.pop
    righe = []
    gruppi = np.unique(pop.gruppo)
    for regime in REGIMI:
        diritto, per_teste = decide_diritto(regime, pop)
        metodo = metodo_stima(regime)
        prop = genera_proposte(m, metodo, diritto)
        # verita': il programma esiste davvero con i vincoli veri?
        lb_vero = limiti_variabili(m.t_min if diritto else None)
        stato_vero, _ = verifica_ammissibilita(m.A, m.b, lb_vero)
        w = pesi_regime(regime, pop)
        quota_sorv = w[pop.gruppo == m.gruppo_sorvegliato].sum() / w.sum()
        f_sorv = float((pop.gruppo == m.gruppo_sorvegliato).mean())
        top = np.sort(w)[::-1][: max(1, pop.n // 10)].sum() / w.sum()
        riga = {
            "mondo": indice, "scenario": scenario, "regime": regime,
            "metodo_stima": metodo, "stato": "", "ammissibile_vero_esiste": int(stato_vero == "ammissibile"),
            "diritto_adottato": int(diritto), "diritto_per_teste": int(per_teste),
            "ribaltamento_diritto": int(diritto != per_teste), "t_min": round(m.t_min, 4),
            "n_proposte": len(prop["proposte"]),
            "esperti_min": min(prop["n_esperti"]),
            "gruppo_sorvegliato": m.gruppo_sorvegliato,
            "quota_peso_sorvegliato": quota_sorv, "quota_teste_sorvegliato": f_sorv,
            "limite_d14": (limite_d14(f_sorv, wmax_regime(regime))
                           if wmax_regime(regime) else np.nan),
            "quota_peso_top10": top, "rapporto_peso_max_min": float(w.max() / w.min()),
        }
        if prop["stato"] != "ammissibile":
            riga["stato"] = ("impossibile_stimato" if prop["stato"] == "impossibile"
                             else "non_trovato")
            righe.append(riga)
            continue
        X = prop["proposte"]
        if regime == "tecnico":
            if not prop["tecnico_ok"]:
                riga["stato"] = "non_trovato"
                righe.append(riga)
                continue
            scelta = 0
        else:
            scelta = voto_copeland(utilita_percepita(m, X), w)
        x = X[scelta]
        U_perc = utilita_percepita(m, X)
        rango = (U_perc > U_perc[:, [scelta]]).sum(1)   # quante proposte preferite
        pref = preferenza(pop, x[None, :])[:, 0]
        g_vero = m.A @ x - m.b
        viol = float(np.maximum(0, g_vero).sum())
        danno = PARAMETRI["penalita_vincolo"] * pop.avversione.mean() * \
            float((np.maximum(0, g_vero) ** 2).sum())
        riga.update({
            "stato": "adottata", "proposta_scelta": scelta,
            "x_abitazioni": x[0], "x_rete_idrica": x[1], "x_trasporti": x[2],
            "fattibile_vera": int(np.max(g_vero) <= 1e-9),
            "violazione_vera": viol,
            "benessere_medio": float(pref.mean()),
            "benessere_totale": float(pref.mean()) - danno,
            "benessere_minoranza": float(pref[pop.gruppo == "minoranza"].mean()),
            "benessere_peggior_gruppo": float(min(pref[pop.gruppo == g].mean() for g in gruppi)),
            "soddisfazione": float((rango < len(X) / 2).mean()),
        })
        righe.append(riga)
    # differenza rispetto al voto uguale
    base = next(r for r in righe if r["regime"] == "uguale")
    for r in righe:
        if r["stato"] == "adottata" and base["stato"] == "adottata":
            d = np.linalg.norm([r[f"x_{v}"] - base[f"x_{v}"] for v in VARIABILI])
            r["diverso_da_uguale"] = int(d > 0.05)
    return righe


# ---------------------------------------------------------------------------
# Riepiloghi e bootstrap accoppiato
# ---------------------------------------------------------------------------
METRICHE = ("fattibile_vera", "violazione_vera", "benessere_medio", "benessere_totale",
            "benessere_minoranza", "benessere_peggior_gruppo", "soddisfazione",
            "ribaltamento_diritto", "diritto_adottato", "diverso_da_uguale",
            "quota_peso_sorvegliato", "quota_peso_top10", "rapporto_peso_max_min")
CONFRONTI = ("fattibile_vera", "violazione_vera", "benessere_medio", "benessere_totale",
             "benessere_minoranza", "benessere_peggior_gruppo", "soddisfazione")


def ic_bootstrap(valori: np.ndarray, rng: np.random.Generator, B: int):
    valori = np.asarray(valori, dtype=float)
    if len(valori) == 0:
        return np.nan, np.nan, np.nan
    idx = rng.integers(0, len(valori), (B, len(valori)))
    medie = valori[idx].mean(1)
    return float(valori.mean()), float(np.quantile(medie, 0.025)), float(np.quantile(medie, 0.975))


def valore(r: dict, k: str) -> float:
    v = r.get(k, np.nan)
    return np.nan if v == "" or v is None else float(v)


def riepiloga(righe: list[dict], seed: int):
    B = PARAMETRI["bootstrap"]
    rng = np.random.default_rng([seed, 999])
    riepilogo, confronti = [], []
    for s in SCENARI:
        per_regime = {g: [r for r in righe if r["scenario"] == s and r["regime"] == g]
                      for g in REGIMI}
        for g, rr in per_regime.items():
            out = {"scenario": s, "regime": g, "mondi": len(rr),
                   "adottate": sum(r["stato"] == "adottata" for r in rr),
                   "impossibile_stimato": sum(r["stato"] == "impossibile_stimato" for r in rr),
                   "non_trovato": sum(r["stato"] == "non_trovato" for r in rr)}
            for k in METRICHE:
                v = np.array([valore(r, k) for r in rr])
                v = v[~np.isnan(v)]
                mu, lo, hi = ic_bootstrap(v, rng, B)
                out[k] = mu
                out[k + "_ic_basso"] = lo
                out[k + "_ic_alto"] = hi
            riepilogo.append(out)
        for rif in ("uguale", "tecnico"):
            ref = {r["mondo"]: r for r in per_regime[rif]}
            for g in REGIMI:
                if g == rif:
                    continue
                for k in CONFRONTI:
                    d = [valore(r, k) - valore(ref[r["mondo"]], k) for r in per_regime[g]
                         if r["stato"] == "adottata" and ref[r["mondo"]]["stato"] == "adottata"]
                    mu, lo, hi = ic_bootstrap(np.array(d), rng, B)
                    confronti.append({"scenario": s, "regime": g, "riferimento": rif,
                                      "metrica": k, "mondi_accoppiati": len(d),
                                      "differenza_media": mu, "ic95_basso": lo,
                                      "ic95_alto": hi})
    return riepilogo, confronti


def scrivi_csv(percorso: Path, righe: list[dict]):
    chiavi = []
    for r in righe:
        for k in r:
            if k not in chiavi:
                chiavi.append(k)
    with percorso.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=chiavi)
        w.writeheader()
        for r in righe:
            w.writerow({k: (f"{v:.6g}" if isinstance(v, (float, np.floating)) else v)
                        for k, v in r.items()})


def esegui(mondi: int, seed: int, scenari=SCENARI) -> list[dict]:
    righe = []
    for s in scenari:
        for i in range(mondi):
            righe.extend(esegui_mondo(seed, i, s))
    return righe


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--mondi", type=int, default=200)
    ap.add_argument("--seed", type=int, default=2121)
    ap.add_argument("--output", type=Path, default=Path(__file__).parent / "risultati")
    ap.add_argument("--margine", type=float, default=None,
                    help="margine di certificazione (sensibilita'); default 0.15")
    ap.add_argument("--test", action="store_true", help="prova rapida su 3 mondi")
    a = ap.parse_args()
    if a.margine is not None:
        PARAMETRI["margine_certificazione"] = a.margine
    mondi = 3 if a.test else a.mondi
    righe = esegui(mondi, a.seed)
    riepilogo, confronti = riepiloga(righe, a.seed)
    a.output.mkdir(parents=True, exist_ok=True)
    scrivi_csv(a.output / "dettaglio.csv", righe)
    scrivi_csv(a.output / "riepilogo.csv", riepilogo)
    scrivi_csv(a.output / "confronti_accoppiati.csv", confronti)
    (a.output / "parametri.json").write_text(
        json.dumps({"mondi": mondi, "seed": a.seed, "scenari": SCENARI, "regimi": REGIMI,
                    **PARAMETRI}, indent=2, ensure_ascii=False), encoding="utf-8")
    for r in riepilogo:
        print(f"{r['scenario']:20s} {r['regime']:12s} adottate={r['adottate']:3d} "
              f"fatt={r['fattibile_vera']:.3f} ben={r['benessere_medio']:.2f} "
              f"min={r['benessere_minoranza']:.2f} sodd={r['soddisfazione']:.3f} "
              f"rib={r['ribaltamento_diritto']:.3f} quota={r['quota_peso_sorvegliato']:.3f}")


if __name__ == "__main__":
    main()
