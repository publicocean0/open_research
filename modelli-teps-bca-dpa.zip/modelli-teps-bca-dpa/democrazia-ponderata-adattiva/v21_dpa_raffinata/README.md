# Democrazia Ponderata Adattiva — V21 (raffinata)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra l'efficacia
di un ordinamento reale. Tutti i numeri seguenti sono prodotti dal simulatore con
parametri fissati prima dell'esecuzione (`risultati/parametri.json`).

La V21 non aggiunge un nuovo meccanismo decisionale: **raffina** la DPA delle
versioni V3–V16 e corregge i difetti emersi dalla revisione del codice.

## Raffinamenti

| # | Raffinamento | Motivo (revisione V0–V16) |
|---|---|---|
| 1 | **Tetto ai pesi** `w = 1 + (w_max−1)(C−τ)/(1−τ)` per `C > τ`, altrimenti `w = 1`; `w_max = 3`, `τ = 0,40`. Nessun cittadino pesa meno di 1. | Nelle versioni precedenti il rapporto tra peso massimo e minimo poteva arrivare a ~13 (`0,08 + Σ r c²`). |
| 2 | **Voto uguale sui diritti universali** (qui: servizio minimo universale di trasporto `t ≥ t_min`). | Il diritto non deve dipendere dalla competenza certificata. |
| 3 | **Competenza epistemicamente attiva**: chi è più competente percepisce i vincoli con meno errore (`σ = 2,0·(1 − 0,85c)`) e, se esperto (`c ≥ 0,65`), li stima con meno rumore. | Prima la competenza modificava solo il peso, non la qualità dell'informazione. |
| 4 | **Due riferimenti sempre presenti**: voto uguale e ottimizzatore tecnico senza voto (ottimo utilitarista sulle stime). | Senza riferimenti non si distingue l'effetto del peso da quello dell'ottimizzazione. |
| 5 | **Ammissibilità esatta**: vincoli lineari verificati con programmazione lineare (HiGHS). Si distingue `impossibile_stimato` da `non_trovato`; ogni proposta è verificata prima del voto. | In V12–V13 i fallimenti di recupero erano spesso fallimenti del risolutore locale (SLSQP), non impossibilità. |
| 6 | **Aggregazione robusta delle stime**: mediana pesata (pesi con tetto) invece della media pesata `c²`. | Resistenza a esperti che falsano le stime. |
| 7 | **Prove di manipolazione e minoranze**: esperti corrotti, competenze gonfiate, benessere della minoranza e del gruppo peggiore. | Non erano mai state verificate. |
| 8 | **Statistica**: 200 mondi indipendenti per scenario, bootstrap accoppiato per mondo (2000 ricampionamenti), esecuzione deterministica, nessuna informazione vera passata al decisore. | In V11/V16 lo stimatore leggeva valori veri; in V14–V16 gli shock di addestramento erano quelli di test più rumore. |

## Modello

- Decisione `x = (abitazioni, rete idrica, trasporti)`, ciascuna in `[0, 15]`.
- Quattro vincoli tecnici lineari veri `A x ≤ b` (acqua, trasporti, bilancio,
  ambiente), con coefficienti diversi in ogni mondo. Il decisore **non** li vede:
  usa le stime degli esperti meno un margine di certificazione `m = 0,15`.
  Gli esperti condividono un errore di modello comune (non eliminabile mediando).
  I vincoli sono la linearizzazione di quelli della V1, scelta per poter
  verificare l'ammissibilità in modo esatto.
- 600 cittadini: maggioranza 60% (ideale medio 9, 4, 4), minoranza 25% (5, 3, 8),
  tecnici 15% (6, 5, 3); competenza Beta(2,4) o Beta(5,2) su quattro domini.
  Il bilancio è sempre vincolante: le preferenze sono in conflitto.
- Proposte (fino a 9): ottimo tecnico, proiezioni che proteggono una variabile,
  passo di retropropagazione deliberativa `x − α Âᵀ max(0, Âx − b̂)`, proposte dei
  gruppi; tutte ammissibili rispetto alle stime.
- Voto: Copeland pesato, parità risolte con Borda pesato.

### Regimi confrontati

| Regime | Voto sul piano | Voto sul diritto | Stime tecniche |
|---|---|---|---|
| `uguale` | una testa un voto | per teste | mediana robusta |
| `senza_tetto` | peso `0,08 + Σ r c²` (stile V3) | pesato | media pesata `c²` |
| `dpa_v21` | peso con tetto `w_max = 3` | per teste | mediana robusta |
| `dpa_v21_media` | come `dpa_v21` (ablazione) | per teste | media pesata `c²` |
| `dpa_v21_w2/w5/w10` | tetto 2, 5, 10 (sensibilità) | per teste | mediana robusta |
| `tecnico` | nessun voto: ottimo sulle stime | per teste | mediana robusta |

### Scenari

- `base`.
- `esperti_corrotti`: metà dei tecnici allenta di 1,5 le stime dei limiti e vota
  ignorando l'ammissibilità.
- `competenze_gonfiate`: una lobby pari al 10% della popolazione (presa dalla
  maggioranza, ideale 13, 2, 2) ha competenza certificata gonfiata di +0,5; la sua
  accuratezza reale resta bassa.

## Risultati (200 mondi per scenario, margine 0,15)

In tutti i 4 800 casi il piano è stato adottato: nessun caso `impossibile_stimato`
né `non_trovato`; l'insieme vero era sempre non vuoto. La verifica esatta è quindi
attiva ma in questa batteria non è mai scattata.

| Scenario | Regime | Fattibile davvero (IC 95%) | Benessere medio | Benessere minoranza | Diritto ribaltato | Quota peso gruppo sorvegliato |
|---|---|---:|---:|---:|---:|---:|
| base | uguale | 61,5% (55,0–68,0) | −23,27 | −13,80 | 0% | 15,0% |
| base | senza_tetto | 64,0% (57,5–71,0) | −18,35 | −22,00 | 57,5% | 32,8% |
| base | dpa_v21 | 61,5% (54,5–68,5) | −23,26 | −13,78 | 0% | 25,7% |
| base | tecnico | 61,5% (55,0–68,5) | −23,26 | −13,78 | 0% | — |
| esperti corrotti | uguale | 47,0% (40,5–54,5) | −22,39 | −13,55 | 0% | 15,0% |
| esperti corrotti | senza_tetto | 22,5% (16,5–28,5) | −16,88 | −21,58 | 57,5% | 32,8% |
| esperti corrotti | dpa_v21 | 47,0% (40,0–54,5) | −22,39 | −13,53 | 0% | 25,7% |
| esperti corrotti | dpa_v21_media | 19,5% (14,0–25,0) | −20,59 | −13,28 | 0% | 25,7% |
| competenze gonfiate | uguale | 61,5% (54,5–68,5) | −25,58 | −18,51 | 0% | 10,0% |
| competenze gonfiate | senza_tetto | 63,5% (57,0–70,5) | −19,17 | −28,96 | 69,5% | 22,7% |
| competenze gonfiate | dpa_v21 | 61,5% (55,0–68,5) | −25,58 | −18,53 | 0% | 17,9% |

Gruppo sorvegliato: tecnici (base, esperti corrotti), lobby (competenze gonfiate).
Il benessere è il termine di preferenza (più vicino a zero = meglio); **non
include il valore intrinseco del diritto**, quindi rinunciare al diritto appare
come un guadagno medio.

### Cosa mostrano i numeri

1. **Il peso del voto sul piano conta pochissimo.** `dpa_v21` sceglie un piano
   diverso dal voto uguale nell'1–2,5% dei mondi; le differenze accoppiate sono
   nulle entro l'intervallo (benessere medio +0,001, IC 0,000–0,003 nella base).
   Anche l'ottimizzatore tecnico senza voto dà quasi sempre lo stesso piano.
   Conferma il dato della revisione (V11–V16: una divergenza su 456 voti).
2. **Il diritto universale è dove il peso fa danno.** Senza tetto e con voto
   pesato sul diritto, la decisione per teste viene ribaltata nel 57,5% dei mondi
   (69,5% con la lobby). La minoranza perde 8,2 punti di benessere
   (IC −9,2 / −7,2) nella base e 10,4 con la lobby. Con il voto uguale sui diritti
   il ribaltamento è 0% per costruzione.
3. **Il tetto limita la quota di peso, ma non a zero.** La lobby (10% delle teste)
   passa al 22,7% del peso senza tetto e al 17,9% con `w_max = 3`; il limite teorico
   D-14 è 25%. Tetti alti peggiorano il risultato: con `w_max = 10` il piano cambia
   nel 52,5% dei mondi base, benessere medio −1,29 (IC −1,50 / −1,09),
   gruppo peggiore −2,56, soddisfazione −8,6 punti.
4. **La robustezza dell'informazione conta più della regola di voto.** Con esperti
   corrotti la mediana robusta mantiene il piano davvero fattibile nel 47,0% dei
   mondi contro il 19,5% della media pesata con le stesse regole di voto
   (differenza −27,5 punti, IC −34,0 / −21,0). Il guadagno apparente di benessere
   della media (+1,8) è ottenuto violando vincoli veri.
5. **Il margine di certificazione è decisivo.** Con `m = 0,15` solo il 61,5% dei
   piani rispetta davvero i vincoli, perché l'errore comune degli esperti non si
   elimina mediando. Sensibilità (stesso seed, `dpa_v21`):

   | Margine | Fattibile base | Fattibile esperti corrotti | Benessere medio base |
   |---:|---:|---:|---:|
   | 0,15 | 61,5% | 47,0% | −23,26 |
   | 0,50 | 89,5% | 80,0% | −25,27 |
   | 0,80 | 98,0% | 93,5% | −27,14 |

   La scelta del margine è uno scambio tra sicurezza e benessere: è una decisione
   da approvare (livello degli obiettivi), non un parametro tecnico neutro.

### Esiti negativi da conservare

- La V21 **non** mostra un vantaggio del voto ponderato sul piano rispetto al voto
  uguale o all'ottimizzatore tecnico in questo ambiente.
- Con le competenze gonfiate la mediana robusta non aiuta (la lobby non mente
  sulle stime, è solo imprecisa): la difesa in quel caso è il tetto e il voto
  uguale sui diritti, non l'aggregazione.
- La V21 è statica (una decisione per mondo): retroazione temporale, mandati e
  riserve delle V7–V16 non sono ancora riportati sulle regole V21.

## Limiti

- Preferenze quadratiche e vincoli lineari: il voto di Copeland tende all'ottimo
  utilitarista, il che spiega in parte perché il peso conti poco.
- Una sola questione di diritto, sostegno per gruppo ipotizzato.
- La corruzione è semplice (allentamento costante); una corruzione coordinata e
  adattiva potrebbe superare la mediana.
- Le competenze vere sono note al generatore; nel mondo reale vanno certificate,
  e la certificazione stessa è manipolabile (scenario `competenze_gonfiate`).

## File

- `simulazione_v21.py` — modello, regimi, scenari, riepiloghi e bootstrap.
- `test_v21.py` — 8 test: tetto dei pesi, limite D-14, impossibilità esatta,
  ammissibilità delle proposte, ottimo tecnico, voto uguale sui diritti, mediana
  robusta, determinismo.
- `risultati/dettaglio.csv` — una riga per mondo × scenario × regime.
- `risultati/riepilogo.csv` — medie con IC bootstrap.
- `risultati/confronti_accoppiati.csv` — differenze accoppiate per mondo rispetto
  a `uguale` e `tecnico`.
- `risultati/sensibilita_margine_0.5/`, `risultati/sensibilita_margine_0.8/`.

## Riproduzione

```bash
cd democrazia-ponderata-adattiva/v21_dpa_raffinata
python -m pip install -r requirements.txt
python test_v21.py
python simulazione_v21.py --mondi 200 --seed 2121
python simulazione_v21.py --mondi 200 --seed 2121 --margine 0.5 --output risultati/sensibilita_margine_0.5
python simulazione_v21.py --mondi 200 --seed 2121 --margine 0.8 --output risultati/sensibilita_margine_0.8
```

Tempo: circa 25 secondi per batteria su una CPU.
