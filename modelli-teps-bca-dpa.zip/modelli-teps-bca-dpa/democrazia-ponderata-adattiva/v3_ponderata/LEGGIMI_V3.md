# Democrazia Ponderata Adattiva — prototipo Python V3

**7 novembre 2026 — studio computazionale esplorativo.**

Questa V3 corregge una differenza strutturale rispetto a V1/V2: **tutti** i voti del nuovo modello sono ponderati per la competenza **pertinente alla specifica questione**. Non esiste una votazione tradizionale, egualitaria, per la definizione degli obiettivi. Anche le decisioni iniziali, le revisioni e il voto sulle strategie rimangono ponderati.

## Architettura

1. **Iniziativa pubblica**: qualunque cittadino può proporre un obiettivo o una revisione, indipendentemente dal proprio livello di competenza.
2. **Filtro dell'agenda**: per essere ammessa alla discussione/voto la proposta raccoglie una soglia di sostegno ponderato sul tema *e* un minimo di sostenitori distinti. Nella simulazione: 27% del peso espresso e almeno 45 cittadini. Non è una soglia proposta per l'adozione reale.
3. **Voto ponderato sugli obiettivi**: il sistema sceglie il target, la direzione (minimo o massimo) e l'orizzonte temporale. Non viene ancora votata la strategia.
4. **Voto specialistico sulle metriche**: soltanto chi raggiunge `competenza_ambito >= 0.65` può presentare una metrica e votarla. Anche tra questi soggetti il voto è ponderato.
5. **Voto ponderato sulle strategie**: i modelli interdisciplinari calcolano le incompatibilità; il Jacobiano propaga all'indietro l'effetto dei vincoli; le alternative vengono sottoposte a votazioni ponderate, con eventuale ritorno alla proposta globale.
6. **Attuazione progressiva, monitoraggio e apprendimento**: i risultati effettivi, rilevati dopo l'attuazione, aggiornano un modello tecnico RLS. Il monitoraggio separa i valori certificati dalla verifica sintetica indipendente.
7. **Revisione**: la revisione di un obiettivo passa per nuova iniziativa, sostegno e voto ponderato. La metrica può essere sottoposta a nuovo voto ponderato specialistico in caso di discrepanza sistematica rilevata da un audit.

Le singole fasi sono **processi diversi che utilizzano lo stesso principio democratico ponderato**.

## Matematica del voto

Per la questione `q`:

```
w_i(q) = 0.08 + somma_k r_k(q) * competenza(i,k)^2
V(q) = somma_i w_i(q) * voto_i(q) / somma_i w_i(q)
```

`r_k(q)` descrive la rilevanza delle competenze per quella specifica questione. Può differire tra obiettivi ambientali, edilizi, scelte infrastrutturali e singoli settori coinvolti durante i rivoti. La costante `0.08` dà una partecipazione positiva ma di peso ridotto anche ai cittadini meno competenti nei voti generali: **non rende il voto uguale per tutti**. Nei voti specialistici sulle metriche:

```
w_i(metrica, settore k) = competenza(i,k)^2  se competenza(i,k) >= 0.65
                        = 0                    altrimenti
```

Le competenze e le rilevanze sono attualmente **dati sintetici imposti dal simulatore**. Non esiste ancora una certificazione scientifica delle competenze, né la governance dell'eventuale valutazione tramite più IA indipendenti.

## Obiettivi, non gradimento

Per illustrare le regole, vengono votati due obiettivi numerici sintetici:

- Realizzare almeno un certo numero di **centinaia di abitazioni effettivamente completate** entro 10 periodi.
- Contenere un indicatore sintetico delle **emissioni territoriali** sotto una soglia massima.

Le strategie comprendono tre parametri: abitazioni programmate, investimento idrico e investimento nei trasporti. Quattro settori introducono vincoli: acqua, trasporti, bilancio, ambiente.

**La funzione di ricerca non massimizza la soddisfazione delle persone.** Impone prima i target approvati e i vincoli tecnici (sulla base delle informazioni disponibili), poi minimizza il costo di attuazione come criterio secondario. I cittadini possono tuttavia respingere le strategie in fase di votazione, soprattutto quando il sacrificio immediato risulta elevato.

La retropropagazione interdisciplinare usa:

```
b(x) = J_g(x).T @ max(0, g(x))
```

Gli scostamenti dagli obiettivi sono separatamente imposti come vincoli nel problema di ottimizzazione. Il segnale `b(x)` non modifica mai un voto o un obiettivo automaticamente.

## Monitoraggio delle metriche

I candidati esemplificativi comprendono metriche pertinenti e proxy fuorvianti: abitazioni completate vs permessi edilizi; emissioni territoriali vs emissioni parziali. Nei primi due casi le metriche sono fedeli al target; i proxy hanno distorsioni sistematiche impostate nella simulazione.

Nel test con dati distorti il voto specialistico può inizialmente preferire un proxy ingannevole. Un *auditor indipendente sintetico*, che in questa simulazione ha accesso al risultato effettivo, controlla lo scarto tra la metrica ufficiale e il risultato reale. Due discrepanze consecutive superiori a 0,25 attivano una nuova scelta ponderata della metrica. È un meccanismo **ideale di test**, non la dimostrazione che nel mondo reale si possa misurare senza errore il «valore vero».

Nel CSV sono presenti `goal_gap` (scostamento effettivo), `official_goal_gap` (scostamento secondo le metriche votate), `false_complete` (tutti i target ufficialmente raggiunti ma non effettivamente). I gap sono sommati in **unità sintetiche non omogenee**: sono indicativi all'interno dell'esperimento, non una misura di benessere sociale.

## Simulazione effettuata

- 4 scenari, ciascuno con **6 mondi** sintetici.
- **300 cittadini** per mondo, con competenze differenti e interessi conflittuali.
- **10 periodi** per mondo, **3 varianti ponderate** che osservano condizioni comparabili.
- **60 decisioni per metodo e scenario**, **720 deliberazioni di strategia** complessive.
- I sei mondi condividono gli stessi semi tra gli scenari: i confronti trasversali non sono 24 repliche statistiche indipendenti.

Tutti e tre i metodi usano **voti ponderati**:

1. **Statica ponderata**: previsioni tecniche fisse, nessun apprendimento.
2. **Adattiva ponderata**: stime aggiornate via RLS e margine di cautela.
3. **Adattiva senza rivoto globale**: come la seconda, ma rinuncia alla riapertura globale della proposta dopo uno stallo locale.

### Esiti principali (percentuali sui cicli, salvo dove indicato)

| Scenario | Metodo | Nuove strategie approvate | Approvate e tecnicamente valide | Mondi con entrambi gli obiettivi raggiunti al periodo 10 |
|---|---|---:|---:|---:|
| Stabile | Statica ponderata | 50,0% | 10,0% | 16,7% |
| Stabile | Adattiva ponderata | 50,0% | 36,7% | 50,0% |
| Stabile | Adattiva senza rivoto globale | 36,7% | 25,0% | 50,0% |
| Cambiamento condizioni | Statica ponderata | 50,0% | 1,7% | 0,0% |
| Cambiamento condizioni | Adattiva ponderata | 50,0% | 11,7% | 16,7% |
| Cambiamento condizioni | Adattiva senza rivoto globale | 36,7% | 10,0% | 50,0% |
| Dati distorti | Statica ponderata | 50,0% | 1,7% | 0,0% |
| Dati distorti | Adattiva ponderata | 48,3% | 16,7% | 0,0% |
| Dati distorti | Adattiva senza rivoto globale | 41,7% | 10,0% | 0,0% |
| Forte conflitto | Tutti e tre i metodi | 0,0% | 0,0% | 0,0% |

I dati non consentono una graduatoria generale tra i tre metodi. Per esempio, dopo il cambiamento delle condizioni il metodo senza rivoto globale raggiunge in questo piccolo campione più spesso i target finali pur approvando meno nuove proposte: *stabilità del percorso* e qualità dell'implementazione contano oltre alla frequenza dei rivoti.

### Fatti osservati

- Tutti i **12 voti sugli obiettivi per scenario** (due obiettivi × sei mondi) hanno approvato i target, anche nello scenario di forte conflitto. Nello stesso scenario, **nessuna strategia** è stata approvata. L'accordo sugli obiettivi non implica accordo sui sacrifici necessari.
- Si sono svolte **36 petizioni di revisione** per scenario (due richieste per mondo, per i tre metodi): nello scenario stabile 21 sono passate, 15 no. Le revisioni hanno richiesto un nuovo voto ponderato.
- Lo scenario con metriche distorte ha prodotto **36 rivotazioni specialistiche sulle metriche** dopo il controllo indipendente. Le metriche ingannevoli sono state sostituite nei casi simulati.
- Il modello adattivo ha mostrato un errore di previsione inferiore a quello statico, ma ciò **non garantisce** il raggiungimento degli obiettivi quando le strategie sono respinte oppure i vincoli diventano incompatibili.
- Gli intervalli bootstrap accoppiati, su soli sei mondi, sono nel file `risultati/differenze_accoppiate.csv`; non costituiscono una validazione statistica robusta.

### Cosa NON dimostra il prototipo

- Non dimostra che la ponderazione per competenza sia più giusta o più efficace del voto eguale: **non c'è un comparatore egualitario in V3**, per coerenza con il modello richiesto.
- Non fornisce un metodo affidabile per *misurare* la competenza né per decidere democraticamente le rilevanze `r_k(q)`.
- Simula due sole famiglie di obiettivi. Nuovi temi richiedono moduli fisici, metriche e connessioni di competenza aggiuntivi: la proposta politica può essere libera, ma il simulatore non elabora ancora un argomento mai modellato.
- I gruppi simulati usano preferenze e soglie generate artificialmente. Mancano propaganda, coercizione, informazione asimmetrica strategica, conflitti di interesse, attribuzione causale reale e meccanismi anti-concentrazione.
- Non modella la tutela costituzionale dei diritti, la privacy, il consenso informato, l'inclusione o i quorum differenziati.
- L'audit delle metriche usa una verità sintetica nota al valutatore; nel mondo reale non è sempre identificabile.
- I sacrifici sono approssimati dal costo infrastrutturale e dalle preferenze sintetiche dei gruppi. La loro distribuzione e durata non hanno ancora un modello completo di equità intertemporale.
- L'ottimizzazione numerica non ha garanzia generale di convergenza; una strategia assente potrebbe dipendere da incompatibilità reali **o** dai limiti della ricerca numerica.

## Riprodurre gli esperimenti

Dal contenuto dello ZIP, nella directory che contiene `democrazia-ponderata-adattiva/`:

```bash
python -m pip install -r democrazia-ponderata-adattiva/v3_ponderata/requirements.txt
python democrazia-ponderata-adattiva/v3_ponderata/simulazione_ponderata.py --test
python democrazia-ponderata-adattiva/v3_ponderata/simulazione_ponderata.py --mondi 6 --periodi 10 --cittadini 300 --scenario tutti --output democrazia-ponderata-adattiva/v3_ponderata/nuovi_risultati
```

Per riprodurre la struttura `risultati/{scenario}/` usata nell'analisi, avviare una chiamata per ciascuno di `stabile`, `cambiamento`, `dati_distorti`, `conflitto`, con `--output democrazia-ponderata-adattiva/v3_ponderata/risultati/NOME_SCENARIO`. Quindi:

```bash
python democrazia-ponderata-adattiva/v3_ponderata/analisi_v3.py
```

Il codice include test automatici per pesi di competenza, differenza dal voto egualitario, ammissione alle metriche, iniziativa aperta, retropropagazione e immutabilità degli obiettivi durante la ricerca di strategie. La riproducibilità esatta dipende anche dalle versioni delle librerie numeriche.

## Prossimi esperimenti

1. **Negoziazione intertemporale dei sacrifici**: proporre compensazioni, scansioni temporali, alternative finanziarie e votazioni successive, senza confondere l'accettazione di un obiettivo con l'accettazione di un costo specifico.
2. **Certificazione del peso di competenza**: valutazione indipendente, aggiornamento, audit degli errori e limiti di concentrazione del potere.
3. **Scelta interdisciplinare delle metriche**: un indicatore che interessa più settori deve essere soggetto a meccanismi di verifica e voti pertinenti a tutti i settori coinvolti.
4. **Metriche e raggiungimento causale**: distinguere indicatori di progresso, misure d'impatto e prova che la strategia abbia effettivamente causato il risultato.
5. **Garanzie procedurali e costituzionali**: determinare quali decisioni richiedono requisiti ulteriori rispetto al voto ponderato ordinario.