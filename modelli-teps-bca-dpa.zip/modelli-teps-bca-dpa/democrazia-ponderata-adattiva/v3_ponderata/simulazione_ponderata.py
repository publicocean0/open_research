#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Democrazia Ponderata Adattiva v3, simulatore SINTETICO.

TUTTI i voti sono ponderati per competenza SPECIFICA della questione:
1. iniziativa aperta a ogni cittadino, sostegno ponderato per l'agenda;
2. scelta ponderata degli obiettivi, separata dai metodi;
3. proposta e voto delle metriche riservati a competenti, sempre ponderati;
4. strategie vincolate dagli obiettivi, retropropagazione, rivoti ponderati;
5. monitoraggio e apprendimento RLS soltanto dopo l'attuazione;
6. revisione degli obiettivi mediante nuovo sostegno e voto ponderato.

NON e' una procedura politica valida o una dimostrazione della sua superiorita'.
Usa i vincoli sintetici di simulazione.py v1 e il filtro RLS v2.
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Optional
import numpy as np
from scipy.optimize import minimize

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'v2_adattiva'))
import simulazione as base
from simulazione_adattiva import OnlineRLS, as_model, phi

DOMAINS=base.DOMAINS
GOAL_RELEVANCE={
    'alloggi':np.array([.30,.30,.25,.15]),
    'ambiente':np.array([.10,.10,.22,.58]),
}
METHODS=('Statica ponderata','Adattiva ponderata','Adattiva senza rivoto globale')


@dataclass(frozen=True)
class Proposal:
    topic:str
    target:float
    proposer:int
    revision:bool=False


@dataclass(frozen=True)
class Goal:
    topic:str
    target:float
    direction:str
    horizon:int
    version:int=1


@dataclass(frozen=True)
class Metric:
    topic:str
    name:str
    domain:int
    bias:float
    noise_sd:float
    proposer:int


@dataclass
class Electorate:
    competence:np.ndarray  # n x 4
    group:np.ndarray       # 0 alloggi, 1 ambiente, 2 bilancio, 3 misti
    jitter:np.ndarray      # stabile: preferenze specifiche cittadino
    risk:np.ndarray
    def __len__(self):return len(self.group)


def build_electorate(rng,n,scenario):
    probs=([.25,.25,.25,.25] if scenario!='conflitto' else [.15,.15,.55,.15])
    groups=rng.choice(4,size=n,p=probs)
    comp=rng.beta(2.4,2.4,(n,4))
    for i,d in enumerate([1,3,2,0]):
        comp[groups==i,d]=np.clip(comp[groups==i,d]+.24,0,1)
    return Electorate(comp,groups,rng.normal(0,.12,n),rng.uniform(.7,1.4,n))


def weights(pop:Electorate,topic:str,domain:Optional[int]=None):
    """All ballots weight by knowledge; weights depend on question.

    For specialist metric votes, only qualified experts participate.
    A positive minimum lets non-experts express a low-weight vote in
    ordinary goal/strategy decisions; no unweighted fallback.
    """
    if domain is not None:
        qualified=pop.competence[:,domain]>=.65
        w=np.where(qualified,pop.competence[:,domain]**2,0.)
    else:
        relevant=GOAL_RELEVANCE[topic] if topic in GOAL_RELEVANCE else (
            (.70*np.eye(4)[int(topic.split('_')[1])] + .30*np.mean(np.stack(list(GOAL_RELEVANCE.values())),axis=0))
            if topic.startswith('dominio_') else np.mean(np.stack(list(GOAL_RELEVANCE.values())),axis=0))
        w=.08+np.sum(pop.competence**2*relevant[None,:],axis=1)
        qualified=np.ones(len(pop),dtype=bool)
    if w.sum()<=0:raise ValueError('Nessun partecipante abilitato')
    return w,qualified


def fraction(pop,topic,yes,domain=None):
    w,allowed=weights(pop,topic,domain)
    y=np.asarray(yes,dtype=bool)
    return float(w[y].sum()/w.sum()),int(np.sum(y & allowed)),int(np.sum(allowed))


def goal_affinity(pop,topic,target):
    if topic=='alloggi':
        baseline=np.array([.85,.59,.58,.72])[pop.group]
        cost=.20*max(0,target-8.7)/.5
    else:
        baseline=np.array([.58,.87,.57,.72])[pop.group]
        cost=.20*max(0,4.6-target)/.4
    return np.clip(baseline-cost+pop.jitter,.025,.975)


def support_signature(pop,proposal):
    """Supporto deterministico sintetico, stesso per tutti i metodi.

    Un cittadino puo' avanzare una proposta indipendentemente dalla
    competenza. Una proposta e' iscrivibile se sostenuta da abbastanza
    persone e con sufficiente peso di competenza sul tema.
    """
    score=goal_affinity(pop,proposal.topic,proposal.target)
    supporters=score>.51
    share,number,_=fraction(pop,proposal.topic,supporters)
    return supporters,share,number


def agenda(pop,proposals,min_share=.27,min_people=45):
    selected=[]
    for p in proposals:
        _,share,num=support_signature(pop,p)
        selected.append({'proposal':p,'share':share,'supporters':num,
                        'in_agenda':share>=min_share and num>=min_people})
    return selected


def select_goals(pop,proposals,horizon):
    """Voto ponderato su alternative di obiettivo dopo il filtro agenda.

    'No goal' has citizen-specific support probability <= .5 when voters
    oppose all alternatives. The vote on a goal is not the strategy vote.
    """
    result={};events=[]
    for topic in ('alloggi','ambiente'):
        candidates=[r for r in agenda(pop,proposals) if r['proposal'].topic==topic]
        good=[r for r in candidates if r['in_agenda']]
        for r in candidates:events.append({'tipo':'agenda','tema':topic,
            'proponente':r['proposal'].proposer,'target':r['proposal'].target,
            'supporto':r['share'],'sostenitori':r['supporters'],
            'ammessa':r['in_agenda']})
        if not good:continue
        # Among admissible proposals, each citizen chooses one or abstains.
        scores=np.column_stack([goal_affinity(pop,topic,r['proposal'].target)
                                for r in good])
        best=np.argmax(scores,axis=1)
        bestscore=np.max(scores,axis=1)
        tallies=[]
        for j,r in enumerate(good):
            share,_,_=fraction(pop,topic,(best==j)&(bestscore>.5))
            tallies.append(share)
        winner_idx=int(np.argmax(tallies))
        winner=good[winner_idx]['proposal']
        # Separate affirmative ratification for chosen goal vs no new goal.
        approved,_,_=fraction(pop,topic,goal_affinity(pop,topic,winner.target)>.5)
        events.append({'tipo':'voto_obiettivo','tema':topic,'target':winner.target,
                       'quota_si_ponderata':approved,'approvata':approved>.5})
        if approved>.5:
            result[topic]=Goal(topic,winner.target,'min' if topic=='alloggi' else 'max',horizon)
    return result,events


def propose_metric(pop,topic,name,domain,bias,noise_sd,proposer):
    """An unqualified citizen cannot register a specialist metric candidate.

    The quality parameters are illustrative simulator parameters, NOT values
    a real proposer would certify about their own metric.
    """
    if proposer<0 or proposer>=len(pop) or pop.competence[proposer,domain]<.65:
        raise PermissionError('Proposta di metrica riservata alla competenza pertinente')
    return Metric(topic,name,domain,float(bias),float(noise_sd),int(proposer))


def metric_candidates(pop,topic):
    domain=1 if topic=='alloggi' else 3
    eligible=np.where(pop.competence[:,domain]>=.65)[0]
    if not len(eligible):return []
    a=int(eligible[0]);b=int(eligible[-1])
    if topic=='alloggi':
        return [propose_metric(pop,topic,'abitazioni completate',domain,0.,.07,a),
                propose_metric(pop,topic,'permessi edilizi',domain,.65,.025,b)]
    return [propose_metric(pop,topic,'emissioni territoriali',domain,0.,.07,a),
            propose_metric(pop,topic,'emissioni parziali',domain,-.40,.035,b)]


def metric_vote(pop,topic,distortion=0.):
    """Only eligible experts vote; they can propose metrics, not everyone.

    Measured quality uses latent expert assessment + expertise-dependent
    noise. We never pass the actual future realization into the vote.
    """
    candidates=metric_candidates(pop,topic)
    if not candidates:return None,{'tipo':'metriche','tema':topic,'approvata':False}
    w,eligible=weights(pop,topic,domain=candidates[0].domain)
    ids=np.where(eligible)[0]
    # deterministic heterogeneous panel; experts have imperfect judgment
    scores=[]
    for j,m in enumerate(candidates):
        # fidelity + precision; distortion favors deceptive proxy only under stress
        quality=-(m.bias**2+.8*m.noise_sd**2)+(distortion if j else 0.)
        noise=(1-pop.competence[ids,m.domain])*.30*np.sin(ids*1.618+j*3.2)
        scores.append(quality+noise)
    votes=np.argmax(np.column_stack(scores),axis=1)
    shares=[float(w[ids][votes==j].sum()/w.sum()) for j in range(len(candidates))]
    choice=int(np.argmax(shares));winner=candidates[choice]
    return winner,{'tipo':'metriche','tema':topic,'approvata':True,
      'metriche':[m.name for m in candidates], 'votanti_qualificati':len(ids),
      'quote_ponderate':shares,'scelta':winner.name,'proponente':winner.proposer}


def eco_actual(x,model):
    return 5.+model.g(x)[3]*base.SCALE[3]


def actual_values(x,model):
    bad=np.maximum(model.g(x),0)
    return {'alloggi':float(x[0]-.90*bad[0]-.65*bad[1]),
            'ambiente':float(eco_actual(x,model))}


def measure(actual:float,metric:Metric,eps:float):
    return float(actual+metric.bias+metric.noise_sd*eps)


def goal_loss(x,goals,model):
    estimates=actual_values(x,model)
    errors=[]
    for topic,g in goals.items():
        diff=(g.target-estimates[topic]) if g.direction=='min' else (estimates[topic]-g.target)
        errors.append(max(0.,diff))
    return np.array(errors,dtype=float)


def backprop(x,model,domains):
    """Domain-specific residual backprop through physical Jacobian."""
    if not len(domains):return np.zeros(3)
    viol=np.maximum(model.g(x)[domains],0)
    return model.jac(x)[domains].T@viol


def fit_plan(start,goals,model,active,margin,variant,learner=None,caution=False):
    """Strategic optimization: targets + technical constraints are primary.

    Minimize social implementation burden SECONDARY, not voter satisfaction.
    Experts' predictor and uncertainty only; never true synthetic world.
    """
    bounds=list(zip(base.LOW,base.HIGH))
    def technical(z,k):
        extra=.65*learner.sd(z)[k] if learner is not None and caution else 0.
        return float(-model.g(z)[k]-extra-margin)
    cons=[{'type':'ineq','fun':lambda z,k=k:technical(z,k)} for k in active]
    for topic,g in goals.items():
        if topic=='alloggi':
            cons.append({'type':'ineq','fun':lambda z,t=g.target:z[0]-t})
        elif topic=='ambiente':
            cons.append({'type':'ineq','fun':lambda z,t=g.target: t-(5.+model.g(z)[3])})
    # Several secondary objectives give citizens truly different strategies.
    def objective(z):
        h,w,t=z
        if variant==0:return 1.20*w*w+1.05*t*t+.14*(h-6.2)**2
        if variant==1:return .65*w*w+1.75*t*t+.18*(h-6.2)**2
        return 1.8*w*w+.65*t*t+.17*(h-6.2)**2
    attempts=[start,np.array([8.8,2.2,2.2]),np.array([8.6,2.8,1.8])]
    feasible=[]
    for a in attempts:
        opt=minimize(objective,np.clip(a,base.LOW,base.HIGH),method='SLSQP',
            bounds=bounds,constraints=cons,options={'maxiter':110,'ftol':1.e-8})
        x=np.clip(opt.x,base.LOW,base.HIGH)
        if np.all([c['fun'](x)>=-1.e-4 for c in cons]):
            feasible.append((objective(x),x))
    if not feasible:return None
    return min(feasible,key=lambda v:v[0])[1]


def policy_value(pop,x,model,active):
    """Descriptive proxy for conflicting political interests at the ballot.

    NOT the optimization objective. Residents can reject a feasible plan.
    """
    h,w,t=x
    eco=eco_actual(x,model)
    housing_coeff=np.array([2.30,.50,.55,1.27])[pop.group]
    eco_coeff=np.array([.40,2.70,.65,1.20])[pop.group]
    cost_coeff=np.array([.42,.32,1.45,.67])[pop.group]
    risk=np.sum(np.maximum(model.g(x)[active],0)**2) if len(active) else 0.
    return (housing_coeff*(h-6.2) + eco_coeff*(4.7-eco)
            -cost_coeff*(w+t)-pop.risk*6.5*risk+pop.jitter)


def policy_ballot(pop,model,proposed,current,active,topic='strategia'):
    diff=policy_value(pop,proposed,model,active)-policy_value(pop,current,model,active)
    # Small fixed individual participation threshold avoids artificial ties.
    yes=diff>0.035
    return fraction(pop,topic,yes)[0]


def plan_with_voting(pop,goals,estimate,learner,global_rollback=True):
    if not goals:return {'approved':False,'reason':'nessun_obiettivo','plan':base.STATUS_QUO.copy(),
                          'revotes':0,'global_revote':False,'feedback':0.}
    anchor=np.array([max(goals['alloggi'].target+.6,9.3) if 'alloggi' in goals else 9.0,.30,.45])
    proposal=np.clip(anchor,base.LOW,base.HIGH)
    revotes=0;failed=False;backnorm=0.
    for stage,k in enumerate(range(4)):
        active=list(range(stage+1))
        # If the current proposal already meets all known requirements,
        # do not force an unnecessary amendment or veto.
        known=np.all(estimate.g(proposal)[active]<=-.07+1.e-6)
        known=known and np.all(goal_loss(proposal,goals,estimate)<=1.e-6)
        if learner is not None:
            known=known and np.all(estimate.g(proposal)[active]+.65*learner.sd(proposal)[active]<=-.07+1.e-6)
        if known:continue
        feedback=backprop(proposal,estimate,active)
        backnorm+=float(np.linalg.norm(feedback))
        plans=[fit_plan(proposal,goals,estimate,active,.07,v,
                        learner=learner,caution=learner is not None) for v in range(3)]
        eligible=[]
        for p in plans:
            if p is None or np.linalg.norm(p-proposal)<1.e-5:continue
            # Each stage has issue-specific weights for the currently active domain.
            share=policy_ballot(pop,estimate,p,proposal,active,topic=f'dominio_{k}')
            if share>.5:eligible.append((share,p))
        if eligible:
            proposal=max(eligible,key=lambda z:z[0])[1]
            revotes+=1
        elif any(p is not None for p in plans):
            failed=True
            break
        else:
            failed=True
            break
    global_used=False
    if failed and not global_rollback:
        return {'approved':False,'reason':'blocco_locale','plan':proposal,
                'revotes':revotes,'global_revote':False,'feedback':backnorm}
    # Final global re-elaboration always verifies ALL constraints and goals.
    pool=[fit_plan(anchor,goals,estimate,list(range(4)),.07,v,
                    learner=learner,caution=learner is not None) for v in range(3)]
    pool=[p for p in pool if p is not None]
    if not pool:
        return {'approved':False,'reason':'obiettivi_incompatibili','plan':proposal,
                'revotes':revotes,'global_revote':failed,'feedback':backnorm}
    if failed:global_used=True
    # Weighted ballot compares the whole package with the current status quo;
    # informed assessment sees ALL domains, not only selected ones.
    choices=[]
    for p in pool:
        share=policy_ballot(pop,estimate,p,base.STATUS_QUO,np.arange(4))
        if share>.5:choices.append((share,p))
    if not choices:
        return {'approved':False,'reason':'rivoto_finale_respinto','plan':proposal,
                'revotes':revotes,'global_revote':global_used,'feedback':backnorm}
    share,p=max(choices,key=lambda z:z[0]);revotes+=1
    return {'approved':True,'reason':'approvata','plan':p,'revotes':revotes,
            'global_revote':global_used,'feedback':backnorm,'vote_share':share}


def revision_petition(pop,goals,period,scenario):
    """Any citizen may request reconsideration: no automatic target changes."""
    if not goals:return None,None
    topic='alloggi' if (period//4)%2==1 and 'alloggi' in goals else 'ambiente'
    if topic not in goals:topic=next(iter(goals))
    old=goals[topic]
    # Every 4th simulated period, citizen requests modest target adjustment.
    target=(max(7.9,old.target-.22) if topic=='alloggi' else min(4.9,old.target+.15))
    p=Proposal(topic,round(target,3),int((period*37+7)%len(pop)),revision=True)
    _,support,n=support_signature(pop,p)
    if support<.27 or n<45:return p,{'in_agenda':False,'support':support,'passed':False}
    # Revision is a genuine weighted choice between old and new target,
    # not a hidden automatic relaxation of the adopted goal.
    prefs=np.array([8.9,8.2,8.25,8.55])[pop.group] if topic=='alloggi' else (
        np.array([4.80,4.18,4.75,4.48])[pop.group])
    olddist=np.abs(prefs-old.target)
    newdist=np.abs(prefs-p.target)
    support_vote=newdist+pop.jitter*.08<olddist
    share,_,_=fraction(pop,topic,support_vote)
    return p,{'in_agenda':True,'support':support,'vote_share':share,'passed':share>.5}


def make_world(rng,periods,scenario):
    theta0=rng.normal(0,.11,(4,4))
    panel=theta0+rng.normal(0,.30,(4,4))
    seq=np.repeat(theta0[None,:,:],periods,axis=0)
    if scenario in ('cambiamento','dati_distorti'):
        shock=np.zeros((4,4))
        shock[0,0]=.28; shock[1,0]=.13;shock[2,0]=.12;shock[3,0]=.18
        seq[periods//2:]+=shock
    return seq,panel


def single_world(seed,periods,n,scenario):
    rng=np.random.default_rng(seed)
    pop=build_electorate(rng,n,scenario)
    theta,panel=make_world(rng,periods,scenario)
    # Any citizen can be proposer, including citizens with low competence.
    proposals=[Proposal('alloggi',8.7,int((seed+17)%n)),
        Proposal('alloggi',9.1,int((seed+53)%n)),
        Proposal('ambiente',4.6,int((seed+23)%n)),
        Proposal('ambiente',4.35,int((seed+71)%n))]
    goals,goalevents=select_goals(pop,proposals,periods)
    metrics={};metricevents=[]
    for topic in goals:
        metric,event=metric_vote(pop,topic,distortion=.7 if scenario=='dati_distorti' else 0.)
        metrics[topic]=metric
        metricevents.append(event)
    # Identical exogenous observation error for all comparison methods.
    monitor_noise=rng.normal(0,.10,(periods,4))
    for t in range(periods):
        if scenario=='dati_distorti' and (t+seed)%5==0:
            monitor_noise[t]+=rng.normal(0,.60,4)
    results=[];revision_events=[];metric_review_events=[]
    # Comparator methods experience same synthetic world, initial goals,
    # electorate, initial technical information and observation disturbances.
    for method in METHODS:
        learner=OnlineRLS.from_panel(panel,uncertainty=.32,noise=.16) if method!='Statica ponderata' else None
        state=base.STATUS_QUO.copy()
        last_enacted_plan=base.STATUS_QUO.copy()
        method_goals=goals.copy()
        method_metrics=metrics.copy()
        metric_mismatches={topic:0 for topic in goals}
        for t in range(periods):
            real=as_model(theta[t]);estimated=learner.predictor() if learner is not None else as_model(panel)
            # Requests to review goals are possible even if technical progress
            # is good. Petition has weighted signatures + weighted final vote.
            if t>0 and t%4==0:
                petition,rev=revision_petition(pop,method_goals,t,scenario)
                if petition is not None:
                    revision_events.append({'scenario':scenario,'world':seed,'method':method,'t':t,
                        'topic':petition.topic,'old':method_goals[petition.topic].target,
                        'requested':petition.target,**rev})
                    if rev['passed']:
                        old=method_goals[petition.topic]
                        method_goals[petition.topic]=replace(old,target=petition.target,version=old.version+1)
            election=plan_with_voting(pop,method_goals,estimated,learner,
                            global_rollback=method!='Adattiva senza rivoto globale')
            enacted=bool(election['approved'])
            # No approval means retain the last democratically enacted plan.
            if enacted:last_enacted_plan=election['plan'].copy()
            desired=last_enacted_plan
            # Slow implementation of policies: cumulative state, not instant benefit.
            state=state+.53*(desired-state)
            observed=real.g(state)+monitor_noise[t]
            if learner is not None:learner.update(state,observed)
            realval=actual_values(state,real)
            measured={};quality={}
            for topic,g in method_goals.items():
                m=method_metrics[topic]
                # Matched deterministic measurement noise across methods.
                epsi=np.sin(seed*.17+t*.9+len(topic)*.7)
                measured[topic]=measure(realval[topic],m,epsi)
                quality[topic]=abs(measured[topic]-realval[topic])
            gap=0.;official_gap=0.;met_count=0;official_met_count=0
            for topic,g in method_goals.items():
                v=realval[topic]
                delta=g.target-v if g.direction=='min' else v-g.target
                observed_delta=(g.target-measured[topic] if g.direction=='min' else measured[topic]-g.target)
                gap+=max(0.,delta)
                official_gap+=max(0.,observed_delta)
                met_count+=int(delta<=.10)
                official_met_count+=int(observed_delta<=.10)
                # Independent audit compares registry with audited ground truth;
                # after 2 strong discrepancies qualified experts can reconsider.
                if quality[topic]>.25:metric_mismatches[topic]+=1
                else:metric_mismatches[topic]=0
                if metric_mismatches[topic]>=2:
                    replacement,event=metric_vote(pop,topic,distortion=0.)
                    metric_review_events.append({'scenario':scenario,'world':seed,
                        'method':method,'t':t+1,'topic':topic,
                        'before':method_metrics[topic].name,
                        'after':replacement.name if replacement else 'nessuna',
                        'votanti_qualificati':event.get('votanti_qualificati',0)})
                    if replacement is not None:method_metrics[topic]=replacement
                    metric_mismatches[topic]=0
            valid_technical=bool(np.max(real.g(election['plan']))<=1.e-4) if enacted else False
            active_feasible=bool(np.max(real.g(desired))<=1.e-4)
            result={'scenario':scenario,'world':seed,'method':method,'t':t+1,
                'goals':len(method_goals),'approved':int(enacted),
                'approved_technically_feasible':int(enacted and valid_technical),
                'applied_technically_feasible':int(active_feasible),
                'active_plan':int(np.linalg.norm(desired-base.STATUS_QUO)>1.e-6),
                'target_achieved_count':met_count,'target_count':len(method_goals),
                'goal_gap':gap,'official_goal_gap':official_gap,
                'official_target_achieved_count':official_met_count,
                'false_complete':int(bool(method_goals) and official_met_count==len(method_goals) and met_count<len(method_goals)),
                'backprop_strength':election['feedback'],
                'revotes':election['revotes'],'global_revote':int(election['global_revote']),
                'status':election['reason'],
                'housing_actual':realval['alloggi'], 'env_actual':realval['ambiente'],
                'housing_target':method_goals['alloggi'].target if 'alloggi' in method_goals else float('nan'),
                'env_target':method_goals['ambiente'].target if 'ambiente' in method_goals else float('nan'),
                'metric_error':float(np.mean(list(quality.values()))) if quality else float('nan'),
                'technical_max_violation':float(np.max(np.maximum(real.g(election['plan']),0))) if enacted else float('nan'),
                'burden':float(np.sum(state[1:])),
                'predictor_error':float(np.sqrt(np.mean((estimated.g(state)-real.g(state))**2))),
                'weighted_yes':float(election.get('vote_share',float('nan'))),
            }
            results.append(result)
    return results,goalevents,metricevents,revision_events,metric_review_events


def aggregate(rows):
    out=[]
    for scenario in sorted(set(r['scenario'] for r in rows)):
        for method in METHODS:
            rs=[r for r in rows if r['scenario']==scenario and r['method']==method]
            def avg(k):
                a=np.array([r[k] for r in rs],dtype=float)
                return float(np.nanmean(a)) if np.any(np.isfinite(a)) else float('nan')
            finals={r['world']:r for r in rs if r['t']==max(t['t'] for t in rs)}
            last=list(finals.values())
            out.append({'scenario':scenario,'method':method,'n_decisions':len(rs),
              'approval_pct':round(100*avg('approved'),1),
              'valid_pct':round(100*avg('approved_technically_feasible'),1),
              'active_plan_pct':round(100*avg('active_plan'),1),
              'active_feasible_pct':round(100*avg('applied_technically_feasible'),1),
              'target_achievement_final_pct':round(100*np.mean([
                  r['target_achieved_count']==r['target_count'] and r['target_count']>0 for r in last]),1),
              'mean_target_gap':round(avg('goal_gap'),3),
              'mean_official_target_gap':round(avg('official_goal_gap'),3),
              'false_complete_pct':round(100*avg('false_complete'),1),
              'final_mean_target_gap':round(float(np.mean([r['goal_gap'] for r in last])),3),
              'mean_burden':round(avg('burden'),3),
              'mean_prediction_rmse':round(avg('predictor_error'),3),
              'mean_metric_error':round(avg('metric_error'),3),
              'mean_revotes':round(avg('revotes'),2),
              'global_revote_pct':round(100*avg('global_revote'),1)})
    return out


def write_csv(path,records):
    if not records:return
    with open(path,'w',newline='',encoding='utf-8') as f:
        fields=list(dict.fromkeys(k for r in records for k in r.keys()))
        wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader();wr.writerows(records)


def render_charts(rows,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for scenario in sorted(set(r['scenario'] for r in rows)):
        plt.figure(figsize=(9,4.5))
        for method in METHODS:
            r=[q for q in rows if q['scenario']==scenario and q['method']==method]
            t=sorted(set(q['t'] for q in r))
            means=[np.mean([q['goal_gap'] for q in r if q['t']==i]) for i in t]
            plt.plot(t,means,label=method,lw=2)
        plt.xlabel('Periodo');plt.ylabel('Scostamento medio dagli obiettivi')
        plt.title('Obiettivi misurati, scenario '+scenario)
        plt.legend(fontsize=8);plt.grid(alpha=.25);plt.tight_layout()
        plt.savefig(out/f'obiettivi_{scenario}.png',dpi=145);plt.close()


def selftest():
    r=np.random.default_rng(44)
    pop=build_electorate(r,400,'stabile')
    for topic in ('alloggi','ambiente','strategia'):
        w,_=weights(pop,topic)
        assert np.std(w)>0 and np.all(w>0)
    # Weighted votes need not equal a simple headcount.
    p=Electorate(np.array([[1,1,1,1],[.1,.1,.1,.1],[.1,.1,.1,.1]]),
       np.array([0,0,0]),np.zeros(3),np.ones(3))
    assert fraction(p,'alloggi',[True,False,False])[0]>.5
    assert fraction(p,'alloggi',[True,False,False])[1]==1
    _,eligible=weights(pop,'alloggi',domain=1)
    assert 0<eligible.sum()<len(pop)
    unqualified=int(np.where(~eligible)[0][0])
    try:
        propose_metric(pop,'alloggi','non autorizzata',1,0.,.1,unqualified)
        raise AssertionError('Deve rifiutare il proponente non qualificato')
    except PermissionError:pass
    proposal=Proposal('alloggi',8.7,0)
    assert proposal.proposer==0  # initiative right independent of expertise
    goals,events=select_goals(pop,[Proposal('alloggi',8.7,0),Proposal('ambiente',4.6,1)],12)
    assert goals and any(e['tipo']=='voto_obiettivo' for e in events)
    for topic in goals:
        m,event=metric_vote(pop,topic)
        assert m is not None and pop.competence[m.proposer,m.domain]>=.65
        assert event['votanti_qualificati']<len(pop)
    theta=np.zeros((4,4));model=as_model(theta)
    x=np.array([9.4,.3,.4]);b=backprop(x,model,[0,1,2,3])
    assert b.shape==(3,) and np.linalg.norm(b)>0
    # Goal target cannot be changed by the strategy generator.
    saved=goals.copy();election=plan_with_voting(pop,goals,model,None)
    assert goals==saved and election['revotes']>=0
    a,_,_,_,_=single_world(900,6,160,'stabile')
    assert len(a)==6*len(METHODS)
    assert all(q['goal_gap']>=0 for q in a)
    print('Test automatici V3: OK')


def main():
    pa=argparse.ArgumentParser(description=__doc__)
    pa.add_argument('--mondi',type=int,default=8)
    pa.add_argument('--periodi',type=int,default=12)
    pa.add_argument('--cittadini',type=int,default=360)
    pa.add_argument('--scenario',choices=['stabile','cambiamento','dati_distorti','conflitto','tutti'],default='tutti')
    pa.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'risultati')
    pa.add_argument('--test',action='store_true')
    a=pa.parse_args()
    selftest()
    if a.test:return
    a.output.mkdir(exist_ok=True,parents=True)
    scenarios=('stabile','cambiamento','dati_distorti','conflitto') if a.scenario=='tutti' else (a.scenario,)
    rows=[];goals=[];metrics=[];revisions=[];metric_reviews=[]
    for scenario in scenarios:
        for s in range(a.mondi):
            r,g,m,v,mr=single_world(3000+s,a.periodi,a.cittadini,scenario)
            rows.extend(r)
            goals.extend([{'scenario':scenario,'world':3000+s,**e} for e in g])
            metrics.extend([{'scenario':scenario,'world':3000+s,**e} for e in m])
            revisions.extend(v)
            metric_reviews.extend(mr)
        print(scenario,'completato',flush=True)
    summary=aggregate(rows)
    write_csv(a.output/'risultati_dettaglio.csv',rows)
    write_csv(a.output/'riepilogo.csv',summary)
    write_csv(a.output/'agenda_obiettivi.csv',goals)
    write_csv(a.output/'voti_metriche.csv',metrics)
    write_csv(a.output/'revisioni_obiettivi.csv',revisions)
    write_csv(a.output/'revisioni_metriche.csv',metric_reviews)
    render_charts(rows,a.output)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('Revisioni obiettivi:',len(revisions),'passate:',sum(x['passed'] for x in revisions),
         'revisioni metriche:',len(metric_reviews))


if __name__=='__main__':main()