# Democrazia Ponderata Adattiva — V9

## Scopo

Prototipo Python **sintetico e sperimentale**. Confronta la V8 (correzioni locali con mandato condizionale) con due varianti di ricerca di strategie a orizzonte mobile:

1. **MPC nominale** (`mpc_nominale`): ottimizza una correzione considerando la dinamica dei periodi successivi, ma senza margini di incertezza (`risk=0`).
2. **MPC robusto euristico** (`mpc_robusto`): stessa ricerca, con penalizzazioni derivate dalla covarianza del modello di previsione (`risk=0,8`).

Le sigle MPC e *robusto* sono usate in senso sperimentale: il piano è rappresentato da un unico livello d'intervento, e viene riottimizzato quando il controllo V8 attiva una revisione. **Non** è un MPC generale con un vettore di controlli separati per tutti i periodi, né una garanzia di rispetto probabilistico dei vincoli. Gli intervalli robusti sono euristici e non certificati.

Il modello mantiene immutati i voti ponderati della V3, la definizione specialistica delle metriche, il mandato condizionale e i rivoti della V8. **Gli obiettivi originari non vengono rivisti in questa prova.**

## Modello matematico

Lo stato d'attuazione osservabile cambia in ciascun periodo secondo

\[
 s_{t+1}=s_t+\alpha(u_t-s_t),
\]

con `u_t` piano approvato e `alpha=0,67` per lo scenario di pianificazione rapida. La previsione tecnica dei quattro ambiti è `g_hat(x)`; lo stimatore RLS produce anche un'incertezza `sigma_k(x)`.

La valutazione prudente delle conseguenze usa:

\[
 \bar g_k(u)=\hat g_k(u)+\kappa\,\sigma_k(u),\quad \kappa=0,8.
\]

Si valutano sia la compatibilità del piano `u` sia gli obiettivi all'ultimo stato previsto `s_T(u)`; il punteggio della strategia penalizza in primo luogo violazioni dei quattro vincoli e scostamenti dai due obiettivi *nella busta di incertezza*, poi costo e cambiamenti del piano, e marginalmente gli scostamenti lungo la traiettoria. Una soluzione viene selezionata soltanto se soddisfa anche i vincoli nominali stimati con piccole tolleranze. La ricerca usa SLSQP da quattro punti iniziali: **ottimo locale, non globale**.

La proposta passa attraverso le stesse regole della V8: se è coperta dal mandato votato può essere attuata entro i limiti autorizzati; altrimenti richiede un **nuovo voto ponderato**. Se la proposta viene respinta, resta in vigore la strategia già autorizzata.

### Cinque precisazioni

- **Non** si ottimizza la soddisfazione individuale come obiettivo primario: prima viene la riduzione dello scostamento dai target definiti e votati.
- Le funzioni di voto, pur ponderate, modellano preferenze e sacrifici con formule puramente inventate per la prova.
- Non vengono usati nella ricerca parametri reali del mondo sintetico al tempo futuro; questi servono esclusivamente alla simulazione di attuazione e alla verifica finale.
- La maggiore potenza del risolutore è un cambiamento rispetto alla V8: il confronto non isola l'effetto del solo orizzonte temporale.
- L'uso di una patch temporanea del generatore di correzioni della V8 è **solo per esecuzioni sequenziali**. Non eseguire `simulate_variant` in parallelo nello stesso processo.

## Disegno sperimentale

- **4 scenari:** stabile; shock tecnico; shock con misure rumorose; shock con conflitto.
- **24 mondi artificiali** per scenario; **300 cittadini**, **12 periodi** per mondo.
- **4 metodi** in ciascuno stesso mondo: `bloccato`, `mandato_v8`, `mpc_nominale`, `mpc_robusto`.
- **384 esecuzioni** in totale, ciascuna su 12 periodi: 4 × 24 × 4.
- Identici semi casuali, obiettivi iniziali, competenze, regole e rumori per ciascun confronto accoppiato.
- **Successo completo:** entrambi i target originali raggiunti entro la tolleranza (`gap <= 0,11`) e massima violazione dei vincoli tecnici reali (`<= 0,02`).

## Risultati

| Scenario | Piano bloccato | V8 | V9 nominale | V9 robusta |
|---|---:|---:|---:|---:|
| Stabile | 87,5% | 87,5% | 75,0% | 87,5% |
| Shock | 0% | 0% | 0% | **8,3%** |
| Shock rumoroso | 0% | 0% | 0% | 0% |
| Shock + conflitto | 0% | 0% | 0% | 0% |

Nello scenario `shock`:

| Indicatore finale | V8 | V9 nominale | V9 robusta |
|---|---:|---:|---:|
| Società con successo completo (su 24) | 0 | 0 | **2** |
| Società che raggiungono i target | 6 | 1 | 3 |
| Scostamento medio dai target | 0,4059 | 0,4676 | 0,4280 |
| Violazione tecnica media | 0,0905 | 0,1320 | 0,1076 |

La V9 robusta permette **alcuni successi** che la V8 non ottiene, ma **peggiora il risultato medio** rispetto alla V8. Il confronto bootstrap accoppiato (95% illustrativo) della differenza di successo della V9 robusta rispetto alla V8 è **da 0 a +20,8 punti percentuali** nello scenario shock. L'intervallo comprende zero: non vi è evidenza sufficientemente forte di un vantaggio generale nemmeno nella popolazione sintetica esaminata. Non vi è alcuna inferenza consentita sul comportamento di società reali.

Negli scenari rumoroso e conflittuale, il risultato completo resta a zero. Nel conflitto la V8 e la V9 registrano **92 rivoti correttivi respinti** nell'insieme delle 24 società. Le percentuali dipendono direttamente dalle funzioni sintetiche che generano l'elettorato.

### Riferimento tecnico ideale

Il riferimento della V7 trova una traiettoria tecnicamente ammissibile in 24/24 mondi per ogni scenario. Si tratta di un risolutore diagnostico che conosce i vincoli tecnici veri **al momento del cambiamento** e **non sottopone i piani a votazione**. Non è una prova che una determinata procedura politica sia capace di raggiungerla, né una dimostrazione di ottimalità matematica globale.

## Diagnosi: perché non funziona ancora in modo affidabile

1. Lo shock modifica i parametri fisici in modo più rapido dell'aggiornamento del modello RLS; i margini basati sull'incertezza stimata possono sottovalutarlo.
2. La correzione V9 ottimizza un **unico piano mantenuto costante** nell'orizzonte, non una sequenza di azioni coordinata e votata. La dinamica pluriperiodale è presente nell'obiettivo, non come nuovi controlli indipendenti.
3. Il sistema attiva il ricalcolo quando intervengono i trigger della V8; alcuni shock sono rilevati tardi.
4. I mandati e i nuovi voti pongono limiti reali alla correzione, per definizione. Nel conflitto molti voti sono respinti.
5. Le tolleranze numeriche e le funzioni di valutazione sono scelte sperimentali, non standard di politica pubblica.

Un successivo sviluppo utile è testare **azioni differenziate per periodo, riserve esplicite e verifica preventiva delle soglie di intervento**, separando con un esperimento fattoriale precisione delle previsioni, flessibilità del mandato e qualità della ricerca. Ciò richiederebbe comunque autorizzazioni ponderate anche per le azioni contingenti.

## Riproduzione

Dalla directory che contiene `democrazia-ponderata-adattiva/`:

```bash
python -m pip install -r democrazia-ponderata-adattiva/v9_ottimizzazione_robusta/requirements.txt
python democrazia-ponderata-adattiva/v9_ottimizzazione_robusta/simulazione_v9.py --test
python democrazia-ponderata-adattiva/v9_ottimizzazione_robusta/simulazione_v9.py --mondi 24 --cittadini 300 --periodi 12
python democrazia-ponderata-adattiva/v9_ottimizzazione_robusta/analisi_accoppiata.py \
  --input democrazia-ponderata-adattiva/v9_ottimizzazione_robusta/risultati/periodi.csv \
  --output democrazia-ponderata-adattiva/v9_ottimizzazione_robusta/risultati/confronti_accoppiati.csv
```

**File principali:** `simulazione_v9.py` (V9), `analisi_accoppiata.py` (intervalli bootstrap), `risultati/riepilogo.csv` (sintesi), `risultati/periodi.csv` (periodi e verifica ex post), `risultati/decisioni.csv` (voti e attivazioni), `risultati/confronti_accoppiati.csv` (confronti), `risultati/confronto_v9.png` (grafico).

**Dipendenze dei moduli:** V1, V2, V3, V4, V7, V8. I file necessari sono inclusi nello ZIP. Le V5 e V6 non sono importate dal simulatore V9.