#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V9 - sperimentazione sintetica di pianificazione robusta a orizzonte mobile.

Riutilizza la democrazia ponderata V3 e il protocollo di voto/mandato V8.
Il solo esperimento V9 sostituisce il generatore delle correzioni V8, non
la scelta degli obiettivi, delle metriche o i pesi del voto.

AVVERTENZA: non è un modello costituzionale validato, né un modello MPC
con garanzia di ottimalità globale. I vincoli e gli elettori sono sintetici.
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
from contextlib import contextmanager
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
for p in (ROOT, ROOT/'v2_adattiva', ROOT/'v3_ponderata', ROOT/'v4_negoziazione',
          ROOT/'v7_feedback_temporale', ROOT/'v8_mandato_condizionale'):
    sys.path.insert(0,str(p))
import simulazione as base
import simulazione_v4 as v4
import simulazione_v7 as v7
import simulazione_v8 as v8
from simulazione_adattiva import as_model

SCENARIOS=v7.SCENARIOS
METHODS=('bloccato','mandato_v8','mpc_nominale','mpc_robusto')


def predicted_endpoint(state,x,left,speed='rapida'):
    # Plan remains fixed inside the forward simulation; only the first change
    # can be implemented now, later changes require authorization or a rivoto.
    return v4.final_state(state,x,left,speed)


def worst_case_forecast(x,model,learner,state,left,risk):
    """Test across a deterministic uncertainty envelope, not against truth.

    The envelope covers x and the final implemented state; it explicitly
    includes the more adverse direction of each technical model uncertainty.
    ``risk`` is a heuristic multiple of one standard error, not a certified
    probability/coverage statement.
    """
    end=predicted_endpoint(state,x,left)
    sigma_x=learner.sd(x)
    sigma_end=learner.sd(end)
    worst_g=model.g(x)+risk*sigma_x
    worst_end_g=model.g(end)+risk*sigma_end
    housing_worst=end[0]-.90*max(0.,worst_end_g[0])-.65*max(0.,worst_end_g[1])
    environment_worst=5.+worst_end_g[3]*base.SCALE[3]
    return worst_g, housing_worst, environment_worst, end


def optimize_receding_horizon(goals,model,learner,state,plan,left,risk=0.8):
    """Constrained risk-aware multi-period correction.

    Hard constraints: nominal estimated technical constraints + target
    achievement at the forecast endpoint (the endpoint captures all future
    periods of execution). Among estimated feasible solutions, optimize
    worst-case uncertainty envelope FIRST and cost/movement SECOND.

    The optimization never accesses the synthetic true parameters.
    """
    left=max(1,int(left))
    anchor=np.clip(plan,base.LOW,base.HIGH)
    current_g=model.g(plan)
    back=model.jac(plan).T@np.maximum(current_g,0.)
    corrected=np.clip(plan-0.8*back/(np.linalg.norm(back)+1.e-9),base.LOW,base.HIGH)
    starts=[anchor,corrected,np.array([9.1,2.1,2.1]),np.array([9.4,2.8,2.6])]
    # Nominal technical envelope allows the same tolerance as V8.
    cons=[{'type':'ineq','fun':lambda z,j=j:float(.085-model.g(z)[j])} for j in range(4)]
    def nominal_goal(z,topic):
        end=predicted_endpoint(state,z,left)
        values=v7.v3.actual_values(end,model)
        g=goals[topic]
        return (values[topic]-g.target+.11 if g.direction=='min'
                else g.target-values[topic]+.11)
    for topic in goals:
        cons.append({'type':'ineq','fun':lambda z,q=topic:float(nominal_goal(z,q))})

    def score(z):
        bad,housing,env,end=worst_case_forecast(z,model,learner,state,left,risk)
        violation=np.maximum(bad,0.)
        misses=[]
        for topic,g in goals.items():
            measured=housing if topic=='alloggi' else env
            misses.append(max(0.,g.target-measured) if g.direction=='min'
                          else max(0.,measured-g.target))
        # Respect targets above every cost/comfort criterion.
        worst_objective=28.*sum(q*q for q in misses)+28.*np.dot(violation,violation)
        cost=.0035*v4.capital_cost(z) + .006*float(np.dot(z-plan,z-plan))
        # Mild additional penalty for delayed benefits, evaluated at all periods.
        trajectory=0.
        state_i=np.asarray(state,dtype=float).copy()
        for h in range(left):
            state_i+=v4.SPEED['rapida']*(z-state_i)
            vals=v7.v3.actual_values(state_i,model)
            trajectory+=(sum(max(0.,g.target-vals[q]) if g.direction=='min'
                            else max(0.,vals[q]-g.target) for q,g in goals.items())
                          * (h+1)/left)
        return float(worst_objective+cost+0.008*trajectory)

    solutions=[]
    for start in starts:
        res=minimize(score,np.clip(start,base.LOW,base.HIGH),method='SLSQP',
                     bounds=list(zip(base.LOW,base.HIGH)),constraints=cons,
                     options={'maxiter':48,'ftol':2.e-5})
        x=np.clip(res.x,base.LOW,base.HIGH)
        if all(c['fun'](x)>=-2.e-4 for c in cons):
            solutions.append((score(x),x))
    if not solutions:
        return None,dict(risk=risk,feasible_candidates=0,best_score=float('nan'))
    score_,candidate=min(solutions,key=lambda a:a[0])
    return candidate,dict(risk=risk,feasible_candidates=len(solutions),best_score=score_)


@contextmanager
def temporary_picker(picker):
    """Temporarily substitute ONLY V8's correction proposer in sequential runs.
    Scoped patch ensures V8 can be rerun unmodified and is undone on error.
    """
    original=v8.pick_correction
    v8.pick_correction=picker
    try:yield
    finally:v8.pick_correction=original


def simulate_variant(world,scenario,periods,method):
    if method=='bloccato':
        return v7.simulate_method(world,scenario,'bloccato',periods)
    if method=='mandato_v8':
        out=v8.simulate_mandate(world,scenario,periods)
    else:
        records=[]
        risk=0.0 if method=='mpc_nominale' else 0.80
        def picker(w,model,learner,state,plan,t,total):
            candidate,diag=optimize_receding_horizon(
                w['goals'],model,learner,state,plan,total-t,risk)
            records.append({'period':t+1,**diag})
            grad=float(np.linalg.norm(model.jac(plan).T@np.maximum(model.g(plan),0.)))
            if candidate is None:
                return None,0,grad
            return candidate,int(diag['feasible_candidates']),grad
        with temporary_picker(picker):
            out=v8.simulate_mandate(world,scenario,periods)
        # In the model, only an initially approved strategy can be amended;
        # no changes may bypass within_mandate() and weighted_revote().
    rows,votes,audits=out
    for r in rows:r['method']=method
    for e in votes:e['method']=method
    for e in audits:e['method']=method
    return rows,votes,audits


def run(n_worlds=12,n=300,periods=12,scenarios=SCENARIOS):
    rows=[];events=[];audits=[];oracles=[]
    for scenario in scenarios:
        for j in range(n_worlds):
            w=v7.generate_world(j,scenario,periods,n)
            if len(w['goals'])!=2:continue
            oracles.append(dict(scenario=scenario,seed=w['seed'],
                         **v7.oracle_dynamic(w,periods)))
            for method in METHODS:
                p,v,a=simulate_variant(w,scenario,periods,method)
                rows.extend(p);events.extend(v);audits.extend(a)
    summary=[]
    for scenario in scenarios:
        for method in METHODS:
            sample=[r for r in rows if r['scenario']==scenario and r['method']==method]
            finals=[r for r in sample if r['t']==periods]
            decisions=[e for e in events if e['scenario']==scenario and e['method']==method]
            if not finals:continue
            summary.append(dict(scenario=scenario,method=method,worlds=len(finals),
                joint_success_count=sum(int(r['joint_success']) for r in finals),
                joint_success_pct=round(100*np.mean([r['joint_success'] for r in finals]),1),
                goal_success_pct=round(100*np.mean([r['both_goals'] for r in finals]),1),
                mean_gap=round(float(np.mean([r['gap'] for r in finals])),4),
                mean_max_constraint_violation=round(float(np.mean([r['true_violation'] for r in finals])),4),
                mean_prediction_rmse=round(float(np.mean([r['predicted_rmse_state'] for r in sample])),4),
                ballot_events=sum(e.get('kind') in ('strategia_iniziale','voto_sul_mandato','rivoto_fuori_mandato')
                    for e in decisions) if method!='bloccato' else len(decisions),
                preauthorized_changes=sum(e.get('kind')=='attivazione_preautorizzata'
                    and e.get('approved') for e in decisions),
                rejections=sum(e.get('approved')==0 and e.get('kind')=='rivoto_fuori_mandato'
                    for e in decisions),
                no_candidate=sum(e.get('kind')=='allarme_senza_piano' for e in decisions)))
    return rows,events,audits,oracles,summary


def write_csv(path,records):
    if not records:return
    cols=list(dict.fromkeys(k for r in records for k in r))
    with open(path,'w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=cols);wr.writeheader();wr.writerows(records)


def graph(rows,output,scenarios):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for scenario in scenarios:
        fig,ax=plt.subplots(figsize=(9,5))
        for method in METHODS:
            data=[r for r in rows if r['scenario']==scenario and r['method']==method]
            if not data:continue
            timeline=sorted({r['t'] for r in data})
            means=[np.mean([r['gap'] for r in data if r['t']==tt]) for tt in timeline]
            ax.plot(timeline,means,marker='o',label=method)
        ax.set_title('V9 — scenario '+scenario)
        ax.set_xlabel('Periodo');ax.set_ylabel('Scostamento medio dagli obiettivi originari')
        ax.legend(fontsize=9);ax.grid(alpha=.2);fig.tight_layout()
        fig.savefig(output/f'traiettoria_{scenario}.png',dpi=160);plt.close(fig)
    fig,ax=plt.subplots(figsize=(11,5.5))
    x=np.arange(len(scenarios));width=.18
    for j,method in enumerate(METHODS):
        vals=[100*np.mean([r['joint_success'] for r in rows if r['scenario']==scenario
                and r['method']==method and r['t']==max(e['t'] for e in rows if e['scenario']==scenario)])
              for scenario in scenarios]
        ax.bar(x+(j-1.5)*width,vals,width,label=method)
    ax.set_xticks(x,list(scenarios),rotation=10)
    ax.set_ylabel('Target originari + vincoli reali (%)')
    ax.set_ylim(0,105);ax.legend(fontsize=9);fig.tight_layout()
    fig.savefig(output/'confronto_v9.png',dpi=170);plt.close(fig)


def test():
    w=v7.generate_world(1,'shock',12,80)
    assert len(w['goals'])==2
    learner=v7.common_initial_model(w)
    est=learner.predictor()
    s=base.STATUS_QUO.copy()
    for risk in [0.,.8]:
        x,diag=optimize_receding_horizon(w['goals'],est,learner,s,np.array([9,2,2]),12,risk)
        if x is not None:
            assert np.all(x<=base.HIGH+1e-8) and np.all(x>=base.LOW-1e-8)
            assert np.max(est.g(x))<=.086
            assert v4.predicted_acceptable(x,w['goals'],est,s,12,'rapida')
    a,_ ,_=v8.simulate_mandate(w,'shock',12)
    simulate_variant(w,'shock',12,'mpc_robusto')
    b,_ ,_=v8.simulate_mandate(w,'shock',12)
    assert np.array_equal([r['gap'] for r in a],[r['gap'] for r in b]),'V8 baseline mutated'
    # V8's weighted voting is used without change.
    pop=w['pop'];weights,_=v7.v3.weights(pop,'strategia')
    assert np.ptp(weights)>0.001
    print('OK V9: fattibilita stimata, voto ponderato, mandato, baseline V8 invariata')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--test',action='store_true')
    p.add_argument('--mondi',type=int,default=12)
    p.add_argument('--cittadini',type=int,default=300)
    p.add_argument('--periodi',type=int,default=12)
    p.add_argument('--scenari',nargs='*',choices=SCENARIOS,default=list(SCENARIOS))
    p.add_argument('--output',type=Path,default=HERE/'risultati')
    args=p.parse_args()
    if args.test:test();return
    args.output.mkdir(parents=True,exist_ok=True)
    data=run(args.mondi,args.cittadini,args.periodi,args.scenari)
    for name,part in zip(('periodi.csv','decisioni.csv','audit_metriche.csv','oracolo.csv','riepilogo.csv'),data):
        write_csv(args.output/name,part)
    graph(data[0],args.output,args.scenari)
    (args.output/'parametri.json').write_text(json.dumps(vars(args),indent=2,default=str),encoding='utf8')
    print(json.dumps(data[-1],indent=2,ensure_ascii=False))

if __name__=='__main__':main()