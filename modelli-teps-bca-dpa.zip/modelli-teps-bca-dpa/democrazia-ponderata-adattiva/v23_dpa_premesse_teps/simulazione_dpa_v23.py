# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DPA V23 — Democrazia Ponderata Adattiva con le premesse della TEPS.

Le votazioni sono **indirizzate per competenze** e hanno una **base minima di
votanti**, con le stesse regole della TEPS 1.5 (§11, §12, §17.7-17.8):

* Competenze riconosciute: ogni persona ha formazione ed esperienza lavorativa
  per disciplina. Cinque agenti IA isolati valutano il dossier; la competenza
  riconosciuta e' prudenziale: C* = max(0, mediana - lambda * MAD) (§12.1).
* Ammissione e peso (§11.1): w = 0 se C(q) < tau; altrimenti
  w = 1 + (w_max - 1)(C(q) - tau)/(1 - tau), con w_max = 3.
  C(q) = somma_k r_k(q) C*_k: la competenza rilevante per la questione q.
* Base minima (D-15): tau* = min(tau0, C_(N_min)). Se i voti espressi sono meno
  di N_min, la convocazione si estende ai successivi in graduatoria (Nota 1.5).
* Diritti universali e obiettivi che toccano tutti: voto uguale ("sulle materie
  che toccano tutti il voto resta eguale", TEPS §17.7). La variante
  ``dpa_teps_obiettivi_per_competenza`` indirizza per competenze anche gli
  obiettivi. Astensione: non entra nell'esito.
* Nessuno vota con peso sulla propria pratica (§11.2): chi ha un interesse
  diretto registrato su un tema e' escluso da quella questione.

La dinamica nel tempo (monitoraggio, rivoto mirato, inerzia, deriva, shock)
e' quella della DPA V22. Lo storico delle previsioni (chi stima male perde peso)
e' tenuto come variante separata: il §11.2 della TEPS esclude penalizzazioni
automatiche della competenza.

Simulazione su popolazioni sintetiche: non e' una prova dell'efficacia di un
ordinamento reale.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np

QUI = Path(__file__).resolve().parent
sys.path.insert(0, str(QUI.parent / "v21_dpa_raffinata"))
sys.path.insert(0, str(QUI.parent / "v22_dpa_dinamica_tematica"))
import simulazione_v21 as d21  # noqa: E402
import simulazione_dpa_v22 as d22  # noqa: E402
from simulazione_v21 import mediana_pesata  # noqa: E402

PERIODI = d22.PERIODI
TAU0 = 0.60
W_MAX = 3.0
N_MIN = 101
N_MIN_SENSIBILITA = (25, 201)
PARTECIPAZIONE = 0.80        # probabilita' che un convocato voti (non si astenga)
AGENTI = 5
RUMORE_AGENTI = 0.08
LAMBDA_MAD = 1.0
GONFIAMENTO = 0.5            # quanto la lobby gonfia le valutazioni degli agenti ingannati
# rilevanza delle discipline (acqua, trasporti, bilancio, ambiente) per ogni questione
RILEVANZA_VINCOLI = np.eye(4)
RILEVANZA_OBIETTIVI = d22.RILEVANZA

SCENARI = ("base", "esperti_corrotti", "credenziali_gonfiate_2su5", "credenziali_gonfiate_3su5", "shock")
REGIMI = ("uguale_tutti", "tecnico", "dpa_teps_statico", "dpa_teps", "dpa_teps_storico",
          "dpa_teps_obiettivi_per_competenza", "dpa_teps_nmin25", "dpa_teps_nmin201")


# ---------------------------------------------------------------------------
# Competenze riconosciute: formazione + esperienza, valutate da agenti IA isolati
# ---------------------------------------------------------------------------
def competenze_riconosciute(pop, rng, ingannati, gonfiamento=GONFIAMENTO, bersaglio=None):
    """Restituisce C* per persona e disciplina, la formazione e l'esperienza."""
    n = pop.n
    formazione = np.clip(pop.c_vera + rng.normal(0, 0.15, (n, 4)), 0, 1)
    esperienza = np.clip(pop.c_vera + rng.normal(0, 0.15, (n, 4)), 0, 1)
    dossier = 0.5 * formazione + 0.5 * esperienza
    valutazioni = dossier[None] + rng.normal(0, RUMORE_AGENTI, (AGENTI, n, 4))
    if bersaglio is not None and ingannati > 0:
        valutazioni[:ingannati, bersaglio] += gonfiamento
    valutazioni = np.clip(valutazioni, 0, 1)
    C_hat = np.median(valutazioni, 0)
    mad = np.median(np.abs(valutazioni - C_hat[None]), 0)
    return np.clip(C_hat - LAMBDA_MAD * mad, 0, 1), formazione, esperienza


def peso_teps(C, tau):
    return np.where(C < tau, 0.0, 1 + (W_MAX - 1) * (C - tau) / max(1 - tau, 1e-9))


def convoca(Cq, escludi, rng, n_min):
    """Ammissione D-15 sui voti espressi: restituisce (votanti, pesi, tau*, estesa)."""
    ordine = np.argsort(-Cq, kind="stable")
    ordine = ordine[~escludi[ordine]]
    vota = rng.random(len(Cq)) < PARTECIPAZIONE
    ammessi = int((Cq[ordine] >= TAU0).sum())
    k = max(ammessi, min(n_min, len(ordine)))
    while vota[ordine[:k]].sum() < n_min and k < len(ordine):
        k += 1
    convocati = ordine[:k]
    tau_eff = min(TAU0, float(Cq[convocati[-1]]))
    votanti = convocati[vota[convocati]]
    return votanti, peso_teps(Cq[votanti], tau_eff), tau_eff, k > ammessi


# ---------------------------------------------------------------------------
# Esecuzione
# ---------------------------------------------------------------------------
def n_min_regime(regime):
    return {"dpa_teps_nmin25": 25, "dpa_teps_nmin201": 201}.get(regime, N_MIN)


def esegui_regime(md, regime, Cstar, conflitti, sorvegliato, seed_voto):
    pop = md.pop
    n = pop.n
    rng = np.random.default_rng(seed_voto)
    peso_storico = np.ones((n, 4))
    sq_err, n_err = np.zeros((n, 4)), np.zeros((n, 4))
    t_min = md.m.t_min if md.diritto else None
    x = d22.STATO_INIZIALE.copy()
    b_cert = np.zeros(4)
    ultima = {}
    tau_obj = np.zeros(3)
    W = np.ones(3)
    schede, voti, estese, tau_eff_lista, quota_ind_max = n, [], 0, [], 0.0
    q0 = qT = np.nan
    righe_t = []
    for t in range(PERIODI):
        if regime == "dpa_teps_storico" and t > 0:
            b_oss = md.b[t - 1] + md.monitor[t - 1]
            for k, (idx, rep) in ultima.items():
                sq_err[idx, k] += (rep - b_oss[k]) ** 2
                n_err[idx, k] += 1
            rmse = np.sqrt(sq_err / np.maximum(n_err, 1))
            for k in range(4):
                visti = n_err[:, k] > 0
                if visti.any():
                    rif = np.median(rmse[visti, k])
                    peso_storico[visti, k] = np.exp(-np.maximum(0, rmse[visti, k] - rif) / 0.4)
        dinamico = regime not in ("uguale_tutti", "dpa_teps_statico", "tecnico")
        if dinamico and t > 1:
            b_oss = md.b[t - 1] + md.monitor[t - 1]
            vincoli = [k for k in range(4) if abs(b_oss[k] - (b_cert[k] + d22.MARGINE)) > d22.SOGLIA_RIVOTO]
        else:
            vincoli = list(range(4))
        obiettivi = (t == 0) if dinamico else True
        stime = md.stime(t)
        ultima = {}
        for k in vincoli:
            if regime == "uguale_tutti":
                idx, w = np.arange(n), np.ones(n)
            else:
                Cq = Cstar @ RILEVANZA_VINCOLI[k]
                idx, w, tau_e, est = convoca(Cq, np.zeros(n, bool), rng, n_min_regime(regime))
                w = w * peso_storico[idx, k]
                tau_eff_lista.append(tau_e)
                estese += int(est)
                quota_ind_max = max(quota_ind_max, float(w.max() / w.sum()))
            b_cert[k] = mediana_pesata(stime[idx, k], w) - d22.MARGINE
            ultima[k] = (idx, stime[idx, k])
            schede += len(idx)
            voti.append(len(idx))
            if k == 2:
                q = w[pop.gruppo[idx] == sorvegliato].sum() / w.sum()
                qT = q
                q0 = q if np.isnan(q0) else q0
        if obiettivi:
            if regime == "tecnico":
                Wt = pop.omega.sum(0)
                tau_obj, W = (pop.omega * pop.ideale).sum(0) / Wt, Wt / n
            else:
                for j in range(3):
                    if regime != "dpa_teps_obiettivi_per_competenza":
                        # gli obiettivi toccano tutti: voto eguale (TEPS §11.1, §17.7)
                        idx, w = np.arange(n), np.ones(n)
                    else:
                        Cq = Cstar @ RILEVANZA_OBIETTIVI[j]
                        idx, w, tau_e, est = convoca(Cq, conflitti[:, j], rng, n_min_regime(regime))
                        tau_eff_lista.append(tau_e)
                        estese += int(est)
                    tau_obj[j] = mediana_pesata(pop.ideale[idx, j], w)
                    W[j] = 1.0            # priorita' uguali: il livello e' votato
                    schede += len(idx)
                    voti.append(len(idx))
        x, stato = d22.piano(tau_obj, W, md.A, b_cert, x, t_min)
        g = md.A @ x - md.b[t]
        pref = d21.preferenza(pop, x[None, :])[:, 0]
        righe_t.append({"fattibile": float(np.max(g) <= 1e-9), "violazione": float(np.maximum(0, g).sum()),
                        "benessere": float(pref.mean()),
                        "benessere_minoranza": float(pref[pop.gruppo == "minoranza"].mean()),
                        "peggior_gruppo": float(min(pref[pop.gruppo == gn].mean() for gn in np.unique(pop.gruppo))),
                        "impossibile": float(stato == "impossibile_stimato")})
    media = {k: float(np.mean([r[k] for r in righe_t])) for k in righe_t[0]}
    dopo = righe_t[d22.PERIODO_SHOCK:]
    media.update({
        "fattibile_dopo_5": float(np.mean([r["fattibile"] for r in dopo])),
        "schede_per_periodo": schede / PERIODI,
        "votanti_medi_per_questione": float(np.mean(voti)),
        "votanti_minimi_per_questione": float(np.min(voti)),
        "soglia_effettiva_media": float(np.mean(tau_eff_lista)) if tau_eff_lista else np.nan,
        "questioni_con_estensione": estese,
        "quota_individuale_max": quota_ind_max,
        "quota_sorvegliato_primo_voto": q0, "quota_sorvegliato_ultimo_voto": qT,
        "abitazioni_finali": float(x[0])})
    return media


def esegui_mondo(seed, indice, scenario):
    base = "competenze_gonfiate" if scenario.startswith("credenziali") else scenario
    md = d22.MondoDinamico(seed, indice, base if base in d22.SCENARI else "base")
    if scenario == "shock":
        md = d22.MondoDinamico(seed, indice, "shock")
    pop = md.pop
    rng = np.random.default_rng([seed, indice, 900 + SCENARI.index(scenario)])
    sorv = "tecnico"
    bersaglio, ingannati = None, 0
    if scenario.startswith("credenziali"):
        sorv = "lobby"
        bersaglio = np.where(pop.gruppo == "lobby")[0]
        ingannati = int(scenario.split("_")[-1][0])
        pop.c_cert = pop.c_vera.copy()        # nessun gonfiamento diretto: passa dagli agenti IA
    if scenario == "esperti_corrotti":
        sorv = "corrotti"
        pop.gruppo = pop.gruppo.copy()
        pop.gruppo[pop.corrotto] = "corrotti"
    Cstar, _, _ = competenze_riconosciute(pop, rng, ingannati, bersaglio=bersaglio)
    # interessi diretti registrati: la lobby non vota con peso sulle abitazioni
    conflitti = np.zeros((pop.n, 3), bool)
    conflitti[pop.gruppo == "lobby", 0] = True
    righe = []
    for r_i, regime in enumerate(REGIMI):
        r = esegui_regime(md, regime, Cstar, conflitti, sorv, [seed, indice, 7, r_i])
        righe.append({"mondo": indice, "scenario": scenario, "regime": regime,
                      "gruppo_sorvegliato": sorv, **r})
    return righe


METRICHE = ("fattibile", "violazione", "fattibile_dopo_5", "benessere", "benessere_minoranza",
            "peggior_gruppo", "schede_per_periodo", "votanti_medi_per_questione",
            "votanti_minimi_per_questione", "soglia_effettiva_media", "questioni_con_estensione",
            "quota_individuale_max", "quota_sorvegliato_primo_voto", "quota_sorvegliato_ultimo_voto",
            "abitazioni_finali")


def riepiloga(righe, seed):
    rng = np.random.default_rng([seed, 23])
    rie, conf = [], []
    for s in SCENARI:
        per = {g: [r for r in righe if r["scenario"] == s and r["regime"] == g] for g in REGIMI}
        for g, rr in per.items():
            out = {"scenario": s, "regime": g, "mondi": len(rr)}
            for k in METRICHE:
                v = np.array([r[k] for r in rr], float)
                v = v[~np.isnan(v)]
                mu, lo, hi = d21.ic_bootstrap(v, rng, 2000)
                out.update({k: mu, k + "_ic_basso": lo, k + "_ic_alto": hi})
            rie.append(out)
        for g in REGIMI:
            if g == "dpa_teps":
                continue
            ref = {r["mondo"]: r for r in per[g]}
            for k in ("fattibile", "fattibile_dopo_5", "benessere", "benessere_minoranza",
                      "peggior_gruppo", "schede_per_periodo"):
                d = [r[k] - ref[r["mondo"]][k] for r in per["dpa_teps"]]
                mu, lo, hi = d21.ic_bootstrap(np.array(d), rng, 2000)
                conf.append({"scenario": s, "confronto": f"dpa_teps - {g}", "metrica": k,
                             "differenza": mu, "ic95_basso": lo, "ic95_alto": hi})
    return rie, conf


def main():
    ap = argparse.ArgumentParser(description="DPA V23 con premesse TEPS")
    ap.add_argument("--mondi", type=int, default=200)
    ap.add_argument("--seed", type=int, default=2323)
    ap.add_argument("--errore-laico-medio", type=float, default=None)
    ap.add_argument("--output", type=Path, default=QUI / "risultati")
    ap.add_argument("--test", action="store_true")
    a = ap.parse_args()
    if a.errore_laico_medio is not None:
        d22.PARAMETRI_SCENARIO["errore_laico"] = (a.errore_laico_medio, d22.ERRORE_LAICO[1])
    mondi = 3 if a.test else a.mondi
    righe = [r for s in SCENARI for i in range(mondi) for r in esegui_mondo(a.seed, i, s)]
    rie, conf = riepiloga(righe, a.seed)
    a.output.mkdir(parents=True, exist_ok=True)
    d21.scrivi_csv(a.output / "dettaglio.csv", righe)
    d21.scrivi_csv(a.output / "riepilogo.csv", rie)
    d21.scrivi_csv(a.output / "confronti_accoppiati.csv", conf)
    (a.output / "parametri.json").write_text(json.dumps({
        "mondi": mondi, "seed": a.seed, "tau0": TAU0, "w_max": W_MAX, "n_min": N_MIN,
        "n_min_sensibilita": N_MIN_SENSIBILITA, "partecipazione": PARTECIPAZIONE, "agenti": AGENTI,
        "rumore_agenti": RUMORE_AGENTI, "lambda_mad": LAMBDA_MAD, "gonfiamento": GONFIAMENTO,
        "errore_laico": d22.PARAMETRI_SCENARIO["errore_laico"], "margine": d22.MARGINE,
        "periodi": PERIODI, "regimi": REGIMI, "scenari": SCENARI}, indent=2, ensure_ascii=False),
        encoding="utf-8")
    for r in rie:
        print(f"{r['scenario']:26s} {r['regime']:18s} fatt={r['fattibile']:.3f} fatt5={r['fattibile_dopo_5']:.3f} "
              f"ben={r['benessere']:.2f} min={r['benessere_minoranza']:.2f} pegg={r['peggior_gruppo']:.2f} "
              f"schede={r['schede_per_periodo']:.0f} vot={r['votanti_medi_per_questione']:.0f}/"
              f"{r['votanti_minimi_per_questione']:.0f} tau*={r['soglia_effettiva_media']:.3f} "
              f"est={r['questioni_con_estensione']:.1f} qind={r['quota_individuale_max']:.3f} "
              f"q0={r['quota_sorvegliato_primo_voto']:.3f} qT={r['quota_sorvegliato_ultimo_voto']:.3f} "
              f"h={r['abitazioni_finali']:.2f}")


if __name__ == "__main__":
    main()
