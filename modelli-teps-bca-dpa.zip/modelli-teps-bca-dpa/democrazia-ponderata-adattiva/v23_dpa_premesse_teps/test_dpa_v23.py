# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test DPA V23 (premesse TEPS). Esecuzione: python test_dpa_v23.py"""
import numpy as np

import simulazione_dpa_v23 as s


def test_peso_teps():
    C = np.array([0.0, 0.59, 0.6, 0.8, 1.0])
    w = s.peso_teps(C, 0.6)
    assert w[0] == 0 and w[1] == 0 and w[2] == 1 and abs(w[4] - s.W_MAX) < 1e-12
    assert np.all(np.diff(w[2:]) > 0)


def test_base_minima_d15():
    rng = np.random.default_rng(0)
    Cq = np.r_[np.full(30, 0.9), np.linspace(0.1, 0.55, 570)]   # solo 30 sopra la soglia
    vot, w, tau, estesa = s.convoca(Cq, np.zeros(600, bool), rng, 101)
    assert len(vot) >= 101 and estesa and tau < s.TAU0
    assert np.all(w >= 1 - 1e-12) and np.all(w <= s.W_MAX + 1e-12)
    assert w.max() / w.sum() <= s.W_MAX / (s.W_MAX + 101 - 1) + 1e-12   # D-15
    Cq2 = np.r_[np.full(300, 0.9), np.full(300, 0.2)]
    vot2, _, tau2, estesa2 = s.convoca(Cq2, np.zeros(600, bool), rng, 101)
    assert tau2 == s.TAU0 and not estesa2 and len(vot2) >= 101


def test_conflitto_di_interessi():
    rng = np.random.default_rng(1)
    Cq = np.full(600, 0.9)
    escludi = np.zeros(600, bool)
    escludi[:50] = True
    vot, _, _, _ = s.convoca(Cq, escludi, rng, 101)
    assert not np.any(vot < 50)


def test_agenti_ia_mediana():
    """Con 2 agenti su 5 ingannati la mediana resiste; con 3 no."""
    class P:
        pass
    p = P()
    p.n = 200
    p.c_vera = np.full((200, 4), 0.3)
    bersaglio = np.arange(20)
    C2, _, _ = s.competenze_riconosciute(p, np.random.default_rng(2), 2, bersaglio=bersaglio)
    C3, _, _ = s.competenze_riconosciute(p, np.random.default_rng(2), 3, bersaglio=bersaglio)
    assert C2[:20].mean() < 0.45 and C3[:20].mean() > C2[:20].mean() + 0.1


def test_obiettivi_a_voto_eguale_e_determinismo():
    a = s.esegui_mondo(2323, 0, "base")
    b = s.esegui_mondo(2323, 0, "base")
    assert a == b
    reg = {r["regime"]: r for r in a}
    assert reg["dpa_teps"]["votanti_minimi_per_questione"] >= s.N_MIN
    assert reg["dpa_teps"]["quota_individuale_max"] <= s.W_MAX / (s.W_MAX + s.N_MIN - 1) + 1e-9


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK", t.__name__)
    print(f"OK DPA V23: {len(tests)} test superati")
