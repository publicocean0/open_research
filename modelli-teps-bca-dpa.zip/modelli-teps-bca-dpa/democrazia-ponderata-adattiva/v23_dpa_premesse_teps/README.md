# Democrazia Ponderata Adattiva — V23 (premesse TEPS)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra
l'efficacia di un ordinamento reale. Parametri fissati prima dell'esecuzione
(`risultati/parametri.json`).

## Cosa cambia rispetto alla V22

Le votazioni sono **indirizzate per competenze** e hanno una **base minima di
votanti**, con le stesse regole della TEPS 1.5:

| Regola | Nella V23 | Riferimento TEPS 1.5 |
|---|---|---|
| Competenze riconosciute | ogni persona ha formazione ed esperienza lavorativa per disciplina; 5 agenti IA isolati valutano il dossier; `C* = max(0, mediana − λ·MAD)`, λ = 1 | §11, §12.1 |
| Ammissione e peso | su ogni questione `w = 0` se `C(q) < τ₀ = 0,6`, altrimenti `w = 1 + (w_max − 1)(C(q) − τ)/(1 − τ)`, `w_max = 3`; `C(q)` è la competenza rilevante per q | §11.1 |
| Base minima | `τ* = min(τ₀, C₍N_min₎)`, `N_min = 101`; se i voti espressi sono meno di N_min si convocano i successivi in graduatoria | §17.8, Nota 1.5 |
| Astensione | partecipazione dell'80%; l'astensione non entra nell'esito | §11.3 |
| Materie che toccano tutti | diritto universale e **obiettivi** a voto eguale | §11.1, §17.7 |
| Conflitto di interessi | chi ha un interesse diretto registrato su un tema non vota con peso su quel tema | §11.2 |

La dinamica è quella della V22: 10 periodi, limiti reali che si spostano, shock
in uno scenario, inerzia dei piani, monitoraggio e rivoto mirato.

**Storico delle previsioni (variante separata).** Nella V22 chi stimava male
perdeva peso. Il §11.2 della TEPS esclude penalizzazioni automatiche della
competenza; qui lo storico è quindi una variante (`dpa_teps_storico`) che
riduce solo il peso nelle questioni di misura, senza toccare la competenza
riconosciuta.

## Regimi

| Regime | Vincoli | Obiettivi | Monitoraggio |
|---|---|---|---|
| `uguale_tutti` | tutti, voto eguale | tutti, voto eguale | no, si rivota tutto |
| `tecnico` | competenti (regole TEPS) | ottimo utilitarista calcolato | no |
| `dpa_teps_statico` | competenti (regole TEPS) | tutti, voto eguale | no, si rivota tutto |
| **`dpa_teps`** | competenti (regole TEPS) | tutti, voto eguale | sì, rivoto mirato |
| `dpa_teps_storico` | come `dpa_teps` + storico delle previsioni | tutti, voto eguale | sì |
| `dpa_teps_obiettivi_per_competenza` | competenti | **competenti** (con conflitto di interessi) | sì |
| `dpa_teps_nmin25`, `dpa_teps_nmin201` | come `dpa_teps` con N_min 25 o 201 | tutti, voto eguale | sì |

Scenari: `base`; `esperti_corrotti` (metà dei tecnici allenta le stime di 1,5);
`credenziali_gonfiate_2su5` e `_3su5` (una lobby, il 10% della popolazione, gonfia
di 0,5 la valutazione di 2 o 3 agenti IA su 5); `shock`.

## Risultati (200 mondi per scenario)

Quota di periodi in cui il piano rispetta davvero i limiti:

| Regime | Base | Esperti corrotti | Credenziali 2/5 | Credenziali 3/5 | Shock | Schede per periodo (base) |
|---|---:|---:|---:|---:|---:|---:|
| Tutti, voto eguale | 60,7% | 46,3% | 61,1% | 61,1% | 58,9% | 4 260 |
| Tecnico | 92,9% | 66,7% | 93,4% | 91,2% | 93,7% | 464 |
| DPA-TEPS statico | 93,2% | 66,4% | 93,4% | 91,4% | 93,8% | 2 264 |
| **DPA-TEPS** | 96,3% | 76,8% | 95,8% | 94,6% | 95,0% | 394 |
| DPA-TEPS + storico | **97,4%** | **91,7%** | **96,2%** | **95,4%** | **95,6%** | 391 |
| DPA-TEPS, obiettivi per competenza | 96,8% | 77,5% | 95,8% | 95,2% | 95,2% | 244 |
| DPA-TEPS, N_min 25 | 97,5% | 77,7% | 96,5% | 94,5% | 95,4% | 361 |
| DPA-TEPS, N_min 201 | 91,6% | 71,1% | 91,1% | 89,7% | 90,7% | 581 |

Differenze accoppiate (IC bootstrap 95%) per DPA-TEPS:

| Confronto | Fattibilità | Benessere del gruppo più svantaggiato |
|---|---|---|
| − tutti, voto eguale (base) | +35,6 punti [+31,5, +39,9] | −2,0 [−2,2, −1,8] |
| − DPA-TEPS statico (esperti corrotti) | +10,4 [+8,6, +12,3] | −0,6 [−0,7, −0,5] |
| − DPA-TEPS + storico (esperti corrotti) | −14,8 [−17,2, −12,6] | +0,9 [+0,8, +1,0] |
| − obiettivi per competenza (base) | −0,4 [−1,0, +0,1] | **+4,6 [+4,4, +4,8]** |
| − N_min 201 (base) | +4,8 [+3,3, +6,2] | −0,4 [−0,5, −0,3] |

Altre misure: con N_min = 101 nessuna persona supera l'1,8% del peso (limite
D-15: 2,9%); la soglia effettiva scende in media a 0,55 perché i competenti
sopra 0,6 che votano davvero sono meno di 101. La lobby che inganna 2 agenti su
5 pesa il 4,7% nel voto sul bilancio; se ne inganna 3 su 5 pesa il 29%, ridotto
al 23% dallo storico.

### Sensibilità: i non esperti sbagliano solo a caso

Senza errore sistematico comune dei non esperti tutti i regimi superano il 92%
di fattibilità. DPA-TEPS resta migliore di "tutti, voto eguale" di 2,7 punti
[+1,5, +4,0] nella base; con esperti corrotti lo storico porta dal 95,3% al
98,2%. Le differenze fra N_min 25, 101 e 201 scompaiono.

## Cosa mostrano i numeri

1. **Indirizzare per competenze le questioni tecniche funziona**: +35 punti di
   piani davvero fattibili rispetto a "tutti su tutto", con un decimo delle
   schede. Il vantaggio è così grande **solo se i non esperti condividono un
   errore sistematico**; altrimenti è di circa 3 punti. Va misurato nella realtà.
2. **Gli obiettivi che toccano tutti vanno votati a voto eguale.** Se anche gli
   obiettivi si votano per competenza, il piano segue le preferenze di chi ha le
   competenze: il gruppo più svantaggiato perde 4,6 punti di benessere (la
   minoranza, che qui ha preferenze vicine a quelle dei tecnici, ne guadagna 2).
   È coerente con la TEPS: «sulle materie che toccano tutti il voto resta eguale».
3. **La base minima ha un punto giusto.** Con 25 o 101 votanti i risultati sono
   simili; con 201 la soglia scende a 0,38, entrano persone meno competenti e la
   fattibilità cala di 5 punti (se i non esperti sbagliano in modo sistematico).
   "Base non troppo piccola" ma nemmeno troppo grande rispetto alle competenze
   disponibili: N_min va fissato guardando quante persone competenti esistono.
4. **Il consesso di agenti IA protegge le competenze riconosciute finché la
   maggioranza degli agenti non è ingannata** (4,7% contro 29% di peso della
   lobby), come previsto dal §12.2 della TEPS.
5. **Lo storico delle previsioni è la difesa più forte contro gli esperti
   corrotti** (+14,8 punti) e non peggiora mai la fattibilità. Va però
   conciliato con il §11.2: qui riduce il peso solo sulle questioni di misura e
   non la competenza riconosciuta.
6. **Monitoraggio e rivoto mirato** migliorano rispetto al rivotare tutto ogni
   periodo (+3 punti nella base, +10 con esperti corrotti) con circa un sesto
   delle schede.

### Esiti negativi da conservare

- Dopo uno shock il rivoto mirato reagisce con un periodo di ritardo: 93,2%
  contro 94,1% del rivoto completo nei periodi successivi.
- I regimi prudenti hanno un benessere medio più basso di "tutti su tutto"
  (−1,8), ma quel benessere in più viene da piani che violano i limiti reali.

## Limiti

- Formazione ed esperienza sono generate attorno alla competenza vera; nella
  realtà il legame va misurato.
- I coefficienti dei vincoli sono noti; si votano solo i limiti.
- La distinzione fra questioni tecniche e materie che toccano tutti è fissata a
  priori: chi la decide è un punto da garantire (nella TEPS, voto eguale).
- Le preferenze non cambiano nel tempo; strategie di manipolazione semplici.
- Mandati condizionali e riserve delle V8–V16 non sono ancora inclusi.

## File e riproduzione

- `simulazione_dpa_v23.py` — competenze riconosciute, convocazione D-15,
  regimi, scenari. Usa V21 e V22.
- `test_dpa_v23.py` — 5 test: peso TEPS, base minima D-15, conflitto di
  interessi, mediana degli agenti IA, obiettivi a voto eguale e determinismo.
- `risultati/` e `risultati/sensibilita_errore_laico_0/`.

```bash
cd democrazia-ponderata-adattiva/v23_dpa_premesse_teps
python -m pip install -r requirements.txt
python test_dpa_v23.py
python simulazione_dpa_v23.py --mondi 200
python simulazione_dpa_v23.py --mondi 200 --errore-laico-medio 0 --output risultati/sensibilita_errore_laico_0
```
