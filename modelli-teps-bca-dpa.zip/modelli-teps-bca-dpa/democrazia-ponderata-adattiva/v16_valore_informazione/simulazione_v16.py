#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V16: scelta sequenziale tra agire, attendere e acquisire informazioni.

Il sistema NON conosce il guasto reale nel deliberare. Utilizza 140 eventi
sintetici precedenti, non i mondi di test; approssima l'EVSI (expected value
of sample information) con Monte Carlo predittivo. I rami sono approvati con
voto ponderato nella V14; ogni ulteriore correzione tecnica viene rivotata.

Il tempo della misura e' qui un COSTO RIDOTTO-FORMA dei benefici intermedi:
non viene simulato uno slittamento fisico del cantiere. Questo e' un limite,
non una dimostrazione di recuperabilita' dinamica.
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
from functools import lru_cache
from pathlib import Path
from dataclasses import dataclass
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'v15_riserva_marginale'))
import simulazione_v15 as v15

v14 = v15.v14
v13 = v15.v13
v12 = v15.v12
p = v15.p
v11 = v15.v11

METHODS = ('V15_sensore_singolo', 'V15_due_sensori_soglia',
           'V16_posterior', 'V16_due_sensori', 'V16_valore_informazione')
SCENARIOS = tuple(v14.TEST_SCENARIOS)
NOISE_LEVELS = (0.08, 0.18)
SENSOR_COST = 0.08            # Unita' finanziarie, sottratte a budget V11
SENSOR_DELAY_BASE = 0.009    # Indice di beneficio perso per verifica
SENSOR_DELAY_URGENCY = 0.035 # Maggior costo di attesa in presenza di shock
SIMULATIONS_PER_VALUE = 24

@lru_cache(maxsize=1)
def historical_factors():
    # Storia indipendente dalle realizzazioni del test; nessun scenario futuro.
    factors = v15.risk_validation()
    assert factors.shape == (140, p.K)
    return factors


def posterior(prod0, observations, sd):
    """Posterior discreto P(evento storico | osservazioni tecniche), non P(test)."""
    factors = historical_factors()
    preds = factors * np.asarray(prod0)[None, :]
    sigma = max(0.04, float(sd))  # ipotesi sul rumore, da validare esternamente
    logw = np.zeros(len(factors), dtype=float)
    for obs in observations:
        residual = (preds - np.asarray(obs)[None, :]) / sigma
        logw -= .5 * np.sum(residual * residual, axis=1)
    logw -= logw.max()
    w = np.exp(logw)
    return w / w.sum()


def shock_probability(weights):
    return float(np.dot(weights, np.any(historical_factors()[:, :3] < 0.945, axis=1)))


def batch_loss(plan, prod0, factors, sensor_cost=0.0):
    """Perdita predetta ex-ante per evento (non il risultato del test).

    Solo dati e obiettivi tecnici gia' definiti nel mondo sintetico.
    L'importanza di target/vincoli rispetto ai benefici intermedi e' una
    scelta parametrica esplicita, NON un'utilita' democratica universale.
    """
    prod = prod0[None, :] * factors
    clock = np.linspace(1.15, 1., p.T)
    contributions = np.cumsum(plan * clock[:, None], axis=0)
    accum = prod[:, None, :] * contributions[None, :, :]
    a,b,c,d = (accum[:,:,j] for j in range(p.K))
    energy = 1.12*a + .58*b + .73*c + .35*d + .18*np.sqrt(np.maximum(a*c,0) + 1e-10) + .22*np.sqrt(np.maximum(a*b,0) + 1e-10)
    co2 = .96*a + .12*b + .26*c + 1.04*d
    stress = np.maximum(0., .52*a-.38*b-.32*c-.09*d)
    eshort = np.maximum(p.TARGET_ENERGY-energy[:,-1], 0.) / p.TARGET_ENERGY
    cshort = np.maximum(p.TARGET_CO2-co2[:,-1], 0.) / p.TARGET_CO2
    violation = np.maximum(stress[:,-1] - p.STRESS_LIMIT,0.)
    service = np.mean((np.clip(energy / p.TARGET_ENERGY, 0, 1) + np.clip(co2 / p.TARGET_CO2, 0, 1))/2., axis=1)
    budget = plan @ p.COSTS
    cost_violation = max(0., (np.sum(budget) + sensor_cost - p.TOTAL_BUDGET)/p.TOTAL_BUDGET)
    cost_violation += max(0., (budget[0]+sensor_cost-p.PERIOD_BUDGET)/p.PERIOD_BUDGET)
    return 8.0*(eshort+cshort) + 7.0*violation + 9.0*cost_violation + .65*(1.0-service)


def plan_losses(policy, prod0):
    factors = historical_factors()
    return np.stack((batch_loss(policy.normal, prod0, factors),
                     batch_loss(policy.stressed, prod0, factors)),axis=0)


def optimum_branch(weights, losses):
    expect = losses @ weights
    # Vincolo di mandato: il ramo di emergenza non e' utilizzabile solo
    # perche' conveniente; serve evidenza che lo shock sia plausibile.
    # La soglia 0.50 e' un'ipotesi operativa dichiarata, non una votazione
    # ulteriore ne' un permesso di alterare gli obiettivi.
    j = int(np.argmin(expect)) if shock_probability(weights) >= .50 else 0
    return ('normal' if j == 0 else 'shock'), float(expect[j])


@dataclass(frozen=True)
class Decision:
    action: str
    branch: str
    expected_information_value: float
    cost_of_information: float
    posterior_shock: float
    initial_branch: str
    measured_second: bool


def choose_action(prod0, sensor_a, sd, loss, rng_seed, use_value=True, sensor_b=None,
                  samples=SIMULATIONS_PER_VALUE):
    # Can be called without sensor_b: hence no peeking at the actual second sensor.
    first = posterior(prod0, (sensor_a,), sd)
    initial_branch, now_loss = optimum_branch(first, loss)
    pshock = shock_probability(first)
    if not use_value:
        return Decision('attendi' if initial_branch=='normal' else 'agisci',
                        initial_branch, 0., 0., pshock, initial_branch, False)
    if samples <= 0:
        raise ValueError('samples must be positive')
    # Monte Carlo *predictive* draws, from past data, not the future test label.
    rng = np.random.default_rng(int(rng_seed))
    candidates = rng.choice(len(first),size=samples,p=first)
    pred = historical_factors()[candidates] * prod0[None,:]
    sigma = float(sd)
    second_draws = np.clip(pred + rng.normal(0.,sigma,size=pred.shape), .10, 1.45)
    informed_losses=[]
    for second in second_draws:
        further = posterior(prod0,(sensor_a,second),sd)
        _branch,value = optimum_branch(further,loss)
        # Conditional value evaluated under synthetic predictive model.
        informed_losses.append(value)
    evsi = max(0., float(now_loss - np.mean(informed_losses)))
    # Cost of acquisition and delay risk are modeled; values are illustrative.
    info_cost = float(0.020 + SENSOR_DELAY_BASE + SENSOR_DELAY_URGENCY*pshock)
    # Choice made BEFORE the real second observation.
    acquire = bool(evsi > info_cost)
    branch = initial_branch
    if acquire:
        if sensor_b is None:
            raise ValueError('Real second measurement required only if acquisition was chosen')
        branch,_ = optimum_branch(posterior(prod0,(sensor_a,sensor_b),sd),loss)
    return Decision('verifica' if acquire else ('attendi' if initial_branch=='normal' else 'agisci'),
                    branch,evsi,info_cost,pshock,initial_branch,acquire)


def evaluate_decision(world,prod0,policy,factor,measurement,selected_branch,second=False,pshock=0.):
    """Ex-ante branch choice; evaluates the true state only after election.

    A correction NOT covered by the two-branch mandate requires a weighted
    re-vote. Sensor costs subtract from original financial resources.
    """
    truth = prod0 * factor
    if policy is None:
        return dict(approved=0, success=0, revote=0, revote_approved=0,
                    branch=selected_branch, service=0., sensor_cost=0.,
                    objective_gap=p.TARGET_ENERGY+p.TARGET_CO2, constraints_ok=1)
    fee = v11.transfer_admin(world,policy.transfer) + (SENSOR_COST if second else 0.)
    branch=policy.stressed if selected_branch=='shock' else policy.normal
    estimated_ok = v13.actually_feasible(branch,measurement,fee)
    final = branch.copy()
    revote=0;passed=0
    # Regola V16 contro falsi allarmi: se il ramo normale e' coerente
    # con la posterior, non ripianificare per una singola stima rumorosa.
    if not estimated_ok and not (selected_branch=='normal' and pshock < .50):
        executed=np.zeros_like(branch)
        executed[:v12.PREFIX]=branch[:v12.PREFIX]
        candidate=v13.fast_recovery(measurement,executed,branch)
        if candidate is not None and np.array_equal(candidate[:v12.PREFIX],executed[:v12.PREFIX]) and v13.actually_feasible(candidate,measurement,fee):
            revote=1
            passed=int(v11.vote(world,candidate,measurement,policy.transfer)>.5)
            if passed:
                final = candidate
    assert np.array_equal(final[:v12.PREFIX],branch[:v12.PREFIX])
    actual_metrics=p.indicators(final,truth)
    constraints=(actual_metrics['stress_rete']<=p.STRESS_LIMIT+v12.TOL
                 and actual_metrics['spesa_totale']+fee<=p.TOTAL_BUDGET+v12.TOL
                 and max(actual_metrics['spesa_periodo'])<=p.PERIOD_BUDGET+v12.TOL
                 and actual_metrics['spesa_periodo'][0]+fee<=p.PERIOD_BUDGET+v12.TOL)
    goals=actual_metrics['energia']>=p.TARGET_ENERGY-v12.TOL and actual_metrics['emissioni_evitate']>=p.TARGET_CO2-v12.TOL
    service=v13.intermediate_benefit(final,truth)
    if second:
        # Tempo di verifica non modellato come spostamento fisico del piano:
        # e' un costo sociale ridotto-forma separato dall'obiettivo finale.
        real_shock=bool(np.any(factor[:3]<.945))
        service-=SENSOR_DELAY_BASE+SENSOR_DELAY_URGENCY*float(real_shock)
    return dict(approved=1, success=int(goals and constraints), revote=revote,
                revote_approved=passed, branch=selected_branch,
                service=round(float(service),5), sensor_cost=float(SENSOR_COST if second else 0.),
                objective_gap=round(float(max(0,p.TARGET_ENERGY-actual_metrics['energia'])+max(0,p.TARGET_CO2-actual_metrics['emissioni_evitate'])),5),
                constraints_ok=int(constraints))


def simulate_seed(seed,scenario,sd,risk=None,policy_data=None):
    if risk is None:
        risk=v15.trained_risk(None)
    if policy_data is None:
        policy_data=v14.choose_policy(seed,'V14_shock_appreso',risk,False)
    world,prod0,policy,reason=policy_data
    factor=v14.TEST_SCENARIOS[scenario]
    truth=prod0*factor
    sa=v15.observation(truth,seed,scenario,sd,0)
    sb=v15.observation(truth,seed,scenario,sd,1)
    rows=[]
    for method in METHODS:
        if method in METHODS[:2]:
            second=method==METHODS[1]
            estimate=(sa+sb)*.5 if second else sa
            ev=v15.evaluate(world,prod0,policy,factor,estimate,risk,sd,confidence_gate=second)
            output=dict(approved=ev['approved'],success=ev['success'],revote=ev['revote_required'],
                        revote_approved=ev['revote_approved'],branch=ev['initial_branch'],
                        service=ev['service'],sensor_cost=0.,objective_gap=ev['gap'],constraints_ok=ev['constraints_ok'])
            decision=Decision('due_misure_fisse' if second else 'agisci_su_sensore',ev['initial_branch'],0.,0.,0.,ev['initial_branch'],second)
        else:
            if policy is None:
                decision=Decision('nessun_piano','none',0.,0.,0.,'none',False)
                output=evaluate_decision(world,prod0,policy,factor,sa,'none')
            else:
                losses=plan_losses(policy,prod0)
                if method==METHODS[3]:
                    first=posterior(prod0,(sa,),sd)
                    prior_branch,_=optimum_branch(first,losses)
                    two_branch,_=optimum_branch(posterior(prod0,(sa,sb),sd),losses)
                    decision=Decision('verifica_sempre',two_branch,0.,0.,
                                      shock_probability(first),prior_branch,True)
                else:
                    decision=choose_action(prod0,sa,sd,losses,991731+seed*51+int(sd*1000)*101,
                                           use_value=(method==METHODS[4]),sensor_b=sb)
                measured=(sa+sb)*.5 if decision.measured_second else sa
                posterior_final = posterior(prod0,(sa,sb),sd) if decision.measured_second else posterior(prod0,(sa,),sd)
                output=evaluate_decision(world,prod0,policy,factor,measured,decision.branch,
                                         second=decision.measured_second,pshock=shock_probability(posterior_final))
        output.update(seed=seed,scenario=scenario,noise=sd,method=method,
                      action=decision.action,evsi=round(decision.expected_information_value,5),
                      information_cost=round(decision.cost_of_information,5),
                      posterior_shock=round(decision.posterior_shock,5),
                      second_measurement=int(decision.measured_second),
                      initial_weighted_vote=round(policy.weighted_vote,5) if policy else 0.,
                      original_goals_unchanged=1,
                      initial_reason=reason)
        rows.append(output)
    return rows


def summarise(rows):
    groups=sorted({(r['scenario'],r['noise'],r['method']) for r in rows})
    out=[]
    for scenario,noise,method in groups:
        rr=[r for r in rows if (r['scenario'],r['noise'],r['method'])==(scenario,noise,method)]
        n=len(rr)
        out.append(dict(scenario=scenario,noise=noise,method=method,n=n,
            success=sum(r['success'] for r in rr),success_pct=round(100*sum(r['success'] for r in rr)/n,1),
            measurements=sum(r['second_measurement'] for r in rr),
            revotes=sum(r['revote'] for r in rr),revotes_approved=sum(r['revote_approved'] for r in rr),
            mean_service=round(float(np.mean([r['service'] for r in rr])),4),
            mean_gap=round(float(np.mean([r['objective_gap'] for r in rr])),4),
            mean_sensor_cost=round(float(np.mean([r['sensor_cost'] for r in rr])),4),
            waits=sum(r['action']=='attendi' for r in rr)))
    return out


def paired(rows, scenario, noise, control=METHODS[3], treatment=METHODS[4], repetitions=3000):
    a={r['seed']:r['success'] for r in rows if (r['scenario'],r['noise'],r['method'])==(scenario,noise,control)}
    b={r['seed']:r['success'] for r in rows if (r['scenario'],r['noise'],r['method'])==(scenario,noise,treatment)}
    if a.keys()!=b.keys():raise ValueError('Unpaired rows')
    d=np.array([b[k]-a[k] for k in sorted(a)])
    rng=np.random.default_rng(17031)
    boot=rng.choice(d,size=(repetitions,len(d)),replace=True).mean(axis=1)
    return dict(scenario=scenario,noise=noise,control=control,treatment=treatment,n=len(d),
                delta_pp=round(100*float(np.mean(d)),2),ci95_low=round(100*float(np.quantile(boot,.025)),2),
                ci95_high=round(100*float(np.quantile(boot,.975)),2),wins=int((d>0).sum()),losses=int((d<0).sum()))


def save(path,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)


def test():
    risk=v15.trained_risk(None)
    assert len(historical_factors())==140
    prod=np.ones(p.K)
    w=posterior(prod,(prod,),.08)
    assert np.isclose(w.sum(),1.) and np.all(w>=0.)
    w2=posterior(prod,(prod,prod),.08)
    assert shock_probability(w2)<=shock_probability(w)+1e-9
    world,initial,policy,_=v14.choose_policy(0,'V14_shock_appreso',risk,False)
    assert policy is not None and policy.weighted_vote>.5
    losses=plan_losses(policy,initial)
    reading=initial.copy()
    one=choose_action(initial,reading,.08,losses,147,False)
    two=choose_action(initial,reading,.08,losses,147,True,reading)
    assert one.initial_branch==two.initial_branch
    assert optimum_branch(posterior(initial,(initial,),.08),losses)[0]=='normal', 'Ramo shock non autorizzato in condizioni normali'
    same_but_diff_truth_a=evaluate_decision(world,initial,policy,np.ones(p.K),reading,one.branch)
    same_but_diff_truth_b=evaluate_decision(world,initial,policy,np.array([.65,1,1,1]),reading,one.branch)
    assert same_but_diff_truth_a['branch']==same_but_diff_truth_b['branch']
    assert not same_but_diff_truth_a['sensor_cost']
    assert all(r['success']<=r['approved'] for r in simulate_seed(0,'doppio_moderato',.08,risk,(world,initial,policy,'approvata')))
    print('OK V16: posterior, informazione ex ante, integrita mandato, costo misura, assenza di fuga dal futuro')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--mondi',type=int,default=16)
    ap.add_argument('--seed-offset',type=int,default=0)
    ap.add_argument('--noise',type=float,nargs='*',default=list(NOISE_LEVELS))
    ap.add_argument('--output',default=str(HERE/'risultati'))
    args=ap.parse_args()
    if args.test:
        test();return
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in range(args.seed_offset,args.seed_offset+args.mondi):
        risk=v15.trained_risk(None)
        policy_data=v14.choose_policy(seed,'V14_shock_appreso',risk,False)
        for sc in SCENARIOS:
            for sd in args.noise:
                rows.extend(simulate_seed(seed,sc,sd,risk,policy_data))
        print('V16 mondo',seed,'completato',flush=True)
    summary=summarise(rows)
    pairs=[paired(rows,sc,sd,control=c,treatment=t) for sc in SCENARIOS for sd in args.noise
           for c,t in [(METHODS[2],METHODS[4]),(METHODS[3],METHODS[4]),(METHODS[1],METHODS[4])]]
    save(out/'dettaglio.csv',rows)
    save(out/'riepilogo.csv',summary)
    save(out/'confronti_accoppiati.csv',pairs)
    (out/'configurazione.json').write_text(json.dumps(dict(worlds=args.mondi,seed_offset=args.seed_offset,
        scenarios=list(SCENARIOS),noise=args.noise,training_n=len(historical_factors()),
        sensor_cost=SENSOR_COST, sensor_delay_base=SENSOR_DELAY_BASE,
        sensor_delay_urgency=SENSOR_DELAY_URGENCY,mc_draws=SIMULATIONS_PER_VALUE,
        note='Nessun accesso al vero shock nella decisione; ritardo come costo di servizio ridotto-forma'),indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__':main()