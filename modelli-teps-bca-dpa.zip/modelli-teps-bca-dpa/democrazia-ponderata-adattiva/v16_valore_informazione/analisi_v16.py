#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Analisi per mondo (bootstrap cluster): 12 scenari ripetuti per ciascun seed."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent

def analyze(path:Path,rep=5000,seed=1641):
    df=pd.read_csv(path/'dettaglio.csv')
    keys=['seed','scenario','noise']
    control='V16_due_sensori'
    alt='V16_valore_informazione'
    a=df[df.method==control].set_index(keys).sort_index()
    b=df[df.method==alt].set_index(keys).sort_index()
    assert a.index.equals(b.index)
    diffs=(b[['success','second_measurement','service','revote']]-a[['success','second_measurement','service','revote']])
    clusters=diffs.groupby(level='seed').mean()
    boot=np.random.default_rng(seed).choice(len(clusters),size=(rep,len(clusters)),replace=True)
    samples=clusters.to_numpy()[boot].mean(axis=1)
    means=clusters.mean().to_numpy()
    bounds=np.quantile(samples,[.025,.975],axis=0)
    result={'cluster_count':len(clusters),'comparisons_per_cluster':len(diffs)//len(clusters),
        'comparison':'V16_valore_informazione minus V16_due_sensori',
        'statistics': {col:{'difference':round(float(means[j]),5),
                  'bootstrap95':[round(float(bounds[0,j]),5),round(float(bounds[1,j]),5)]}
                       for j,col in enumerate(clusters.columns)}}
    (path/'bootstrap_mondi.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('directory',nargs='?',default=str(HERE/'validazione_indipendente'))
    args=parser.parse_args()
    print(json.dumps(analyze(Path(args.directory)),ensure_ascii=False,indent=2))
