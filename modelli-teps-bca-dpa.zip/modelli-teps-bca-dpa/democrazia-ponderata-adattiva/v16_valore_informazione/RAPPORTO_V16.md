# Rapporto V16 — Valore dell'informazione nel voto ponderato adattivo

La V16 testa una politica di monitoraggio che decide se chiedere una seconda misura in funzione del suo beneficio atteso, invece di applicare una soglia unica agli scostamenti.

## Evidenze riprodotte

- In sviluppo, **171/288** successi con seconda misura sistematica e **171/288** con misura selettiva; quest'ultima acquisisce 51 seconde misure.
- In validazione indipendente, **172/288** successi con misura sistematica e **166/288** con misura selettiva; quest'ultima acquisisce 67 seconde misure.
- Su shock doppio grave, rumore 0,08, nel holdout la verifica selettiva peggiora di **6/24** successi rispetto alla verifica sistematica.
- Il risparmio di seconde misure non dipende dall'inclusione nel decisore del guasto futuro; la posterior viene dai dati storici e dalle osservazioni.

Il test non prova superiorità generale. L'effetto sul beneficio netto deriva in parte dal costo di acquisizione e ritardo definito nello stesso simulatore. Il valore dell'informazione è un'approssimazione Monte Carlo e può essere stimato male fuori distribuzione.

## Problemi ancora aperti

1. Soglie di mandato ponderate, esplicitamente votate e differenziate per ambito; l'attuale soglia 0,50 è assunta.
2. Modello dinamico dei tempi persi per la seconda misurazione, anziché penalità ridotta-forma.
3. Informazione proveniente da sensori correlati o manipolati e test su shock mai osservati.
4. Costi di errori irreversibili, criteri di urgenza e diritti/garanzie di soggetti con bassa competenza attribuita.
5. Calibrazione dei pesi di competenza e delle funzioni di utilità su dati credibili e controlli di equità.

Vedere `README.md` per formule, file e comandi; `validazione_indipendente/bootstrap_mondi.json` per gli intervalli a livello di mondo.
