# Democrazia Ponderata Adattiva — V16

**Decisione sull'acquisizione di informazioni: agire, mantenere il piano o verificare.**

Stato: **prototipo matematico sintetico**. Non dimostra l'efficacia di una forma di governo reale. Recupera i portafogli paralleli (4 settori, 6 periodi) e il voto ponderato sui piani e sulle revisioni delle versioni V11–V15. Gli obiettivi e le metriche vengono assunti già approvati nelle simulazioni: non se ne simula un nuovo voto.

## Domanda

La conferma sistematica con due sensori aumenta il numero dei successi, ma comporta un costo. Quando conviene verificarne un secondo e quando decidere subito sulla prima misura? Un segnale rumoroso non deve innescare un intervento non autorizzato.

## Procedura

1. **Ex ante:** come in V14, i cittadini simulati approvano con voto ponderato un programma condizionale con due rami (normale e shock), aventi gli stessi interventi nei due periodi iniziali. I rischi e le preferenze sono sintetici.
2. **Osservazione:** dopo due periodi arriva il sensore A, con errore gaussiano noto solo nella simulazione. Il decisore confronta la lettura con 140 fattori di produttività di episodi storici sintetici indipendenti dai test. Si forma una distribuzione discreta:

   \[P(f_i\mid y)\propto P(y\mid f_i)P(f_i).\]

3. **Perdita prevista:** per ciascun ramo calcola il costo atteso di scostamento dai target, violazione dei vincoli e benefici intermedi perduti. Sono pesi scelti per l'esperimento, non una funzione costituzionale del benessere. Il ramo d'emergenza richiede anche evidenza di shock con probabilità posteriore almeno 0,50, altrimenti non può essere attivato: è una guardia aggiuntiva del mandato sperimentale.
4. **Decisione:** stima mediante 24 campioni *predittivi* quanto migliorerebbe la decisione con una seconda lettura. Chiama questa quantità EVSI (*expected value of sample information*):

   \[\mathrm{EVSI}=\min_a E[L(a)\mid y_A]-E_{y_B\mid y_A}\left[\min_a E[L(a)\mid y_A,y_B]\right].\]

   Se l'EVSI stimato supera il costo prefissato di misurazione e attesa, acquisisce il sensore B; in caso contrario mantiene il piano normale oppure agisce con il ramo autorizzato. Nessuna osservazione futura viene passata al calcolo della decisione prima che la misura sia richiesta.
5. **Correzione:** se il ramo selezionato sembra tecnicamente insufficiente e i dati suggeriscono uno shock plausibile, il risolutore può proporre una correzione per i periodi futuri. **La correzione deve essere approvata da un nuovo voto ponderato**; il passato è immutabile. Le compensazioni tra gruppi restano bilanciate secondo il modulo V11.
6. **Audit:** solo dopo il voto si valutano target e vincoli effettivi usando lo shock realmente simulato.

## Limiti di modellazione

- La seconda misurazione costa `0.08` unità di budget, sottratte alle stesse risorse del piano. Il suo ritardo è modellato come perdita **ridotta-forma di beneficio intermedio**, non come spostamento fisico di interventi. Il vantaggio in «tempo di reazione» non è dunque dimostrato come recuperabilità dinamica reale.
- Il costo informativo usato nell'EVSI è un'ipotesi (`0.020+0.009+0.035 P(shock)`); **non** è stato calibrato da dati reali. L'impatto del tempo sul beneficio realizzato è `0.009+0.035 × shock_reale` (solo per la valutazione), senza usare il futuro nella scelta.
- I dati storici sono generati da V14; gli scenari estremi o non rappresentati possono essere valutati male.
- Il modello V16 non modifica i voti originari su metriche e obiettivi. Non calcola consenso politico realista o diritti costituzionali, né garantisce ottimalità globale.
- Il confronto `V15_due_sensori_soglia` **riproduce la V15, che non valorizzava il costo di acquisizione della seconda misura**; è un riferimento storico favorevole alla V15, **non il controllo economico principale**.
- Il controllo accoppiato corretto `V16_due_sensori` usa **la stessa distribuzione posteriore e lo stesso costo della seconda misura** della `V16_valore_informazione`, ma la richiede sempre. L'ablazione `V16_posterior` usa la stessa logica senza sensore B.

## Metodi messi a confronto

- `V15_sensore_singolo`: discriminazione euristica con una misura, come V15.
- `V15_due_sensori_soglia`: due misure sempre e soglia fissa V15.
- `V16_posterior`: posterior storica, senza seconda misura.
- `V16_due_sensori`: posterior con due misure sempre, entrambe valorizzate come costo.
- `V16_valore_informazione`: posterior con misura aggiuntiva soltanto quando il valore stimato supera il costo.

## Campioni e risultati

Sviluppo: 24 mondi con seed 0–23. Validazione separata: 24 mondi con seed 300–323, **non utilizzati per le correzioni del modello**. Per ciascun mondo: sei scenari × due livelli di rumore (σ=0,08/0,18). Quindi 288 valutazioni per metodo in ciascuna batteria, ma solo **24 mondi statistici indipendenti** in ciascuna batteria.

| Batteria | Posterior: A | Posterior: A+B sempre | Posterior: misura selettiva | Seconde misure selettive |
|---|---:|---:|---:|---:|
| Sviluppo | 162/288 | 171/288 | 171/288 | 51/288 |
| Validazione | 153/288 | 172/288 | 166/288 | 67/288 |

Nella validazione la differenza **selettiva − verifica sistematica** è di −2,08 punti percentuali, intervallo bootstrap **per mondo** al 95% da −4,86 a +0,69 punti. Le seconde misurazioni passano da 288 a 67, differenza −76,7% dei casi (bootstrap da −81,0% a −72,6%). Il beneficio medio netto dei costi ridotti-forma della verifica è maggiore di circa 0,029 unità per episodio; questo vantaggio è in parte **costruito** attraverso i costi esplicitamente modellati e non prova un effetto empirico.

**Esito negativo da conservare:** nei 24 mondi di validazione con shock doppio grave e rumore 0,08, il metodo selettivo raggiunge 7 esiti completi contro 13 del metodo con seconda misura sistematica. Nel caso di tre guasti estremi le strategie rimangono sostanzialmente incapaci di recuperare.

La scelta selettiva è interessante per ridurre il costo dei sensori, ma non è dominante nei successi. Le regole della V16 non sono state ritarate a posteriori sui mondi di validazione.

## Riproduzione

Richiede Python 3.10+, NumPy, SciPy, pandas e Matplotlib; mantenere nella directory madre i moduli V11–V15.

```bash
python -m pip install numpy scipy pandas matplotlib
cd v16_valore_informazione
python simulazione_v16.py --test
python test_integrita_v16.py
python simulazione_v16.py --mondi 24 --seed-offset 0 --noise .08 .18 --output risultati
python simulazione_v16.py --mondi 24 --seed-offset 300 --noise .08 .18 --output validazione_indipendente
python analisi_v16.py risultati
python analisi_v16.py validazione_indipendente
python grafici_v16.py
```

File: `simulazione_v16.py` (metodo), `test_integrita_v16.py` (controlli di integrità), `analisi_v16.py` (bootstrap per mondo), `grafici_v16.py`, `risultati/` e `validazione_indipendente/` (CSV e immagini).

## Interpretazione

I dati supportano una tesi circoscritta: **misurare soltanto quando un'informazione aggiuntiva ha valore atteso superiore al suo costo può ridurre sensibilmente il numero delle misurazioni**, ma **può anche compromettere alcune decisioni urgenti**. La procedura è un elemento tecnico da inserire nel processo democratico ponderato, non sostituisce la decisione politica.
