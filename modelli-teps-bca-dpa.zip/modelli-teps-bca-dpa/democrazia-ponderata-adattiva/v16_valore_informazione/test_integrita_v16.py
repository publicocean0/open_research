#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Controlli di integrità V16, non prove di efficacia reale."""
import numpy as np
import simulazione_v16 as v

def test():
    v.test()
    risk = v.v15.trained_risk(None)
    world,prod0,policy,reason = v.v14.choose_policy(3,'V14_shock_appreso',risk,False)
    assert policy is not None and policy.weighted_vote > 0.5
    losses = v.plan_losses(policy,prod0)
    assert losses.shape == (2, 140)
    obs1=prod0.copy()
    obs2=np.clip(prod0*.6,.1,1.45)
    w=v.posterior(prod0,(obs1,),.08)
    assert np.isclose(w.sum(),1) and v.shock_probability(w) < 0.5
    choice,_=v.optimum_branch(w,losses)
    assert choice=='normal', 'Ramo di emergenza senza autorizzazione'
    first=v.choose_action(prod0,obs1,.08,losses,99,True,obs2)
    same=v.choose_action(prod0,obs1,.08,losses,99,True,obs2)
    assert first==same
    # Cambiare un dato FUTURO non fornito al decisore non cambia la scelta.
    first_no_future=v.choose_action(prod0,obs1,.08,losses,99,True,obs1)
    assert first_no_future.measured_second==first.measured_second
    assert first_no_future.expected_information_value==first.expected_information_value
    if not first.measured_second:
        assert first_no_future.branch==first.branch
    pre=np.zeros_like(policy.normal)
    pre[:v.v12.PREFIX]=policy.normal[:v.v12.PREFIX]
    for sd in (0.08,0.18):
        for sc in ('stabile','doppio_grave','rischio_non_addestrato'):
            rows=v.simulate_seed(3,sc,sd,risk,(world,prod0,policy,reason))
            assert len(rows)==len(v.METHODS)
            for row in rows:
                assert row['success'] <= row['approved']
                assert row['revote_approved'] <= row['revote']
                assert row['initial_weighted_vote'] > 0.5
                assert row['original_goals_unchanged'] == 1
                if row['method']=='V16_valore_informazione':
                    assert bool(row['second_measurement']) == (row['action']=='verifica')
                if row['method']=='V16_due_sensori':
                    assert row['second_measurement'] == 1
                if row['method']=='V16_posterior':
                    assert row['second_measurement'] == 0
    # Il costo di un secondo sensore non puo' migliorare una fattibilita' di budget.
    fee=v.v11.transfer_admin(world,policy.transfer)
    assert v.v13.actually_feasible(policy.normal,prod0,fee)
    assert v.SENSOR_COST>0 and v.SENSOR_DELAY_BASE>0
    print('OK V16: autorizzazioni, voto, posterior, riproducibilita, sensori, niente informazione futura')

if __name__=='__main__':test()
