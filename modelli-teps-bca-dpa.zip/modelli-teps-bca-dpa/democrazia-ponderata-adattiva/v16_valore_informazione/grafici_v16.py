#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Grafici di confronto V16 da dati verificati, senza simulare nuovi risultati."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent


def plot(folder:Path):
    data=pd.read_csv(folder/'riepilogo.csv')
    scenarios=['stabile','singolo','doppio_moderato','doppio_grave','rischio_non_addestrato','triplo_estremo']
    selected=data.query('noise==0.18')
    methods=['V15_due_sensori_soglia','V16_due_sensori','V16_valore_informazione']
    labels=['V15: soglia fissa','V16: verifica sempre','V16: verifica selettiva']
    fig,ax=plt.subplots(figsize=(12,5.8))
    x=np.arange(len(scenarios));w=.25
    for j,method in enumerate(methods):
        numbers=[int(selected[(selected.scenario==s)&(selected.method==method)].success.iloc[0]) for s in scenarios]
        ax.bar(x+(j-1)*w,numbers,w,label=labels[j])
    ax.set_xticks(x, ['Stabile','Guasto singolo','Due moderati','Due gravi','Rischio nuovo','Tre estremi'],rotation=12)
    ax.set_ylim(0,25)
    ax.set_ylabel('Successi completi su 24 mondi')
    ax.set_title('V16: confronto fuori campione, rumore σ=0,18')
    ax.legend(fontsize=9)
    ax.grid(axis='y',alpha=.19)
    fig.tight_layout()
    fig.savefig(folder/'successi_v16.png',dpi=175)
    plt.close(fig)

    fig,ax=plt.subplots(figsize=(9,5.2))
    all_n=data.groupby('method')[['measurements','success']].sum()
    keys=['V16_posterior','V16_due_sensori','V16_valore_informazione']
    x=np.arange(len(keys));y=all_n.loc[keys,'measurements'].values
    rect=ax.bar(x,y,width=.52)
    ax.set_xticks(x,['Solo sensore A','Secondo sempre','Secondo se utile'])
    ax.set_ylim(0,315)
    ax.set_ylabel('Seconde misure acquisite, su 288 valutazioni')
    ax.set_title('V16: costo informativo, validazione indipendente')
    for item,value in zip(rect,y):
        ax.annotate(str(value),(item.get_x()+item.get_width()/2,value),ha='center',va='bottom',xytext=(0,4),textcoords='offset points')
    ax.grid(axis='y',alpha=.19)
    fig.tight_layout()
    fig.savefig(folder/'misurazioni_v16.png',dpi=175)
    plt.close(fig)

if __name__=='__main__':
    plot(HERE/'validazione_indipendente')
    plot(HERE/'risultati')
