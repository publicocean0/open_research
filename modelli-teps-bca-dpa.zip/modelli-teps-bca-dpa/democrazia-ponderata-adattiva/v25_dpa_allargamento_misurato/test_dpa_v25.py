# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test DPA V25. Esecuzione: python test_dpa_v25.py"""
import numpy as np

import simulazione_dpa_v25 as s


def test_indice_autoattribuzione():
    zona = np.repeat(np.arange(4), 100)
    equa = np.full(4, 0.25)
    assert abs(s.indice_autoattribuzione(zona, equa, np.arange(100))) < 1e-12
    sbilanciata = np.array([0.55, 0.15, 0.15, 0.15])
    assert s.indice_autoattribuzione(zona, sbilanciata, np.arange(100)) > 0.5      # vota la zona 0
    assert s.indice_autoattribuzione(zona, sbilanciata, np.arange(100, 400)) < 0   # votano le altre


def test_ripartizione_media_pesata():
    zona = np.array([0, 0, 1, 2])
    a = s.ripartizione(zona, np.array([0, 1]), np.ones(2))
    assert abs(a.sum() - 1) < 1e-12 and a[0] == a.max()


def test_test_di_permutazione():
    rng = np.random.default_rng(0)
    zona = np.repeat(np.arange(4), 150)
    alloc = np.array([0.55, 0.15, 0.15, 0.15])
    _, p_conc = s.test_autoattribuzione(zona, alloc, np.arange(101), rng)
    assert p_conc < s.LIVELLO_TEST
    _, p_casuale = s.test_autoattribuzione(zona, np.full(4, 0.25), rng.choice(600, 101, replace=False), rng)
    assert p_casuale > s.LIVELLO_TEST


def test_allargamento_orizzontale_usa_discipline_vicine():
    md, Cstar = s.prepara(2525, 0, "base", "concentrate")
    assert Cstar.shape[1] == len(s.DISCIPLINE)
    assert np.all(s.RILEVANZA_VICINA[:, :4] == 0) and np.allclose(s.RILEVANZA_VICINA.sum(1), 1)
    r = {x["regime"]: x for x in s.esegui_mondo(2525, 0, "base", "concentrate")}
    if r["v25_misurato"]["allargamento_scattato"]:
        assert r["v25_misurato"]["ia_dopo"] < r["v25_misurato"]["ia_prima"]


def test_determinismo():
    assert s.esegui_mondo(2525, 1, "shock", "diffuse") == s.esegui_mondo(2525, 1, "shock", "diffuse")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK", t.__name__)
    print(f"OK DPA V25: {len(tests)} test superati")
