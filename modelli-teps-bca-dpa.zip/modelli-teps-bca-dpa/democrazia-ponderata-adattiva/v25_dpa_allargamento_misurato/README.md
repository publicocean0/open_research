# Democrazia Ponderata Adattiva — V25 (allargamento in base a ciò che si misura)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra
l'efficacia di un ordinamento reale.

## La regola

Il tipo di allargamento della base dipende da **ciò che si misura**:

| Cosa si misura | Problema | Allargamento (automatico) |
|---|---|---|
| Troppo pochi voti espressi | base troppo piccola | **verticale**: si scende nella graduatoria della stessa competenza (D-15 della TEPS) |
| Gli effetti della decisione si concentrano su chi l'ha votata | autoattribuzione | **orizzontale**: entrano i competenti delle discipline vicine, fissate prima per ogni questione |

Scendere nella stessa graduatoria quando il problema è il conflitto di
interessi rischierebbe di portare dentro altre persone dello stesso gruppo.
Entrambe le regole sono pubbliche, automatiche e uguali per tutti: nessuno
sceglie caso per caso chi aggiungere.

Il resto è come nella V24: tutte le questioni tematiche, obiettivi compresi,
votate solo dai competenti sopra soglia; competenze certificate da agenti IA;
voto eguale solo sui diritti universali; base senza tetto con N_min = 101 come
pavimento; dinamica con monitoraggio.

## Come si misura l'autoattribuzione

- Oltre agli obiettivi si vota la **ripartizione dell'investimento fra 4 zone**.
  Ogni persona risiede in una zona (registro pubblico) e tende a favorire la
  propria: ripartizione preferita = 0,15 a ogni zona + 0,40 alla propria.
  L'esito è la media pesata dei voti (regola TEPS).
- **Indice di autoattribuzione (IA):** beneficio medio di chi ha votato meno
  beneficio medio di chi non ha votato. Il beneficio di una persona è la quota
  andata alla sua zona divisa per la quota di popolazione della zona
  (1 = parte proporzionale).
- Servono solo il **registro di partecipazione** (chi ha votato, già previsto
  dalla TEPS §11.3) e la **ripartizione decisa**. Non servono né il contenuto
  dei voti né le preferenze delle persone.
- **Quando scatta:** test statistico. L'IA osservato si confronta con quello di
  500 elettorati estratti a caso della stessa dimensione; l'allargamento scatta
  se l'elettorato reale supera il 95% degli elettorati casuali.

**Tentativo abbandonato.** La prima regola era una soglia fissa (IA > 0,30),
scelta prima di vedere i risultati: non scattava mai, perché l'IA massimo
osservato è circa 0,18. Invece di abbassarla guardando i risultati, l'ho
sostituita con il test statistico, che non dipende da soglie tarate.

## Mondi e regimi

- **Competenze concentrate:** come in V21–V24, la competenza tecnica è quasi
  tutta nei tecnici (15% delle persone), che vivono per l'80% nella zona 0.
- **Competenze diffuse:** stessa distribuzione, assegnata a caso fra tutti.
- Due discipline vicine nuove, urbanistica e politiche sociali, le cui
  competenze stanno fra maggioranza e minoranza, non fra i tecnici.
- Regimi: tutti a voto eguale; V23 (obiettivi a voto eguale); V24 (tutto per
  competenza, nessun controllo); V25 verticale (se scatta il test, si scende
  nella stessa graduatoria triplicando la base); **V25 misurato** (se scatta il
  test, allargamento orizzontale alle discipline vicine).

## Risultati (200 mondi per scenario)

Scenario base:

| Regime | Competenze | Zona 0 / parte proporzionale | Benessere maggioranza | Divario fra gruppi | Votanti per obiettivo | Test positivo |
|---|---|---:|---:|---:|---:|---:|
| V23, obiettivi a voto eguale | concentrate | 0,84 | −28,45 | 17,2 | 600 | — |
| V24, nessun controllo | concentrate | **1,29** | −34,18 | 24,6 | 101 | 100% |
| V25 verticale | concentrate | 1,00 | −30,36 | 20,1 | 303 | 100% |
| **V25 misurato (orizzontale)** | concentrate | **1,01** | **−30,50** | 20,3 | **202** | 100% |
| V24, nessun controllo | diffuse | 0,84 | −28,50 | 17,3 | 101 | 14% |
| V25 misurato | diffuse | 0,85 | −28,54 | 17,3 | 115 | 14% |

Differenze accoppiate (IC bootstrap 95%), competenze concentrate, base:

| Confronto | Benessere maggioranza | Gruppo più svantaggiato | Divario fra gruppi |
|---|---|---|---|
| V25 misurato − V24 | **+3,68 [+3,53, +3,82]** | +3,69 [+3,53, +3,85] | −4,33 [−4,52, −4,15] |
| V25 misurato − V25 verticale | −0,14 [−0,24, −0,04] | −0,14 [−0,25, −0,03] | +0,17 [+0,04, +0,31] |
| V25 misurato − V23 | −2,05 [−2,14, −1,96] | −1,10 [−1,30, −0,91] | +3,11 [+2,90, +3,31] |

La fattibilità dei piani non cambia fra i regimi DPA (95% circa nella base).

## Cosa mostrano i numeri

1. **La misura funziona.** Con competenze concentrate l'elettorato si
   attribuisce il 29% in più della sua parte e il test se ne accorge sempre.
   Con l'allargamento orizzontale la ripartizione torna proporzionale e la
   maggioranza recupera 3,7 punti di benessere, circa due terzi di quanto
   perdeva rispetto al voto eguale sugli obiettivi.
2. **Orizzontale contro verticale.** In questo mondo funzionano quasi uguali,
   ma l'orizzontale ci arriva con 202 votanti invece di 303 e senza abbassare la
   soglia di competenza. Il verticale funziona qui solo perché il gruppo in
   conflitto è piccolo (15%): scendendo in graduatoria si esce presto dal
   gruppo. Con un gruppo in conflitto grande non funzionerebbe, ma questo caso
   non è ancora stato provato.
3. **Con competenze diffuse non serve e non fa danni**: il benessere non cambia.
4. **Falsi allarmi più alti del previsto: 10–20% invece del 5%.** Qualunque
   elettorato, anche casuale, tende a favorire le proprie zone; il confronto con
   elettorati casuali a ripartizione fissa non ne tiene conto. Il costo è basso:
   la base cresce del 15–25%, senza effetti sul benessere. Va comunque corretto.

## Limiti e prossimi passi

- **Correggere il test** perché i falsi allarmi scendano al livello dichiarato.
- **Gruppo in conflitto grande** (per esempio il 35–40% dei competenti), dove la
  differenza fra verticale e orizzontale dovrebbe vedersi davvero.
- La ripartizione fra zone è un esempio semplice di "azioni verso un gruppo"; i
  benefici indiretti, come il valore delle case vicino a un'opera, non sono
  modellati.
- Prestanome: chi non vota ma è legato a chi vota non è considerato.

## File e riproduzione

- `simulazione_dpa_v25.py` — zone, discipline vicine, indice e test di
  autoattribuzione, allargamenti, regimi. Usa V21–V23.
- `test_dpa_v25.py` — 5 test.
- `risultati/` — `dettaglio.csv`, `riepilogo.csv`, `confronti_accoppiati.csv`,
  `parametri.json`.

```bash
cd democrazia-ponderata-adattiva/v25_dpa_allargamento_misurato
python -m pip install -r requirements.txt
python test_dpa_v25.py
python simulazione_dpa_v25.py --mondi 200
```

Circa tre minuti e mezzo su una CPU.
