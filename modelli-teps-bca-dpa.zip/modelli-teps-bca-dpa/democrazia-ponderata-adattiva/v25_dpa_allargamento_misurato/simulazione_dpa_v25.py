# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DPA V25 — allargamento della base in base a cio' che si misura.

Due misure, due allargamenti diversi, entrambi automatici e fissati prima:

* **troppo pochi voti espressi** -> allargamento **verticale**: si scende nella
  graduatoria della stessa competenza (D-15 della TEPS);
* **autoattribuzione**: gli effetti degli obiettivi votati si concentrano su chi
  li ha votati -> allargamento **orizzontale**: entrano i competenti delle
  discipline vicine (mappa fissata prima per ogni questione).

Questione di ripartizione: oltre agli obiettivi si vota come ripartire
l'investimento fra 4 zone; ogni persona risiede in una zona (registro
pubblico) e tende a favorire la propria. Indice di autoattribuzione (IA):
beneficio medio di chi ha votato meno beneficio medio di chi non ha votato,
dove il beneficio di una persona e' la quota assegnata alla sua zona divisa per
la quota di popolazione della zona (1 = parte proporzionale). Usa solo il
registro di partecipazione (chi ha votato) e la ripartizione decisa, non il
contenuto dei voti ne' le preferenze.

Quando scatta: test di permutazione. L'IA osservato si confronta con quello di
500 elettorati estratti a caso della stessa dimensione (stessa ripartizione);
l'allargamento scatta se l'elettorato reale supera il 95% degli elettorati
casuali (falsi allarmi attesi: 5%). Nessuna soglia tarata sui risultati.
Una prima soglia fissa (IA > 0,30) non scattava mai: e' riportata nel README.

Come in V24: tutte le questioni tematiche per competenza (certificata da agenti
IA), voto eguale solo sui diritti universali, base senza tetto con N_min come
pavimento. Due discipline sociali in piu' (urbanistica, politiche sociali), le
cui competenze stanno in gruppi diversi da quelli dei tecnici.

Simulazione su popolazioni sintetiche: non e' una prova su ordinamenti reali.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np

QUI = Path(__file__).resolve().parent
for c in ("v21_dpa_raffinata", "v22_dpa_dinamica_tematica", "v23_dpa_premesse_teps"):
    sys.path.insert(0, str(QUI.parent / c))
import simulazione_v21 as d21  # noqa: E402
import simulazione_dpa_v22 as d22  # noqa: E402
import simulazione_dpa_v23 as d23  # noqa: E402
from simulazione_v21 import mediana_pesata  # noqa: E402

PERIODI = d22.PERIODI
N_MIN = d23.N_MIN
SOGLIA_IA_INIZIALE = 0.30      # primo tentativo, abbandonato (vedi README)
PERMUTAZIONI = 500
LIVELLO_TEST = 0.05
ZONE = 4
QUOTA_PROPRIA_ZONA = 0.40       # ripartizione preferita: 0,15 a ogni zona + 0,40 alla propria
DISCIPLINE = ("acqua", "trasporti", "bilancio", "ambiente", "urbanistica", "politiche_sociali")
# competenza rilevante per ciascun obiettivo (abitazioni, rete idrica, trasporti)
RILEVANZA_PRIMARIA = np.hstack([d23.RILEVANZA_OBIETTIVI, np.zeros((3, 2))])
# discipline vicine, usate solo per l'allargamento orizzontale (fissate prima)
RILEVANZA_VICINA = np.array([[0, 0, 0, 0, .5, .5],
                             [0, 0, 0, 0, .3, .7],
                             [0, 0, 0, 0, .7, .3]])
SCENARI = ("base", "esperti_corrotti", "shock")
DISTRIBUZIONI = ("concentrate", "diffuse")
REGIMI = ("uguale_tutti", "dpa_v23_obiettivi_eguali", "dpa_v24", "v25_verticale", "v25_misurato")


# ---------------------------------------------------------------------------
# Popolazione con competenze sociali e certificazione IA
# ---------------------------------------------------------------------------
def certifica(c_vera, rng):
    """Cinque agenti IA isolati; C* = mediana - MAD (TEPS par. 12.1)."""
    n, d = c_vera.shape
    formazione = np.clip(c_vera + rng.normal(0, 0.15, (n, d)), 0, 1)
    esperienza = np.clip(c_vera + rng.normal(0, 0.15, (n, d)), 0, 1)
    v = np.clip((0.5 * formazione + 0.5 * esperienza)[None]
                + rng.normal(0, d23.RUMORE_AGENTI, (d23.AGENTI, n, d)), 0, 1)
    med = np.median(v, 0)
    return np.clip(med - d23.LAMBDA_MAD * np.median(np.abs(v - med[None]), 0), 0, 1)


def prepara(seed, indice, scenario, distribuzione):
    md = d22.MondoDinamico(seed, indice, scenario)
    pop = md.pop
    rng = np.random.default_rng([seed, indice, 2500 + SCENARI.index(scenario), DISTRIBUZIONI.index(distribuzione)])
    # competenze sociali: professionisti in maggioranza e minoranza, non fra i tecnici
    c_soc = rng.beta(2, 4, (pop.n, 2))
    prof = (pop.gruppo != "tecnico") & (rng.random(pop.n) < 0.20)
    c_soc[prof] = rng.beta(5, 2, (prof.sum(), 2))
    if distribuzione == "diffuse":
        perm = rng.permutation(pop.n)
        for attr in ("c_vera", "c_cert", "allentamento_b", "corrotto"):
            setattr(pop, attr, getattr(pop, attr)[perm].copy())
        c_soc = c_soc[rng.permutation(pop.n)]
    if scenario == "esperti_corrotti":
        pop.gruppo = pop.gruppo.copy()
        pop.gruppo[pop.corrotto] = "corrotti"
    Cstar = certifica(np.hstack([pop.c_vera, c_soc]), rng)
    # zona di residenza: i tecnici vivono per lo piu' nella zona 0; le competenze
    # seguono le persone, quindi nel mondo "diffuse" non c'e' legame zona-competenza
    zona_rng = np.random.default_rng([seed, indice, 77])
    zona = zona_rng.integers(0, ZONE, pop.n)
    tecnici = np.where(pop.gruppo == "tecnico")[0] if scenario != "esperti_corrotti" else \
        np.where(np.isin(pop.gruppo, ["tecnico", "corrotti"]))[0]
    zona[tecnici[zona_rng.random(len(tecnici)) < 0.8]] = 0
    md.zona = zona
    return md, Cstar


# ---------------------------------------------------------------------------
# Voto sugli obiettivi con allargamento misurato
# ---------------------------------------------------------------------------
def ripartizione(zona, idx, w):
    """Esito TEPS: media pesata delle ripartizioni preferite dai votanti."""
    pref = np.full((len(idx), ZONE), (1 - QUOTA_PROPRIA_ZONA) / ZONE)
    pref[np.arange(len(idx)), zona[idx]] += QUOTA_PROPRIA_ZONA
    return (w[:, None] * pref).sum(0) / w.sum()


def indice_autoattribuzione(zona, alloc, votanti):
    quota_pop = np.bincount(zona, minlength=ZONE) / len(zona)
    beneficio = alloc[zona] / quota_pop[zona]
    dentro = np.zeros(len(zona), bool)
    dentro[votanti] = True
    if dentro.all() or not dentro.any():
        return 0.0
    return float(beneficio[dentro].mean() - beneficio[~dentro].mean())


def test_autoattribuzione(zona, alloc, votanti, rng):
    """p-value: quota di elettorati casuali della stessa dimensione con IA >= osservato."""
    oss = indice_autoattribuzione(zona, alloc, votanti)
    n, k = len(zona), len(np.unique(votanti))
    nulli = np.array([indice_autoattribuzione(zona, alloc, rng.choice(n, k, replace=False))
                      for _ in range(PERMUTAZIONI)])
    return oss, float((1 + (nulli >= oss).sum()) / (1 + PERMUTAZIONI))


def vota_obiettivi(pop, zona, Cstar, rng, regime):
    """Restituisce obiettivi, ripartizione, votanti, IA iniziale e finale, allargamento."""
    n = pop.n
    if regime in ("uguale_tutti", "dpa_v23_obiettivi_eguali"):
        tau = np.array([mediana_pesata(pop.ideale[:, j], np.ones(n)) for j in range(3)])
        return tau, ripartizione(zona, np.arange(n), np.ones(n)), np.arange(n), 0.0, 0.0, "nessuno", n
    elettorati = []
    for j in range(3):
        idx, w, _, _ = d23.convoca(Cstar @ RILEVANZA_PRIMARIA[j], np.zeros(n, bool), rng, N_MIN)
        elettorati.append((idx, w))

    def esito(el):
        tau = np.array([mediana_pesata(pop.ideale[idx, j], w) for j, (idx, w) in enumerate(el)])
        votanti = np.unique(np.concatenate([idx for idx, _ in el]))
        # la ripartizione fra zone la vota l'elettorato delle abitazioni
        return tau, ripartizione(zona, *el[0]), votanti

    tau, alloc, votanti = esito(elettorati)
    ia0, p0 = test_autoattribuzione(zona, alloc, elettorati[0][0], rng)
    allargamento = "nessuno"
    if regime != "dpa_v24" and p0 < LIVELLO_TEST:
        nuovi = []
        for j, (idx, w) in enumerate(elettorati):
            gia = np.zeros(n, bool)
            gia[idx] = True
            if regime == "v25_verticale":
                # stessa competenza, base tripla: si scende nella stessa graduatoria
                idx2, w2, _, _ = d23.convoca(Cstar @ RILEVANZA_PRIMARIA[j], gia, rng, 2 * N_MIN)
                allargamento = "verticale"
            else:
                # competenti delle discipline vicine
                idx2, w2, _, _ = d23.convoca(Cstar @ RILEVANZA_VICINA[j], gia, rng, N_MIN)
                allargamento = "orizzontale"
            nuovi.append((np.r_[idx, idx2], np.r_[w, w2]))
        elettorati = nuovi
        tau, alloc, votanti = esito(elettorati)
    ia1 = indice_autoattribuzione(zona, alloc, elettorati[0][0])
    dim = float(np.mean([len(idx) for idx, _ in elettorati]))
    allargamento = allargamento if allargamento != "nessuno" or p0 >= LIVELLO_TEST else "segnalato"
    return tau, alloc, votanti, ia0, ia1, allargamento, dim


def esegui_regime(md, regime, Cstar, seed_voto):
    pop = md.pop
    n = pop.n
    rng = np.random.default_rng(seed_voto)
    t_min = md.m.t_min if md.diritto else None
    x = d22.STATO_INIZIALE.copy()
    b_cert = np.zeros(4)
    dinamico = regime != "uguale_tutti"
    righe_t = []
    tau_obj = None
    info = {}
    for t in range(PERIODI):
        if dinamico and t > 1:
            b_oss = md.b[t - 1] + md.monitor[t - 1]
            vincoli = [k for k in range(4) if abs(b_oss[k] - (b_cert[k] + d22.MARGINE)) > d22.SOGLIA_RIVOTO]
        else:
            vincoli = list(range(4))
        stime = md.stime(t)
        for k in vincoli:
            if regime == "uguale_tutti":
                idx, w = np.arange(n), np.ones(n)
            else:
                idx, w, _, _ = d23.convoca(Cstar[:, k], np.zeros(n, bool), rng, N_MIN)
            b_cert[k] = mediana_pesata(stime[idx, k], w) - d22.MARGINE
        if t == 0 or not dinamico:
            tau_obj, alloc, votanti, ia0, ia1, allarg, dim = vota_obiettivi(pop, md.zona, Cstar, rng, regime)
            if t == 0:
                quota_pop = np.bincount(md.zona, minlength=ZONE) / n
                rapporto = alloc / quota_pop
                info = {"ia_prima": ia0, "ia_dopo": ia1, "test_positivo": int(allarg != "nessuno"),
                        "allargamento_scattato": int(allarg in ("verticale", "orizzontale")),
                        "votanti_obiettivi": dim,
                        "quota_tecnici_votanti_obiettivi": float((pop.gruppo[votanti] == "tecnico").mean()),
                        "zona0_su_quota_equa": float(rapporto[0]),
                        "scarto_max_ripartizione": float(np.abs(rapporto - 1).max()),
                        "beneficio_peggior_zona": float(rapporto.min())}
        x, _ = d22.piano(tau_obj, np.ones(3), md.A, b_cert, x, t_min)
        g = md.A @ x - md.b[t]
        pref = d21.preferenza(pop, x[None, :])[:, 0]
        gruppi = np.unique(pop.gruppo)
        medie = [pref[pop.gruppo == gn].mean() for gn in gruppi]
        righe_t.append({"fattibile": float(np.max(g) <= 1e-9), "benessere": float(pref.mean()),
                        "benessere_maggioranza": float(pref[pop.gruppo == "maggioranza"].mean()),
                        "benessere_minoranza": float(pref[pop.gruppo == "minoranza"].mean()),
                        "peggior_gruppo": float(min(medie)), "divario_gruppi": float(max(medie) - min(medie))})
    media = {k: float(np.mean([r[k] for r in righe_t])) for k in righe_t[0]}
    media.update(info)
    return media


def esegui_mondo(seed, indice, scenario, distribuzione):
    md, Cstar = prepara(seed, indice, scenario, distribuzione)
    return [{"mondo": indice, "scenario": scenario, "competenze": distribuzione, "regime": reg,
             **esegui_regime(md, reg, Cstar, [seed, indice, 9, i])} for i, reg in enumerate(REGIMI)]


METRICHE = ("fattibile", "benessere", "benessere_maggioranza", "benessere_minoranza", "peggior_gruppo",
            "divario_gruppi", "ia_prima", "ia_dopo", "test_positivo", "allargamento_scattato", "votanti_obiettivi",
            "quota_tecnici_votanti_obiettivi", "zona0_su_quota_equa", "scarto_max_ripartizione",
            "beneficio_peggior_zona")


def riepiloga(righe, seed):
    rng = np.random.default_rng([seed, 25])
    rie, conf = [], []
    for dist in DISTRIBUZIONI:
        for s in SCENARI:
            per = {g: [r for r in righe if r["competenze"] == dist and r["scenario"] == s and r["regime"] == g]
                   for g in REGIMI}
            for g, rr in per.items():
                out = {"competenze": dist, "scenario": s, "regime": g, "mondi": len(rr)}
                for k in METRICHE:
                    v = np.array([r[k] for r in rr], float)
                    mu, lo, hi = d21.ic_bootstrap(v, rng, 2000)
                    out.update({k: mu, k + "_ic_basso": lo, k + "_ic_alto": hi})
                rie.append(out)
            for a, b in (("v25_misurato", "dpa_v24"), ("v25_misurato", "v25_verticale"),
                         ("v25_misurato", "dpa_v23_obiettivi_eguali"), ("v25_verticale", "dpa_v24")):
                ref = {r["mondo"]: r for r in per[b]}
                for k in ("fattibile", "benessere", "benessere_maggioranza", "benessere_minoranza",
                          "peggior_gruppo", "divario_gruppi", "ia_dopo", "scarto_max_ripartizione",
                          "beneficio_peggior_zona"):
                    d = [r[k] - ref[r["mondo"]][k] for r in per[a]]
                    mu, lo, hi = d21.ic_bootstrap(np.array(d), rng, 2000)
                    conf.append({"competenze": dist, "scenario": s, "confronto": f"{a} - {b}", "metrica": k,
                                 "differenza": mu, "ic95_basso": lo, "ic95_alto": hi})
    return rie, conf


def main():
    ap = argparse.ArgumentParser(description="DPA V25: allargamento in base a cio' che si misura")
    ap.add_argument("--mondi", type=int, default=200)
    ap.add_argument("--seed", type=int, default=2525)
    ap.add_argument("--output", type=Path, default=QUI / "risultati")
    ap.add_argument("--test", action="store_true")
    a = ap.parse_args()
    mondi = 3 if a.test else a.mondi
    righe = [r for dist in DISTRIBUZIONI for s in SCENARI for i in range(mondi)
             for r in esegui_mondo(a.seed, i, s, dist)]
    rie, conf = riepiloga(righe, a.seed)
    a.output.mkdir(parents=True, exist_ok=True)
    d21.scrivi_csv(a.output / "dettaglio.csv", righe)
    d21.scrivi_csv(a.output / "riepilogo.csv", rie)
    d21.scrivi_csv(a.output / "confronti_accoppiati.csv", conf)
    (a.output / "parametri.json").write_text(json.dumps({
        "mondi": mondi, "seed": a.seed, "soglia_ia_iniziale_abbandonata": SOGLIA_IA_INIZIALE,
        "permutazioni": PERMUTAZIONI, "livello_test": LIVELLO_TEST, "n_min": N_MIN, "tau0": d23.TAU0,
        "w_max": d23.W_MAX, "zone": ZONE, "quota_propria_zona": QUOTA_PROPRIA_ZONA, "discipline": DISCIPLINE, "rilevanza_primaria": RILEVANZA_PRIMARIA.tolist(),
        "rilevanza_vicina": RILEVANZA_VICINA.tolist(), "regimi": REGIMI, "scenari": SCENARI,
        "distribuzioni": DISTRIBUZIONI}, indent=2, ensure_ascii=False), encoding="utf-8")
    for r in rie:
        print(f"{r['competenze']:11s} {r['scenario']:16s} {r['regime']:25s} fatt={r['fattibile']:.3f} "
              f"ben={r['benessere']:.2f} magg={r['benessere_maggioranza']:.2f} min={r['benessere_minoranza']:.2f} "
              f"pegg={r['peggior_gruppo']:.2f} div={r['divario_gruppi']:.2f} ia0={r['ia_prima']:.2f} "
              f"ia1={r['ia_dopo']:.2f} test={r['test_positivo']:.2f} scatta={r['allargamento_scattato']:.2f} vot={r['votanti_obiettivi']:.0f} "
              f"tec={r['quota_tecnici_votanti_obiettivi']:.2f} z0={r['zona0_su_quota_equa']:.2f} "
              f"scarto={r['scarto_max_ripartizione']:.2f}")


if __name__ == "__main__":
    main()
