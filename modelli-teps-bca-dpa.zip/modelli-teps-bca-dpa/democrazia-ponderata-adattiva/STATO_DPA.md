# Stato della DPA (9 novembre 2026)

Sintesi di ciò che le simulazioni mostrano e di ciò che non mostrano.
**Tutti i risultati sono sintetici**: popolazioni e mondi generati al computer
con regole scelte dall'autore.

## Configurazione consolidata (V23–V27)

- **Competenze riconosciute** da formazione ed esperienza lavorativa, certificate
  da più agenti IA isolati (mediana meno dispersione).
- **Voto indirizzato per competenza** su vincoli e obiettivi: vota chi supera la
  soglia di competenza rilevante per quella questione; peso con tetto
  `w_max = 3`; sotto soglia non si vota quel tema.
- **Diritti universali a voto eguale.**
- **Base minima** con allargamento automatico: **verticale** se mancano votanti
  (D-15), **orizzontale** alle discipline vicine se gli effetti della decisione
  si concentrano su chi l'ha votata (test di autoattribuzione da registri
  pubblici).
- **Dinamica**: monitoraggio dei limiti reali, rivoto mirato, inerzia dei piani.
- **Variante**: storico delle previsioni (chi stima male perde peso sulle
  questioni di misura).

## Cosa mostrano le simulazioni

| Risultato | Dove |
|---|---|
| Votare i vincoli fra competenti: piani davvero fattibili dal ~61% al ~96% (se chi non è esperto ha un errore sistematico comune; altrimenti +3 punti) | V22–V23 |
| Lo storico delle previsioni toglie peso agli esperti corrotti (fattibilità dal 77% al 92%) | V22–V23 |
| Gli agenti IA reggono finché meno di metà è ingannata | V23 |
| Il tetto ai pesi e il voto eguale sui diritti impediscono ribaltamenti a danno delle minoranze | V21 |
| Votare gli obiettivi per competenza dà lo stesso esito del voto eguale se le competenze sono diffuse fra gruppi con interessi diversi | V24 |
| Il test di autoattribuzione rileva i casi di interesse, con falsi allarmi al 5–7% | V25–V26 |
| A parità di persone aggiunte, l'allargamento orizzontale supera il verticale, soprattutto con un gruppo in conflitto grande | V26 |
| Quando i competenti si discostano per conoscenza di conseguenze che contano, votare per competenza dà risultati reali migliori del voto eguale, anche per la maggioranza; il controllo non blocca la conoscenza | V27 |

## Cosa non è dimostrato

- Nessuna verifica su dati o istituzioni reali.
- L'esistenza e l'entità dell'errore sistematico dei non esperti, e la gravità
  delle conseguenze che solo i competenti vedono: da questi due numeri dipende
  quanto convenga la DPA rispetto al voto eguale, e vanno misurati.
- Comportamento strategico realistico (coalizioni, prestanome, manipolazione
  coordinata degli agenti IA), legittimità e accettazione sociale.
- Mandati condizionali e riserve (V8–V16) non sono ancora riportati sulle
  regole V23–V27.

## Qualità del materiale

- Ogni versione ha codice, test automatici, risultati per mondo, riepiloghi con
  intervalli bootstrap, parametri e un README con limiti ed esiti negativi.
- Le esecuzioni sono deterministiche con semi fissati.
- Gli errori trovati lungo il percorso sono corretti in versioni nuove e
  documentati, senza riscrivere le versioni precedenti.

## Passo successivo

Un **caso pilota piccolo e delimitato**: una decisione tecnica locale con
competenze certificabili, per misurare l'errore dei non esperti e la qualità
delle stime degli esperti.
