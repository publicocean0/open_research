# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test DPA V27. Esecuzione: python test_dpa_v27.py"""
import numpy as np

import simulazione_dpa_v27 as s


def test_solo_conoscenza():
    md, Cstar, voto, zona, quota = s.prepara(2727, 0, "solo_conoscenza", "concentrate")
    tec = md.pop.gruppo == "tecnico"
    magg = md.pop.gruppo == "maggioranza"
    # stessi desideri, ma i competenti votano meno abitazioni perche' conoscono le conseguenze
    assert abs(md.pop.ideale[tec, 0].mean() - md.pop.ideale[magg, 0].mean()) < 0.6
    assert voto[tec, 0].mean() < voto[magg, 0].mean() - 0.5
    assert quota == 0.0


def test_ripartizione_neutrale_proporzionale():
    zona = np.r_[np.zeros(100, int), np.ones(300, int), np.full(200, 2), np.full(0, 3)]
    a = s.ripartizione(zona, np.arange(600), np.ones(600), 0.0)
    assert np.allclose(a, np.bincount(zona, minlength=s.ZONE) / 600)


def test_conseguenza_nascosta():
    md, Cstar, voto, zona, quota = s.prepara(2727, 1, "solo_conoscenza", "concentrate")
    r = s.esegui_regime(md, Cstar, voto, zona, quota, "uguale_tutti", [1])
    assert r["capacita_idrica_persa"] > 0


def test_controllo_non_scatta_senza_interesse():
    for i in range(12):
        for reg in s.esegui_mondo(2727, i, "solo_conoscenza", "concentrate"):
            if reg["regime"] == "dpa_v26_controllo":
                assert reg["test_scattato"] == 0


def test_determinismo():
    assert s.esegui_mondo(2727, 2, "conoscenza_e_interesse", "diffuse") == \
        s.esegui_mondo(2727, 2, "conoscenza_e_interesse", "diffuse")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK", t.__name__)
    print(f"OK DPA V27: {len(tests)} test superati")
