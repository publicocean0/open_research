# Democrazia Ponderata Adattiva — V27 (conoscenza o interesse?)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra
l'efficacia di un ordinamento reale.

## La domanda

È normale che il gruppo competente voglia cose diverse dalla base. Ma perché?

- **Conoscenza:** sa cose che gli altri non sanno. Questa differenza è
  legittima: è il motivo per cui si vota per competenza.
- **Interesse:** vuole cose che convengono alla propria posizione. Qui la
  competenza non rende la scelta più giusta.

Nelle versioni precedenti le preferenze dei competenti erano fissate a caso e il
"benessere" misurava solo quanto il piano soddisfa i desideri attuali. Così ogni
scostamento dalla maggioranza contava come una perdita, anche se dovuto alla
conoscenza. La V27 separa i due casi e valuta i piani sulle **conseguenze reali**.

## Come è costruita

- **Conseguenza nascosta:** costruire abitazioni oltre un livello sicuro (5)
  consuma la capacità idrica nei periodi successivi (0,30 per unità in eccesso
  per periodo). La capacità persa danneggia tutti, in ogni periodo successivo
  (**danno da scarsità**: 0, 2 o 5 per unità persa; tre livelli fissati prima,
  perché nella realtà l'intensità va misurata).
- **Conoscenza:** chi è competente in acqua o urbanistica conosce la conseguenza
  e vota meno abitazioni, in proporzione a ciò che sa.
- **Interesse:** preferenze di gruppo proprie e preferenza per la propria zona
  nella ripartizione dell'investimento.
- **Scenari:** `solo_conoscenza` (i competenti hanno gli stessi desideri della
  maggioranza e nessuna preferenza per la propria zona) e
  `conoscenza_e_interesse`.
- **Valutazione in 20 periodi:** servizi ottenuti rispetto ai desideri, danni da
  limiti superati (ora con un costo proporzionale allo sforamento), danno da
  scarsità.
- **Correzioni rispetto alla V26:** chi non ha interessi propri vuole una
  ripartizione proporzionale alla popolazione delle zone (prima uniforme per
  zona, che favoriva le zone piccole anche senza interessi); il test di
  autoattribuzione ha una tolleranza per gli arrotondamenti.
- **Regimi:** tutti a voto eguale; V23 (obiettivi a voto eguale); V24 (tutto per
  competenza); V26 (tutto per competenza + controllo di autoattribuzione con
  allargamento orizzontale).

## Risultati (200 mondi per scenario)

Benessere realizzato in 20 periodi: tutto per competenza (V24) − obiettivi a voto
eguale (V23). Positivo = votare per competenza dà risultati migliori.
Intervalli bootstrap al 95%.

**Solo conoscenza**

| Danno da scarsità | Competenze concentrate | Competenze diffuse |
|---:|---|---|
| 0 | −0,19 [−0,24, −0,14] | −0,30 [−0,35, −0,24] |
| 2 | +0,08 [+0,00, +0,15] | +0,37 [+0,27, +0,46] |
| 5 | **+0,48 [+0,32, +0,63]** | **+1,36 [+1,16, +1,57]** |

Con danno 5 sta meglio anche la maggioranza: +0,44 (concentrate) e +1,08
(diffuse). Il controllo di autoattribuzione **non scatta mai** quando c'è solo
conoscenza, e quindi non la blocca.

**Conoscenza e interesse, competenze concentrate**

| Danno da scarsità | V24 − V23 (maggioranza) | V26 − V24 (maggioranza) | V26 − V23 (tutti) |
|---:|---|---|---|
| 0 | −6,04 [−6,21, −5,87] | +3,35 [+3,23, +3,46] | −1,23 [−1,28, −1,17] |
| 2 | −4,63 [−4,95, −4,32] | +3,05 [+2,90, +3,19] | −0,12 [−0,28, +0,05] |
| 5 | −2,52 [−3,17, −1,91] | +2,60 [+2,33, +2,83] | **+1,54 [+1,16, +1,94]** |

Il controllo scatta nel 100% dei casi; la zona dei competenti passa da 1,93 a
1,36 volte la sua parte proporzionale.

## Cosa mostrano i numeri

1. **La tua tesi regge quando la conoscenza riguarda conseguenze che contano.**
   Se i competenti si discostano per ciò che sanno, votare per competenza dà
   risultati migliori del voto eguale, anche per la maggioranza, da un danno da
   scarsità intorno a 2 in su. Se le conseguenze che conoscono non danneggiano
   nessuno, il loro sapere non serve e il voto eguale è un po' migliore.
2. **Il controllo di autoattribuzione separa i due casi:** non scatta quando c'è
   solo conoscenza; scatta quando c'è interesse e restituisce alla maggioranza
   circa 3 punti.
3. **Con conoscenza e interesse insieme, la combinazione migliore è "tutto per
   competenza + controllo" (V26)** quando le conseguenze sono importanti: con
   danno 5 è la migliore in assoluto (+1,5 sul voto eguale) e la maggioranza
   non ci perde (+0,08, non significativo).
4. **Dove sta il punto di pareggio dipende da quanto sono gravi le conseguenze
   che solo i competenti vedono.** Nella realtà questa intensità va misurata:
   è il dato empirico da cui dipende la scelta.

## Limiti

- Un solo tipo di conseguenza nascosta (consumo idrico) e un solo canale di
  conoscenza.
- L'intensità del danno da scarsità è un parametro; la V27 ne mostra tre valori.
- Le preferenze non cambiano nel tempo: la maggioranza non impara dalle
  conseguenze.

## File e riproduzione

- `simulazione_dpa_v27.py` — conseguenze nascoste, conoscenza, interesse,
  valutazione sulle conseguenze reali. Usa V21, V22, V23 e V26.
- `test_dpa_v27.py` — 5 test.
- `risultati/scarsita_0/`, `risultati/scarsita_2/`, `risultati/scarsita_5/`.

```bash
cd democrazia-ponderata-adattiva/v27_dpa_conoscenza_interesse
python -m pip install -r requirements.txt
python test_dpa_v27.py
for d in 0 2 5; do python simulazione_dpa_v27.py --mondi 200 --danno-scarsita $d --output risultati/scarsita_$d; done
```
