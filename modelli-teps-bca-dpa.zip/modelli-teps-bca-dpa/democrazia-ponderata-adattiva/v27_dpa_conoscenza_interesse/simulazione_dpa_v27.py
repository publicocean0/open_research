# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DPA V27 — conoscenza o interesse? Valutazione sulle conseguenze reali.

Il gruppo competente vuole cose diverse dalla base. Due ragioni possibili:

* **conoscenza**: sa cose che gli altri non sanno. Qui: costruire abitazioni
  oltre un livello sicuro (5) consuma la capacita' della rete idrica nei
  periodi successivi (0,30 per unita' oltre il livello, per periodo), e la
  capacita' persa danneggia tutti (scarsita': 0, 2 o 5 per unita' persa). Chi e'
  competente in acqua o urbanistica lo sa e chiede meno abitazioni, in
  proporzione a cio' che sa; chi non lo sa chiede cio' che desidera;
* **interesse**: preferenze legate alla propria posizione (qui: la propria zona
  nella ripartizione dell'investimento, e preferenze di gruppo diverse).

Scenari:
* ``solo_conoscenza``: i competenti hanno gli stessi desideri della maggioranza
  e nessuna preferenza per la propria zona; differiscono solo per cio' che sanno;
* ``conoscenza_e_interesse``: in piu' preferenze di gruppo proprie e preferenza
  per la propria zona (come in V25-V26).

La valutazione e' sulle **conseguenze reali** in 20 periodi: servizi
effettivamente ottenuti rispetto ai desideri, danni da limiti superati,
capacita' idrica rimasta. Si riporta anche la vecchia misura (soddisfazione dei
desideri iniziali sugli obiettivi votati).

Simulazione su popolazioni sintetiche: non e' una prova su ordinamenti reali.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np

QUI = Path(__file__).resolve().parent
for c in ("v21_dpa_raffinata", "v22_dpa_dinamica_tematica", "v23_dpa_premesse_teps", "v26_dpa_test_corretto"):
    sys.path.insert(0, str(QUI.parent / c))
import simulazione_v21 as d21  # noqa: E402
import simulazione_dpa_v22 as d22  # noqa: E402
import simulazione_dpa_v23 as d23  # noqa: E402
import simulazione_dpa_v26 as d26  # noqa: E402
from simulazione_v21 import mediana_pesata  # noqa: E402

PERIODI = 20
d22.PERIODI = PERIODI          # i mondi dinamici della V22 vengono generati su 20 periodi
H_SICURO = 5.0
CONSUMO_IDRICO = 0.30
DANNO_LINEARE = 10.0           # costo per unita' di limite reale superato (sensibilita': 0 e 10)
DANNO_SCARSITA = 2.0           # danno per persona e periodo per unita' di capacita' idrica persa (0, 2, 5)
PARAMETRI_ESECUZIONE = {"consumo": CONSUMO_IDRICO, "danno_lineare": DANNO_LINEARE,
                        "danno_scarsita": DANNO_SCARSITA}
CORREZIONE_CONOSCENZA = 0.8
N_MIN = d23.N_MIN
ZONE = d26.ZONE
SCENARI = ("solo_conoscenza", "conoscenza_e_interesse")
DISTRIBUZIONI = ("concentrate", "diffuse")
REGIMI = ("uguale_tutti", "dpa_v23_obiettivi_eguali", "dpa_v24_tutto_competenza", "dpa_v26_controllo")


# ---------------------------------------------------------------------------
# Mondo
# ---------------------------------------------------------------------------
def prepara(seed, indice, scenario, distribuzione):
    md = d22.MondoDinamico(seed, indice, "base")
    pop = md.pop
    rng = np.random.default_rng([seed, indice, 2700 + SCENARI.index(scenario), DISTRIBUZIONI.index(distribuzione)])
    tec = pop.gruppo == "tecnico"
    if scenario == "solo_conoscenza":
        # i competenti desiderano cio' che desidera la maggioranza
        magg = np.array(d21.PARAMETRI["gruppi"]["maggioranza"][1])
        pop.ideale[tec] = np.clip(magg + rng.normal(0, d21.PARAMETRI["rumore_ideale"], (tec.sum(), 3)), 0, 15)
    c_soc = rng.beta(2, 4, (pop.n, 2))
    prof = (~tec) & (rng.random(pop.n) < 0.20)
    c_soc[prof] = rng.beta(5, 2, (prof.sum(), 2))
    if distribuzione == "diffuse":
        perm = rng.permutation(pop.n)
        for attr in ("c_vera", "c_cert"):
            setattr(pop, attr, getattr(pop, attr)[perm].copy())
        c_soc = c_soc[rng.permutation(pop.n)]
    Cstar = d26.certifica(np.hstack([pop.c_vera, c_soc]), rng)
    # conoscenza delle conseguenze: competenza vera in acqua e urbanistica
    conoscenza = 0.5 * pop.c_vera[:, 0] + 0.5 * c_soc[:, 0]
    # cio' che ciascuno vota per le abitazioni: il desiderio corretto da cio' che sa
    voto = pop.ideale.copy()
    voto[:, 0] = pop.ideale[:, 0] - CORREZIONE_CONOSCENZA * conoscenza * np.maximum(0, pop.ideale[:, 0] - H_SICURO)
    zr = np.random.default_rng([seed, indice, 77])
    zona = np.where(zr.random(pop.n) < 0.10, 0, zr.integers(1, ZONE, pop.n))
    zona[tec] = np.where(zr.random(tec.sum()) < 0.90, 0, zr.integers(1, ZONE, tec.sum()))
    quota_zona = 0.40 if scenario == "conoscenza_e_interesse" else 0.0
    return md, Cstar, voto, zona, quota_zona


def ripartizione(zona, idx, w, quota):
    """Chi non ha interessi propri vuole una ripartizione proporzionale alla
    popolazione delle zone; ``quota`` va in piu' alla propria zona."""
    quota_pop = np.bincount(zona, minlength=ZONE) / len(zona)
    pref = np.tile((1 - quota) * quota_pop, (len(idx), 1))
    pref[np.arange(len(idx)), zona[idx]] += quota
    return (w[:, None] * pref).sum(0) / w.sum()


# ---------------------------------------------------------------------------
# Voto sugli obiettivi
# ---------------------------------------------------------------------------
def vota_obiettivi(pop, voto, zona, quota, Cstar, rng, regime):
    n = pop.n
    if regime in ("uguale_tutti", "dpa_v23_obiettivi_eguali"):
        tau = np.array([mediana_pesata(voto[:, j], np.ones(n)) for j in range(3)])
        return tau, ripartizione(zona, np.arange(n), np.ones(n), quota), 0, 0.0, 0.0, n
    el = [d23.convoca(Cstar @ d26.RILEVANZA_PRIMARIA[j], np.zeros(n, bool), rng, N_MIN)[:2] for j in range(3)]

    def esito(el):
        tau = np.array([mediana_pesata(voto[idx, j], w) for j, (idx, w) in enumerate(el)])
        return tau, ripartizione(zona, *el[0], quota)

    tau, alloc = esito(el)
    ia0 = d26.indice_autoattribuzione(zona, alloc, el[0][0])
    scatta = 0
    if regime == "dpa_v26_controllo":
        p = d26.test_composizione(zona, el[0][0], rng)
        if p < d26.LIVELLO_TEST and ia0 > 1e-9:     # tolleranza per gli arrotondamenti
            scatta = 1
            nuovi = []
            for j, (idx, w) in enumerate(el):
                gia = np.zeros(n, bool)
                gia[idx] = True
                idx2, w2, _, _ = d23.convoca(Cstar @ d26.RILEVANZA_VICINA[j], gia, rng, N_MIN)
                nuovi.append((np.r_[idx, idx2], np.r_[w, w2]))
            el = nuovi
            tau, alloc = esito(el)
    ia1 = d26.indice_autoattribuzione(zona, alloc, el[0][0])
    return tau, alloc, scatta, ia0, ia1, float(np.mean([len(i) for i, _ in el]))


# ---------------------------------------------------------------------------
# Esecuzione nel tempo con conseguenze reali
# ---------------------------------------------------------------------------
def esegui_regime(md, Cstar, voto, zona, quota, regime, seed_voto):
    pop = md.pop
    n = pop.n
    rng = np.random.default_rng(seed_voto)
    b = md.b.copy()                     # i limiti reali cambiano con le scelte (consumo idrico)
    t_min = md.m.t_min if md.diritto else None
    x = d22.STATO_INIZIALE.copy()
    b_cert = np.zeros(4)
    tau = None
    righe = []
    info = {}
    for t in range(PERIODI):
        stime = (b[t][None, :] + (1 - pop.c_vera) * (md.errore_laico[None, :] + md.z[t])
                 + md.errore_modello[t][None, :] + pop.allentamento_b[:, None])
        if regime != "uguale_tutti" and t > 1:
            b_oss = b[t - 1] + md.monitor[t - 1]
            vincoli = [k for k in range(4) if abs(b_oss[k] - (b_cert[k] + d22.MARGINE)) > d22.SOGLIA_RIVOTO]
        else:
            vincoli = range(4)
        for k in vincoli:
            if regime == "uguale_tutti":
                idx, w = np.arange(n), np.ones(n)
            else:
                idx, w, _, _ = d23.convoca(Cstar[:, k], np.zeros(n, bool), rng, N_MIN)
            b_cert[k] = mediana_pesata(stime[idx, k], w) - d22.MARGINE
        if t == 0:
            tau, alloc, scatta, ia0, ia1, dim = vota_obiettivi(pop, voto, zona, quota, Cstar, rng, regime)
            quota_pop = np.bincount(zona, minlength=ZONE) / n
            info = {"abitazioni_obiettivo": float(tau[0]), "test_scattato": scatta, "ia_prima": ia0,
                    "ia_dopo": ia1, "votanti_obiettivi": dim,
                    "zona0_su_quota_equa": float(alloc[0] / quota_pop[0]),
                    "soddisfazione_iniziale": float(d21.preferenza(pop, tau[None, :])[:, 0].mean()),
                    "soddisfazione_iniziale_maggioranza":
                        float(d21.preferenza(pop, tau[None, :])[:, 0][pop.gruppo == "maggioranza"].mean())}
        x, _ = d22.piano(tau, np.ones(3), md.A, b_cert, x, t_min)
        g = md.A @ x - b[t]
        sforamento = np.maximum(0, g)
        persa = md.b[t, 0] - b[t, 0]            # capacita' idrica gia' consumata
        danno = (d21.PARAMETRI["penalita_vincolo"] * pop.avversione * (sforamento ** 2).sum()
                 + PARAMETRI_ESECUZIONE["danno_lineare"] * sforamento.sum()
                 + PARAMETRI_ESECUZIONE["danno_scarsita"] * persa)
        ben = d21.preferenza(pop, x[None, :])[:, 0] - danno
        righe.append({"benessere_realizzato": float(ben.mean()),
                      "benessere_realizzato_maggioranza": float(ben[pop.gruppo == "maggioranza"].mean()),
                      "benessere_realizzato_minoranza": float(ben[pop.gruppo == "minoranza"].mean()),
                      "peggior_gruppo_realizzato": float(min(ben[pop.gruppo == gn].mean()
                                                             for gn in np.unique(pop.gruppo))),
                      "fattibile": float(np.max(g) <= 1e-9), "abitazioni": float(x[0])})
        # conseguenza nascosta: le abitazioni oltre il livello sicuro consumano la rete idrica
        if t + 1 < PERIODI:
            b[t + 1:, 0] -= PARAMETRI_ESECUZIONE["consumo"] * max(0.0, x[0] - H_SICURO)
    media = {k: float(np.mean([r[k] for r in righe])) for k in righe[0]}
    media["benessere_ultimi_5"] = float(np.mean([r["benessere_realizzato"] for r in righe[-5:]]))
    media["capacita_idrica_persa"] = float(md.b[-1, 0] - b[-1, 0])
    media.update(info)
    return media


def esegui_mondo(seed, indice, scenario, distribuzione):
    md, Cstar, voto, zona, quota = prepara(seed, indice, scenario, distribuzione)
    return [{"mondo": indice, "scenario": scenario, "competenze": distribuzione, "regime": reg,
             **esegui_regime(md, Cstar, voto, zona, quota, reg, [seed, indice, 11, i])}
            for i, reg in enumerate(REGIMI)]


METRICHE = ("benessere_realizzato", "benessere_realizzato_maggioranza", "benessere_realizzato_minoranza",
            "peggior_gruppo_realizzato", "benessere_ultimi_5", "fattibile", "abitazioni",
            "capacita_idrica_persa", "abitazioni_obiettivo", "soddisfazione_iniziale",
            "soddisfazione_iniziale_maggioranza", "test_scattato", "ia_prima", "ia_dopo",
            "votanti_obiettivi", "zona0_su_quota_equa")


def riepiloga(righe, seed):
    rng = np.random.default_rng([seed, 27])
    rie, conf = [], []
    for dist in DISTRIBUZIONI:
        for s in SCENARI:
            per = {g: [r for r in righe if r["competenze"] == dist and r["scenario"] == s and r["regime"] == g]
                   for g in REGIMI}
            for g, rr in per.items():
                out = {"competenze": dist, "scenario": s, "regime": g, "mondi": len(rr)}
                for k in METRICHE:
                    mu, lo, hi = d21.ic_bootstrap(np.array([r[k] for r in rr], float), rng, 2000)
                    out.update({k: mu, k + "_ic_basso": lo, k + "_ic_alto": hi})
                rie.append(out)
            for a, b in (("dpa_v24_tutto_competenza", "dpa_v23_obiettivi_eguali"),
                         ("dpa_v26_controllo", "dpa_v23_obiettivi_eguali"),
                         ("dpa_v26_controllo", "dpa_v24_tutto_competenza"),
                         ("dpa_v23_obiettivi_eguali", "uguale_tutti")):
                ref = {r["mondo"]: r for r in per[b]}
                for k in ("benessere_realizzato", "benessere_realizzato_maggioranza", "peggior_gruppo_realizzato",
                          "benessere_ultimi_5", "capacita_idrica_persa", "soddisfazione_iniziale_maggioranza",
                          "zona0_su_quota_equa"):
                    d = [r[k] - ref[r["mondo"]][k] for r in per[a]]
                    mu, lo, hi = d21.ic_bootstrap(np.array(d), rng, 2000)
                    conf.append({"competenze": dist, "scenario": s, "confronto": f"{a} - {b}", "metrica": k,
                                 "differenza": mu, "ic95_basso": lo, "ic95_alto": hi})
    return rie, conf


def main():
    ap = argparse.ArgumentParser(description="DPA V27: conoscenza o interesse")
    ap.add_argument("--mondi", type=int, default=200)
    ap.add_argument("--seed", type=int, default=2727)
    ap.add_argument("--output", type=Path, default=QUI / "risultati")
    ap.add_argument("--consumo", type=float, default=CONSUMO_IDRICO)
    ap.add_argument("--danno-lineare", type=float, default=DANNO_LINEARE)
    ap.add_argument("--danno-scarsita", type=float, default=DANNO_SCARSITA)
    ap.add_argument("--test", action="store_true")
    a = ap.parse_args()
    PARAMETRI_ESECUZIONE.update(consumo=a.consumo, danno_lineare=a.danno_lineare, danno_scarsita=a.danno_scarsita)
    mondi = 3 if a.test else a.mondi
    righe = [r for dist in DISTRIBUZIONI for s in SCENARI for i in range(mondi)
             for r in esegui_mondo(a.seed, i, s, dist)]
    rie, conf = riepiloga(righe, a.seed)
    a.output.mkdir(parents=True, exist_ok=True)
    d21.scrivi_csv(a.output / "dettaglio.csv", righe)
    d21.scrivi_csv(a.output / "riepilogo.csv", rie)
    d21.scrivi_csv(a.output / "confronti_accoppiati.csv", conf)
    (a.output / "parametri.json").write_text(json.dumps({
        "mondi": mondi, "seed": a.seed, "periodi": PERIODI, "h_sicuro": H_SICURO,
        "consumo_idrico": PARAMETRI_ESECUZIONE["consumo"],
        "danno_lineare": PARAMETRI_ESECUZIONE["danno_lineare"],
        "danno_scarsita": PARAMETRI_ESECUZIONE["danno_scarsita"], "correzione_conoscenza": CORREZIONE_CONOSCENZA,
        "n_min": N_MIN, "regimi": REGIMI, "scenari": SCENARI, "distribuzioni": DISTRIBUZIONI},
        indent=2, ensure_ascii=False), encoding="utf-8")
    for r in rie:
        print(f"{r['competenze']:11s} {r['scenario']:22s} {r['regime']:25s} "
              f"real={r['benessere_realizzato']:.2f} magg={r['benessere_realizzato_maggioranza']:.2f} "
              f"pegg={r['peggior_gruppo_realizzato']:.2f} ult5={r['benessere_ultimi_5']:.2f} "
              f"fatt={r['fattibile']:.3f} h_ob={r['abitazioni_obiettivo']:.2f} acqua_persa={r['capacita_idrica_persa']:.2f} "
              f"sodd_magg={r['soddisfazione_iniziale_maggioranza']:.2f} test={r['test_scattato']:.2f} "
              f"z0={r['zona0_su_quota_equa']:.2f}")


if __name__ == "__main__":
    main()
