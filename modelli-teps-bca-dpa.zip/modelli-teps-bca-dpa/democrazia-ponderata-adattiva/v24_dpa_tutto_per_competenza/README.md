# Democrazia Ponderata Adattiva — V24 (tutto per competenza)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra
l'efficacia di un ordinamento reale.

## Scelte di questa versione

- **Tutte le questioni tematiche sono indirizzate per competenza**: i vincoli
  e anche gli obiettivi li votano solo i competenti sopra soglia. Chi è sotto
  soglia su un tema non vota quel tema. A voto eguale restano solo i **diritti
  universali**.
- **La base è chi supera la soglia, senza tetto.** La sua larghezza emerge
  dalle competenze certificate; N_min = 101 vale solo come pavimento (D-15).
- **Competenze certificate da un sistema imparziale**: cinque agenti IA isolati,
  nessun essere umano; competenza = mediana delle valutazioni meno la loro
  dispersione (TEPS §12.1).
- Peso TEPS con soglia `τ₀ = 0,6` e tetto `w_max = 3`; nessuno vota con peso
  sulla propria pratica; dinamica con monitoraggio e rivoto mirato (V22–V23).

## La domanda nuova

Votare gli obiettivi solo per competenza cambia **chi vince**? Nella V23 la
variante "obiettivi per competenza" faceva perdere benessere al gruppo più
svantaggiato. Il sospetto: dipende da come sono distribuite le competenze nel
mondo simulato, non dall'indirizzamento in sé. Per verificarlo ogni scenario è
ripetuto con:

- **competenze concentrate**: come in V21–V23, la competenza alta è quasi tutta
  in un gruppo (i tecnici, 15%) che ha preferenze proprie;
- **competenze diffuse**: stessa distribuzione delle competenze, ma assegnata a
  caso fra tutti i gruppi, senza legame con le preferenze.

## Risultati (200 mondi per scenario)

Quota di periodi in cui il piano rispetta davvero i limiti (base):

| Regime | Concentrate | Diffuse | Schede per periodo |
|---|---:|---:|---:|
| Tutti, voto eguale | 60,6% | 60,8% | 4 260 |
| DPA V23 (obiettivi a voto eguale) | 96,4% | 96,2% | ≈ 395 |
| **DPA V24 (tutto per competenza)** | 96,1% | 96,1% | **≈ 245** |
| DPA V24 + storico delle previsioni | 96,8% | 96,8% | ≈ 240 |

Con esperti corrotti: V24 79,5%, V24 + storico 92,9% (concentrate), 92,2%
(diffuse); tutti a voto eguale 50,8%.

Benessere (DPA V24 − DPA V23, differenze accoppiate, IC bootstrap 95%), base:

| Misura | Competenze concentrate | Competenze diffuse |
|---|---|---|
| Benessere medio | −2,21 [−2,30, −2,13] | −0,03 [−0,07, +0,01] |
| Maggioranza | **−5,69 [−5,83, −5,54]** | −0,07 [−0,15, +0,00] |
| Minoranza | +2,11 [+1,89, +2,31] | +0,04 [−0,10, +0,19] |
| Gruppo più svantaggiato | **−4,37 [−4,59, −4,14]** | −0,02 [−0,15, +0,12] |
| Divario fra gruppi | +7,05 [+6,82, +7,27] | −0,01 [−0,18, +0,14] |

Con competenze concentrate il gruppo competente pesa il 73% nei voti sugli
obiettivi; con competenze diffuse il 15%, pari alla sua quota di persone.

## Cosa mostrano i numeri

1. **Indirizzare tutto per competenza funziona sui vincoli e non costa nulla
   in fattibilità**: 96% di piani davvero fattibili, come la V23, con il 40% di
   schede in meno.
2. **Sugli obiettivi l'esito dipende da come sono distribuite le competenze.**
   Se le competenze certificate sono **diffuse** fra gruppi con interessi
   diversi, votare gli obiettivi per competenza dà lo stesso risultato del voto
   eguale (differenze nulle entro l'intervallo). Se sono **concentrate** in un
   gruppo con preferenze proprie, il piano segue quel gruppo: la maggioranza
   perde 5,7 punti di benessere e il divario fra gruppi cresce di 7.
3. Quindi il problema non è l'indirizzamento per competenza: è il **legame fra
   competenza certificata e interessi**. È misurabile: confrontando le
   preferenze espresse dall'elettorato di un tema con quelle dell'intera
   popolazione, o la composizione per gruppi dell'elettorato.
4. **Lo storico delle previsioni** resta la difesa più forte contro gli esperti
   corrotti (+13 punti).
5. **La base emerge dalle competenze**: nei vincoli e negli obiettivi votano in
   media 101 persone, cioè il pavimento. In questo mondo i competenti sopra
   0,6 che votano davvero sono meno di 101, quindi la soglia scende come
   previsto da D-15.

Senza errore sistematico dei non esperti (sensibilità in
`risultati/sensibilita_errore_laico_0/`) le conclusioni sul benessere non
cambiano; sulla fattibilità tutti i regimi superano il 93%.

## Una proposta che segue da qui

Una **verifica di rappresentatività** dell'elettorato per competenza, pubblica e
automatica come le altre regole: se l'elettorato di un obiettivo è troppo
squilibrato verso un gruppo di interesse rispetto alla popolazione, la base si
allarga (come D-15, ma per la composizione invece che per il numero). Non è
ancora implementata: va definito come misurare i gruppi di interesse senza
schedare le persone.

## Limiti

- Gruppi e preferenze sintetici; nella realtà il legame fra competenze e
  interessi va misurato.
- Le competenze rilevanti per gli obiettivi sono le stesse dei vincoli (acqua,
  trasporti, bilancio, ambiente); discipline sociali o di pianificazione
  cambierebbero gli elettorati.
- Coefficienti dei vincoli noti; preferenze costanti; manipolazioni semplici.

## File e riproduzione

- `simulazione_dpa_v24.py` — regimi, competenze concentrate/diffuse, scenari.
  Usa V21–V23.
- `test_dpa_v24.py` — 4 test.
- `risultati/` e `risultati/sensibilita_errore_laico_0/`.

```bash
cd democrazia-ponderata-adattiva/v24_dpa_tutto_per_competenza
python -m pip install -r requirements.txt
python test_dpa_v24.py
python simulazione_dpa_v24.py --mondi 200
python simulazione_dpa_v24.py --mondi 200 --errore-laico-medio 0 --output risultati/sensibilita_errore_laico_0
```
