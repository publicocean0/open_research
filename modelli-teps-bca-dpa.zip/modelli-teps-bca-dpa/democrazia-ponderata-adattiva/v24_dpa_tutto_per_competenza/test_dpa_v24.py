# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test DPA V24. Esecuzione: python test_dpa_v24.py"""
import numpy as np

import simulazione_dpa_v24 as s


def test_diffuse_stessa_distribuzione_altra_assegnazione():
    mc, _, _, _ = s.prepara(2424, 0, "base", "concentrate")
    md, _, _, _ = s.prepara(2424, 0, "base", "diffuse")
    a, b = mc.pop.c_vera, md.pop.c_vera
    assert np.allclose(np.sort(a, 0), np.sort(b, 0))          # stessa distribuzione
    tec = mc.pop.gruppo == "tecnico"
    assert a[tec].mean() > b[tec].mean() + 0.2                   # non piu' concentrate nei tecnici


def test_chi_e_sotto_soglia_non_vota_gli_obiettivi():
    md, Cstar, conflitti, sorv = s.prepara(2424, 1, "base", "concentrate")
    rng = np.random.default_rng(0)
    Cq = Cstar @ s.d23.RILEVANZA_OBIETTIVI[0]
    idx, w, tau, _ = s.d23.convoca(Cq, conflitti[:, 0], rng, s.N_MIN)
    assert np.all(Cq[idx] >= tau - 1e-12) and len(idx) >= s.N_MIN
    assert len(idx) < md.pop.n


def test_base_senza_tetto():
    """Se molti superano la soglia, votano tutti quelli sopra soglia (nessun tetto)."""
    rng = np.random.default_rng(3)
    Cq = np.r_[np.full(400, 0.9), np.full(200, 0.1)]
    idx, _, tau, estesa = s.d23.convoca(Cq, np.zeros(600, bool), rng, s.N_MIN)
    assert tau == s.d23.TAU0 and not estesa and len(idx) > 250


def test_determinismo():
    assert s.esegui_mondo(2424, 2, "shock", "diffuse") == s.esegui_mondo(2424, 2, "shock", "diffuse")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK", t.__name__)
    print(f"OK DPA V24: {len(tests)} test superati")
