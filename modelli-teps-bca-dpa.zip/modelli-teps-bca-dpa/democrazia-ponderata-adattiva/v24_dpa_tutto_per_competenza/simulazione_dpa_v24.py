# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DPA V24 — tutte le questioni tematiche indirizzate per competenza.

Rispetto alla V23:

* anche gli **obiettivi** li votano solo i competenti sopra soglia (chi e' sotto
  soglia su un tema non vota quel tema); a voto eguale restano solo i diritti
  universali;
* la **base** e' chi supera la soglia, senza tetto: la sua larghezza emerge dalle
  competenze certificate; N_min = 101 vale solo come pavimento (D-15);
* nuova verifica: competenze **concentrate** in un gruppo con preferenze proprie
  (come in V21-V23) oppure **diffuse** fra tutti i gruppi (stessa distribuzione,
  nessun legame con le preferenze).

Competenze certificate da cinque agenti IA isolati (nessun essere umano), peso
TEPS con soglia e tetto, dinamica con monitoraggio e rivoto mirato come in V22-V23.
Simulazione su popolazioni sintetiche: non e' una prova su ordinamenti reali.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import json
import sys
from pathlib import Path

import numpy as np

QUI = Path(__file__).resolve().parent
for c in ("v21_dpa_raffinata", "v22_dpa_dinamica_tematica", "v23_dpa_premesse_teps"):
    sys.path.insert(0, str(QUI.parent / c))
import simulazione_v21 as d21  # noqa: E402
import simulazione_dpa_v22 as d22  # noqa: E402
import simulazione_dpa_v23 as d23  # noqa: E402
from simulazione_v21 import mediana_pesata  # noqa: E402

PERIODI = d22.PERIODI
N_MIN = d23.N_MIN
SCENARI = ("base", "esperti_corrotti", "credenziali_gonfiate_3su5", "shock")
DISTRIBUZIONI = ("concentrate", "diffuse")
# regime: (obiettivi, storico, dinamico)
REGIMI = {
    "uguale_tutti": ("tutti", False, False),
    "dpa_v23_obiettivi_eguali": ("eguale", False, True),
    "dpa_v24": ("competenza", False, True),
    "dpa_v24_storico": ("competenza", True, True),
}


def esegui_regime(md, regime, Cstar, conflitti, sorvegliato, seed_voto):
    obiettivi_modo, usa_storico, dinamico = REGIMI[regime]
    pop = md.pop
    n = pop.n
    rng = np.random.default_rng(seed_voto)
    peso_storico = np.ones((n, 4))
    sq_err, n_err = np.zeros((n, 4)), np.zeros((n, 4))
    t_min = md.m.t_min if md.diritto else None
    x = d22.STATO_INIZIALE.copy()
    b_cert = np.zeros(4)
    ultima = {}
    tau_obj, W = np.zeros(3), np.ones(3)
    schede, voti_vinc, voti_obj, quota_ind = n, [], [], 0.0
    q_obj = []
    righe_t = []
    for t in range(PERIODI):
        if usa_storico and t > 0:
            b_oss = md.b[t - 1] + md.monitor[t - 1]
            for k, (idx, rep) in ultima.items():
                sq_err[idx, k] += (rep - b_oss[k]) ** 2
                n_err[idx, k] += 1
            rmse = np.sqrt(sq_err / np.maximum(n_err, 1))
            for k in range(4):
                visti = n_err[:, k] > 0
                if visti.any():
                    rif = np.median(rmse[visti, k])
                    peso_storico[visti, k] = np.exp(-np.maximum(0, rmse[visti, k] - rif) / 0.4)
        if dinamico and t > 1:
            b_oss = md.b[t - 1] + md.monitor[t - 1]
            vincoli = [k for k in range(4) if abs(b_oss[k] - (b_cert[k] + d22.MARGINE)) > d22.SOGLIA_RIVOTO]
        else:
            vincoli = list(range(4))
        rivota_obiettivi = (t == 0) if dinamico else True
        stime = md.stime(t)
        ultima = {}
        for k in vincoli:
            if obiettivi_modo == "tutti":
                idx, w = np.arange(n), np.ones(n)
            else:
                idx, w, _, _ = d23.convoca(Cstar[:, k], np.zeros(n, bool), rng, N_MIN)
                w = w * peso_storico[idx, k]
                quota_ind = max(quota_ind, float(w.max() / w.sum()))
            b_cert[k] = mediana_pesata(stime[idx, k], w) - d22.MARGINE
            ultima[k] = (idx, stime[idx, k])
            schede += len(idx)
            voti_vinc.append(len(idx))
        if rivota_obiettivi:
            for j in range(3):
                if obiettivi_modo in ("tutti", "eguale"):
                    idx, w = np.arange(n), np.ones(n)
                else:
                    idx, w, _, _ = d23.convoca(Cstar @ d23.RILEVANZA_OBIETTIVI[j], conflitti[:, j], rng, N_MIN)
                    voti_obj.append(len(idx))
                    q_obj.append(w[pop.gruppo[idx] == sorvegliato].sum() / w.sum())
                tau_obj[j] = mediana_pesata(pop.ideale[idx, j], w)
                schede += len(idx)
        x, stato = d22.piano(tau_obj, W, md.A, b_cert, x, t_min)
        g = md.A @ x - md.b[t]
        pref = d21.preferenza(pop, x[None, :])[:, 0]
        gruppi = [gn for gn in np.unique(pop.gruppo)]
        righe_t.append({
            "fattibile": float(np.max(g) <= 1e-9), "violazione": float(np.maximum(0, g).sum()),
            "benessere": float(pref.mean()),
            "benessere_minoranza": float(pref[pop.gruppo == "minoranza"].mean()),
            "benessere_maggioranza": float(pref[pop.gruppo == "maggioranza"].mean()),
            "peggior_gruppo": float(min(pref[pop.gruppo == gn].mean() for gn in gruppi)),
            "divario_gruppi": float(max(pref[pop.gruppo == gn].mean() for gn in gruppi)
                                    - min(pref[pop.gruppo == gn].mean() for gn in gruppi))})
    media = {k: float(np.mean([r[k] for r in righe_t])) for k in righe_t[0]}
    media.update({
        "fattibile_dopo_5": float(np.mean([r["fattibile"] for r in righe_t[d22.PERIODO_SHOCK:]])),
        "schede_per_periodo": schede / PERIODI,
        "votanti_medi_vincoli": float(np.mean(voti_vinc)),
        "votanti_medi_obiettivi": float(np.mean(voti_obj)) if voti_obj else float(n),
        "quota_individuale_max": quota_ind,
        "quota_sorvegliato_obiettivi": float(np.mean(q_obj)) if q_obj else np.nan,
        "abitazioni_finali": float(x[0]), "trasporti_finali": float(x[2])})
    return media


def prepara(seed, indice, scenario, distribuzione):
    base = "competenze_gonfiate" if scenario.startswith("credenziali") else scenario
    md = d22.MondoDinamico(seed, indice, base)
    pop = md.pop
    rng = np.random.default_rng([seed, indice, 1000 + SCENARI.index(scenario), DISTRIBUZIONI.index(distribuzione)])
    if scenario.startswith("credenziali"):
        pop.c_cert = pop.c_vera.copy()
    if distribuzione == "diffuse":
        # stessa distribuzione delle competenze, assegnata a caso fra i gruppi
        perm = rng.permutation(pop.n)
        for attr in ("c_vera", "c_cert", "allentamento_b", "corrotto"):
            setattr(pop, attr, getattr(pop, attr)[perm].copy())
    sorv, bersaglio, ingannati = "tecnico", None, 0
    if scenario == "esperti_corrotti":
        sorv = "corrotti"
        pop.gruppo = pop.gruppo.copy()
        pop.gruppo[pop.corrotto] = "corrotti"
    if scenario.startswith("credenziali"):
        sorv = "lobby"
        bersaglio = np.where(pop.gruppo == "lobby")[0]
        ingannati = 3
    Cstar, _, _ = d23.competenze_riconosciute(pop, rng, ingannati, bersaglio=bersaglio)
    conflitti = np.zeros((pop.n, 3), bool)
    conflitti[pop.gruppo == "lobby", 0] = True
    return md, Cstar, conflitti, sorv


def esegui_mondo(seed, indice, scenario, distribuzione):
    md, Cstar, conflitti, sorv = prepara(seed, indice, scenario, distribuzione)
    righe = []
    for r_i, regime in enumerate(REGIMI):
        r = esegui_regime(md, regime, Cstar, conflitti, sorv, [seed, indice, 7, r_i])
        righe.append({"mondo": indice, "scenario": scenario, "competenze": distribuzione,
                      "regime": regime, "gruppo_sorvegliato": sorv, **r})
    return righe


METRICHE = ("fattibile", "violazione", "fattibile_dopo_5", "benessere", "benessere_minoranza",
            "benessere_maggioranza", "peggior_gruppo", "divario_gruppi", "schede_per_periodo",
            "votanti_medi_vincoli", "votanti_medi_obiettivi", "quota_individuale_max",
            "quota_sorvegliato_obiettivi", "abitazioni_finali", "trasporti_finali")


def riepiloga(righe, seed):
    rng = np.random.default_rng([seed, 24])
    rie, conf = [], []
    for dist in DISTRIBUZIONI:
        for s in SCENARI:
            per = {g: [r for r in righe if r["competenze"] == dist and r["scenario"] == s and r["regime"] == g]
                   for g in REGIMI}
            for g, rr in per.items():
                out = {"competenze": dist, "scenario": s, "regime": g, "mondi": len(rr)}
                for k in METRICHE:
                    v = np.array([r[k] for r in rr], float)
                    v = v[~np.isnan(v)]
                    mu, lo, hi = d21.ic_bootstrap(v, rng, 2000)
                    out.update({k: mu, k + "_ic_basso": lo, k + "_ic_alto": hi})
                rie.append(out)
            for g in REGIMI:
                if g == "dpa_v24":
                    continue
                ref = {r["mondo"]: r for r in per[g]}
                for k in ("fattibile", "benessere", "benessere_minoranza", "benessere_maggioranza",
                          "peggior_gruppo", "divario_gruppi", "schede_per_periodo"):
                    d = [r[k] - ref[r["mondo"]][k] for r in per["dpa_v24"]]
                    mu, lo, hi = d21.ic_bootstrap(np.array(d), rng, 2000)
                    conf.append({"competenze": dist, "scenario": s, "confronto": f"dpa_v24 - {g}",
                                 "metrica": k, "differenza": mu, "ic95_basso": lo, "ic95_alto": hi})
    return rie, conf


def main():
    ap = argparse.ArgumentParser(description="DPA V24: tutto per competenza")
    ap.add_argument("--mondi", type=int, default=200)
    ap.add_argument("--seed", type=int, default=2424)
    ap.add_argument("--errore-laico-medio", type=float, default=None)
    ap.add_argument("--output", type=Path, default=QUI / "risultati")
    ap.add_argument("--test", action="store_true")
    a = ap.parse_args()
    if a.errore_laico_medio is not None:
        d22.PARAMETRI_SCENARIO["errore_laico"] = (a.errore_laico_medio, d22.ERRORE_LAICO[1])
    mondi = 3 if a.test else a.mondi
    righe = [r for dist in DISTRIBUZIONI for s in SCENARI for i in range(mondi)
             for r in esegui_mondo(a.seed, i, s, dist)]
    rie, conf = riepiloga(righe, a.seed)
    a.output.mkdir(parents=True, exist_ok=True)
    d21.scrivi_csv(a.output / "dettaglio.csv", righe)
    d21.scrivi_csv(a.output / "riepilogo.csv", rie)
    d21.scrivi_csv(a.output / "confronti_accoppiati.csv", conf)
    (a.output / "parametri.json").write_text(json.dumps({
        "mondi": mondi, "seed": a.seed, "tau0": d23.TAU0, "w_max": d23.W_MAX, "n_min_pavimento": N_MIN,
        "partecipazione": d23.PARTECIPAZIONE, "agenti_ia": d23.AGENTI, "lambda_mad": d23.LAMBDA_MAD,
        "errore_laico": d22.PARAMETRI_SCENARIO["errore_laico"], "margine": d22.MARGINE,
        "regimi": {k: list(v) for k, v in REGIMI.items()}, "scenari": SCENARI,
        "distribuzioni": DISTRIBUZIONI}, indent=2, ensure_ascii=False), encoding="utf-8")
    for r in rie:
        print(f"{r['competenze']:11s} {r['scenario']:26s} {r['regime']:25s} fatt={r['fattibile']:.3f} "
              f"ben={r['benessere']:.2f} magg={r['benessere_maggioranza']:.2f} min={r['benessere_minoranza']:.2f} "
              f"pegg={r['peggior_gruppo']:.2f} div={r['divario_gruppi']:.2f} schede={r['schede_per_periodo']:.0f} "
              f"vv={r['votanti_medi_vincoli']:.0f} vo={r['votanti_medi_obiettivi']:.0f} "
              f"qobj={r['quota_sorvegliato_obiettivi']:.3f} h={r['abitazioni_finali']:.2f}")


if __name__ == "__main__":
    main()
