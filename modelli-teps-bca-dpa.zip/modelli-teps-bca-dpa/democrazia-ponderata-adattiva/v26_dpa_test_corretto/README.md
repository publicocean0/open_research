# Democrazia Ponderata Adattiva — V26 (test corretto, gruppo in conflitto grande)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra
l'efficacia di un ordinamento reale.

La regola è quella della V25: **verticale** se mancano votanti (D-15),
**orizzontale** alle discipline vicine se gli effetti della decisione si
concentrano su chi l'ha votata. La V26 corregge tre cose e aggiunge un mondo.

## Correzioni

1. **Test di autoattribuzione.** Nella V25 si confrontava l'indice osservato con
   quello di elettorati casuali tenendo fissa la ripartizione; ma qualunque
   elettorato, anche casuale, tende a favorire le proprie zone, quindi i falsi
   allarmi erano molti più del 5% dichiarato. Ora scatta solo se:
   - la **composizione per zona** dell'elettorato si discosta da quella della
     popolazione più del 95% degli elettorati estratti a caso della stessa
     dimensione, **e**
   - la ripartizione decisa **favorisce le zone di chi ha votato** (indice > 0).

   Entrambe le misure usano solo registri pubblici: residenza e partecipazione.
2. **Confronto equo fra verticale e orizzontale.** Nella V25 il verticale
   aggiungeva il doppio delle persone. Ora entrambi aggiungono lo stesso numero
   (101): si confronta solo *chi* entra, non *quanti*.
3. **Costruzione di uno scenario.** Con competenze diffuse ed esperti corrotti
   la residenza veniva assegnata in base all'etichetta "corrotti" invece che al
   gruppo di origine; ora segue il gruppo di origine.

## Mondi

- **Residenza:** la zona 0 è abitata soprattutto dal gruppo competente (90% di
  loro); gli altri vi abitano solo al 10%, nelle altre tre zone al 30% ciascuna.
  È il caso in cui "azioni verso la zona 0" significa "azioni verso il gruppo".
- **Competenze concentrate:** il gruppo competente è il 15% della popolazione.
- **Gruppo competente grande (nuovo):** il gruppo competente è il 40%.
- **Competenze diffuse:** stessa distribuzione, assegnata a caso fra tutti.

## Risultati (200 mondi per scenario, scenario base)

| Mondo | Regime | Zona 0 / parte proporzionale | Indice dopo | Benessere maggioranza | Votanti per obiettivo | Test positivo |
|---|---|---:|---:|---:|---:|---:|
| Concentrate 15% | V24, nessun controllo | 2,01 | 0,69 | −35,50 | 101 | 100% |
| Concentrate 15% | verticale | 1,65 | 0,28 | −33,32 | 202 | 100% |
| Concentrate 15% | **orizzontale** | **1,44** | **0,14** | **−31,84** | 202 | 100% |
| Gruppo grande 40% | V24, nessun controllo | 1,21 | 0,23 | −37,66 | 142 | 100% |
| Gruppo grande 40% | verticale | 1,15 | 0,17 | −37,08 | 243 | 100% |
| Gruppo grande 40% | **orizzontale** | **0,92** | **−0,04** | **−35,09** | 242 | 100% |
| Diffuse | V24, nessun controllo | 1,09 | 0,01 | −29,86 | 101 | **6%** |
| Diffuse | orizzontale | 1,09 | 0,01 | −29,86 | 106 | 5% |

Differenze accoppiate (IC bootstrap 95%), benessere della maggioranza, base:

| Confronto | Concentrate 15% | Gruppo grande 40% | Diffuse |
|---|---|---|---|
| orizzontale − nessun controllo | +3,67 [+3,53, +3,79] | +2,57 [+2,46, +2,67] | −0,01 [−0,08, +0,06] |
| verticale − nessun controllo | +2,18 [+2,07, +2,29] | +0,58 [+0,50, +0,66] | +0,02 [−0,04, +0,07] |
| **orizzontale − verticale** | **+1,49 [+1,39, +1,58]** | **+1,99 [+1,90, +2,07]** | −0,02 [−0,09, +0,05] |

Falsi allarmi con competenze diffuse (nessun legame zona-competenza): test
corretto **5–7%** nei tre scenari; test della V25 26–33% in questo mondo.
La fattibilità dei piani non cambia fra i regimi (circa 96% nella base).

## Cosa mostrano i numeri

1. **Il test corretto rispetta il livello dichiarato**: falsi allarmi al 5–7%
   invece del 26–33% del test della V25, e rileva sempre i casi veri.
2. **A parità di persone aggiunte, l'allargamento orizzontale è migliore del
   verticale**, come ipotizzato: scendere nella stessa graduatoria porta dentro
   altre persone dello stesso gruppo.
3. **Con un gruppo in conflitto grande la differenza è decisiva.** Il verticale
   quasi non serve (indice da 0,23 a 0,17; +0,6 di benessere per la
   maggioranza): i successivi in graduatoria sono ancora del gruppo. L'orizzontale
   riporta la ripartizione sotto la parte proporzionale (indice −0,04) e
   recupera 2,6 punti.
4. **Con competenze diffuse nessuna regola cambia nulla**, e il test scatta solo
   per caso, al livello dichiarato.
5. Anche con l'orizzontale resta un divario rispetto al voto eguale sugli
   obiettivi (la maggioranza sta meglio con il voto eguale: −29,7 contro −31,8
   nel mondo al 15%). L'allargamento a 202 votanti riduce il problema, non lo
   annulla.

## Limiti

- La ripartizione fra zone è un esempio semplice di "azioni verso un gruppo";
  benefici indiretti e prestanome non sono modellati.
- Le discipline vicine (urbanistica, politiche sociali) hanno, per costruzione,
  competenti in gruppi diversi da quelli dei tecnici: è questo che rende utile
  l'allargamento orizzontale. Nella realtà la mappa delle discipline vicine va
  costruita e verificata.
- Si allarga una sola volta; un secondo giro, se l'indice resta alto, non è
  ancora provato.

## File e riproduzione

- `simulazione_dpa_v26.py` — test corretto, gruppo grande, residenza,
  allargamenti a parità di dimensione. Derivato dalla V25.
- `test_dpa_v26.py` — 5 test, tra cui i falsi allarmi con elettorati casuali.
- `risultati/` — `dettaglio.csv`, `riepilogo.csv`, `confronti_accoppiati.csv`,
  `parametri.json`.

```bash
cd democrazia-ponderata-adattiva/v26_dpa_test_corretto
python -m pip install -r requirements.txt
python test_dpa_v26.py
python simulazione_dpa_v26.py --mondi 200
```
