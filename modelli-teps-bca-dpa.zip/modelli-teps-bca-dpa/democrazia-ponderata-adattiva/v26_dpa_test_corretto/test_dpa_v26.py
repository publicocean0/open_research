# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test DPA V26. Esecuzione: python test_dpa_v26.py"""
import numpy as np

import simulazione_dpa_v26 as s


def test_falsi_allarmi_del_test_corretto():
    """Elettorati casuali: il test corretto scatta al massimo nel 5% circa dei casi,
    anche quando la ripartizione segue la loro composizione."""
    rng = np.random.default_rng(0)
    zona = rng.integers(0, s.ZONE, 600)
    positivi = 0
    prove = 200
    for _ in range(prove):
        vot = rng.choice(600, 101, replace=False)
        alloc = s.ripartizione(zona, vot, np.ones(len(vot)))
        p = s.test_composizione(zona, vot, rng)
        ia = s.indice_autoattribuzione(zona, alloc, vot)
        positivi += (p < s.LIVELLO_TEST) and ia > 0
    assert positivi / prove <= 0.09


def test_rileva_elettorato_concentrato():
    rng = np.random.default_rng(1)
    zona = np.r_[np.zeros(150, int), rng.integers(1, s.ZONE, 450)]
    vot = np.arange(101)                                    # tutti dalla zona 0
    alloc = s.ripartizione(zona, vot, np.ones(101))
    assert s.test_composizione(zona, vot, rng) < s.LIVELLO_TEST
    assert s.indice_autoattribuzione(zona, alloc, vot) > 0


def test_gruppo_grande():
    md, _ = s.prepara(2626, 0, "base", "concentrate_grande")
    assert abs((md.pop.gruppo == "tecnico").mean() - s.QUOTA_GRUPPO_GRANDE) < 0.01


def test_residenza_segue_il_gruppo_di_origine():
    md, _ = s.prepara(2626, 0, "esperti_corrotti", "diffuse")
    corr = md.pop.gruppo == "corrotti"
    # nel mondo diffuso i "corrotti" sono persone qualsiasi: non abitano in blocco nella zona 0
    assert (md.zona[corr] == 0).mean() < 0.6


def test_determinismo():
    assert s.esegui_mondo(2626, 1, "shock", "concentrate_grande") == \
        s.esegui_mondo(2626, 1, "shock", "concentrate_grande")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK", t.__name__)
    print(f"OK DPA V26: {len(tests)} test superati")
