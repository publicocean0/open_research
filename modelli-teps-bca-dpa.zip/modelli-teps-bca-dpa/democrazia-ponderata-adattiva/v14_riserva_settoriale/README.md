# V14 — Apprendimento della riserva settoriale e guasti correlati

**Stato:** esperimento computazionale sintetico, non validazione di una costituzione democratica. Il modello economico/tecnico e le preferenze dei 300 elettori per mondo sono artificiali.

Questa versione estende le V11–V13. Gli obiettivi finali e le metriche sono **considerati già votati** e non sono alterati durante la simulazione. La scelta delle strategie e le revisioni fuori mandato restano sottoposte a voto **ponderato per competenza pertinente**, nello stesso elettorato sintetico delle versioni precedenti.

## Domanda sperimentale

> Apprendere rischio e correlazioni tra guasti e vincolare separatamente la spesa anticipata per settore migliora gli esiti rispetto a una riserva globale di 7,5 unità?

Il test confronta tre metodi sui medesimi mondi:

1. `V13_tetto_globale`: riserva globale, due rami già approvati (normale e shock ipotetico soltanto sulle rinnovabili). Lo stesso motore V13 delle versioni precedenti.
2. `V14_shock_appreso`: tetto globale invariato, ma ramo di emergenza progettato su un **guasto congiunto multicomponente** ricavato da episodi di addestramento sintetici.
3. `V14_riserva_settoriale`: stesso ramo di emergenza appreso, con **tetti separati** alla spesa dei primi due periodi per rinnovabili, reti, accumuli ed efficienza.

I piani comprendono quattro interventi **simultanei e interdipendenti** per sei periodi. I primi due periodi sono identici nei rami e irrevocabili dopo l'esecuzione. Si rispettano il budget totale, i tetti di periodo, i limiti di stress delle reti e i due target tecnici fissati. Nuove proposte per la parte non eseguita sono rivotate se escono dal mandato condizionale originale. Compensazioni tra gruppi a saldo zero e costi amministrativi restano come nel simulatore V11–V13.

## Definizione della riserva settoriale

Se `c_i` è il costo unitario e `X[t,i]` l'intensità dell'intervento, per il metodo 3:

\[
\sum_{t=0}^{1}c_i X[t,i] \le C_i,\quad i=1,\dots,4,
\qquad \sum_i C_i=7.5.
\]

Non si creano risorse: i `C_i` ripartiscono il medesimo tetto iniziale e possono lasciare una parte del tetto globale inutilizzata se i vincoli tecnici lo impongono. Il budget totale resta 26. La politica non è una riserva monetaria segregata: è spazio di attuazione futura nei diversi ambiti.

Gli `score_i` derivano da perdite attese e covarianze tra settori osservate nel training:

\[
\mathrm{score}_i=(1-\bar f_i)\,a_i+
1.8\sum_j\max(\operatorname{Cov}(1-f_i,1-f_j),0)\,a_j.
\]

I punteggi condizionano l'allocazione dei tetti `C_i`. I coefficienti `a_i`, `1.8` e il fattore di riserva `0.32` sono **euristiche scelte nel programma**, non ottimizzate su dati reali o validate. Questo è uno dei limiti più importanti del risultato.

## Separazione training/valutazione

- Training: 320 episodi di shock sintetici con seed fissato **83171**, non derivati dalle 24 società usate nel confronto. Vengono apprese frequenza degli shock, perdite medie e matrice di covarianza.
- Validazione: 24 mondi sintetici con elettorati deterministici, sei scenari per ciascun mondo. Cinque scenari appartengono a **famiglie di shock già contemplate dal generatore del training** ma impiegano istanze di valutazione separate: non costituiscono vera validazione fuori distribuzione.
- Scenario `rischio_non_addestrato`: danni a reti, accumuli ed efficienza senza perdita nelle rinnovabili; non appartiene alle famiglie del training, ed è quindi una prova di generalizzazione più severa.
- Dopo lo shock si assume **misurazione perfetta** della produttività effettiva ai fini della revisione: il programma non simula ritardi di sensori o errore della misura post-evento.

## Risultati principali (24 mondi per scenario)

| Scenario | V13 globale | V14 shock appreso | V14 riserva settoriale |
|---|---:|---:|---:|
| Stabile | 24 | 24 | 24 |
| Singolo | 24 | 24 | 24 |
| Doppio moderato | 24 | 24 | 24 |
| Doppio grave | 24 | 24 | 24 |
| Triplo estremo | 0 | 0 | 0 |
| Rischio non addestrato | 24 | 24 | 24 |

Numero di programmi inizialmente approvati e con target + vincoli effettivi raggiunti alla scadenza. Percentuali di successo identiche, **nessun vantaggio dimostrato nel successo finale**.

### Differenze nel processo

- `doppio_moderato`: la V13 deve ottenere 24 approvazioni di correzioni durante l'attuazione, mentre entrambi i metodi V14 hanno un ramo di emergenza già valido **senza bisogno di nuovi voti**. L'autorizzazione democratica non viene omessa: è stata conferita inizialmente.
- `doppio_grave`: tutti i metodi richiedono 24 nuove correzioni approvate.
- `rischio_non_addestrato`: i nuovi voti scendono da 24 (V13) a 13 (V14 shock appreso) e 16 (V14 settoriale).
- `stabile`: beneficio intermedio normalizzato medio 0.7854 (V13), 0.7818 (V14 shock appreso) e **0.7266** (V14 settoriale).
- La spesa dei primi due periodi vale 7.5 unità in V13 e V14 shock appreso, **6.611** in V14 settoriale. Il rallentamento può essere socialmente costoso anche quando i target finali sono raggiunti.
- Nel `triplo_estremo` nessun metodo raggiunge entrambi gli obiettivi rispettando tutti i vincoli. Il metodo V14 settoriale aumenta l'indice dei benefici intermedi, ma non va conteggiato come successo.

La stessa matrice delle preferenze, delle competenze e dei vincoli tecnici è applicata ai diversi metodi nello stesso mondo. Non si attribuisce automaticamente un miglioramento alla rete dove non emerge dai dati. Gli intervalli bootstrap nei CSV derivano da ricampionamenti **accoppiati per mondo**, non costituiscono validazione statistica su società reali.

## Incertezze e difetti del prototipo

- Il generatore ha correlazioni introdotte artificialmente; l'algoritmo ha accesso a un campione ottenuto *dallo stesso generatore*. Le correlazioni non sono evidenze empiriche.
- I pesi della preferenza civica e l'algoritmo di compensazione sono sintetici. I voti su obiettivi e metriche delle versioni V3 non vengono rieseguiti: i target sono dati.
- I tetti settoriali apprendono una regola **euristica**, non una funzione ottima certificata. La perdita di beneficio nelle condizioni stabili mostra perché occorre un criterio di selezione che includa il costo del rinvio.
- L'ottimizzazione è SLSQP locale con tre inizializzazioni: un esito negativo non prova l'impossibilità matematica. Nessuna garanzia di ottimalità globale o sicurezza.
- Si assume che ogni shock sia rilevato correttamente dopo i primi due periodi. Gli shock reali possono persistere, migrare e avere effetti diversi dall'ipotesi moltiplicativa del modello.
- I sei scenari si ripetono nei medesimi mondi, quindi non sono 144 osservazioni indipendenti per metodo.

## Riproduzione

Python >=3.10; dipendenze: `numpy scipy matplotlib`.

La cartella V14 deve essere accanto a `v13_riserva_rischio`, `v12_resilienza_portafoglio`, `v11_negoziazione`.

```bash
cd democrazia-ponderata-adattiva/v14_riserva_settoriale
python simulazione_v14.py --test
python simulazione_v14.py --mondi 24
python analisi_v14.py
```

Contenuti `risultati/`: `dettaglio.csv`, `riepilogo.csv`, `confronti_accoppiati.csv`, `benefici_e_rivoti_accoppiati.csv`, `apprendimento.json`, grafici PNG. Tutti i seed, gli scenari e i pesi sono definiti nel codice.