#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Independent consistency checks for published V14 results and code."""
from __future__ import annotations
from pathlib import Path
import csv
import numpy as np
import simulazione_v14 as v

BASE=Path(__file__).resolve().parent

def test():
    v.test()
    with open(BASE/'risultati'/'dettaglio.csv',newline='',encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==24*3*6
    assert len({int(r['seed']) for r in rows})==24
    assert all(int(r['initial_approved']) for r in rows)
    for row in rows:
        assert int(row['success'])<=int(row['initial_approved'])
        assert int(row['recovered'])<=int(row['revote'])
        assert float(row['early_spend'])<=v.CAP+v.TOL
        assert abs(sum(__import__('json').loads(row['sector_early']))-float(row['early_spend']))<1e-4
        if row['method']=='V14_riserva_settoriale':
            risk=v.learn_risk(v.synthetic_training())
            assert np.all(np.array(__import__('json').loads(row['sector_early'])) <=risk.sector_caps+v.TOL)
    for scenario in v.TEST_SCENARIOS:
        subset=[r for r in rows if r['scenario']==scenario]
        assert len(subset)==24*3
        bymethod={m:sum(int(r['success']) for r in subset if r['method']==m) for m in v.METHODS}
        assert len(set(bymethod.values()))==1
    moderate=[r for r in rows if r['scenario']=='doppio_moderato']
    revotes={m:sum(int(r['recovered']) for r in moderate if r['method']==m) for m in v.METHODS}
    assert revotes['V13_tetto_globale']==24
    assert revotes['V14_shock_appreso']==0
    assert revotes['V14_riserva_settoriale']==0
    print('OK V14: 432 esiti, voto ponderato, caps, target, nessuna falsa approvazione, risultati auditabili')

if __name__=='__main__':test()