#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V14 - Riserva settoriale appresa, interventi paralleli e ricorso a rivoto.

Ricerca sintetica: il training osserva SOLO shock storici simulati, indipendenti
(altri seed) dai mondi di valutazione. Obiettivi e metriche dati gia' votati.
Non si usa lo shock futuro nella deliberazione; lo shock realizzato viene
rilevato dopo 2 periodi ed eventuali cambi fuori mandato sono rivotati.

Confronto nello STESSO modello/risolutore:
- V13: tetto 7.5, shock ipotetico solo sulle rinnovabili (baseline storico);
- V14_g: shock correlato appreso, tetto 7.5 soltanto globale;
- V14_s: shock correlato appreso e vincoli di riserva per ogni settore.
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
from pathlib import Path
from dataclasses import dataclass
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'v13_riserva_rischio'))
import simulazione_v13 as v13
v12=v13.v12
p=v13.p
v11=v13.v11

CAP=7.5
PREFIX=v12.PREFIX
METHODS=('V13_tetto_globale', 'V14_shock_appreso', 'V14_riserva_settoriale')
TOL=v12.TOL
TEST_SCENARIOS={
    'stabile':np.array([1.,1.,1.,1.]),
    'singolo':np.array([.60,1.,1.,1.]),
    'doppio_moderato':np.array([.60,.75,1.,1.]),
    'doppio_grave':np.array([.45,.50,.80,1.]),
    'triplo_estremo':np.array([.25,.35,.60,1.]),
    'rischio_non_addestrato':np.array([1.,.42,.62,.69]),
}
PRIOR=np.array([.60,.10,.12,.12,.06])
PRIOR_LABELS=('stabile','singolo','doppio_moderato','doppio_grave','triplo_estremo')

@dataclass
class LearnedRisk:
    probability:float
    conditional_mean:np.ndarray
    covariance:np.ndarray
    proxy_stress:np.ndarray
    scores:np.ndarray
    sector_caps:np.ndarray
    holdout_indices:tuple


def synthetic_training(n=320, seed=83171):
    """Training synthetic past events, never the future evaluation scenarios."""
    rng=np.random.default_rng(seed)
    events=[]
    kinds=rng.choice(len(PRIOR),size=n,p=PRIOR)
    for k in kinds:
        ref=TEST_SCENARIOS[PRIOR_LABELS[k]].copy()
        if k:
            # noisy correlated severity but independent of evaluation worlds
            shared=rng.normal(0,0.035)
            ref=np.minimum(1.,np.maximum(.20,ref+shared+rng.normal(0,0.02,4)))
        events.append(ref)
    return np.array(events)


def learn_risk(train:np.ndarray, reserve_strength=0.32)->LearnedRisk:
    shock=np.any(train[:,:3]<0.945,axis=1)
    observed=train[shock]
    if len(observed)<10:raise ValueError('Dati insufficienti per stimare lo shock')
    probability=float(np.mean(shock))
    conditional_mean=np.mean(observed,axis=0)
    deficits=1.-observed
    covariance=np.cov(deficits,rowvar=False)
    # A correlated hypothetical adverse scenario; not a prediction of a future event.
    proxy_stress=np.clip(np.quantile(observed,0.30,axis=0),0.28,1.0)
    # Sector exposure: lost productive capacity * contribution to objectives +
    # cross-sector covariance: correlated outages increase the score.
    importance=np.array([1.12,0.63,0.75,0.55])
    correlation_term=np.maximum(covariance,0)@importance
    scores=np.clip((1.-conditional_mean)*importance+1.8*correlation_term,0.005,None)
    # Higher risk -> reserve more future implementation in that sector.
    # Shares apply to the 7.5-unit early expenditure (fixed across methods).
    reserved_bias=scores/np.mean(scores)
    allocation=np.clip(1.0-reserve_strength*(reserved_bias-1.),.50,1.50)
    shares=allocation/np.sum(allocation)
    sector_caps=CAP*shares
    return LearnedRisk(probability,conditional_mean,covariance,proxy_stress,scores,sector_caps,tuple(np.where(shock)[0]))


_SOLVE_CACHE={}

def solve_policy(prod0, risk:LearnedRisk, per_sector:bool=False, style='costo'):
    """Two-branch joint optimisation on a learned multi-sector shock scenario.

    x_normal[:2] == x_stress[:2] is enforced by construction. No future truth.
    Global and (optionally) sector-specific early spending caps. The sector caps
    sum to CAP so per-sector allocation does not add spending capacity.
    """
    shock_productivity=prod0*risk.proxy_stress
    key=(tuple(np.round(prod0,6)),tuple(np.round(risk.proxy_stress,6)),
         float(round(risk.probability,6)),per_sector,style,
         tuple(np.round(risk.sector_caps,6)))
    if key in _SOLVE_CACHE:
        ans=_SOLVE_CACHE[key]
        return None if ans is None else tuple(np.copy(x) for x in ans)
    early=PREFIX*p.K
    tail=(p.T-PREFIX)*p.K
    size=early+2*tail
    extra=1+p.K if per_sector else 1
    def unpack(z):
        shared=z[:early].reshape(PREFIX,p.K)
        a=np.vstack((shared,z[early:early+tail].reshape(p.T-PREFIX,p.K)))
        b=np.vstack((shared,z[early+tail:].reshape(p.T-PREFIX,p.K)))
        return a,b
    def restrictions(x,prod):
        g=v12.inequalities(x,prod,reserve=CAP)
        if per_sector:
            sector_spending=np.sum(x[:PREFIX]*p.COSTS[None,:],axis=0)
            g=np.r_[g,risk.sector_caps-sector_spending]
        return g
    def jac_restrictions(x,prod):
        g=v12.inequalities_jac(x,prod,reserve=CAP)
        if per_sector:
            additional=np.zeros((p.K,p.T,p.K))
            for k in range(p.K):additional[k,:PREFIX,k]=-p.COSTS[k]
            g=np.vstack((g,additional.reshape(p.K,-1)))
        return g
    prob=risk.probability
    def obj(z):
        a,b=unpack(z)
        return ((1-prob)*v12.schedule_objective(a,style)
                +prob*v12.schedule_objective(b,style)
                +0.035*np.sum((a[PREFIX:]-b[PREFIX:])**2))
    def jobj(z):
        a,b=unpack(z)
        ga=(1-prob)*v12.schedule_grad(a,style)
        gb=prob*v12.schedule_grad(b,style)
        delta=a[PREFIX:]-b[PREFIX:]
        ga[PREFIX:]+=0.07*delta
        gb[PREFIX:]-=0.07*delta
        return np.r_[(ga[:PREFIX]+gb[:PREFIX]).ravel(),ga[PREFIX:].ravel(),gb[PREFIX:].ravel()]
    def ineq(z):
        a,b=unpack(z)
        return np.r_[restrictions(a,prod0),restrictions(b,shock_productivity)]
    def jineq(z):
        a,b=unpack(z)
        j1=jac_restrictions(a,prod0);j2=jac_restrictions(b,shock_productivity)
        out=np.zeros((len(j1)+len(j2),size))
        out[:len(j1),:early]=j1[:,:early]
        out[:len(j1),early:early+tail]=j1[:,early:]
        out[len(j1):,:early]=j2[:,:early]
        out[len(j1):,early+tail:]=j2[:,early:]
        return out
    best=None
    for fill in (0.28,0.46,0.60):
        base=np.full((p.T,p.K),fill)
        if per_sector:
            e=base[:PREFIX]*p.COSTS
            for k in range(p.K):
                share=risk.sector_caps[k]/max(e[:,k].sum(),1e-8)
                base[:PREFIX,k]*=min(1.0,0.96*share)
        bad=base.copy()
        bad[PREFIX:,2]=np.clip(bad[PREFIX:,2]*1.35,0.,1.)
        z=np.r_[base[:PREFIX].ravel(),base[PREFIX:].ravel(),bad[PREFIX:].ravel()]
        res=minimize(obj,z,jac=jobj,method='SLSQP',bounds=[(0.,1.)]*size,
                     constraints=[{'type':'ineq','fun':ineq,'jac':jineq}],
                     options={'ftol':2e-7,'maxiter':155})
        if np.min(ineq(res.x)) < -TOL:continue
        a,b=unpack(res.x)
        val=obj(res.x)
        if best is None or val<best[0]:best=(val,a,b)
    answer=None if best is None else (best[1],best[2])
    _SOLVE_CACHE[key]=answer
    return None if answer is None else tuple(np.copy(x) for x in answer)


def choose_policy(seed:int,method:str,risk:LearnedRisk,conflict=False):
    world,prod0=v12.world_for_seed(seed,'conflitto_shock' if conflict else 'shock')
    if method=='V13_tetto_globale':
        world,prod0,pol,reason=v13.choose_policy(seed,CAP,risk.probability,conflict)
        return world,prod0,pol,reason
    sector=(method=='V14_riserva_settoriale')
    options=[]
    proxy=prod0*risk.proxy_stress
    for style in ('costo','rateizzazione'):
        result=solve_policy(prod0,risk,per_sector=sector,style=style)
        if result is None:continue
        normal,stressed=result
        assert np.allclose(normal[:PREFIX],stressed[:PREFIX])
        for transfer in v11.transfers(world,normal,True):
            if not(v11.feasible(normal,prod0,world,transfer)
                   and v11.feasible(stressed,proxy,world,transfer)):continue
            cost_fee=v11.transfer_admin(world,transfer)
            if (p.economic_cost(normal)+cost_fee>p.TOTAL_BUDGET+TOL
                or p.economic_cost(stressed)+cost_fee>p.TOTAL_BUDGET+TOL):continue
            share=v12.weighted_policy_vote(world,normal,stressed,prod0,proxy,transfer,
                                           risk=risk.probability)
            if share<=0.5:continue
            expected_cost=(1-risk.probability)*p.economic_cost(normal)+risk.probability*p.economic_cost(stressed)+cost_fee
            options.append(v12.Policy(normal,stressed,transfer,share,expected_cost,
                                       float(np.sum((normal@p.COSTS)[:PREFIX])),method,True))
    if not options:return world,prod0,None,'nessuna_proposta_approvata_o_fattibile'
    return world,prod0,min(options,key=lambda z:z.expected_cost),'approvata'


def evaluate_policy(world,prod0,policy,truth_factor):
    # All initial plans and ballots selected without access to truth_factor.
    prod=prod0*truth_factor
    if policy is None:
        return dict(initial_approved=0,success=0,branch_feasible=0,
                    recovered=0,revote=0,reason='non_approvata',
                    delivered_service=0.,early_spend=0.,sector_early=[0.]*p.K)
    fee=v11.transfer_admin(world,policy.transfer)
    stable=np.allclose(truth_factor,1.)
    branch=policy.normal if stable else policy.stressed
    branch_ok=v13.actually_feasible(branch,prod,fee)
    final=branch
    recovered=False;voted=False
    reason='ramo_autorizzato' if branch_ok else 'correzione_non_trovata'
    if not branch_ok:
        executed=np.zeros_like(branch)
        executed[:PREFIX]=branch[:PREFIX]
        # Real state becomes observable after executing these periods.
        candidate=v13.fast_recovery(prod,executed,branch)
        if (candidate is not None and
                np.array_equal(candidate[:PREFIX],executed[:PREFIX]) and
                v13.actually_feasible(candidate,prod,fee)):
            # Revision outside initial mandate MUST pass the competence-weighted vote.
            voted=v11.vote(world,candidate,prod,policy.transfer)>0.5
            if voted:
                final=candidate;recovered=True;reason='rivoto_approvato'
            else:
                reason='rivoto_respinto'
    feasible=v13.actually_feasible(final,prod,fee)
    success=int(bool(branch_ok or recovered) and feasible)
    assert np.allclose(final[:PREFIX],branch[:PREFIX])
    return dict(initial_approved=1,success=success,branch_feasible=int(branch_ok),
                recovered=int(recovered),revote=int(voted),reason=reason,
                delivered_service=float(v13.intermediate_benefit(final,prod)),
                early_spend=float(np.sum((final@p.COSTS)[:PREFIX])),
                sector_early=np.sum(final[:PREFIX]*p.COSTS[None,:],axis=0).tolist())


def run(n=24,train_n=320,conflict=False):
    train=synthetic_training(train_n)
    risk=learn_risk(train)
    results=[]
    for seed in range(n):
        for method in METHODS:
            world,prod0,policy,reason=choose_policy(seed,method,risk,conflict)
            for scenario,shock in TEST_SCENARIOS.items():
                outcome=evaluate_policy(world,prod0,policy,shock)
                outcome.update(seed=seed,method=method,scenario=scenario,
                               initial_reason=reason,world_conflict=int(conflict))
                outcome['sector_early']=json.dumps(np.round(outcome['sector_early'],5).tolist())
                results.append(outcome)
        print(f'world {seed+1}/{n}',flush=True)
    summary=[]
    for scenario in TEST_SCENARIOS:
        for method in METHODS:
            sub=[r for r in results if r['scenario']==scenario and r['method']==method]
            summary.append(dict(scenario=scenario,method=method,n=len(sub),
                                initial_approvals=sum(x['initial_approved'] for x in sub),
                                successes=sum(x['success'] for x in sub),
                                percentage=round(100*np.mean([x['success'] for x in sub]),1),
                                recovered_after_revote=sum(x['recovered'] for x in sub),
                                mean_service=round(float(np.mean([x['delivered_service'] for x in sub])),4),
                                early_spend=round(float(np.mean([x['early_spend'] for x in sub])),3)))
    return risk,results,summary


def paired_comparisons(rows,base='V13_tetto_globale',rep=5000):
    d=[]
    for scenario in TEST_SCENARIOS:
        a={r['seed']:r['success'] for r in rows if r['scenario']==scenario and r['method']==base}
        for other in METHODS:
            if other==base:continue
            b={r['seed']:r['success'] for r in rows if r['scenario']==scenario and r['method']==other}
            pairs=np.array([b[i]-a[i] for i in sorted(a)])
            rng=np.random.default_rng(20261107)
            boot=np.mean(rng.choice(pairs,size=(rep,len(pairs)),replace=True),axis=1)
            d.append(dict(scenario=scenario,baseline=base,alternative=other,n=len(pairs),
                          delta_pp=round(float(100*np.mean(pairs)),2),
                          boot95_low=round(float(100*np.quantile(boot,.025)),2),
                          boot95_high=round(float(100*np.quantile(boot,.975)),2),
                          wins=int(np.sum(pairs>0)),losses=int(np.sum(pairs<0))))
    return d


def save_csv(path,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        wr.writeheader();wr.writerows(rows)


def test():
    train=synthetic_training(320,83171)
    r=learn_risk(train)
    assert np.all(r.proxy_stress<=1.)
    assert np.all(r.sector_caps>0) and np.isclose(np.sum(r.sector_caps),CAP)
    assert len(set(np.round(r.sector_caps,2)))>1,'Riserva non diversificata per settore'
    assert 0.<r.probability<1.
    assert np.any(np.triu(r.covariance[:3,:3],1)!=0),'Mancano shock correlati'
    w,prod,pol,why=choose_policy(0,'V14_shock_appreso',r)
    assert pol is not None,why
    assert pol.weighted_vote>.5
    assert np.allclose(pol.normal[:PREFIX],pol.stressed[:PREFIX])
    assert np.sum((pol.normal@p.COSTS)[:PREFIX])<=CAP+TOL
    sector_result=solve_policy(prod,r,True,'costo')
    if sector_result is not None:
        a,b=sector_result
        early=np.sum(a[:PREFIX]*p.COSTS[None,:],axis=0)
        assert np.all(early<=r.sector_caps+TOL)
        assert np.array_equal(a[:PREFIX],b[:PREFIX])
    for sc in (TEST_SCENARIOS['stabile'],TEST_SCENARIOS['doppio_grave']):
        out=evaluate_policy(w,prod,pol,sc)
        assert out['success']<=out['initial_approved']
        assert not out['recovered'] or out['revote']==1
    # Training does not depend on evaluation seed or choice of future scenario.
    assert np.array_equal(train,synthetic_training(320,83171))
    print('OK V14: dati indipendenti, correlazioni, budget settoriale, atti paralleli, mandato e rivoto')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--test',action='store_true')
    parser.add_argument('--mondi',type=int,default=24)
    parser.add_argument('--training',type=int,default=320)
    parser.add_argument('--conflitto',action='store_true')
    parser.add_argument('--output',default=str(HERE/'risultati'))
    args=parser.parse_args()
    if args.test:
        test();return
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    r,rows,summary=run(args.mondi,args.training,args.conflitto)
    save_csv(out/'dettaglio.csv',rows)
    save_csv(out/'riepilogo.csv',summary)
    save_csv(out/'confronti_accoppiati.csv',paired_comparisons(rows))
    (out/'apprendimento.json').write_text(json.dumps(dict(probability=r.probability,
          conditional_mean=r.conditional_mean.tolist(),covariance=r.covariance.tolist(),
          stress_sintetico=r.proxy_stress.tolist(),risk_scores=r.scores.tolist(),
          caps_settoriali=r.sector_caps.tolist(),training_n=args.training),indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()