#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Report di confronti accoppiati sui risultati V14 senza assumere indipendenza intra-mondo."""
import argparse
import csv
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent

def read_csv(f):
    with open(f,newline='',encoding='utf8') as h:return list(csv.DictReader(h))

def save_csv(path,rows):
    with open(path,'w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)

def report(rows):
    v=[]
    methods=('V13_tetto_globale','V14_shock_appreso','V14_riserva_settoriale')
    for scenario in sorted(set(r['scenario'] for r in rows)):
        by_method={m:{int(r['seed']):r for r in rows if r['scenario']==scenario and r['method']==m} for m in methods}
        assert all(by_method[m].keys()==by_method[methods[0]].keys() for m in methods)
        for m in methods[1:]:
            x=[(by_method[methods[0]][s],by_method[m][s]) for s in sorted(by_method[methods[0]])]
            r_d=np.array([int(y['recovered'])-int(z['recovered']) for z,y in x])
            b_d=np.array([float(y['delivered_service'])-float(z['delivered_service']) for z,y in x])
            rng=np.random.default_rng(14501)
            boots=np.mean(rng.choice(b_d,size=(3000,len(b_d)),replace=True),axis=1)
            v.append(dict(scenario=scenario,confronto=m,n=len(x),
                rivoti_in_meno=int(-np.sum(r_d)),
                delta_beneficio=round(float(np.mean(b_d)),5),
                beneficio_ci95_basso=round(float(np.quantile(boots,.025)),5),
                beneficio_ci95_alto=round(float(np.quantile(boots,.975)),5)))
    return v

def charts(rows,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    methods=('V13_tetto_globale','V14_shock_appreso','V14_riserva_settoriale')
    scenarios=('stabile','singolo','doppio_moderato','doppio_grave','triplo_estremo','rischio_non_addestrato')
    figures=[('delivered_service','Benefici erogati durante il programma (indice 0–1)','benefici_intermedi.png'),
             ('recovered','Correzioni approvate con nuovo voto su 24 societa','rivoti_post_shock.png')]
    for key,ylabel,filename in figures:
        fig,ax=plt.subplots(figsize=(10,5))
        xx=np.arange(len(scenarios))
        for j,m in enumerate(methods):
            yy=[]
            for sc in scenarios:
                subset=[r for r in rows if r['scenario']==sc and r['method']==m]
                vals=[float(r[key]) for r in subset]
                yy.append(np.mean(vals) if key=='delivered_service' else np.sum(vals))
            ax.bar(xx+(j-1)*.26,yy,width=.26,label=m.replace('_',' '))
        ax.set_xticks(xx,[s.replace('_','\n') for s in scenarios])
        ax.set_ylabel(ylabel)
        ax.set_title('V14 — Confronto accoppiato su 24 mondi sintetici')
        ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(out/filename,dpi=150)
        fig.savefig(out/filename.replace('.png', '.svg'))
        plt.close(fig)

def main():
    a=argparse.ArgumentParser()
    a.add_argument('--input',default=str(HERE/'risultati'/'dettaglio.csv'))
    ns=a.parse_args()
    rows=read_csv(ns.input)
    dest=Path(ns.input).parent
    save_csv(dest/'benefici_e_rivoti_accoppiati.csv',report(rows))
    charts(rows,dest)
    print('OK: grafici e confronti appaiati salvati in',dest)

if __name__=='__main__':main()