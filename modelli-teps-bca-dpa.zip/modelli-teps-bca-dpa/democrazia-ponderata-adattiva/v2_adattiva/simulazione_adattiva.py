#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DNA v2: apprendimento online delle esternalita' + retropropagazione + rivoto.

Estensione COMPATIBILE con simulazione.py (v1): decisioni tramite enactment,
1 cittadino = 1 voto, confronto con lo stato quo, conferma tecnica sul modello
stimato. NON usa esiti reali durante il processo deliberativo.

Usa un modello sintetico ricorrente g_t(x) = g_base(x) + theta_t @ phi(x).
Il valutatore conosce theta_t, ma gli algoritmi apprendono soltanto dalle
osservazioni rumorose delle politiche effettivamente messe in atto e da
piccoli progetti pilota effettuati dopo il voto.
"""
from __future__ import annotations
import argparse
import csv
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import numpy as np

# Reuse the existing deliberation/vote model unchanged.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import simulazione as prior

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

CTR = np.array([8.0, 1.7, 1.7]); RANGE=np.array([3.0,2.5,2.5])
DIM = 4                 # Intercept + normalized coefficients, 4 domains.
BASE = prior.Model(np.zeros(4),np.zeros((4,3)))
EVAL_POINTS=np.array([[h,w,t] for h in (6.3,7.5,9.,10.)
                        for w,t in ((.2,.2),(1.2,1.2),(2.4,2.4))])
METHODS=('Fisso','Fisso + cautela','Adattivo','Adattivo + cautela')


def phi(x):
    return np.r_[1.,(np.asarray(x)-CTR)/RANGE]


def as_model(theta):
    """Convert g_base + theta phi into the old Model(shift, slope) API."""
    sl=np.asarray(theta)[:,1:]/RANGE[None,:]
    sh=np.asarray(theta)[:,0]-sl@CTR
    return prior.Model(sh,sl)


@dataclass
class OnlineRLS:
    # RLS/Bayesian filter; P is parameter-error covariance for each domain.
    mu: np.ndarray                 # shape (4,4)
    P: np.ndarray                  # shape (4,4,4)
    noise: float = .13
    forgetting: float = .992
    robust: bool = True
    observations: int = 0

    @classmethod
    def from_panel(cls, theta_panel, uncertainty=.43, noise=.13,
                   forgetting=.992, robust=True):
        # Initial uncertainty is PRIOR information, not knowledge of theta_true.
        diag=np.array([1.,.8,.8,.8])*uncertainty**2
        p=np.repeat(np.diag(diag)[None,:,:],4,axis=0)
        return cls(theta_panel.copy(),p,noise,forgetting,robust,0)

    def predictor(self):
        return as_model(self.mu)

    def sd(self, x):
        f=phi(x)
        return np.sqrt(np.maximum(np.einsum('i,kij,j->k',f,self.P,f),0))

    def update(self, x, observed_g):
        # e.g., monitoring water, transport, budget, environmental consequences
        f=phi(x)
        y=np.asarray(observed_g)-BASE.g(x)
        for k in range(4):
            Pk=self.P[k]/self.forgetting
            pf=Pk@f
            denom=self.noise**2+f@pf
            innovation=y[k]-self.mu[k]@f
            # Constrain corrupt-outlier influence; a large real regime shift
            # may also be mistakenly clipped (explicitly evaluated below).
            if self.robust:
                cap=3.5*np.sqrt(denom)
                innovation=np.clip(innovation,-cap,cap)
            gain=pf/denom
            self.mu[k]=self.mu[k]+gain*innovation
            self.P[k]=Pk-np.outer(pf,pf)/denom
            self.P[k]=.5*(self.P[k]+self.P[k].T)
        self.observations+=1


def world(rng,scenario,episodes):
    """Simulated unknown physics / material constraints across decisions."""
    # Expert observations share an unobserved common bias component.
    initial=rng.normal(0.,.17,(4,4))
    initial[:,0]+=rng.normal(0.,.10,4)
    deltas=np.zeros((episodes,4,4))
    if scenario in ('cambiamento','osservazioni_distorte'):
        # Known by the evaluator only; *not* preannounced to the learners.
        # Post-change: worsening in water, improvement in transport etc.
        shock=np.zeros((4,4))
        shock[0]=[.48,.22,-.09,.06]
        shock[1]=[-.26,-.1,.19,.06]
        shock[2]=[.16,.04,.02,.02]
        shock[3]=[.22,.06,-.04,-.07]
        deltas[episodes//2:]=shock
    theta=np.repeat(initial[None,:,:],episodes,axis=0)+deltas
    # Panel imperfectly estimates initial environment; persistent systematic bias.
    panel=initial+rng.normal(0.,.40,(4,4))
    return theta,panel


def get_voters(rng,n):
    return prior.citizens(rng,n,awareness=1.)


def predictor_for(method,base_panel,learners,voters,z=1.15):
    if method=='Fisso':
        return as_model(base_panel)
    learner=learners.get(method)
    if learner is None:
        learner=OnlineRLS.from_panel(base_panel)
    pred=learner.predictor()
    if method in ('Fisso + cautela','Adattivo + cautela'):
        # Conservative constraint at a reference area around the planned policy.
        # Coverage is a heuristic, not a certified robust chance constraint.
        sig=learner.sd(voters.mean_ideal)
        pred=prior.Model(pred.shift+z*sig,pred.slope)
    return pred


def true_eval(x,truth):
    residual=truth.g(x)
    return bool(np.max(residual)<=1.e-5),float(np.max(np.maximum(residual,0)))


def model_rmse(pred,truth):
    return float(np.sqrt(np.mean([(pred.g(x)-truth.g(x))**2 for x in EVAL_POINTS])))


def vote_policy(voters,estimate,margin=.16):
    # Existing protocol: 4 sectoral votes, Jacobian feedback, global rollback,
    # full popular ratification; outcome not used to select the proposal.
    return prior.enactment(voters,estimate,margin=margin,global_rollback=True)


def episode_run(seed,scenario,episodes,n,margin=.16,use_pilots=True):
    rng=np.random.default_rng(seed)
    true_seq, panel=world(rng,scenario,episodes)
    learners={method:OnlineRLS.from_panel(panel) for method in METHODS if method.startswith('Adattivo')}
    rows=[]
    for t in range(episodes):
        voters=get_voters(rng,n)
        true_model=as_model(true_seq[t])
        # Freeze observation perturbations before running the methods;
        # all strategies face matched noise and exogenous random world.
        monitor_noise=rng.normal(0.,.12,4)
        contaminated=(scenario=='osservazioni_distorte' and rng.random()<.15)
        if contaminated:
            monitor_noise+=rng.normal(0.,.85,4)
        # Optional policy pilot measures independently of an enacted decision;
        # only available AFTER the decision of the current round.
        pilot=use_pilots and (t%5==4)
        pilot_x=np.clip(np.array([6.9, .7, .8])+rng.normal(0.,[.3,.25,.25]),prior.LOW,prior.HIGH)
        pilot_noise=rng.normal(0.,.12,4)
        for method in METHODS:
            estimate=predictor_for(method,panel,learners,voters)
            result=vote_policy(voters,estimate,margin)
            passed=bool(result['enacted'])
            actually_feasible,violation=true_eval(result['x'],true_model)
            # Do not call unenacted, theoretically feasible proposals successes.
            enacted_good=passed and actually_feasible
            enacted_bad=passed and not actually_feasible
            # Observable policy: if enacted measure policy, else status quo.
            experienced=result['x'] if passed else prior.STATUS_QUO
            observed_g=true_model.g(experienced)+monitor_noise
            # Utility loss relative to citizen ideals; NOT a rights guarantee.
            individual=np.sum(voters.issue_weights*(result['x']-voters.ideals)**2,axis=1)
            grouped=np.array_split(np.sort(individual),5)
            estimate_mean = learners[method].predictor() if method in learners else as_model(panel)
            rows.append({'scenario':scenario,'seed':seed,'t':t,'metodo':method,
                'approvata':int(passed),'approvata_fattibile':int(enacted_good),
                'approvata_non_fattibile':int(enacted_bad),
                'violazione':violation if passed else 0.,
                'violazione_potenziale':violation,
                'errore_previsione':model_rmse(estimate_mean,true_model),
                'errore_predizione_operativa':model_rmse(estimate,true_model),
                'voti_emendamento':result['accepted_revotes'],
                'rivoto_globale':int(result['rollback_used']),
                'mancata_approvazione':int(not passed),
                'insoddisfazione_media':float(individual.mean()) if passed else float('nan'),
                'insoddisfazione_peggiore_quintile':float(grouped[-1].mean()) if passed else float('nan')})
            if method in learners:
                learners[method].update(experienced,observed_g)
                if pilot:
                    learners[method].update(pilot_x,true_model.g(pilot_x)+pilot_noise)
    return rows


def run_trials(seeds,scenario,episodes,n,margin,use_pilots=True):
    # Deliberation code reads these caps only through prior.Model methods.
    prior.BUDGET_CAP,prior.ECO_CAP=(85.,4.5) if scenario=='vincoli_stretti' else (100.,5.)
    out=[]
    for seed in range(seeds):
        out.extend(episode_run(7000+seed,scenario,episodes,n,margin,use_pilots=use_pilots))
    return out


def write_csv(path,rows):
    if not rows:return
    with open(path,'w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        writer.writeheader();writer.writerows(rows)


def aggregate(rows):
    results=[]
    for scen in dict.fromkeys(r['scenario'] for r in rows):
        for m in METHODS:
            subset=[r for r in rows if r['scenario']==scen and r['metodo']==m]
            n=len(subset)
            enacted=[r for r in subset if r['approvata']]
            summary={'scenario':scen,'metodo':m,'decisioni':n,
                'promulgate_pct':100*sum(r['approvata'] for r in subset)/n,
                'promulgate_fattibili_pct':100*sum(r['approvata_fattibile'] for r in subset)/n,
                'promulgate_non_fattibili_pct':100*sum(r['approvata_non_fattibile'] for r in subset)/n,
                'errori_fra_promulgate_pct':100*sum(r['approvata_non_fattibile'] for r in subset)/max(len(enacted),1),
                'errore_tecnico_rmse':np.mean([r['errore_previsione'] for r in subset]),
                'errore_operativo_rmse':np.mean([r['errore_predizione_operativa'] for r in subset]),
                'rivoti_accettati_media':np.mean([r['voti_emendamento'] for r in subset]),
                'insoddisfazione_media_condizionata':np.nanmean([r['insoddisfazione_media'] for r in enacted]) if enacted else np.nan,
                'insoddisfazione_peggior_quintile_condizionata':np.nanmean([r['insoddisfazione_peggiore_quintile'] for r in enacted]) if enacted else np.nan}
            results.append(summary)
    return results


def paired_ci(rows,scenario,comp='Adattivo'):
    # Bootstrap over independent simulation worlds, not individual episodes.
    pairs={}
    for r in rows:
        if r['scenario']!=scenario:continue
        pairs.setdefault(r['seed'],defaultdict(dict))[r['t']][r['metodo']]=r
    benefits=[]
    riskdiff=[]
    for seed,ts in pairs.items():
        benefits.append(np.mean([v[comp]['approvata_fattibile']-v['Fisso']['approvata_fattibile'] for v in ts.values()]))
        riskdiff.append(np.mean([v[comp]['approvata_non_fattibile']-v['Fisso']['approvata_non_fattibile'] for v in ts.values()]))
    rng=np.random.default_rng(2210)
    inds=rng.integers(0,len(benefits),(3000,len(benefits)))
    b=np.mean(np.asarray(benefits)[inds],axis=1)
    r=np.mean(np.asarray(riskdiff)[inds],axis=1)
    return {'scenario':scenario,'confronto':comp,'vantaggio_fattibili_pp':round(np.mean(benefits)*100,2),
       'ic95_vantaggio_inf_pp':round(np.quantile(b,.025)*100,2),'ic95_vantaggio_sup_pp':round(np.quantile(b,.975)*100,2),
       'delta_non_fattibili_pp':round(np.mean(riskdiff)*100,2),
       'ic95_non_fattibili_inf_pp':round(np.quantile(r,.025)*100,2),
       'ic95_non_fattibili_sup_pp':round(np.quantile(r,.975)*100,2)}


def charts(rows,out):
    plt.rcParams.update({'font.size':10})
    scenarios=list(dict.fromkeys(r['scenario'] for r in rows))
    fig,axes=plt.subplots(len(scenarios),1,figsize=(10,3.1*len(scenarios)),sharex=True)
    if len(scenarios)==1:axes=[axes]
    for ax,scen in zip(axes,scenarios):
        for m in METHODS:
            vals=[]
            max_t=max(r['t'] for r in rows if r['scenario']==scen)
            for t in range(max_t+1):
                arr=[r for r in rows if r['scenario']==scen and r['metodo']==m and r['t']<=t and r['t']>=max(t-5,0)]
                vals.append(np.mean([r['approvata_fattibile'] for r in arr]))
            ax.plot(range(max_t+1),vals,label=m,linewidth=1.8)
        ax.set_title('Scenario: '+scen);ax.set_ylim(0,1.04)
        ax.set_ylabel('Decisioni fattibili e approvate')
        ax.grid(alpha=.2)
        if scen in ('cambiamento','osservazioni_distorte'):ax.axvline((max_t+1)//2,color='gray',ls=':',alpha=.5)
    axes[0].legend(loc='lower right',fontsize=8)
    axes[-1].set_xlabel('Iterazione (media mobile di 6 decisioni)')
    fig.tight_layout();fig.savefig(out/'esito_nel_tempo.png',dpi=155);plt.close(fig)
    fig,axes=plt.subplots(1,len(scenarios),figsize=(5.6*len(scenarios),3.8),sharey=True)
    if len(scenarios)==1:axes=[axes]
    for ax,scen in zip(axes,scenarios):
        for m in METHODS:
            T=max(r['t'] for r in rows if r['scenario']==scen)
            a=[np.mean([r['errore_previsione'] for r in rows if r['scenario']==scen and r['metodo']==m and r['t']==t]) for t in range(T+1)]
            ax.plot(range(T+1),a,label=m)
        ax.set_title(scen);ax.grid(alpha=.2)
        ax.set_xlabel('Iterazione')
        if scen in ('cambiamento','osservazioni_distorte'):ax.axvline((T+1)//2,color='gray',ls=':',alpha=.5)
    axes[0].set_ylabel('Errore previsionale (RMSE)')
    axes[-1].legend(loc='upper right',fontsize=8)
    fig.tight_layout();fig.savefig(out/'apprendimento_stime.png',dpi=155);plt.close(fig)


def checks():
    # Geometric identity, Jacobian and update sanity check.
    rng=np.random.default_rng(12)
    theta=rng.normal(size=(4,4))
    for _ in range(15):
        x=rng.uniform(prior.LOW,prior.HIGH)
        assert np.max(np.abs(as_model(theta).g(x)-(BASE.g(x)+theta@phi(x))))<1e-10
        eps=1e-5
        numeric=np.column_stack([(as_model(theta).g(x+eps*np.eye(3)[j])-as_model(theta).g(x-eps*np.eye(3)[j]))/(2*eps) for j in range(3)])
        assert np.max(np.abs(numeric-as_model(theta).jac(x)))<1e-8
    learner=OnlineRLS.from_panel(np.zeros((4,4)),uncertainty=.6,noise=.08,forgetting=1.)
    actual=np.tile(np.array([.3,.25,-.1,.15]),(4,1))
    initial=np.linalg.norm(learner.mu-actual)
    for t in range(250):
        x=rng.uniform(prior.LOW,prior.HIGH)
        learner.update(x,as_model(actual).g(x)+rng.normal(0,.08,4))
    assert np.linalg.norm(learner.mu-actual)<.25
    assert np.linalg.norm(learner.mu-actual)<initial
    # Learning should not change the constitutional one-citizen-one-vote test.
    voters=prior.citizens(rng,200,1.)
    yes,share=prior.pairwise(voters,BASE,voters.mean_ideal,prior.STATUS_QUO,list(range(4)))
    assert isinstance(yes,bool) and 0<=share<=1
    print('Test superati: equivalenza modello, Jacobiano, apprendimento RLS, voto.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mondi',type=int,default=30,help='repliche indipendenti')
    p.add_argument('--episodi',type=int,default=40,help='decisioni successive per mondo')
    p.add_argument('--cittadini',type=int,default=550)
    p.add_argument('--margine',type=float,default=.16)
    p.add_argument('--scenario',choices=('tutti','stabile','cambiamento','osservazioni_distorte','vincoli_stretti'),default='tutti')
    p.add_argument('--output',default='v2_adattiva/risultati')
    p.add_argument('--senza-pilota',action='store_true',help='disabilita osservazioni sperimentali periodiche')
    p.add_argument('--test',action='store_true')
    a=p.parse_args()
    checks()
    if a.test:return
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    scenarios=('stabile','cambiamento','osservazioni_distorte','vincoli_stretti') if a.scenario=='tutti' else (a.scenario,)
    all_rows=[]
    for s in scenarios:
        rows=run_trials(a.mondi,s,a.episodi,a.cittadini,a.margine,use_pilots=not a.senza_pilota)
        all_rows.extend(rows)
        print(f'Scenario {s}: '+str({r['metodo']:round(r['promulgate_fattibili_pct'],1) for r in aggregate(rows)}),flush=True)
    summary=aggregate(all_rows)
    write_csv(out/'risultati_dettagliati.csv',all_rows)
    write_csv(out/'riepilogo.csv',summary)
    ci=[paired_ci(all_rows,s,comp) for s in scenarios for comp in METHODS[1:]]
    write_csv(out/'intervalli_bootstrap.csv',ci)
    charts(all_rows,out)
    print('Output in',out)
    for r in summary:
        print(r)
    print('Comparazioni',ci)

if __name__=='__main__':main()