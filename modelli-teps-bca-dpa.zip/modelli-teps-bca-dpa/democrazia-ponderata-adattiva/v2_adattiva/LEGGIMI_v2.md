# Democrazia Neurale Adattiva — simulatore Python v2

## Stato del progetto

**Prototipo computazionale esplorativo, non validazione empirica, non modello di governo pronto all'uso.**

Questa versione estende `../simulazione.py` (v1) con la capacità di imparare gli effetti delle decisioni nel tempo. Il procedimento rimane: proposta iniziale → vincoli dei quattro ambiti → retropropagazione con Jacobiano → alternative → rivoto → eventuale rivoto globale → ratifica. Ogni cittadino ha un voto. L'apprendimento modifica **solo le stime delle conseguenze tecniche**, non i voti espressi e non i diritti.

Quattro ambiti: acqua, trasporti, bilancio, ambiente; tre parametri: numero di abitazioni, investimento idrico, investimento trasporti.

## Modello matematico

Si assume, come sistema *sintetico*, una relazione interdisciplinare con effetti in parte sconosciuti:

```
g_k,t(x) = g_k,base(x) + theta_k,t^T phi(x)
phi(x)   = [1, (h - 8)/3, (w - 1.7)/2.5, (t - 1.7)/2.5]
```

Il pannello tecnico iniziale conosce una stima perturbata `theta_panel`, non il modello effettivo `theta_true`. Dopo l'attuazione di una legge, sono osservati i quattro residui del progetto attuato con rumore. Se la proposta non viene attuata, si osservano le conseguenze dello status quo. Ogni cinque episodi, nel test principale, un esperimento informativo sintetico fornisce una seconda osservazione dopo la decisione (pilotaggio, non misura prima del voto).

Il filtro RLS aggiorna la stima per ogni ambito `k`:

```
e      = y - g_base(x) - theta_hat^T phi(x)
K      = P phi / (sigma^2 + phi^T P phi)
theta' = theta_hat + K * clip(e, -3.5*sigma_predict, +3.5*sigma_predict)
P'     = P / forgetting - P phi phi^T P / (forgetting * (sigma^2 * forgetting + phi^T P phi))
```

Nel codice la matrice `P` viene incrementata con il fattore di forgetting `0.992`, consentendo di apprendere lentamente un cambio di regime. Il rumore strumentale sintetico ha deviazione standard `0.12`, mentre il filtro presuppone `0.13`.

La variante prudente non tratta la stima come certezza. Per ogni ambito somma un sovramargine tecnico:

```
g_conservativo,k(x) = g_stimato,k(x)
                    + 1.15 * sqrt(phi(x_ref)^T P_k phi(x_ref))
```

**Limite:** `x_ref` è la proposta media dei cittadini; la copertura non è una garanzia probabilistica valida su tutte le proposte possibili. Un vincolo reale può comunque essere violato.

Il feedback interdisciplinare sulle proposte rimane quello di v1:

```
b(x) = J(x)^T max(0, g(x))
```

Sono ancora i cittadini a votare le alternative generate e a ratificare una proposta. Le conseguenze realmente osservate entrano nell'apprendimento **soltanto dopo** il voto, evitando l'uso improprio di informazioni future nella simulazione.

## Esperimento e comparatori

- **Fisso:** modello tecnico iniziale, senza apprendimento.
- **Fisso + cautela:** stesso modello fisso con il medesimo criterio iniziale di cautela.
- **Adattivo:** RLS sulle osservazioni successive, senza cautela aggiuntiva.
- **Adattivo + cautela:** RLS con stima dell'incertezza tecnica e margine dinamico.

24 mondi indipendenti, ciascuno con 36 decisioni successive e 500 cittadini per episodio; **864 decisioni per metodo per scenario**. I quattro metodi vedono le stesse preferenze politiche, il medesimo ambiente effettivo e il medesimo rumore esogeno, ma raccolgono osservazioni diverse quando attuano politiche diverse. Queste sono repliche **sintetiche**, non un sondaggio.

Quattro scenari:

1. `stabile`: vincoli invariati.
2. `cambiamento`: a metà sequenza cambia un insieme di coefficienti fisici e tecnici.
3. `osservazioni_distorte`: come il cambio di regime, più alterazioni rumorose del 15% delle osservazioni.
4. `vincoli_stretti`: riduzione del bilancio massimo e del limite ambientale.

## Risultati: proposte attuate e rispettose dei vincoli reali

| Scenario | Fisso | Fisso + cautela | Adattivo | Adattivo + cautela |
|---|---:|---:|---:|---:|
| Stabile | 50,9% | 100,0% | 97,8% | **100,0%** |
| Cambiamento | 36,1% | 89,6% | 56,4% | **98,7%** |
| Osservazioni distorte | 36,0% | 89,6% | 52,1% | **98,1%** |
| Vincoli stretti | 41,0% | 100,0% | 97,3% | **100,0%** |

**Importante:** in questi particolari esperimenti praticamente tutte le proposte sono promulgate dopo il rivoto; la metrica qui rappresenta quindi soprattutto la verifica *ex post* della fattibilità tecnica, non una prova di qualità democratica o di capacità di gestire lo stallo politico. La distinzione tra `approvata` e `approvata_fattibile` resta esplicitamente nel CSV.

Confronto accoppiato **Adattivo + cautela rispetto a Fisso + cautela**, con bootstrap per mondo indipendente (24 cluster, 5.000 ricampionamenti nel file aggiuntivo):

| Scenario | Differenza di attuazioni valide | Riduzione della distanza media dagli ideali dei cittadini |
|---|---:|---:|
| Stabile | 0 punti percentuali | 1,04 unità |
| Cambiamento | +9,14 punti percentuali | 0,97 unità |
| Osservazioni distorte | +8,56 punti percentuali | 0,91 unità |
| Vincoli stretti | 0 punti percentuali | 1,46 unità |

L'indicatore di distanza è un costo politico quadratico sintetico, **non** un valore di benessere misurato sulla popolazione reale. In questo esperimento l'apprendimento consente in generale di essere meno conservativi (più vicini agli ideali) e, nel cambio di regime, di correggere le previsioni del modello fisso. I casi con stime adattive ma senza cautela mostrano che ridurre l'errore medio non basta a evitare attuazioni tecnicamente invalide.

I dettagli, inclusi gli intervalli bootstrap e le traiettorie, sono in `risultati/`.

## Esecuzione

```bash
python -m pip install numpy scipy matplotlib
python v2_adattiva/simulazione_adattiva.py --test
python v2_adattiva/simulazione_adattiva.py --mondi 24 --episodi 36 --cittadini 500 --output v2_adattiva/risultati
python v2_adattiva/analisi_aggiuntiva.py v2_adattiva/risultati
```

Lanciare dalla cartella `democrazia-ponderata-adattiva/`, che contiene `simulazione.py`. Le prove sono deterministiche per lo stesso seed e le stesse versioni delle librerie. Per escludere i mini-esperimenti informativi periodici si aggiunge `--senza-pilota`. Tutti i nomi delle variabili e le condizioni iniziali sono nel sorgente.

## Limiti e test prioritari

- I veri coefficienti sono nello **stesso spazio parametrico** di quelli da apprendere: questo favorisce RLS. Non significa capacità generale di comprendere una società reale.
- Il feedback osservabile è relativamente ricco, tempestivo e ben definito; nella realtà gli effetti di una legge sono ritardati, confusi da altri fattori e soggetti a inferenza causale.
- Mancano gruppi strategici, lobbismo, disinformazione deliberata persistente, censura, mass media, apprendimento endogeno dei cittadini e modifiche strutturali causate dalle stesse politiche.
- Gli errori grossolani introdotti sono rumori casuali, non attacchi coordinati intelligenti.
- Sono solo quattro ambiti e tre scelte continue; non si affrontano decisioni discrete né vere norme costituzionali.
- La misura sintetica della peggiore quinta parte dei votanti non garantisce la tutela delle minoranze.
- L'avversione politica è codificata dal modellatore. Tutte le decisioni votate finiscono approvate nei casi principali: manca ancora un buon test di dissenso e blocco politico.
- Le soglie di prudenza (1.15) e gli altri iperparametri sono illustrate e non stabilite da un protocollo esterno preregistrato.

**Conclusione circoscritta:** esiste una implementazione verificabile di apprendimento delle relazioni interdisciplinari + retropropagazione tecnica + rivoto democratico; alcune configurazioni rendono il sistema simulato più sicuro e meno costoso in termini di distanza dagli ideali. Non esiste ancora una dimostrazione di superiorità democratica o di stabilità teorica generale.

## Ablazione: apprendimento senza piccoli esperimenti pilota

Per separare le osservazioni dalle decisioni attuate dalle informazioni fornite da esperimenti sintetici esterni, è stata eseguita anche una simulazione accoppiata **senza piloti**, con 12 dei 24 mondi dello scenario `cambiamento` (36 episodi, 500 cittadini). Gli scenari, i seed e il rumore sono identici al sottoinsieme corrispondente del test principale.

| Metodo | Con piloti: approvate e fattibili | Senza piloti: approvate e fattibili | Errore tecnico medio con / senza piloti |
|---|---:|---:|---:|
| Fisso | 53,9% | 53,9% | 0,521 / 0,521 |
| Fisso + cautela | 91,7% | 91,7% | 0,521 / 0,521 |
| Adattivo | 55,8% | 56,0% | 0,271 / 0,359 |
| Adattivo + cautela | 98,6% | 100,0% | 0,279 / 0,378 |

**Interpretazione:** apprendere soltanto dalle politiche attuate è possibile, ma senza informazioni pilota il modello ricostruisce peggio gli effetti tecnici medi. L'indicatore di sicurezza non è monotono in questo piccolo campione; perciò l'uso dei piloti non può essere giustificato dalle sole percentuali di proposte valide. Un disegno sperimentale reale dovrebbe anche valutare la sicurezza e la liceità delle prove pilota.