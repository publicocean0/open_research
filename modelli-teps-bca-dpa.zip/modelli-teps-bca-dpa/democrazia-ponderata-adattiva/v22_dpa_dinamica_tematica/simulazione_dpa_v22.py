# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""DPA V22 — Democrazia Ponderata Adattiva dinamica e tematica.

Correzione rispetto alla V21: il voto ponderato e' **per tema**, vincoli
compresi, e **non tutti votano su tutto**.

* Vincoli (acqua, trasporti, bilancio, ambiente): vota chi e' competente in
  quel dominio; il peso dipende dalla competenza in quel dominio (con tetto).
* Obiettivi (abitazioni, rete idrica, trasporti): vota chi e' interessato al
  tema; il peso dipende dalla competenza rilevante per quel tema (con tetto).
* Diritto universale (servizio minimo di trasporto): votano tutti, voto uguale.

Dinamica nel tempo (10 periodi): i limiti reali si spostano, puo' arrivare uno
shock, i piani cambiano solo gradualmente (inerzia). Un monitoraggio misura i
limiti reali dopo ogni periodo; nel regime dinamico si rivota solo il tema che
il monitoraggio segnala, e chi ha stimato male perde peso (storico delle
previsioni).

Simulazione su popolazioni sintetiche: non e' una prova dell'efficacia di un
ordinamento reale.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import linprog, minimize

QUI = Path(__file__).resolve().parent
sys.path.insert(0, str(QUI.parent / "v21_dpa_raffinata"))
import simulazione_v21 as d21  # noqa: E402
from simulazione_v21 import mediana_pesata, peso_v21  # noqa: E402

PERIODI = 10
MARGINE = 0.5             # margine di certificazione (V21: 0,15 era insufficiente)
INERZIA = 2.0             # variazione massima di ogni variabile per periodo
DERIVA = 0.12             # passeggiata casuale dei limiti reali
SHOCK = 1.2               # caduta del limite di un dominio al periodo 5 (scenario shock)
PERIODO_SHOCK = 5
STATO_INIZIALE = np.array([4.0, 3.0, 3.0])
SOGLIA_ESPERTO = 0.65
SOGLIA_INTERESSE = 1.0    # importanza minima per votare su un obiettivo
W_MAX = 3.0
ERRORE_LAICO = (0.8, 0.4)  # errore sistematico comune dei non esperti (ottimismo)
ERRORE_MODELLO = 0.2       # errore comune a tutti, nuovo a ogni periodo
RUMORE_MONITORAGGIO = 0.15
SOGLIA_RIVOTO = 0.35
# rilevanza dei domini (acqua, trasporti, bilancio, ambiente) per ciascun obiettivo
PARAMETRI_SCENARIO = {"errore_laico": ERRORE_LAICO}
RILEVANZA = np.array([[.3, .3, .2, .2],     # abitazioni
                      [.6, .0, .4, .0],     # rete idrica
                      [.0, .6, .2, .2]])    # trasporti

SCENARI = ("base", "esperti_corrotti", "competenze_gonfiate", "shock")
REGIMI = ("uguale_tutti", "ponderato_tutti", "tematico_senza_peso", "tematico", "tematico_dinamico",
          "tematico_una_volta", "tecnico")


# ---------------------------------------------------------------------------
# Mondo dinamico
# ---------------------------------------------------------------------------
class MondoDinamico:
    def __init__(self, seed, indice, scenario):
        base = "base" if scenario == "shock" else scenario
        self.m = d21.crea_mondo(seed, indice, base)
        self.pop = self.m.pop
        rng = np.random.default_rng([seed, indice, 500 + SCENARI.index(scenario)])
        n = self.pop.n
        passi = rng.normal(0, DERIVA, (PERIODI, 4))
        passi[0] = 0
        self.b = self.m.b + np.cumsum(passi, 0)                 # limiti reali per periodo
        self.dominio_shock = int(rng.integers(0, 4))
        if scenario == "shock":
            self.b[PERIODO_SHOCK:, self.dominio_shock] -= SHOCK
        self.errore_laico = rng.normal(*PARAMETRI_SCENARIO["errore_laico"], 4)
        self.errore_modello = rng.normal(0, ERRORE_MODELLO, (PERIODI, 4))
        self.z = rng.normal(size=(PERIODI, n, 4))
        self.monitor = rng.normal(0, RUMORE_MONITORAGGIO, (PERIODI, 4))
        self.A = self.m.A
        self.diritto = bool(self.pop.sostegno_diritto.mean() > 0.5)   # voto uguale per teste

    def stime(self, t):
        """Stima del limite di ogni dominio fatta da ciascun cittadino."""
        p = self.pop
        return (self.b[t][None, :] + (1 - p.c_vera) * (self.errore_laico[None, :] + 1.0 * self.z[t])
                + self.errore_modello[t][None, :] + p.allentamento_b[:, None])


# ---------------------------------------------------------------------------
# Votazioni per tema
# ---------------------------------------------------------------------------
def elettorato_vincolo(regime, c, k):
    """Chi vota sul vincolo k e con quale peso."""
    n = c.shape[0]
    if regime == "uguale_tutti":
        return np.arange(n), np.ones(n)
    if regime == "ponderato_tutti":
        return np.arange(n), peso_v21(c.mean(1), W_MAX)
    idx = np.where(c[:, k] >= SOGLIA_ESPERTO)[0]
    if len(idx) < 5:
        idx = np.argsort(c[:, k])[-5:]
    if regime == "tematico_senza_peso":
        return idx, np.ones(len(idx))
    return idx, peso_v21(c[idx, k], W_MAX)


def elettorato_obiettivo(regime, c, omega, j):
    n = c.shape[0]
    if regime == "uguale_tutti":
        return np.arange(n), np.ones(n)
    if regime == "ponderato_tutti":
        return np.arange(n), peso_v21(c.mean(1), W_MAX)
    idx = np.where(omega[:, j] >= SOGLIA_INTERESSE)[0]
    if regime == "tematico_senza_peso":
        return idx, np.ones(len(idx))
    return idx, peso_v21(c[idx] @ RILEVANZA[j], W_MAX)


def vota_obiettivi(regime, pop, c):
    if regime == "tecnico":   # ottimo utilitarista, senza voto
        W = pop.omega.sum(0)
        return (pop.omega * pop.ideale).sum(0) / W, W / pop.n, 0
    tau, W, schede = np.zeros(3), np.zeros(3), 0
    for j in range(3):
        idx, w = elettorato_obiettivo(regime, c, pop.omega, j)
        tau[j] = mediana_pesata(pop.ideale[idx, j], w)
        W[j] = pop.omega[idx, j].sum() / pop.n
        schede += len(idx)
    return tau, W, schede


# ---------------------------------------------------------------------------
# Piano del periodo: vicino agli obiettivi votati, entro i limiti certificati
# ---------------------------------------------------------------------------
def piano(tau, W, A, b_cert, x_prec, t_min):
    lb = np.maximum(0.0, x_prec - INERZIA)
    ub = np.minimum(15.0, x_prec + INERZIA)
    if t_min is not None:
        lb[2] = min(max(lb[2], t_min), ub[2])
    bounds = list(zip(lb, ub))
    res = linprog(np.zeros(3), A_ub=A, b_ub=b_cert, bounds=bounds, method="highs")
    if res.status != 0:
        # impossibile secondo le stime entro l'inerzia: minima violazione
        c = np.r_[np.zeros(3), np.ones(4)]
        A_ub = np.hstack([A, -np.eye(4)])
        r2 = linprog(c, A_ub=A_ub, b_ub=b_cert, bounds=bounds + [(0, None)] * 4, method="highs")
        return r2.x[:3], "impossibile_stimato"
    fun = lambda x: float((W * (x - tau) ** 2).sum())
    jac = lambda x: 2 * W * (x - tau)
    cons = [{"type": "ineq", "fun": lambda x: b_cert - A @ x, "jac": lambda x: -A}]
    migliore = res.x
    for s in (np.clip(tau, lb, ub), res.x):
        r = minimize(fun, s, jac=jac, bounds=bounds, constraints=cons, method="SLSQP",
                     options={"ftol": 1e-12, "maxiter": 300})
        x = np.clip(r.x, lb, ub)
        if np.max(A @ x - b_cert) <= 1e-7 and fun(x) < fun(migliore):
            migliore = x
    return migliore, "adottato"


# ---------------------------------------------------------------------------
# Esecuzione di un mondo
# ---------------------------------------------------------------------------
def esegui_regime(md: MondoDinamico, regime: str, gruppo_sorvegliato: str):
    pop = md.pop
    n = pop.n
    c = pop.c_cert.copy()
    sq_err, n_err = np.zeros((n, 4)), np.zeros((n, 4))
    t_min = md.m.t_min if md.diritto else None
    x = STATO_INIZIALE.copy()
    b_cert = np.zeros(4)
    ultima_stima = {}
    schede = n          # voto sul diritto, uguale per tutti, al periodo 0
    tau = W = None
    righe_t = []
    quota_iniziale = quota_finale = np.nan
    for t in range(PERIODI):
        # --- calibrazione con il monitoraggio del periodo precedente (regime dinamico)
        if regime == "tematico_dinamico" and t > 0:
            b_oss = md.b[t - 1] + md.monitor[t - 1]
            for k, (idx, rep) in ultima_stima.items():
                sq_err[idx, k] += (rep - b_oss[k]) ** 2
                n_err[idx, k] += 1
            rmse = np.sqrt(sq_err / np.maximum(n_err, 1))
            fiducia = np.ones((n, 4))
            for k in range(4):
                visti = n_err[:, k] > 0
                if visti.any():
                    rif = np.median(rmse[visti, k])
                    fiducia[visti, k] = np.exp(-np.maximum(0, rmse[visti, k] - rif) / 0.4)
            c = pop.c_cert * fiducia
        # --- quali temi si votano in questo periodo
        if regime == "tematico_una_volta":
            vincoli = range(4) if t == 0 else []
            obiettivi = t == 0
        elif regime == "tematico_dinamico":
            if t <= 1:
                vincoli = range(4)
            else:
                b_oss = md.b[t - 1] + md.monitor[t - 1]
                vincoli = [k for k in range(4) if abs(b_oss[k] - (b_cert[k] + MARGINE)) > SOGLIA_RIVOTO]
            obiettivi = t == 0
        else:
            vincoli, obiettivi = range(4), True
        stime = md.stime(t)
        ultima_stima = {}
        for k in vincoli:
            idx, w = elettorato_vincolo(regime, c, k)
            b_cert[k] = mediana_pesata(stime[idx, k], w) - MARGINE
            ultima_stima[k] = (idx, stime[idx, k])
            schede += len(idx)
            if k == 2:   # quota di peso del gruppo sorvegliato nel voto sul bilancio
                quota = w[pop.gruppo[idx] == gruppo_sorvegliato].sum() / w.sum()
                quota_finale = quota
                if np.isnan(quota_iniziale):
                    quota_iniziale = quota
        if obiettivi:
            tau, W, s = vota_obiettivi(regime, pop, c)
            schede += s
        x, stato = piano(tau, W, md.A, b_cert, x, t_min)
        g = md.A @ x - md.b[t]
        pref = d21.preferenza(pop, x[None, :])[:, 0]
        righe_t.append({"fattibile": float(np.max(g) <= 1e-9), "violazione": float(np.maximum(0, g).sum()),
                        "benessere": float(pref.mean()),
                        "benessere_minoranza": float(pref[pop.gruppo == "minoranza"].mean()),
                        "peggior_gruppo": float(min(pref[pop.gruppo == gname].mean()
                                                    for gname in np.unique(pop.gruppo))),
                        "impossibile": float(stato == "impossibile_stimato"),
                        "rivotati": len(list(vincoli))})
    media = {k: float(np.mean([r[k] for r in righe_t])) for k in righe_t[0]}
    dopo = [r for i, r in enumerate(righe_t) if i >= PERIODO_SHOCK]
    media.update({"fattibile_dopo_5": float(np.mean([r["fattibile"] for r in dopo])),
                  "violazione_dopo_5": float(np.mean([r["violazione"] for r in dopo])),
                  "schede_per_periodo": schede / PERIODI,
                  "quota_sorvegliato_primo_voto": quota_iniziale,
                  "quota_sorvegliato_ultimo_voto": quota_finale})
    return media


def esegui_mondo(seed, indice, scenario):
    md = MondoDinamico(seed, indice, scenario)
    sorv = {"esperti_corrotti": "corrotti", "competenze_gonfiate": "lobby"}.get(scenario, "tecnico")
    if sorv == "corrotti":
        md.pop.gruppo = md.pop.gruppo.copy()
        md.pop.gruppo[md.pop.corrotto] = "corrotti"   # etichetta solo per le misure
    righe = []
    for regime in REGIMI:
        r = esegui_regime(md, regime, sorv)
        righe.append({"mondo": indice, "scenario": scenario, "regime": regime,
                      "diritto_adottato": int(md.diritto), "gruppo_sorvegliato": sorv, **r})
    return righe


METRICHE = ("fattibile", "violazione", "fattibile_dopo_5", "violazione_dopo_5", "benessere",
            "benessere_minoranza", "peggior_gruppo", "impossibile", "schede_per_periodo",
            "rivotati", "quota_sorvegliato_primo_voto", "quota_sorvegliato_ultimo_voto")


def riepiloga(righe, seed):
    rng = np.random.default_rng([seed, 22])
    rie, conf = [], []
    for s in SCENARI:
        per = {g: [r for r in righe if r["scenario"] == s and r["regime"] == g] for g in REGIMI}
        for g, rr in per.items():
            out = {"scenario": s, "regime": g, "mondi": len(rr)}
            for k in METRICHE:
                v = np.array([r[k] for r in rr], float)
                v = v[~np.isnan(v)]
                mu, lo, hi = d21.ic_bootstrap(v, rng, 2000)
                out.update({k: mu, k + "_ic_basso": lo, k + "_ic_alto": hi})
            rie.append(out)
        for rif in ("uguale_tutti", "ponderato_tutti", "tematico_senza_peso", "tematico"):
            ref = {r["mondo"]: r for r in per[rif]}
            for k in ("fattibile", "violazione", "fattibile_dopo_5", "benessere",
                      "benessere_minoranza", "peggior_gruppo", "schede_per_periodo"):
                d = [r[k] - ref[r["mondo"]][k] for r in per["tematico_dinamico"]]
                mu, lo, hi = d21.ic_bootstrap(np.array(d), rng, 2000)
                conf.append({"scenario": s, "confronto": f"tematico_dinamico - {rif}", "metrica": k,
                             "differenza": mu, "ic95_basso": lo, "ic95_alto": hi})
        ref = {r["mondo"]: r for r in per["tematico_senza_peso"]}
        for k in ("fattibile", "violazione", "benessere", "benessere_minoranza", "peggior_gruppo"):
            d = [r[k] - ref[r["mondo"]][k] for r in per["tematico"]]
            mu, lo, hi = d21.ic_bootstrap(np.array(d), rng, 2000)
            conf.append({"scenario": s, "confronto": "tematico - tematico_senza_peso", "metrica": k,
                         "differenza": mu, "ic95_basso": lo, "ic95_alto": hi})
    return rie, conf


def main():
    ap = argparse.ArgumentParser(description="DPA V22 dinamica e tematica")
    ap.add_argument("--mondi", type=int, default=200)
    ap.add_argument("--seed", type=int, default=2222)
    ap.add_argument("--output", type=Path, default=QUI / "risultati")
    ap.add_argument("--errore-laico-medio", type=float, default=None,
                    help="sensibilita': errore sistematico medio dei non esperti (default 0,8)")
    ap.add_argument("--test", action="store_true")
    a = ap.parse_args()
    if a.errore_laico_medio is not None:
        PARAMETRI_SCENARIO["errore_laico"] = (a.errore_laico_medio, ERRORE_LAICO[1])
    mondi = 3 if a.test else a.mondi
    righe = [r for s in SCENARI for i in range(mondi) for r in esegui_mondo(a.seed, i, s)]
    rie, conf = riepiloga(righe, a.seed)
    a.output.mkdir(parents=True, exist_ok=True)
    d21.scrivi_csv(a.output / "dettaglio.csv", righe)
    d21.scrivi_csv(a.output / "riepilogo.csv", rie)
    d21.scrivi_csv(a.output / "confronti_accoppiati.csv", conf)
    (a.output / "parametri.json").write_text(json.dumps({
        "mondi": mondi, "seed": a.seed, "periodi": PERIODI, "margine": MARGINE, "inerzia": INERZIA,
        "deriva": DERIVA, "shock": SHOCK, "periodo_shock": PERIODO_SHOCK,
        "soglia_esperto": SOGLIA_ESPERTO, "soglia_interesse": SOGLIA_INTERESSE, "w_max": W_MAX,
        "errore_laico": PARAMETRI_SCENARIO["errore_laico"], "errore_modello": ERRORE_MODELLO,
        "rumore_monitoraggio": RUMORE_MONITORAGGIO, "soglia_rivoto": SOGLIA_RIVOTO,
        "rilevanza": RILEVANZA.tolist(), "regimi": REGIMI, "scenari": SCENARI},
        indent=2, ensure_ascii=False), encoding="utf-8")
    for r in rie:
        print(f"{r['scenario']:20s} {r['regime']:20s} fatt={r['fattibile']:.3f} viol={r['violazione']:.3f} "
              f"fatt5={r['fattibile_dopo_5']:.3f} ben={r['benessere']:.2f} min={r['benessere_minoranza']:.2f} "
              f"pegg={r['peggior_gruppo']:.2f} imp={r['impossibile']:.3f} schede={r['schede_per_periodo']:.0f} "
              f"q0={r['quota_sorvegliato_primo_voto']:.3f} qT={r['quota_sorvegliato_ultimo_voto']:.3f}")


if __name__ == "__main__":
    main()
