# Democrazia Ponderata Adattiva — V22 (dinamica e tematica)

Stato: **prototipo matematico su popolazioni sintetiche**. Non dimostra
l'efficacia di un ordinamento reale. Parametri fissati prima dell'esecuzione
(`risultati/parametri.json`).

## Correzione rispetto alla V21

Nella V21 tutti votavano sull'intero piano con un peso medio uguale per ogni
tema. Non è la DPA: **il voto ponderato è per tema, vincoli compresi, e non
tutti votano su tutto.** La V22 ripristina questa struttura e la rende dinamica
nel tempo. La conclusione della V21 «il peso del voto quasi non conta» riguarda
quella impostazione sbagliata, non la DPA.

## Struttura dei voti

| Tema | Chi vota | Peso |
|---|---|---|
| **Vincoli** (acqua, trasporti, bilancio, ambiente): limite certificato | chi è competente in quel dominio (competenza ≥ 0,65) | competenza in quel dominio, con tetto `w_max = 3` |
| **Obiettivi** (abitazioni, rete idrica, trasporti): livello desiderato | chi è interessato a quel tema (importanza ≥ 1) | competenza rilevante per quel tema, con tetto |
| **Diritto universale** (servizio minimo di trasporto) | tutti | uguale |

Il limite certificato è la mediana pesata delle stime dell'elettorato meno un
margine di 0,5. L'obiettivo è la mediana pesata dei livelli desiderati. Il piano
del periodo è il più vicino agli obiettivi votati (pesati per quanti li hanno a
cuore) entro i limiti certificati.

## Dinamica nel tempo

- 10 periodi; i limiti reali si spostano (passeggiata casuale); nello scenario
  `shock` un limite cade di 1,2 al periodo 5.
- **Inerzia:** ogni variabile può cambiare al massimo di 2 per periodo.
- **Monitoraggio:** dopo ogni periodo si misura il limite reale, con rumore.
- **Regime dinamico:** gli obiettivi si votano una volta. I vincoli si votano
  nei primi due periodi e poi **solo quando il monitoraggio segnala** uno
  scostamento. Chi ha stimato male perde peso (storico delle previsioni).
- Errori delle stime: i non esperti condividono un **errore sistematico comune**
  (ottimismo, in media +0,8 × (1 − competenza)); tutti condividono un errore di
  modello nuovo a ogni periodo. La sensibilità senza errore sistematico dei non
  esperti è riportata sotto.

## Regimi confrontati

| Regime | Descrizione |
|---|---|
| `uguale_tutti` | tutti votano su tutto ogni periodo, voto uguale |
| `ponderato_tutti` | tutti votano su tutto, peso medio (come la V21) |
| `tematico_senza_peso` | elettorati tematici, voto uguale al loro interno |
| `tematico` | elettorati tematici e pesi tematici, si rivota tutto ogni periodo |
| **`tematico_dinamico`** | elettorati e pesi tematici, monitoraggio, rivoto mirato, storico delle previsioni |
| `tematico_una_volta` | elettorati e pesi tematici, si vota solo all'inizio |
| `tecnico` | vincoli dagli esperti, obiettivi come ottimo utilitarista, nessun voto |

## Risultati (200 mondi per scenario)

Quota di periodi in cui il piano rispetta davvero i limiti:

| Regime | Base | Esperti corrotti | Competenze gonfiate | Shock | Schede per periodo |
|---|---:|---:|---:|---:|---:|
| Tutti, voto uguale | 62,1% | 50,2% | 64,5% | 61,2% | 4 260 |
| Tutti, peso medio (V21) | 69,5% | 48,2% | 70,8% | 70,3% | 4 260 |
| Tematico senza peso | 95,0% | 73,9% | 90,7% | 94,6% | 1 320 |
| Tematico | 95,5% | 74,0% | 91,4% | 95,3% | 1 320 |
| **Tematico dinamico** | **97,8%** | **95,5%** | **97,5%** | 95,5% | **≈ 240** |
| Tematico, una volta sola | 86,6% | 69,1% | 81,7% | 73,9% | 186 |
| Tecnico | 95,5% | 74,2% | 91,3% | 95,3% | 419 |

Differenze accoppiate (IC bootstrap 95%), tematico dinamico − altro regime:

| Scenario | − tutti, voto uguale | − tematico statico | Benessere della minoranza − tematico senza peso |
|---|---|---|---|
| Base | +35,6 punti [+31,5, +39,9] | +2,2 [+1,5, +3,0] | +0,79 [+0,72, +0,87] |
| Esperti corrotti | +45,3 [+40,9, +49,6] | **+21,4 [+19,0, +23,9]** | +0,52 [+0,42, +0,61] |
| Competenze gonfiate | +33,1 [+28,8, +37,4] | +6,2 [+4,9, +7,6] | **−1,08 [−1,30, −0,88]** |
| Shock (dopo il periodo 5) | +31,6 [+26,9, +36,3] | −1,4 [−3,2, +0,4] | +0,81 [+0,73, +0,89] |

Peso degli esperti corrotti nel voto sul bilancio: 35,8% al primo voto, **0%**
all'ultimo nel regime dinamico. Peso della lobby con competenze gonfiate: dal
39,2% al 20,9%.

### Sensibilità: i non esperti sbagliano solo a caso

Se si toglie l'errore sistematico comune dei non esperti, la "saggezza della
folla" funziona quasi altrettanto bene sui vincoli:

| Regime | Base | Esperti corrotti | Shock |
|---|---:|---:|---:|
| Tutti, voto uguale | 96,4% | 92,7% | 96,8% |
| Tematico | 98,9% | 93,1% | 99,3% |
| Tematico dinamico | 99,2% | **98,8%** | 97,0% |

## Cosa mostrano i numeri

1. **Far votare i vincoli a chi è competente conta molto, ma solo se i non
   esperti condividono un errore sistematico.** Con un ottimismo comune dei non
   esperti si passa dal 62% al 95% di piani fattibili. Se i non esperti
   sbagliano solo a caso, il vantaggio scende a 2,5 punti. L'esistenza e la
   dimensione di quell'errore comune nella realtà vanno misurate: è il punto
   empirico decisivo.
2. **La dinamica con lo storico delle previsioni è la difesa più forte contro
   la manipolazione.** Contro esperti corrotti porta i piani fattibili dal 74%
   al 95,5%, e al 98,8% anche senza errore dei non esperti. Il peso dei
   corrotti scende a zero. Contro la lobby dimezza il suo peso.
3. **Si vota molto meno.** Circa 240 schede per periodo contro 1 320 del
   tematico statico e 4 260 di "tutti su tutto": non tutti votano su tutto, e
   non tutto si rivota ogni volta.
4. **Il peso dentro l'elettorato tematico conta soprattutto sugli obiettivi, e
   la direzione dipende da chi è competente.** Sulla fattibilità vale mezzo
   punto. Sul benessere della minoranza vale +0,9 quando le competenze sono
   vere, −0,9 quando una lobby gonfia le proprie: il peso amplifica la qualità
   della certificazione delle competenze, nel bene e nel male.
5. **Decidere una volta sola non basta.** Senza monitoraggio la fattibilità
   scende all'87% nella base e al 58% dopo uno shock.

### Esiti negativi da conservare

- **Shock:** il regime dinamico reagisce con un periodo di ritardo, perché
  rivota solo dopo che il monitoraggio ha visto lo scostamento. Dopo lo shock è
  leggermente peggio del tematico che rivota tutto ogni periodo (−1,4 punti,
  intervallo che include lo zero; −4,9 senza errore dei non esperti).
- **Benessere:** i regimi più prudenti hanno un benessere medio un po' più
  basso (−1,9 rispetto a "tutti su tutto" nella base). Gran parte del benessere
  in più di "tutti su tutto" viene da piani che violano i limiti reali.
- **Tecnico ≈ tematico sui vincoli:** usa gli stessi esperti. La DPA si
  distingue dal tecnico sugli obiettivi (votati dagli interessati invece che
  calcolati) e, nel regime dinamico, per lo storico delle previsioni.

## Limiti

- Coefficienti dei vincoli noti; si stimano e si votano solo i limiti.
- La soglia di interesse e quella di competenza sono fissate, non votate; chi
  decide chi è competente è esso stesso un punto da garantire.
- Le preferenze non cambiano nel tempo; nessun comportamento strategico oltre ai
  due scenari di manipolazione.
- Gli esperti percepiscono subito il limite del periodo corrente (con errore):
  è un vantaggio per i regimi che rivotano spesso.
- Mandati condizionali e riserve delle V8–V16 non sono ancora riportati qui.

## File e riproduzione

- `simulazione_dpa_v22.py` — modello, regimi, scenari, riepiloghi.
- `test_dpa_v22.py` — 6 test: non tutti votano su tutto, peso per tema, inerzia
  e diritto, impossibilità stimata, storico contro i corrotti, determinismo.
- `risultati/` — `dettaglio.csv`, `riepilogo.csv`, `confronti_accoppiati.csv`,
  `parametri.json`; `risultati/sensibilita_errore_laico_0/` per la sensibilità.

```bash
cd democrazia-ponderata-adattiva/v22_dpa_dinamica_tematica
python -m pip install -r requirements.txt
python test_dpa_v22.py
python simulazione_dpa_v22.py --mondi 200
python simulazione_dpa_v22.py --mondi 200 --errore-laico-medio 0 --output risultati/sensibilita_errore_laico_0
```

Circa due minuti per batteria su una CPU. Usa funzioni della V21
(`../v21_dpa_raffinata/simulazione_v21.py`).
