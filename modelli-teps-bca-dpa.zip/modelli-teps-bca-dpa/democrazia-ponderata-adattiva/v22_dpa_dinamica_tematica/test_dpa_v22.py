# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test DPA V22. Esecuzione: python test_dpa_v22.py"""
import numpy as np

import simulazione_dpa_v22 as s


def test_non_tutti_votano_su_tutto():
    md = s.MondoDinamico(2222, 0, "base")
    c = md.pop.c_cert
    for k in range(4):
        idx, w = s.elettorato_vincolo("tematico", c, k)
        assert len(idx) < md.pop.n and np.all(c[idx, k] >= s.SOGLIA_ESPERTO)
        assert np.all(w >= 1) and np.all(w <= s.W_MAX)
    for j in range(3):
        idx, _ = s.elettorato_obiettivo("tematico", c, md.pop.omega, j)
        assert len(idx) < md.pop.n and np.all(md.pop.omega[idx, j] >= s.SOGLIA_INTERESSE)
    idx, w = s.elettorato_vincolo("uguale_tutti", c, 0)
    assert len(idx) == md.pop.n and np.all(w == 1)


def test_peso_tematico_dipende_dal_tema():
    md = s.MondoDinamico(2222, 1, "base")
    c = md.pop.c_cert
    _, w_acqua = s.elettorato_vincolo("tematico", c, 0)
    idx_a, _ = s.elettorato_vincolo("tematico", c, 0)
    assert np.allclose(w_acqua, s.peso_v21(c[idx_a, 0], s.W_MAX))


def test_inerzia_e_diritto():
    md = s.MondoDinamico(2222, 2, "base")
    tau, W = np.array([12.0, 1.0, 9.0]), np.ones(3)
    x0 = s.STATO_INIZIALE
    x, stato = s.piano(tau, W, md.A, md.b[0] + 5, x0, 6.0)
    assert np.all(np.abs(x - x0) <= s.INERZIA + 1e-7)
    assert x[2] >= min(6.0, x0[2] + s.INERZIA) - 1e-7


def test_impossibile_stimato():
    A = np.array([[1.0, 0, 0], [-1.0, 0, 0], [0, 0, 0], [0, 0, 0]])
    b = np.array([1.0, -3.0, 1.0, 1.0])      # x <= 1 e x >= 3
    x, stato = s.piano(np.zeros(3), np.ones(3), A, b, np.array([2.0, 0, 0]), None)
    assert stato == "impossibile_stimato"


def test_storico_toglie_peso_ai_corrotti():
    md = s.MondoDinamico(2222, 3, "esperti_corrotti")
    md.pop.gruppo = md.pop.gruppo.copy()
    md.pop.gruppo[md.pop.corrotto] = "corrotti"
    r = s.esegui_regime(md, "tematico_dinamico", "corrotti")
    assert r["quota_sorvegliato_ultimo_voto"] < r["quota_sorvegliato_primo_voto"]


def test_determinismo():
    a = s.esegui_mondo(2222, 4, "shock")
    b = s.esegui_mondo(2222, 4, "shock")
    assert a == b


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK", t.__name__)
    print(f"OK DPA V22: {len(tests)} test superati")
