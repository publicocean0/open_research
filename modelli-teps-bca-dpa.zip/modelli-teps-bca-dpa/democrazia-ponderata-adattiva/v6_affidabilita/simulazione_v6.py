#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V6 esperimento controllato su diagnosi V5.

Confronti sulle stesse istanze tecniche e sugli stessi elettori:
  A. Stime originali V4;
  B. Stime corrette da 6 misure sintetiche e generatore V4 invariato;
  C. Come B con ricerca ampliata V5;
  D. Come B con pianificazione vincolata all'incertezza e screening prudente;
  E. Oracolo tecnico con esiti veri (non accessibile ai decisori).

Tutte le votazioni sono quelle ponderate della V3/V4.
I dati tecnici di calibrazione sono misure di test ideali, non dati reali.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
for p in (ROOT,ROOT/'v2_adattiva',ROOT/'v3_ponderata',ROOT/'v4_negoziazione',ROOT/'v5_diagnostica'):
    sys.path.insert(0,str(p))
import simulazione as base
import simulazione_ponderata as v3
import simulazione_v4 as v4
import simulazione_v5 as v5
from simulazione_adattiva import as_model, phi

METHODS=('V4_stime_originali','V6_calibrazione','V6_calibrazione_ricerca',
         'V6_calibrazione_prudente','Oracolo_ideale')
LEVELS=('facile','intermedia','al_limite')
PROBES=np.array([[6.20,0.30,0.35],[7.00,0.95,0.50],
                 [7.55,0.45,1.15],[8.15,1.35,1.55],
                 [7.45,1.85,0.65],[8.40,0.70,2.10]])
MEASURE_SD=.12  # errore sintetico noto di test di laboratorio
PRIOR_SD=.30    # affidabilita' del panel sintetico (nota nel disegno del test)
KAPPA=.65      # margine inferiore a una deviazione standard, non garanzia di rischio
_OPT_CACHE={}
_EXT_CACHE={}
_ORIG_EXT=v5.propose_extended
def cached_extend(model,h):
    key=(model.shift.tobytes(),model.slope.tobytes(),round(float(h),7))
    if key not in _EXT_CACHE:_EXT_CACHE[key]=_ORIG_EXT(model,h)
    return [x.copy() for x in _EXT_CACHE[key]]
v5.propose_extended=cached_extend


def calibrate(truth,panel,seed,n_probes=6):
    """Bayes lineare, SOLO misure rumorose su un piccolo insieme prestabilito.
    Il pianificatore riceve dati rumorosi, NON l'oggetto truth, che rimane
    esclusivamente all'esecutore del collaudo.
    """
    rng=np.random.default_rng(seed+770000)
    model0=as_model(panel)
    P=PROBES[:n_probes]
    X=np.stack([phi(p) for p in P])
    # y[k,j]=vincolo vero misurato + rumore, senza condividere theta vero
    measurements=np.array([truth.g(p) for p in P])+rng.normal(0,MEASURE_SD,(n_probes,4))
    residual=measurements-np.array([model0.g(p) for p in P])
    post_cov=np.linalg.inv(np.eye(4)/PRIOR_SD**2 + X.T@X/MEASURE_SD**2)
    gain=post_cov@X.T/MEASURE_SD**2
    theta_hat=panel+(gain@residual).T
    corrected=as_model(theta_hat)
    return corrected,post_cov


def sd_predict(x,cov):
    f=phi(x)
    return float(np.sqrt(max(0,f@cov@f)))


def opt_robust(model,cov,h,schedule,periods=10,kappa=KAPPA):
    key=(model.shift.tobytes(),model.slope.tobytes(),cov.tobytes(),round(float(h),7),schedule,periods,kappa)
    if key in _OPT_CACHE:
        out=_OPT_CACHE[key]
        return out.copy() if out is not None else None
    def cons(x):
        endpoint=v5.terminal(x,schedule,periods)
        sdf=sd_predict(x,cov);sde=sd_predict(endpoint,cov)
        return np.r_[ -model.g(x)-kappa*sdf-.006,
                      -model.g(endpoint)-kappa*sde-.006,
                      endpoint[0]-h,
                      v5.ENV_TARGET-(5.+model.g(endpoint)[3]+kappa*sde)]
    starts=(np.array([9.0,2.1,2.2]),np.array([8.8,3.0,2.6]),np.array([h+.20,1.7,2.5]))
    cand=[]
    for st in starts:
        op=minimize(v4.capital_cost,np.clip(st,base.LOW,base.HIGH),
                    method='SLSQP',bounds=list(zip(base.LOW,base.HIGH)),
                    constraints=[{'type':'ineq','fun':cons}],
                    options={'maxiter':95,'ftol':1.e-7})
        x=np.clip(op.x,base.LOW,base.HIGH)
        if float(np.min(cons(x)))>=-2e-4:
            cand.append((v4.capital_cost(x),x))
    answer=min(cand,key=lambda c:c[0])[1] if cand else None
    _OPT_CACHE[key]=answer.copy() if answer is not None else None
    return answer


def evaluate_prudent(pop,truth,corrected,cov,h,periods):
    goals={'alloggi':v3.Goal('alloggi',h,'min',periods),
           'ambiente':v3.Goal('ambiente',v5.ENV_TARGET,'max',periods)}
    # Il numero e la scelta dei piani NON dipendono dalle preferenze politiche.
    proposals=[]
    for sched in v5.SCHEDULES:
        p=opt_robust(corrected,cov,h,sched,periods)
        if p is not None:proposals.append((p,sched))
    viable=[]; screened=0; true_founds=0;approved=0; best_vote=-1.
    for plan,sched in proposals:
        endpoint=v5.terminal(plan,sched,periods)
        risk0=max(corrected.g(plan)+KAPPA*sd_predict(plan,cov))
        risk1=max(corrected.g(endpoint)+KAPPA*sd_predict(endpoint,cov))
        if max(risk0,risk1)>.095 or not v4.predicted_acceptable(
                plan,goals,corrected,base.STATUS_QUO,periods,sched):continue
        screened+=1
        gok,tok,worst,_=v5.real_check(plan,h,truth,sched,periods)
        true_founds+=int(gok and tok)
        for relief_group,relief in v5.candidate_groups(pop):
            bundle=v4.Bundle(plan,sched,relief_group,relief,'v6')
            share=v4.fraction_for_bundle(pop,corrected,goals,bundle,base.STATUS_QUO,
                      base.STATUS_QUO,0,periods,[],mode='forward')
            best_vote=max(best_vote,share)
            if share>.5:
                approved+=1
                viable.append((v4.finance_equity_score(pop,bundle,base.STATUS_QUO),bundle,share))
    if not viable:
        status='nessuna_proposta_tecnica' if screened==0 else 'voto_respinto'
        return dict(status=status,success=0,weighted_approved=0,
                    proposed_true_feasible=int(true_founds>0),chosen_weighted_share=np.nan,
                    generated=len(proposals),screened=screened,best_weighted_share=best_vote)
    _,best,share=min(viable,key=lambda z:z[0])
    gok,tok,_,_=v5.real_check(best.x,h,truth,best.schedule,periods)
    status='successo' if gok and tok else ('vincolo_reale_violato' if not tok else 'obiettivo_non_raggiunto')
    return dict(status=status,success=int(gok and tok),weighted_approved=1,
                proposed_true_feasible=int(true_founds>0),chosen_weighted_share=share,
                generated=len(proposals),screened=screened,best_weighted_share=best_vote)


def run_world(j,n,periods):
    seed=1000+37*j
    rng=np.random.default_rng(seed+920000)
    seq,panel=v3.make_world(rng,periods,'stabile')
    truth=as_model(seq[0]);original=as_model(panel)
    correct,cov=calibrate(truth,panel,seed)
    hmax,_,_=v5.frontier(truth)
    res=[]
    for elec in ('cooperativo','conflittuale'):
        epop=np.random.default_rng(seed+(200000 if elec=='cooperativo' else 400000))
        pop=v3.build_electorate(epop,n,'stabile' if elec=='cooperativo' else 'conflitto')
        for level in LEVELS:
            target=7.20+v5.DIFFICULTY[level]*(hmax-7.20)
            for method in METHODS:
                if method=='V4_stime_originali':
                    out=v5.evaluate_method(pop,truth,original,target,'V4_stime_imperfette',periods)
                elif method=='V6_calibrazione':
                    out=v5.evaluate_method(pop,truth,correct,target,'V4_stime_imperfette',periods)
                elif method=='V6_calibrazione_ricerca':
                    out=v5.evaluate_method(pop,truth,correct,target,'V5_ricerca_ampliata',periods)
                elif method=='V6_calibrazione_prudente':
                    out=evaluate_prudent(pop,truth,correct,cov,target,periods)
                elif method=='Oracolo_ideale':
                    out=v5.evaluate_method(pop,truth,original,target,'Oracolo_costo_minimo',periods)
                else:raise ValueError(method)
                out.update(seed=seed,electorate=elec,difficulty=level,method=method,
                           target=target,oracle_feasible=1,
                           original_rmse=float(np.sqrt(np.mean((truth.g(PROBES[0])-original.g(PROBES[0]))**2))),
                           calibrated_rmse=float(np.sqrt(np.mean((truth.g(PROBES[0])-correct.g(PROBES[0]))**2))))
                res.append(out)
    return res


def summarize(rows):
    out=[]
    for elec in ('cooperativo','conflittuale'):
      for level in LEVELS:
        for method in METHODS:
          group=[r for r in rows if r['electorate']==elec and r['difficulty']==level and r['method']==method]
          n=len(group)
          out.append(dict(electorate=elec,difficulty=level,method=method,worlds=n,
            success_count=sum(r['success'] for r in group),
            success_pct=round(100*sum(r['success'] for r in group)/n,1),
            plan_found_pct=round(100*sum(r['proposed_true_feasible'] for r in group)/n,1),
            weighted_approved_pct=round(100*sum(r['weighted_approved'] for r in group)/n,1),
            n_no_technical=sum(r['status']=='nessuna_proposta_tecnica' for r in group),
            n_vote_reject=sum(r['status']=='voto_respinto' for r in group),
            n_wrong_constraint=sum(r['status']=='vincolo_reale_violato' for r in group),
            n_goal_missed=sum(r['status']=='obiettivo_non_raggiunto' for r in group)))
    return out


def write_csv(path,rows):
    if not rows:return
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)


def tests():
    assert np.allclose(PROBES.shape,(6,3))
    rng=np.random.default_rng(244)
    truth=as_model(rng.normal(0,.11,(4,4)))
    panel=rng.normal(0,.30,(4,4))
    corr,cov=calibrate(truth,panel,22)
    assert np.linalg.eigvalsh(cov).min()>0
    assert sd_predict(np.array([8.,1.,1.]),cov)>0
    assert (v3.weights(v3.build_electorate(rng,300,'stabile'),'strategia')[0]>0).all()
    assert abs(float(np.sum(v4.SCHEDULES['graduale']))-1)<1e-10
    print('Test V6: posterior, covariance, pesi competenza, costi di rateizzazione OK')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--test',action='store_true')
    p.add_argument('--mondi',type=int,default=36)
    p.add_argument('--offset',type=int,default=0)
    p.add_argument('--cittadini',type=int,default=300)
    p.add_argument('--periodi',type=int,default=10)
    p.add_argument('--output',type=Path,default=HERE/'risultati')
    args=p.parse_args()
    if args.test:tests();return
    args.output.mkdir(parents=True,exist_ok=True)
    all_rows=[]
    for j in range(args.offset,args.offset+args.mondi):
        all_rows.extend(run_world(j,args.cittadini,args.periodi))
        if (j-args.offset+1)%3==0:print('Completati',j-args.offset+1,'mondi',flush=True)
    aggregate=summarize(all_rows)
    write_csv(args.output/'dettaglio.csv',all_rows)
    write_csv(args.output/'riepilogo.csv',aggregate)
    (args.output/'parametri.json').write_text(json.dumps(dict(mondi=args.mondi,offset=args.offset,
         cittadini=args.cittadini,periodi=args.periodi,sonde=PROBES.tolist(),
         errore_misure=MEASURE_SD,prior_sd=PRIOR_SD,margine_kappa=KAPPA),indent=2))
    print(json.dumps(aggregate,indent=2))
if __name__=='__main__':main()