# Democrazia Ponderata Adattiva — V6

## Scopo

Questa versione segue la V5: separare **difficoltà fisica dei target**, **precisione delle stime tecniche**, **ricerca delle strategie** e **voto ponderato**. Non è una dimostrazione che un particolare sistema costituzionale sarebbe superiore in una società reale. Tutti gli elettori, le competenze, i vincoli e i dati sono artificiali.

### Principi invariati

- **Il voto è sempre ponderato sulla competenza pertinente**, tramite `v3_ponderata/simulazione_ponderata.py` e `v4_negoziazione/simulazione_v4.py`.
- Gli **obiettivi comuni** sono assunti già approvati nella diagnostica V5–V6: la V3 contiene una implementazione semplificata del processo di proposta, selezione, voto degli obiettivi e delle metriche.
- La funzione di successo misura **raggiungimento del target e rispetto dei vincoli reali**, non gradimento o felicità immediata.
- Una proposta non è attuata senza voto ponderato positivo. Nella V6 è simulato un ciclo di scelta e la verifica dell'esito finale, **non** un sistema di rivoti periodici sul campo.

## Quattro elementi distinti

1. **Fattibilità**: il riferimento tecnico ideale costruisce un piano che soddisfa obiettivi e vincoli reali; le istanze studiate sono intenzionalmente fattibili.
2. **Previsione tecnica**: il panel degli esperti ha errori casuali. La V6 può acquisire sei misure sperimentali fittizie indipendenti con rumore noto (deviazione standard = 0,12 unità normalizzate), eseguite su sei punti prefissati prima della proposta. Sono *osservazioni del mondo artificiale*, non accesso diretto ai coefficienti veri.
3. **Ricerca delle strategie**: confrontiamo generatore V4, più alternative V5 e ricerca prudente su stime corrette.
4. **Voto ponderato**: ciascuna alternativa sottoposta al voto riceve i pesi V3, specifici per cittadino e materia. Tra le strategie approvate, la selezione segue il costo sintetico e la dispersione degli oneri, non una funzione di soddisfazione immediata.

## Esperimento

- 36 mondi tecnici sintetici, con tre livelli di difficoltà calibrati rispetto alla frontiera di ciascun mondo: *facile*, *intermedia*, *al limite*.
- Due elettorati per mondo: bilanciato (`cooperativo`) e con interessi molto contrapposti (`conflittuale`). Identici problemi fisici negli stessi mondi.
- 300 cittadini per elettorato, 10 periodi di realizzazione, cinque metodi.
- 1.080 valutazioni (= 36 x 3 x 2 x 5).
- I confronti sono **accoppiati** usando gli stessi mondi e gli stessi elettorati.
- I dati sono generati con gli stessi seed e i metodi sono valutati separatamente: nessuna politica viene rivista in modo retroattivo grazie alla conoscenza della verità nascosta.

### Metodi

- `V4_stime_originali`: generatore V4 e stime iniziali imperfette.
- `V6_calibrazione`: stesso generatore V4, con modello tecnico aggiornato mediante sei osservazioni rumorose e aggiornamento bayesiano lineare.
- `V6_calibrazione_ricerca`: aggiornamento tecnico più ampliamento di proposte V5; serve da ablation per il numero delle alternative.
- `V6_calibrazione_prudente`: aggiorna il modello e ricerca alternative utilizzando un margine tecnico di 0,65 volte l'incertezza prevista; **non** è una certificazione probabilistica di sicurezza.
- `Oracolo_ideale`: conoscenza del mondo sintetico e generatore di costo minimo; anche questa strategia è sottoposta al voto ponderato. È un riferimento irrealistico, non un obiettivo operativo certo.

## Risultati

### Elettorato bilanciato: decisioni realmente fattibili e approvate

| Metodo | Facile | Intermedia | Al limite |
|---|---:|---:|---:|
| V4 stime originali | 11/36 (30,6%) | 12/36 (33,3%) | 1/36 (2,8%) |
| V6 calibrazione | 30/36 (83,3%) | 25/36 (69,4%) | 4/36 (11,1%) |
| V6 calibrazione + ricerca ampia | 20/36 (55,6%) | 17/36 (47,2%) | 6/36 (16,7%) |
| V6 calibrazione + prudenza | 26/36 (72,2%) | 29/36 (80,6%) | 4/36 (11,1%) |
| Oracolo tecnico + voto | 35/36 (97,2%) | 36/36 (100%) | 36/36 (100%) |

### Elettorato conflittuale: decisioni realmente fattibili e approvate

| Metodo | Facile | Intermedia | Al limite |
|---|---:|---:|---:|
| V4 stime originali | 1/36 (2,8%) | 1/36 (2,8%) | 0/36 |
| V6 calibrazione | 2/36 (5,6%) | 1/36 (2,8%) | 0/36 |
| V6 calibrazione + ricerca ampia | 1/36 (2,8%) | 1/36 (2,8%) | 0/36 |
| V6 calibrazione + prudenza | 2/36 (5,6%) | 2/36 (5,6%) | 1/36 (2,8%) |
| Oracolo tecnico + voto | 2/36 (5,6%) | 2/36 (5,6%) | 2/36 (5,6%) |

### Errore su quattro punti di controllo non usati per calibrare

- RMSE medio originale: **0,3424** unità normalizzate.
- RMSE medio calibrato: **0,1114** unità normalizzate.
- Riduzione dell'errore medio: **67,5%**, miglioramento in 36/36 mondi.

**Nota:** la calibrazione è progettata su un modello lineare a quattro coefficienti per ciascun vincolo, con rumore indipendente e noto. Il risultato elevato è previsto in un ambiente così favorevole e non si trasferisce automaticamente a sistemi sociali più complessi, affetti da rumore sistematico, bias e cambiamenti strutturali.

### Controlli accoppiati

Gli intervalli bootstrap in `risultati/confronti_accoppiati.csv` sono **descrittivi del campione sintetico**, non intervalli per la probabilità di successo in una società reale.

## Che cosa abbiamo appreso

**1. Non è la difficoltà a spiegare tutti i fallimenti.** Tutti i target testati sono progettati per essere fisicamente raggiungibili nell'ambiente sintetico.

**2. Per obiettivi facili e intermedi, la calibrazione tecnica permette frequentemente di migliorare il risultato**, anche con lo stesso voto ponderato e lo stesso generatore V4.

**3. Vicino alla frontiera esistono problemi di ricerca e robustezza ancora aperti.** La semplice prudenza può escludere soluzioni realmente fattibili. Più alternative possono far scegliere una strategia apparentemente meno costosa ma errata, se il filtro predittivo è fallibile.

**4. Il conflitto elettorale non è eliminato dalla competenza tecnica.** Nel modello simulato, 34 su 36 elettorati conflittuali respingono perfino l'oracolo tecnico: questo dipende dalla distribuzione ipotetica delle preferenze e dalle regole del voto, non da un risultato sociologico verificato.

## Limiti più importanti

- Manca una prova dinamica con shock, nuove misure in corso d'opera e rivoti successivi.
- Non c'è un meccanismo provato di negoziazione intergruppo: gli attuali pacchetti compensativi sono molto semplici e non garantiscono consenso.
- I pesi di competenza sono generati artificialmente; non viene validata una certificazione vera.
- Nessuna valutazione empirica di manipolazioni strategiche, concentramento del potere, diritti o legittimità democratica.
- Un riferimento numerico che trova una soluzione non costituisce una prova formale di ottimalità globale.
- 36 mondi per difficoltà costituiscono un campione illustrativo, non un grande studio di sensibilità.

## Esecuzione

Dalla cartella root `democrazia-ponderata-adattiva`:

```bash
python v6_affidabilita/simulazione_v6.py --test
python v6_affidabilita/simulazione_v6.py --mondi 36 --cittadini 300 --periodi 10
```

Dipendenze: Python 3.10+, `numpy`, `scipy`, `matplotlib` (e, solo per i grafici dei risultati, moduli standard). Tutti i seed sono deterministici.

File allegati nel pacchetto: script V1–V6, `risultati/dettaglio.csv`, `risultati/riepilogo.csv`, `risultati/confronti_accoppiati.csv`, `risultati/errori_holdout.csv`, e grafici.