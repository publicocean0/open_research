# Democrazia Ponderata Adattiva V13 — riserva, probabilità di shock e guasti correlati

**Stato: simulatore matematico sintetico; non è una validazione su società reali.**

La V13 continua la V12: strategia come portafoglio di 4 interventi paralleli distribuiti su 6 periodi, con target originari immutati, vincoli tecnici, budget e voto ponderato per competenza. La parte già attuata nei primi due periodi non può essere riscritta; una correzione successiva richiede un nuovo voto.

## Variabili sperimentate

- Tetto della spesa aggregata nei primi 2 periodi: `3, 4.5, 5.8, 7.5, 10` unità (budget totale invariato pari a 26).
- Probabilità dello shock **assunta** al momento della pianificazione e del voto: `0.10, 0.35, 0.65`.
- Probabilità dello shock **reale**: `0.10, 0.35, 0.65`. Non è stimata da dati empirici: viene usata per ponderare i diversi scenari simulati.
- Gravità di shock nella griglia principale: fattori di produttività delle rinnovabili `0.72, 0.60, 0.55, 0.45`, con pesi `0.15, 0.35, 0.30, 0.20`.
- Stress fuori distribuzione con guasti correlati a rinnovabili, reti e accumuli.

## Riepilogo: rischio previsto e reale 35%

Campione di 36 mondi artificiali, 300 cittadini simulati ciascuno.

| Tetto iniziale | Successo atteso | Beneficio intermedio (0–1) |
|---:|---:|---:|
| 3 | 100% | 0.6121 |
| 4.5 | 100% | 0.6661 |
| 5.8 | 100% | 0.7102 |
| 7.5 | 100% | 0.7634 |
| 10 | 91.2% | 0.8215 |

Il tetto 7.5 migliora di 8.75 punti percentuali il successo rispetto al tetto 10, intervallo bootstrap appaiato 95% da +5.83 a +11.67 punti. Sono intervalli **entro questi mondi sintetici**, non intervalli per la società reale.

Il beneficio intermedio è un diagnostico costruito da energia ed emissioni evitate nei periodi intermedi; **non** è un nuovo obiettivo approvato dal voto.

## Shock correlati dopo il voto, risultati su 36 mondi

| Shock | Tetto 3 | Tetto 5.8 | Tetto 7.5 | Tetto 10 |
|---|---:|---:|---:|---:|
| Rinnovabili 0.60, reti 0.75 | 36 | 36 | 36 | 18 |
| Rinnovabili 0.45, reti 0.50, accumuli 0.80 | 24 | 36 | 36 | 18 |
| Rinnovabili 0.25, reti 0.35, accumuli 0.60 | 0 | 0 | 1 | 1 |
| Rinnovabili 0.25, reti 0.15, accumuli 0.50 | 0 | 0 | 0 | 0 |

Nel guasto doppio grave, investire soltanto 3 unità iniziali produce 12 insuccessi in più rispetto a 7.5. Una riserva eccessiva può quindi essere controproducente. Se diversi settori perdono simultaneamente quasi tutta la capacità, nessuna riserva garantisce il recupero.

## Controllo sul conflitto politico

Su 12 elettorati sintetici con interessi fortemente contrapposti, soltanto 4/12 approvano inizialmente i programmi, qualunque sia la riserva. La ricerca tecnica non risolve da sola il blocco deliberativo.

## Riproduzione e limiti

Dipendenze: `numpy`, `scipy`, `matplotlib`. Il modulo V13 richiama quelli delle V11 e V12. I dati e gli script degli esperimenti includono confronti accoppiati, stress singoli e guasti simultanei, controlli dei budget, nuove votazioni e conservazione del passato.

**Caveat:** i target sono assunti già approvati; il risolutore locale non garantisce ottimalità o certificazione di impossibilità matematica. Il modello conosce le produttività reali *dopo* l'osservazione dello shock e usa dipendenze tecniche molto semplificate. Il risolutore di recupero è stato migliorato rispetto alla V12: non attribuire differenze percentuali fra versioni alla sola riserva.

Gli output sono verificabili nel pacchetto completo V13 fornito nella conversazione di sviluppo.