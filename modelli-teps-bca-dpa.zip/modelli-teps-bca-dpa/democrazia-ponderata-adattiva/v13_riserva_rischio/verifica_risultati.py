#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Regression checks of saved V13 simulation results."""
import csv
from pathlib import Path
HERE=Path(__file__).resolve().parent
R=HERE/'risultati'
def load(name):
    with (R/name).open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))
def test():
    detail=load('dettaglio.csv')
    summary=load('riepilogo.csv')
    stress=load('stress_correlato_dettaglio.csv')
    conflict=load('dettaglio_conflitto.csv')
    assert len(detail)==36*5*3*5
    assert len(conflict)==12*5*3*5
    assert len(stress)==36*4*4
    assert len(summary)==5*3*3
    for row in detail+stress+conflict:
        assert int(row['successful'])<=int(row['initial_approved'])
        assert int(row['revote_approved'])<=int(row['revote_required'])
        if int(row['successful']):
            assert int(row['technical_constraints'])==1
    seen=set()
    for row in detail:
        key=(row['seed'],row['cap'],row['assumed_prob'],row['factor'])
        assert key not in seen
        seen.add(key)
    for row in summary:
        assert 0<=float(row['expected_success_pct'])<=100
        assert float(row['early_spend'])<=float(row['cap'])+1e-3
    sc={(r['scenario'],float(r['cap'])):r for r in load('stress_correlato_riepilogo.csv')}
    assert int(sc['doppio_grave',7.5]['success'])==36
    assert int(sc['doppio_grave',3.0]['success'])==24
    assert int(sc['triplo_estremo',7.5]['success'])==1
    assert int(sc['sistemico',7.5]['success'])==0
    print('OK: righe, pairing, tetti, voti, vincoli, risultati correlati')
if __name__=='__main__':test()
