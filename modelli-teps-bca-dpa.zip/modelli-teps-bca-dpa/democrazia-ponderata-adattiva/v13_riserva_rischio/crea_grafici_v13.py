#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Grafici V13 dai CSV: non avvia nuove simulazioni."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
OUT=HERE/'risultati'
with (OUT/'riepilogo.csv').open(encoding='utf-8',newline='') as f:
    data=list(csv.DictReader(f))
get=lambda a,b,c: next(r for r in data if float(r['cap'])==a and float(r['p_assumed'])==b and float(r['p_real'])==c)
caps=(3.,4.5,5.8,7.5,10.)
fig,ax=plt.subplots(figsize=(9.4,5.6))
for probability in (.10,.35,.65):
    rows=[get(cap,.35,probability) for cap in caps]
    ax.plot(caps,[float(r['expected_success_pct']) for r in rows],marker='o',label=f'Probabilita reale shock {probability:.0%}')
ax.set(xlabel='Tetto spesa nei primi due periodi (max 10)',ylabel='Successo atteso (%)',title='V13 — Resilienza e livello della riserva')
ax.set_xticks(caps);ax.set_ylim(0,105);ax.grid(alpha=.2);ax.legend()
fig.tight_layout();fig.savefig(OUT/'successo_vs_riserva.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(figsize=(8.5,5.6))
for cap in caps:
    r=get(cap,.35,.35)
    ax.scatter(float(r['expected_intermediate_service']),float(r['expected_success_pct']),s=85)
    ax.annotate(f'tetto {cap:g}',(float(r['expected_intermediate_service']),float(r['expected_success_pct'])),xytext=(5,5),textcoords='offset points')
ax.set(xlabel='Beneficio medio durante i periodi (indice 0–1)',ylabel='Successo atteso (%)',title='V13 — Trade-off: servizi immediati e riserva')
ax.set_ylim(0,105);ax.set_xlim(.57,.88);ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(OUT/'frontiera_servizi_riserva.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(figsize=(9.4,5.6))
for assumed in (.10,.35,.65):
    rows=[get(cap,assumed,.35) for cap in caps]
    ax.plot(caps,[float(r['expected_success_pct']) for r in rows],marker='o',label=f'Rischio stimato {assumed:.0%}')
ax.set(xlabel='Tetto di spesa iniziale',ylabel='Successo atteso (%)',title='V13 — Sensibilita al rischio stimato (rischio reale 35%)')
ax.set_xticks(caps);ax.set_ylim(0,105);ax.grid(alpha=.2);ax.legend()
fig.tight_layout();fig.savefig(OUT/'rischio_stimato.png',dpi=170);plt.close(fig)
print('Tre grafici creati')
