#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Analisi bootstrap e grafico degli shock correlati, a partire dai CSV V13."""
import csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent/'risultati'
with (OUT/'stress_correlato_dettaglio.csv').open(newline='',encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
for r in rows:
    r.update(seed=int(r['seed']),cap=float(r['cap']),successful=int(r['successful']))
scenarios=list(dict.fromkeys(r['scenario'] for r in rows))
caps=[3.,5.8,7.5,10.]
summary=[]
rng=np.random.default_rng(43722)
for sc in scenarios:
    group={(r['seed'],r['cap']):r['successful'] for r in rows if r['scenario']==sc}
    seeds=sorted({seed for seed,cap in group})
    for a,b in [(3.,7.5),(10.,7.5)]:
        deltas=np.array([group[(seed,b)]-group[(seed,a)] for seed in seeds])
        boots=np.mean(rng.choice(deltas,size=(5000,len(deltas)),replace=True),axis=1)
        summary.append(dict(scenario=sc,base_cap=a,test_cap=b,n=len(deltas),
                            delta_successi=int(np.sum(deltas)),
                            delta_pp=round(100*float(np.mean(deltas)),2),
                            ci_low=round(100*float(np.percentile(boots,2.5)),2),
                            ci_high=round(100*float(np.percentile(boots,97.5)),2),
                            migliorati=int(np.sum(deltas>0)),peggiorati=int(np.sum(deltas<0))))
with (OUT/'stress_correlato_bootstrap.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=summary[0].keys());w.writeheader();w.writerows(summary)
fig,ax=plt.subplots(figsize=(10,5.4))
y=np.arange(len(scenarios));width=.19
for j,cap in enumerate(caps):
    zz=[sum(r['successful'] for r in rows if r['cap']==cap and r['scenario']==sc)/len(seeds)*100 for sc in scenarios]
    ax.barh(y+(j-1.5)*width,zz,height=width,label=f'Tetto {cap:g}')
ax.set_yticks(y,scenarios);ax.set_xlim(0,106)
ax.set_xlabel('Obiettivi e vincoli effettivi rispettati (%)')
ax.set_title('V13 — Shock correlati dopo il voto')
ax.legend(fontsize=9);fig.tight_layout()
fig.savefig(OUT/'shock_correlati.png',dpi=170);plt.close(fig)
print(summary)
