#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V13 - Stress-test accoppiato sulla dimensione della riserva e rischio di shock.

Prototipo su popolazioni e tecnologia sintetiche (V11/V12). La rete non
conosce lo shock realizzato prima di far votare il portafoglio. Si variano:
- tetto agli investimenti dei periodi 0-1 (cap di early spend);
- probabilita' assunta nella pianificazione e nel voto iniziale;
- probabilita' reale e gravita degli shock dopo l'approvazione.

Fase di recupero: osservazione dello shock, passato immutabile, nuovo voto
ponderato quando il ramo condizionale approvato non basta. Nessuna revisione
implicita dei target. Un fallimento del risolutore non dimostra impossibilita'.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'v12_resilienza_portafoglio'))
import simulazione_v12 as v12

p=v12.p
v11=v12.v11
CAPS=(3.0, 4.5, 5.8, 7.5, 10.0)
FORECAST_PROBS=(.10,.35,.65)
TRUE_PROBS=(.10,.35,.65)
SEVERITIES=(.72,.60,.55,.45)
SEVERITY_WEIGHTS=(.15,.35,.30,.20)
TOL=v12.TOL

def choose_policy(seed,cap,assumed_prob,conflict=False):
    world,prod0=v12.world_for_seed(seed,'conflitto_shock' if conflict else 'shock')
    previous_cap=v12.BUDGET_EARLY_RESERVE
    previous_prob=v12.PROB_SHOCK
    try:
        v12.BUDGET_EARLY_RESERVE=cap
        v12.PROB_SHOCK=assumed_prob
        v12._POLICY_CACHE.clear()
        policy,reason=v12.choose_policy(world,prod0,'condizionale_riserva')
    finally:
        v12.BUDGET_EARLY_RESERVE=previous_cap
        v12.PROB_SHOCK=previous_prob
        v12._POLICY_CACHE.clear()
    return world,prod0,policy,reason

def actually_feasible(x,truth,fee):
    metrics=p.indicators(x,truth)
    return (p.feasible(x,truth,TOL)
            and metrics['spesa_totale']+fee <=p.TOTAL_BUDGET+TOL
            and metrics['spesa_periodo'][0]+fee <=p.PERIOD_BUDGET+TOL)

def intermediate_benefit(x,truth):
    """Accumulated delivered service, not a voted goal/metric (diagnostic only)."""
    total=0.0
    for t in range(1,p.T+1):
        seen=np.zeros_like(x)
        seen[:t]=x[:t]
        m=p.indicators(seen,truth)
        e=np.clip(m['energia']/p.TARGET_ENERGY,0,1)
        co2=np.clip(m['emissioni_evitate']/p.TARGET_CO2,0,1)
        total+=(e+co2)/2.0
    return total/p.T

def fast_recovery(truth, executed, initial):
    """SLSQP on future interventions with analytic derivatives (V12 verified).
    Failure to find a solution is NOT a proof of mathematical impossibility.
    """
    start=v12.PREFIX
    dims=(p.T-start,p.K)
    n=start*p.K
    def full(z):
        x=executed.copy()
        x[start:]=np.reshape(z,dims)
        return x
    def constr(z):
        return v12.inequalities(full(z),truth)
    def jac_constr(z):
        return v12.inequalities_jac(full(z),truth)[:,n:]
    def objective(z):
        return v12.schedule_objective(full(z),'costo')
    def jac_objective(z):
        return v12.schedule_grad(full(z),'costo').ravel()[n:]
    bounds=[(0,1)]*int(np.prod(dims))
    starts=[initial[start:].ravel(),np.full(np.prod(dims),.4)]
    best=None
    for s in starts:
        r=minimize(objective,s,jac=jac_objective,bounds=bounds,method='SLSQP',
                   constraints=[{'type':'ineq','fun':constr,'jac':jac_constr}],
                   options={'maxiter':95,'ftol':1e-07})
        if np.min(constr(r.x))<-TOL:continue
        xx=full(r.x)
        val=objective(r.x)
        if best is None or val<best[0]:best=(val,xx)
    return None if best is None else best[1]

def outcome(world,prod0,policy,factor,assumed_prob):
    """Same elected plan for all actual shocks; later revision may vary."""
    actual=prod0.copy()
    if factor<1.0:
        actual[0]*=factor
    if policy is None:
        return dict(factor=factor,initial_approved=0,branch_feasible=0,
                    correction_found=0,revote_required=0,revote_approved=0,
                    successful=0,technical_constraints=1,reason='initial_rejection',
                    service=0.0,execution_cost=0.0,early_spend=0.0)
    fee=v11.transfer_admin(world,policy.transfer)
    branch=policy.normal if factor==1.0 else policy.stressed
    branch_ok=actually_feasible(branch,actual,fee)
    correction_found=0
    revote_required=0
    revote_approved=0
    final=branch
    reason='approved_branch_success' if branch_ok else 'awaiting_revision'
    if not branch_ok:
        executed=np.zeros((p.T,p.K))
        executed[:v12.PREFIX]=branch[:v12.PREFIX]
        candidate=fast_recovery(actual,executed,branch)
        if candidate is not None and np.allclose(candidate[:v12.PREFIX],executed[:v12.PREFIX],atol=1e-09) and actually_feasible(candidate,actual,fee):
            correction_found=1
            revote_required=1
            share=v11.vote(world,candidate,actual,policy.transfer)
            if share>0.5:
                final=candidate
                revote_approved=1
                reason='revision_approved'
            else:
                reason='revision_rejected'
        else:
            reason='no_correction_found'
    m=p.indicators(final,actual)
    goals=(m['energia']>=p.TARGET_ENERGY-TOL and m['emissioni_evitate']>=p.TARGET_CO2-TOL)
    budget=(m['spesa_totale']+fee<=p.TOTAL_BUDGET+TOL and
            max(m['spesa_periodo'])<=p.PERIOD_BUDGET+TOL and
            m['spesa_periodo'][0]+fee<=p.PERIOD_BUDGET+TOL)
    stress=m['stress_rete']<=p.STRESS_LIMIT+TOL
    if factor<1 and not np.allclose(final[:v12.PREFIX],policy.stressed[:v12.PREFIX],atol=1e-09):
        raise AssertionError('Una correzione ha alterato il passato')
    return dict(factor=factor,initial_approved=1,branch_feasible=int(branch_ok),
                correction_found=correction_found,revote_required=revote_required,
                revote_approved=revote_approved,
                successful=int(goals and budget and stress and (branch_ok or revote_approved)),
                technical_constraints=int(budget and stress), reason=reason,
                service=round(intermediate_benefit(final,actual),5),
                execution_cost=round(float(m['spesa_totale']+fee),5),
                early_spend=round(float(np.sum((final@p.COSTS)[:v12.PREFIX])),5))

def run(n=24,conflict=False):
    rows=[]
    for seed in range(n):
        for cap in CAPS:
            for assumed_prob in FORECAST_PROBS:
                world,prod0,policy,reason=choose_policy(seed,cap,assumed_prob,conflict)
                for factor in (1.0,)+SEVERITIES:
                    r=outcome(world,prod0,policy,factor,assumed_prob)
                    r.update(seed=seed,cap=cap,reserve_vs_max=10.0-cap,
                             assumed_prob=assumed_prob,conflict=int(conflict),
                             initial_reason=reason,
                             initial_weighted_vote=round(policy.weighted_vote,5) if policy else 0.0)
                    rows.append(r)
        print(f'completed world {seed+1}/{n}',flush=True)
    summaries=[]
    for cap in CAPS:
        for assumed_prob in FORECAST_PROBS:
            z=[r for r in rows if r['cap']==cap and r['assumed_prob']==assumed_prob]
            no={r['seed']:r for r in z if r['factor']==1.0}
            shocks={(r['seed'],r['factor']):r for r in z if r['factor']!=1.0}
            assert len(no)==n and len(shocks)==n*len(SEVERITIES)
            approved=np.mean([r['initial_approved'] for r in no.values()])
            stable_success=np.mean([r['successful'] for r in no.values()])
            stable_service=np.mean([r['service'] for r in no.values()])
            stable_spend=np.mean([r['execution_cost'] for r in no.values()])
            early=np.mean([r['early_spend'] for r in no.values() if r['initial_approved']]) if approved else 0.
            severe_succ={factor:np.mean([shocks[(s,factor)]['successful'] for s in range(n)]) for factor in SEVERITIES}
            severe_revision={factor:np.mean([shocks[(s,factor)]['revote_approved'] for s in range(n)]) for factor in SEVERITIES}
            shock_success=sum(w*severe_succ[f] for f,w in zip(SEVERITIES,SEVERITY_WEIGHTS))
            shock_service=sum(w*np.mean([shocks[(s,f)]['service'] for s in range(n)]) for f,w in zip(SEVERITIES,SEVERITY_WEIGHTS))
            shock_spend=sum(w*np.mean([shocks[(s,f)]['execution_cost'] for s in range(n)]) for f,w in zip(SEVERITIES,SEVERITY_WEIGHTS))
            for actual_prob in TRUE_PROBS:
                summaries.append(dict(cap=cap,unused_early_allowance=round(10-cap,2),
                    p_assumed=assumed_prob,p_real=actual_prob,n=n,
                    initial_approval_pct=round(100*approved,1),
                    expected_success_pct=round(100*((1-actual_prob)*stable_success+actual_prob*shock_success),1),
                    success_if_no_shock_pct=round(100*stable_success,1),
                    success_conditional_on_shock_pct=round(100*shock_success,1),
                    recovery_vote_rate_after_shock_pct=round(100*sum(w*severe_revision[f] for f,w in zip(SEVERITIES,SEVERITY_WEIGHTS)),1),
                    early_spend=round(early,3),
                    expected_intermediate_service=round((1-actual_prob)*stable_service+actual_prob*shock_service,4),
                    expected_execution_cost=round((1-actual_prob)*stable_spend+actual_prob*shock_spend,3),
                    severe_shock_045_success_pct=round(100*severe_succ[.45],1)))
    return rows,summaries

def paired_ci(rows,a,b,prob=.35,assumed_prob=.35,rep=4000):
    """Pair-resample whole worlds; use exact scenario weights per world."""
    filtered=[r for r in rows if r['assumed_prob']==assumed_prob and r['cap'] in (a,b)]
    worlds=sorted({r['seed'] for r in filtered})
    pairs={(r['seed'],r['cap'],r['factor']):r['successful'] for r in filtered}
    d=[]
    for seed in worlds:
        def ex(cap):
            return (1-prob)*pairs[(seed,cap,1.0)]+prob*sum(w*pairs[(seed,cap,f)] for f,w in zip(SEVERITIES,SEVERITY_WEIGHTS))
        d.append(ex(b)-ex(a))
    d=np.array(d)
    rng=np.random.default_rng(81426)
    boot=np.mean(rng.choice(d,size=(rep,len(d)),replace=True),axis=1)
    return dict(a=a,b=b,p_assumed=assumed_prob,p_real=prob,n=len(d),delta_pp=round(100*np.mean(d),2),
                ci95_pp=[round(float(q)*100,2) for q in np.quantile(boot,[.025,.975])],
                better_worlds=int(np.sum(d>1e-08)),worse_worlds=int(np.sum(d< -1e-08)),
                unchanged_worlds=int(np.sum(np.abs(d)<=1e-08)))

def write_csv(path,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)

def test():
    world,prod,policy,reason=choose_policy(0,5.8,.35)
    assert policy is not None,reason
    assert policy.reserve_used<=5.8+TOL
    assert np.allclose(policy.normal[:v12.PREFIX],policy.stressed[:v12.PREFIX])
    assert policy.weighted_vote>0.5
    for factor in (1.,.6,.45):
        r=outcome(world,prod,policy,factor,.35)
        assert r['successful']<=r['initial_approved']
        assert not r['revote_approved'] or r['revote_required']
    one=choose_policy(0,4.5,.1)[2]
    two=choose_policy(0,9.0,.65)[2]
    assert one is not None and two is not None
    assert one.reserve_used<=4.5+TOL and two.reserve_used<=9.0+TOL
    assert v12.PROB_SHOCK==.35 and v12.BUDGET_EARLY_RESERVE==5.8
    print('OK V13: voto ponderato, no fuga del futuro, margini, budget, rivoto e passato immutabile')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--mondi',type=int,default=24)
    ap.add_argument('--conflitto',action='store_true')
    ap.add_argument('--output',default=str(HERE/'risultati'))
    args=ap.parse_args()
    if args.test:return test()
    dst=Path(args.output);dst.mkdir(exist_ok=True,parents=True)
    rows,summaries=run(args.mondi,conflict=args.conflitto)
    suffix='_conflitto' if args.conflitto else ''
    write_csv(dst/f'dettaglio{suffix}.csv',rows)
    write_csv(dst/f'riepilogo{suffix}.csv',summaries)
    cis=[paired_ci(rows,10.,b,prob,assumed) for assumed in FORECAST_PROBS
         for prob in TRUE_PROBS for b in CAPS if b!=10.]
    write_csv(dst/f'confronti_accoppiati{suffix}.csv',cis)
    print(json.dumps({'n':args.mondi,'conflitto':args.conflitto,'risultati':len(rows),'riepilogo':len(summaries),'confronti':len(cis)},ensure_ascii=False))

if __name__=='__main__':main()
