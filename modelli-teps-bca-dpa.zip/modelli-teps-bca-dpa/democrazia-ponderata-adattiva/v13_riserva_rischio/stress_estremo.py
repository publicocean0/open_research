#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V13: shock single-sector più gravi di quelli della griglia principale."""
import argparse
from pathlib import Path
import numpy as np
import simulazione_v13 as v
CAPS=(3.,5.8,7.5,10.)
FACTORS=(.45,.35,.25)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mondi',type=int,default=36)
    ap.add_argument('--output',default=str(Path(__file__).resolve().parent/'risultati'))
    a=ap.parse_args()
    rows=[]
    for seed in range(a.mondi):
        for cap in CAPS:
            world,prod,policy,reason=v.choose_policy(seed,cap,.35)
            for fac in FACTORS:
                row=v.outcome(world,prod,policy,fac,.35)
                row.update(seed=seed,cap=cap,reason_initial=reason)
                rows.append(row)
        print('holdout completed',seed+1,'/',a.mondi,flush=True)
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    v.write_csv(out/'stress_estremo_dettaglio.csv',rows)
    summary=[]
    for cap in CAPS:
        for fac in FACTORS:
            sub=[r for r in rows if r['cap']==cap and r['factor']==fac]
            summary.append({'cap':cap,'shock_factor':fac,'n':len(sub),
             'initial_approved':sum(r['initial_approved'] for r in sub),
             'success':sum(r['successful'] for r in sub),
             'branch_ok':sum(r['branch_feasible'] for r in sub),
             'recovery_approved':sum(r['revote_approved'] for r in sub)})
    v.write_csv(out/'stress_estremo_riepilogo.csv',summary)
    print(summary,flush=True)
if __name__=='__main__':main()
