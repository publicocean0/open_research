#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Out-of-distribution stress V13: guasti simultanei a più settori."""
import argparse
from pathlib import Path
import simulazione_v13 as v
CAPS=(3.0,5.8,7.5,10.0)
STRESS={'doppio_moderato':(.60,.75,1.),
        'doppio_grave':(.45,.50,.80),
        'triplo_estremo':(.25,.35,.60),
        'sistemico':(.25,.15,.50)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mondi',type=int,default=36)
    ap.add_argument('--output',default=str(Path(__file__).resolve().parent/'risultati'))
    a=ap.parse_args()
    rows=[]
    for seed in range(a.mondi):
        for cap in CAPS:
            w,prod,policy,initial_reason=v.choose_policy(seed,cap,.35)
            for scenario,(solar,grid,storage) in STRESS.items():
                post=prod.copy()
                post[1]*=grid
                post[2]*=storage
                r=v.outcome(w,post,policy,solar,.35)
                r.update(seed=seed,cap=cap,scenario=scenario,solar=solar,grid=grid,storage=storage)
                rows.append(r)
        print('correlated completed',seed+1,'/',a.mondi,flush=True)
    dest=Path(a.output);dest.mkdir(parents=True,exist_ok=True)
    v.write_csv(dest/'stress_correlato_dettaglio.csv',rows)
    summ=[]
    for name in STRESS:
        for cap in CAPS:
            z=[r for r in rows if r['scenario']==name and r['cap']==cap]
            summ.append({'scenario':name,'cap':cap,'n':len(z),
                         'approved_initial':sum(r['initial_approved'] for r in z),
                         'success':sum(r['successful'] for r in z),
                         'found_correction':sum(r['correction_found'] for r in z),
                         'revote_approved':sum(r['revote_approved'] for r in z)})
    v.write_csv(dest/'stress_correlato_riepilogo.csv',summ)
    print(summ,flush=True)
if __name__=='__main__':main()
