#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V12: democrazia ponderata e portafogli paralleli a due stadi con recourse.

Prototipo SINTETICO. Obiettivi/metriche già approvati (V3) e non alterati.
Fase 0: due periodi di azioni comuni; fase 1: ramo normale o shock previsto.
La distribuzione di scenario viene fissata PRIMA dello shock; non si usa
informazione sulla realizzazione futura nella pianificazione.

La V11 precedente resta un riferimento riproducibile; questa V12 si concentra
sulla fattibilita' dei programmi condizionali, preservando il voto ponderato.
"""
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
from dataclasses import dataclass
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
V11=HERE.parent/'v11_negoziazione'
sys.path.insert(0,str(V11))
import portafoglio_parallelo as p
import negoziazione_portafoglio_v11 as v11

PREFIX=2
SHOCK_FACTOR=0.60
PROB_SHOCK=0.35
BUDGET_EARLY_RESERVE=5.8  # total funds for the first two periods (out of 26)
TOL=6e-4
METHODS=('programma_fisso', 'condizionale', 'condizionale_riserva')
SCENARIOS=('stabile','shock','shock_variabile','conflitto','conflitto_shock','shock_imprevisto')

@dataclass
class Policy:
    normal: np.ndarray
    stressed: np.ndarray
    transfer: np.ndarray
    weighted_vote: float
    expected_cost: float
    reserve_used: float
    method: str
    approved: bool


def world_for_seed(seed,scenario):
    base=p.make_world(seed, conflict=('conflitto' in scenario))
    rng=np.random.default_rng(702_000+seed)
    prod0=np.clip(1.0+rng.normal(0.0,0.075,p.K),0.80,1.20)
    world=p.World(base.competence,base.group,base.benefit,base.price_sensitivity,prod0)
    return world,prod0


def stressed_productivity(prod0):
    out=prod0.copy();out[0]*=SHOCK_FACTOR
    return out


def outcome_utility(world,x,productivity,transfers):
    m=p.indicators(x,productivity)
    achievement=0.5*(min(1.0,m['energia']/p.TARGET_ENERGY)+min(1.0,m['emissioni_evitate']/p.TARGET_CO2))
    b=v11.burden_profile(world,x)
    return 0.85*world.benefit*achievement-0.32*world.price_sensitivity*b[world.group]+0.12*transfers[world.group]


def weighted_policy_vote(world,normal,stressed,prod0,prod_stress,transfers,risk=PROB_SHOCK):
    if not v11.net_zero(world,transfers):raise ValueError('Compensazioni non bilanciate')
    # Exactly the same competence weights used by the V11 voting model.
    weights=0.08+world.competence@p.RELEVANCE
    u=(1.0-risk)*outcome_utility(world,normal,prod0,transfers) + risk*outcome_utility(world,stressed,prod_stress,transfers)
    return float(np.dot(weights,u>=0.51)/np.sum(weights))


def target_grad(x,prod):
    """Derivatives of technical outcomes w.r.t T x K portfolio."""
    time=np.linspace(1.15,1.0,p.T)[:,None]
    s=np.sum(x*time,axis=0)*prod
    a,b,c,d=s
    ac=np.sqrt(max(a*c,0.0)+1e-10);ab=np.sqrt(max(a*b,0.0)+1e-10)
    energy=np.array([1.12+0.09*c/ac+0.11*b/ab,
                     0.58+0.11*a/ab,0.73+0.09*a/ac,0.35])
    co2=np.array([0.96,0.12,0.26,1.04])
    raw_stress=0.52*a-0.38*b-0.32*c-0.09*d
    stress=np.array([0.52,-0.38,-0.32,-0.09]) if raw_stress>0 else np.zeros(p.K)
    return np.stack([time*prod*energy,time*prod*co2,time*prod*stress])


def inequalities(x,prod,reserve=None):
    m=p.indicators(x,prod)
    r=np.r_[m['energia']-p.TARGET_ENERGY,m['emissioni_evitate']-p.TARGET_CO2,
            p.STRESS_LIMIT-m['stress_rete'],p.PERIOD_BUDGET-np.asarray(m['spesa_periodo']),p.TOTAL_BUDGET-m['spesa_totale']]
    if reserve is not None:r=np.r_[r,reserve-np.sum((x@p.COSTS)[:PREFIX])]
    return r


def inequalities_jac(x,prod,reserve=None):
    grads=target_grad(x,prod)
    jac=np.zeros((3+p.T+1+(reserve is not None),p.T,p.K))
    jac[0]=grads[0];jac[1]=grads[1];jac[2]=-grads[2]
    for t in range(p.T):jac[3+t,t,:]=-p.COSTS
    jac[3+p.T,:,:]=-p.COSTS
    if reserve is not None:jac[-1,:PREFIX,:]=-p.COSTS
    return jac.reshape(jac.shape[0],-1)


def schedule_objective(x,style='costo'):
    spend=x@p.COSTS
    val=float(np.sum(spend)+0.11*np.sum(np.diff(x,axis=0)**2))
    if style=='rateizzazione':val+=0.18*np.dot(spend,np.linspace(1.0,0.0,p.T))
    if style=='equita':
        shares=(x@np.diag(p.COSTS)@p.BURDEN_SHARE).sum(axis=0)
        val+=35.0*np.sum((shares/max(spend.sum(),1e-8)-0.25)**2)
    return val


def schedule_grad(x,style='costo'):
    g=np.broadcast_to(p.COSTS,(p.T,p.K)).copy()
    d=np.diff(x,axis=0)
    g[:-1]-=0.22*d
    g[1:]+=0.22*d
    if style=='rateizzazione':g+=0.18*np.linspace(1.0,0.0,p.T)[:,None]*p.COSTS
    if style=='equita':
        # Only 2-stage objective uses numerical gradient for fair-shares, and only as a secondary candidate.
        eps=1e-6; gg=np.zeros_like(g)
        for j in range(g.size):
            xp=x.copy().ravel();xm=x.copy().ravel();xp[j]+=eps;xm[j]-=eps
            gg.ravel()[j]=(schedule_objective(xp.reshape(p.T,p.K),style)-schedule_objective(xm.reshape(p.T,p.K),style))/(2*eps)
        return gg
    return g


_POLICY_CACHE={}

def solve_conditional(prod0,method='condizionale',style='costo',maxiter=140):
    """Jointly solve x[:2], x_normal[2:], x_stress[2:]; SLSQP multi-start.

    Shock magnitude is part of public *hypothesized* stress scenario.
    Actual shock magnitude is only observed later, and is never accessed here.
    """
    key=('joint',tuple(np.round(prod0,8)),method,style,maxiter)
    if key in _POLICY_CACHE:
        found=_POLICY_CACHE[key]
        return None if found is None else tuple(x.copy() for x in found)
    stress=stressed_productivity(prod0)
    reserve=BUDGET_EARLY_RESERVE if method=='condizionale_riserva' else None
    nb=p.T*p.K
    early=PREFIX*p.K
    tail=(p.T-PREFIX)*p.K
    size=early+2*tail
    def unpack(z):
        common=z[:early].reshape(PREFIX,p.K)
        norm=np.vstack([common,z[early:early+tail].reshape(p.T-PREFIX,p.K)])
        bad=np.vstack([common,z[early+tail:].reshape(p.T-PREFIX,p.K)])
        return norm,bad
    def f(z):
        normal,bad=unpack(z)
        return (1-PROB_SHOCK)*schedule_objective(normal,style)+PROB_SHOCK*schedule_objective(bad,style)+0.035*float(np.sum((normal[PREFIX:]-bad[PREFIX:])**2))
    def jac_f(z):
        normal,bad=unpack(z)
        gn=schedule_grad(normal,style)*(1-PROB_SHOCK)
        gb=schedule_grad(bad,style)*PROB_SHOCK
        difference=normal[PREFIX:]-bad[PREFIX:]
        gn[PREFIX:]+=0.07*difference
        gb[PREFIX:]-=0.07*difference
        return np.r_[(gn[:PREFIX]+gb[:PREFIX]).ravel(),gn[PREFIX:].ravel(),gb[PREFIX:].ravel()]
    def ineq(z):
        normal,bad=unpack(z)
        return np.r_[inequalities(normal,prod0,reserve),inequalities(bad,stress,reserve)]
    def ineq_jac(z):
        normal,bad=unpack(z)
        jn=inequalities_jac(normal,prod0,reserve)
        jb=inequalities_jac(bad,stress,reserve)
        out=np.zeros((jn.shape[0]+jb.shape[0],size))
        out[:len(jn),:early]=jn[:,:early]
        out[:len(jn),early:early+tail]=jn[:,early:]
        out[len(jn):,:early]=jb[:,:early]
        out[len(jn):,early+tail:]=jb[:,early:]
        return out
    starts=[]
    for fill in (.30,.45,.58):
        normal=np.full((p.T,p.K),fill)
        stress_guess=normal.copy();stress_guess[PREFIX:,0]=np.clip(stress_guess[PREFIX:,0]*0.72,0,1)
        stress_guess[PREFIX:,2]=np.clip(stress_guess[PREFIX:,2]*1.25,0,1)
        starts.append(np.r_[normal[:PREFIX].ravel(),normal[PREFIX:].ravel(),stress_guess[PREFIX:].ravel()])
    best=None
    for x0 in starts:
        res=minimize(f,x0,method='SLSQP',jac=jac_f,bounds=[(0.,1.)]*size,
                     constraints=[{'type':'ineq','fun':ineq,'jac':ineq_jac}],
                     options={'ftol':1e-7,'maxiter':maxiter})
        normal,bad=unpack(res.x)
        if np.min(ineq(res.x)) < -TOL:continue
        value=f(res.x)
        if best is None or value<best[0]:best=(value,normal,bad)
    answer=None if best is None else (best[1],best[2])
    _POLICY_CACHE[key]=answer
    return None if answer is None else tuple(x.copy() for x in answer)


def solve_fixed(prod0):
    key=('fixed',tuple(np.round(prod0,8)))
    if key in _POLICY_CACHE:
        ans=_POLICY_CACHE[key]
        return None if ans is None else tuple(x.copy() for x in ans)
    x=v11.optimize_schedule(prod0,np.zeros((p.T,p.K)),0,'costo',np.full((p.T,p.K),.42))
    ans=None if x is None else (x,x.copy())
    _POLICY_CACHE[key]=ans
    return None if ans is None else tuple(y.copy() for y in ans)


def choose_policy(world,prod0,method):
    stress=stressed_productivity(prod0)
    styles=('costo','rateizzazione') if method!='programma_fisso' else ('costo',)
    alternatives=[]
    for style in styles:
        if method=='programma_fisso':answer=solve_fixed(prod0)
        else:answer=solve_conditional(prod0,method,style)
        if answer is not None:alternatives.append(answer)
    if not alternatives:return None, 'nessuna_proposta_tecnica'
    approved=[]
    for normal,bad in alternatives:
        for tr in v11.transfers(world,normal,True):
            fee=v11.transfer_admin(world,tr)
            # Same compensation package in both branches; no fictitious funding.
            if not (v11.feasible(normal,prod0,world,tr,prior_transfer=np.zeros(4)) and
                    (method=='programma_fisso' or v11.feasible(bad,stress,world,tr,prior_transfer=np.zeros(4)))):
                continue
            if p.economic_cost(normal)+fee>p.TOTAL_BUDGET+1e-5 or p.economic_cost(bad)+fee>p.TOTAL_BUDGET+1e-5:continue
            share=weighted_policy_vote(world,normal,bad,prod0,stress,tr, risk=0.0 if method=='programma_fisso' else PROB_SHOCK)
            if share<=0.5:continue
            cost=(1-PROB_SHOCK)*p.economic_cost(normal)+PROB_SHOCK*p.economic_cost(bad)+fee
            approved.append(Policy(normal,bad,tr,share,cost,float(np.sum((normal@p.COSTS)[:PREFIX])),method,True))
    if not approved:return None, 'voto_ponderato_respinto_o_budget_compensazioni'
    return min(approved,key=lambda q:q.expected_cost), 'approvata'


def simulate(seed,scenario,method):
    world,prod0=world_for_seed(seed,scenario)
    policy,reason=choose_policy(world,prod0,method)
    # True scenario is only determined after the package is approved.
    shock=scenario not in ('stabile','conflitto')
    actual=prod0.copy()
    if shock:
        fac=SHOCK_FACTOR
        if scenario=='shock_imprevisto':
            fac=.55 if seed%2==0 else .72
        elif scenario=='shock_variabile':
            # Shock di intensita variabile: il ramo approvato per 0.60
            # viene valutato su una realizzazione diversa.
            fac=.57 if seed%2==0 else .65
        actual[0]*=fac
    if policy is None:
        plan=np.zeros((p.T,p.K))
        initial_vote=0.0
        legally_approved=0
    else:
        # Both branches approved together as a conditional package.
        # Actions in the first PREFIX periods are identical in both branches.
        assert np.allclose(policy.normal[:PREFIX],policy.stressed[:PREFIX])
        plan=policy.stressed if shock else policy.normal
        initial_vote=policy.weighted_vote
        legally_approved=1
    # Outcomes measured on actual, not anticipated, productivity.
    obs=p.indicators(plan,actual)
    constraints=(obs['stress_rete']<=p.STRESS_LIMIT+TOL and obs['spesa_totale']<=p.TOTAL_BUDGET+TOL and
                 max(obs['spesa_periodo'])<=p.PERIOD_BUDGET+TOL)
    goals=(obs['energia']>=p.TARGET_ENERGY-TOL and obs['emissioni_evitate']>=p.TARGET_CO2-TOL)
    fee=v11.transfer_admin(world,policy.transfer) if policy else 0.0
    constraints=constraints and obs['spesa_totale']+fee<=p.TOTAL_BUDGET+TOL and obs['spesa_periodo'][0]+fee<=p.PERIOD_BUDGET+TOL
    early_spend=float(np.sum((plan@p.COSTS)[:PREFIX]))
    return {'seed':seed,'scenario':scenario,'method':method,'approved':legally_approved,
            'failure_reason':reason,'goals_reached':int(goals and legally_approved),
            'constraints_met':int(constraints and legally_approved),
            'joint_success':int(goals and constraints and legally_approved),
            'goal_gap':round(max(0,p.TARGET_ENERGY-obs['energia'])+max(0,p.TARGET_CO2-obs['emissioni_evitate']),5),
            'weighted_vote':round(initial_vote,5),'early_spend':round(early_spend,5),
            'budget_total':round(obs['spesa_totale']+fee,5),
            'parallel_interventions':int(np.max(np.sum(plan>0.03,axis=1))),
            'shock_true':round(float(actual[0]/prod0[0]),3)}


def run(n,scenarios=SCENARIOS,methods=METHODS):
    rows=[]
    for sc in scenarios:
        for seed in range(n):
            for method in methods:
                rows.append(simulate(seed,sc,method))
    summary=[]
    for sc in scenarios:
        for method in methods:
            sub=[r for r in rows if r['scenario']==sc and r['method']==method]
            summary.append({'scenario':sc,'method':method,'n':len(sub),'approved':sum(r['approved'] for r in sub),
                            'success':sum(r['joint_success'] for r in sub),'rate_pct':round(100*np.mean([r['joint_success'] for r in sub]),1),
                            'mean_gap':round(np.mean([r['goal_gap'] for r in sub]),4),
                            'mean_early_spend_approved':round(float(np.mean([r['early_spend'] for r in sub if r['approved']])) if any(r['approved'] for r in sub) else 0,4)})
    return rows,summary


def paired_bootstrap(rows,a='programma_fisso',b='condizionale_riserva',rep=3000):
    rng=np.random.default_rng(20261107)
    out=[]
    for sc in sorted(set(r['scenario'] for r in rows)):
        aa={(r['seed']):r['joint_success'] for r in rows if r['scenario']==sc and r['method']==a}
        bb={(r['seed']):r['joint_success'] for r in rows if r['scenario']==sc and r['method']==b}
        keys=sorted(set(aa)&set(bb))
        d=np.array([bb[k]-aa[k] for k in keys])
        if not len(d):continue
        boot=np.mean(rng.choice(d,size=(rep,len(d)),replace=True),axis=1)*100
        out.append({'scenario':sc,'n_pairs':len(d),'delta_pp':round(100*np.mean(d),1),
                    'ci95_low_pp':round(float(np.percentile(boot,2.5)),1),
                    'ci95_high_pp':round(float(np.percentile(boot,97.5)),1),
                    'improved':int(np.sum(d>0)),'worsened':int(np.sum(d<0))})
    return out


def write_csv(path,rows):
    with open(path,'w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)


def test():
    rng=np.random.default_rng(1)
    x=rng.uniform(.12,.64,size=(p.T,p.K))
    prod=np.array([.83,1.05,.91,1.01])
    numerical=np.zeros_like(inequalities_jac(x,prod))
    flat=x.ravel()
    for i in range(flat.size):
        plus=flat.copy();minus=flat.copy();plus[i]+=1e-6;minus[i]-=1e-6
        numerical[:,i]=(inequalities(plus.reshape(p.T,p.K),prod)-inequalities(minus.reshape(p.T,p.K),prod))/(2e-6)
    assert np.max(np.abs(numerical-inequalities_jac(x,prod)))<2e-5,'Jacobian incoerente'
    z=solve_conditional(prod,'condizionale')
    if z is not None:
        norm,bad=z
        assert np.allclose(norm[:PREFIX],bad[:PREFIX])
        assert np.min(inequalities(norm,prod))>=-TOL
        assert np.min(inequalities(bad,stressed_productivity(prod)))>=-TOL
    w,initial=world_for_seed(2,'shock')
    for method in METHODS:
        r=simulate(2,'shock',method)
        assert r['joint_success']<=r['approved']
        assert r['parallel_interventions']<=p.K
    tr=np.array([.5,0,0,0]);norm=np.full((p.T,p.K),.42)
    try:weighted_policy_vote(w,norm,norm,initial,initial,tr)
    except ValueError:pass
    else:raise AssertionError('Compensazioni non pareggiate ammesse')
    print('V12 OK: Jacobiano, scenari condividono eseguito, obiettivi, budget, voto ponderato')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--mondi',type=int,default=24)
    ap.add_argument('--output',default=str(HERE/'risultati'))
    a=ap.parse_args()
    if a.test:return test()
    output=Path(a.output);output.mkdir(parents=True,exist_ok=True)
    rows,summary=run(a.mondi)
    write_csv(output/'dettaglio.csv',rows)
    write_csv(output/'riepilogo.csv',summary)
    write_csv(output/'confronti_accoppiati.csv',paired_bootstrap(rows))
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__':main()