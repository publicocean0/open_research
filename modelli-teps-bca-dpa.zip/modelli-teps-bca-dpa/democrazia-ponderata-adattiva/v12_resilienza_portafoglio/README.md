# Democrazia Ponderata Adattiva — V12

**Portafogli paralleli con pianificazione condizionale, riserva e rivoto ponderato**  
Stato: prototipo matematico e simulatore sintetico; non una validazione di una forma di governo.

## Motivazione

La V11 ha introdotto interventi paralleli e negoziazione dei sacrifici. La V12 studia un problema distinto: una strategia inizialmente fattibile può **consumare prima dello shock risorse e flessibilità** che sarebbero necessarie per recuperarne le conseguenze. Il voto resta sempre ponderato per competenza pertinente alla questione. Obiettivi e metriche sono già approvati e NON vengono modificati.

## Algoritmo

La variabile decisionale è una matrice `X[t,i]` con **6 periodi e 4 interventi contemporanei** (rinnovabili, reti, accumuli, efficienza). La nuova strategia ha due rami futuri, ottimizzati **insieme**:

- `X_normale`: andamento previsto;
- `X_shock`: risposta a uno scenario di stress pubblico, con produttività delle rinnovabili moltiplicata per **0,60**.

I primi due periodi sono **identici nei due rami**: non è possibile cambiare retroattivamente interventi eseguiti. Entrambi i rami devono rispettare target, budget per periodo, budget totale e vincoli interdisciplinari. L'ottimizzazione utilizza SciPy SLSQP multistart con Jacobiano esplicito; il mancato reperimento di una soluzione **non prova** che il problema sia impossibile.

Il voto ponderato considera la strategia condizionale complessiva con probabilità simulata dello scenario negativo pari a 0,35. La ponderazione per cittadino utilizza lo schema della V11. Le eventuali compensazioni tra gruppi sono a saldo zero; i costi amministrativi restano contabilizzati. La fase di approvazione politica è distinta dalla ricerca tecnica.

Tre metodi: `programma_fisso` (piano normale senza ricorso), `condizionale` (due rami) e `condizionale_riserva` (due rami, tetto di **5,8 unità** alla spesa dei primi due periodi). Il tetto di riserva è **un parametro sperimentale scelto dal ricercatore**, non un valore legittimato democraticamente.

## Risultati principali — 24 mondi artificiali, 300 cittadini per mondo

| Scenario | Fisso | Condizionale | Condizionale + riserva |
|---|---:|---:|---:|
| Stabile | 24/24 | 24/24 | 24/24 |
| Shock previsto nel modello (fattore 0,60) | 0/24 | 24/24 | 24/24 |
| Shock variabile (0,57/0,65) | 0/24 | 12/24 | 12/24 |
| Conflitto sociale | 0/24 | 6/24 | 6/24 |
| Conflitto + shock | 0/24 | 6/24 | 6/24 |
| Shock non previsto (0,55/0,72) | 0/24 | 12/24 | 12/24 |

**NOTA:** il successo 24/24 nel caso 0,60 è un risultato **interno allo scenario specificato in fase di progettazione**, non dimostra capacità di previsione reale. Il metodo fisso non esegue nuovi rivoti; per confrontare con una V11 reattiva, consultare i risultati V11 (10/24 sullo shock previsto). Non confrontare il fisso con il V11 reattivo come se fossero lo stesso metodo.

## Esperimento di recupero fuori scenario

Il programma iniziale è approvato per 0,60. Dopo due periodi, viene **osservata** un'intensità più severa, 0,55 oppure 0,57; nessun decisore conosce questa realizzazione prima dell'avvio. La rete tenta di correggere soltanto i periodi non eseguiti e sottopone ogni cambiamento al **nuovo voto ponderato**. Qui le misurazioni post-shock sono assunte perfette, un'ipotesi ottimistica.

| Shock effettivo | Senza riserva | Con riserva |
|---|---:|---:|
| 0,55 | 7/24 | 24/24 |
| 0,57 | 7/24 | 24/24 |

Il vantaggio accoppiato è 17/24, cioè **70,8 punti percentuali**, con intervallo bootstrap descrittivo al 95% **[50,0; 87,5]**. I risultati descrivono **solo** questo ambiente sintetico, questo modello di costi e i parametri indicati; le simulazioni non costituiscono dati osservati su cittadini reali.

**Nota:** «nessuna correzione trovata» non equivale a «correzione matematicamente impossibile»; SLSQP è un risolutore locale. Il 24/24 è anche condizionato all'ipotesi di misurazione corretta al momento dello shock.

## Reproduzione

Il codice V12 importa due moduli già presenti nella directory sorella `../v11_negoziazione/`. Da `v12_resilienza_portafoglio`:

```bash
python -m pip install numpy scipy matplotlib
python simulazione_v12.py --test
python recupero_post_shock.py --test
python test_integrita_v12.py
python simulazione_v12.py --mondi 24 --output risultati
python recupero_post_shock.py --mondi 24 --output risultati
```

I CSV archiviati contengono i risultati della batteria già eseguita. Il file `risultati/recupero_accoppiato.csv` descrive le differenze su mondi appaiati. La variabilità inter-mondo è stata prodotta da semi prefissati; non equivale a una stima statistica della qualità politica reale.

## Questioni aperte

1. Verificare altri tipi di shock, più domini e parametri sconosciuti in anticipo.
2. Confrontare più budget di riserva, non un solo valore favorevole.
3. Integrare monitoraggio rumoroso, stima probabilistica e vincoli dinamici più realistici.
4. Collegare V12 alla proposta/voto degli obiettivi e delle metriche della V3.
5. Verificare eventuale concentrazione di potere nei pesi di competenza e robustezza a coalizioni strategiche.
6. Ripetere con generatori sociali e tecnici differenti, includendo verifiche della fattibilità effettiva e del costo dei sacrifici.