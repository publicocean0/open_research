#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Test deterministici della V12; non costituiscono validazione politica."""
import numpy as np
import simulazione_v12 as m
import recupero_post_shock as r

def main():
    m.test()
    r.tests()
    world, prod = m.world_for_seed(0, "shock")
    assert np.ptp(world.competence @ m.p.RELEVANCE) > 0.01
    for method in ("condizionale", "condizionale_riserva"):
        policy = m.solve_conditional(prod, method)
        assert policy is not None
        normal, shock = policy
        assert np.allclose(normal[:m.PREFIX], shock[:m.PREFIX], atol=1e-10)
        assert np.min(m.inequalities(normal, prod)) >= -m.TOL
        assert np.min(m.inequalities(shock, m.stressed_productivity(prod))) >= -m.TOL
        if method == "condizionale_riserva":
            assert sum((normal @ m.p.COSTS)[:m.PREFIX]) <= m.BUDGET_EARLY_RESERVE + m.TOL
        assert all(np.max(np.sum(x > 0.03, axis=1)) > 1 for x in policy)
    for method in m.METHODS:
        row = m.simulate(0, "shock", method)
        assert row["joint_success"] <= row["approved"]
    without = r.one(0, "condizionale", .55)
    with_reserve = r.one(0, "condizionale_riserva", .55)
    assert not without["final_success"] and with_reserve["final_success"]
    assert with_reserve["new_vote"] == 1
    print("OK: tutti i test di integrita V12 superati.")

if __name__ == "__main__":
    main()
