#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Rigenera i grafici V12 dai CSV salvati, senza rieseguire le simulazioni."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SRC=Path(__file__).resolve().parent/"risultati"

def read(filename):
    with (SRC/filename).open(encoding="utf-8",newline="") as f:
        return list(csv.DictReader(f))

def main():
    summary=read("riepilogo.csv")
    scenarios=list(dict.fromkeys(row["scenario"] for row in summary))
    methods=list(dict.fromkeys(row["method"] for row in summary))
    x=np.arange(len(scenarios)); width=.24
    fig,ax=plt.subplots(figsize=(11,5))
    for j,method in enumerate(methods):
        vals=[float(next(row["rate_percent"] for row in summary
              if row["scenario"]==sc and row["method"]==method))
              for sc in scenarios]
        ax.bar(x+(j-1)*width,vals,width,label=method.replace("_"," "))
    ax.set_xticks(x,scenarios,rotation=13,ha="right")
    ax.set_ylabel("Strategie approvate, target e vincoli soddisfatti (%)")
    ax.set_ylim(0,105);ax.legend(fontsize=8);fig.tight_layout()
    fig.savefig(SRC/"confronto_v12.png",dpi=160);plt.close(fig)

    rows=read("recupero_riepilogo.csv")
    shocks=sorted(set(row["shock_factor"] for row in rows))
    methods=list(dict.fromkeys(row["method"] for row in rows))
    x=np.arange(len(shocks));width=.36
    fig,ax=plt.subplots(figsize=(8,4.5))
    for j,method in enumerate(methods):
        vals=[int(next(row["final_successes"] for row in rows
              if row["shock_factor"]==sh and row["method"]==method))
              for sh in shocks]
        ax.bar(x+(j-.5)*width,vals,width,label=method.replace("_"," "))
    ax.set_xticks(x,["Fattore "+z for z in shocks]);ax.set_ylim(0,26)
    ax.set_ylabel("Società con revisione approvata / 24")
    ax.legend(fontsize=9);fig.tight_layout()
    fig.savefig(SRC/"recupero_riserva.png",dpi=160);plt.close(fig)
    print("Grafici scritti in",SRC)

if __name__=="__main__":
    main()
