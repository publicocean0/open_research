#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V12: test FUORI SCENARIO sull'utilita' di riserve iniziali.

I piani sono votati conoscendo il solo stress ipotetico 0.60. Alla fine del
secondo periodo si osserva uno shock REALIZZATO 0.55 o 0.57, e si cerca una
correzione, preservando irrevocabilmente le azioni gia' eseguite.
La nuova proposta richiede un NUOVO voto ponderato; non usa un mandato infinito.
Le metriche tecniche e gli obiettivi sono quelli gia' approvati in V3.
"""
import argparse,csv,json
from pathlib import Path
import numpy as np
import simulazione_v12 as m

HERE=Path(__file__).resolve().parent
METHODS=('condizionale','condizionale_riserva')
SHOCKS=(.55,.57)

def one(seed,method,factor):
    w,prod=m.world_for_seed(seed,'shock')
    policy,reason=m.choose_policy(w,prod,method)
    if policy is None:
        return dict(seed=seed,shock_factor=factor,method=method,initial_approved=0,
                    already_feasible=0,correction_found=0,new_vote=0,
                    final_success=0,early_spend=0.,reason=reason)
    actual=prod.copy();actual[0]*=factor
    old=policy.stressed.copy()
    initial_fee=m.v11.transfer_admin(w,policy.transfer)
    executed=np.zeros((m.p.T,m.p.K));executed[:m.PREFIX]=old[:m.PREFIX]
    def actual_feasible(plan):
        obs=m.p.indicators(plan,actual)
        return (m.p.feasible(plan,actual,m.TOL) and
                obs['spesa_totale']+initial_fee<=m.p.TOTAL_BUDGET+m.TOL and
                obs['spesa_periodo'][0]+initial_fee<=m.p.PERIOD_BUDGET+m.TOL)
    still_ok=actual_feasible(old)
    if still_ok:
        return dict(seed=seed,shock_factor=factor,method=method,initial_approved=1,
                    already_feasible=1,correction_found=1,new_vote=0,
                    final_success=1,early_spend=policy.reserve_used,reason='mandato_condizionale_sufficiente')
    candidate=m.v11.optimize_schedule(actual,executed,m.PREFIX,'costo',old)
    good=(candidate is not None and np.allclose(candidate[:m.PREFIX],executed[:m.PREFIX],atol=1e-9)
          and actual_feasible(candidate))
    if not good:
        return dict(seed=seed,shock_factor=factor,method=method,initial_approved=1,
                    already_feasible=0,correction_found=0,new_vote=0,
                    final_success=0,early_spend=policy.reserve_used,reason='nessuna_correzione_trovata')
    # The old authorization is NOT used for a different schedule.
    share=m.v11.vote(w,candidate,actual,policy.transfer)
    approved=bool(share>0.5)
    return dict(seed=seed,shock_factor=factor,method=method,initial_approved=1,
                already_feasible=0,correction_found=1,new_vote=1,
                final_success=int(approved),early_spend=policy.reserve_used,
                reason='rivoto_approvato' if approved else 'rivoto_respinto',
                share_ponderata=round(share,5))

def run(n):
    rows=[one(seed,method,shock) for shock in SHOCKS for seed in range(n) for method in METHODS]
    summary=[]
    for factor in SHOCKS:
        for method in METHODS:
            z=[r for r in rows if r['method']==method and r['shock_factor']==factor]
            summary.append(dict(shock_factor=factor,method=method,n=len(z),
                                early_spend_mean=round(np.mean([r['early_spend'] for r in z if r['initial_approved']]),3),
                                initials=sum(r['initial_approved'] for r in z),
                                feasible_before_revote=sum(r['already_feasible'] for r in z),
                                corrections_found=sum(r['correction_found'] for r in z),
                                additional_votes=sum(r['new_vote'] for r in z),
                                final_successes=sum(r['final_success'] for r in z)))
    return rows,summary

def write_csv(path,records):
    keys=sorted(set().union(*(d.keys() for d in records)))
    with open(path,'w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys)
        w.writeheader();w.writerows(records)

def tests():
    r=one(0,'condizionale_riserva',.55)
    assert r['final_success']<=r['initial_approved']
    assert r['final_success']<=r['correction_found']
    assert (not r['new_vote']) or (r['reason'] in ('rivoto_approvato','rivoto_respinto'))
    print('OK recupero V12: shock osservato, passato immutabile, correzioni al nuovo voto')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--mondi',type=int,default=24)
    ap.add_argument('--output',default=str(HERE/'risultati'))
    a=ap.parse_args()
    if a.test:return tests()
    dst=Path(a.output);dst.mkdir(exist_ok=True,parents=True)
    rows,summary=run(a.mondi)
    write_csv(dst/'recupero_dettaglio.csv',rows)
    write_csv(dst/'recupero_riepilogo.csv',summary)
    print(json.dumps(summary,indent=2,ensure_ascii=False))
if __name__=='__main__':main()