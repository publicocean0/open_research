#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V4: democrazia PONDERATA, negoziazione progressiva di oneri/interventi.

Studio sintetico, non dimostrazione di efficacia politica.
Usa i modelli tecnici V1 e l'elettorato/decisioni V3. Tutte le votazioni
sono ponderate per competenza pertinente. L'ottimizzazione cerca prima
l'adempimento dei target, poi tra soluzioni ammissibili riduce i costi e
l'esposizione a oneri; il sostegno degli elettori e' un vincolo di approvazione,
NON il fine del modello.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'v3_ponderata'))
sys.path.insert(0,str(ROOT/'v2_adattiva'))
import simulazione as base
import simulazione_ponderata as v3
from simulazione_adattiva import OnlineRLS,as_model

METHODS=('V3-like immediata ponderata','V4 prospettica senza negoziazione',
         'V4 solo scaglionamento','V4 solo redistribuzione','V4 negoziazione adattiva')
SCHEDULES={
 'rapida':np.array([.42,.25,.15,.09,.06,.03]),
 'regolare':np.array([.24,.21,.18,.15,.12,.10]),
 'graduale':np.array([.08,.13,.17,.20,.21,.21]),
}
SPEED={'rapida':.67,'regolare':.54,'graduale':.43}
INTEREST=.03
_PLAN_CACHE={}  # exact deterministic fit; identical simulated information only

@dataclass(frozen=True)
class Bundle:
    x:np.ndarray
    schedule:str
    relief_group:int  # -1 = no reallocation
    relief:float       # fraction of burden moved away from relief_group
    name:str

@dataclass
class Obligation:
    payments:np.ndarray     # future aggregate cash flows
    rate_by_group:np.ndarray
    start:int


def distribution(pop:v3.Electorate, relief_group=-1, relief=0.):
    """Burden per group; population-weighted average is EXACTLY 1.

    Reallocation of cost is zero-sum before 2% administration expense;
    no invented funds, negative contribution, or forgiven liability.
    """
    freq=np.bincount(pop.group,minlength=4).astype(float)
    freq/=freq.sum()
    if np.any(freq<.03):
        raise ValueError('At least 3% in each group needed for this toy model')
    raw=np.array([.91,1.05,1.17,.95]); raw/=np.dot(freq,raw)
    if relief_group>=0 and relief>0:
        saved=freq[relief_group]*raw[relief_group]*relief
        raw[relief_group]*=1-relief
        others=freq.copy();others[relief_group]=0
        raw[others>0]+=saved/np.sum(others)
    assert np.all(raw>=0) and abs(np.dot(freq,raw)-1.)<1e-10
    return raw


def capital_cost(x):
    """Synthetic aggregate funding requirement, NOT voter welfare."""
    h,w,t=x
    return float(7.0+2.1*max(0,h-6.2)+3.2*w+3.0*t)


def schedule_payments(capital,schedule):
    a=SCHEDULES[schedule]
    return capital*a*(1.+INTEREST)**np.arange(len(a))


def final_state(current,plan,periods_left,schedule):
    alpha=SPEED[schedule]
    return np.asarray(plan)+ (np.asarray(current)-np.asarray(plan))*(1-alpha)**periods_left


def actual_goals_ok(x,goals,world,eps=.1):
    vals=v3.actual_values(x,world)
    return all(vals[k]>=g.target-eps if g.direction=='min' else vals[k]<=g.target+eps
               for k,g in goals.items())


def predicted_acceptable(plan,goals,estimated,current,periods_left,schedule,learner=None):
    if np.any(estimated.g(plan)>.09):return False
    # Technical uncertainty is reflected in admissibility, not hidden in votes.
    # Report predictive uncertainty separately; do not silently treat high
    # uncertainty as a mathematical impossibility (stress-tested ex post).
    endpoint=final_state(current,plan,periods_left,schedule)
    return actual_goals_ok(endpoint,goals,estimated,eps=.12)


def current_obligation_flow(obligations,t):
    group_cost=np.zeros(4)
    for o in obligations:
        age=t-o.start
        if 0<=age<len(o.payments):group_cost+=o.payments[age]*o.rate_by_group
    return group_cost


def candidate_groups(pop,mode):
    if mode=='no-negotiation':return [(-1,0.)]
    return [(-1,0.)]+[(k,r) for k in range(4) for r in (.18,.35)]


def subjective_voter_value(pop,estimated,goal,plan,old_x,state,t,total_periods,
                           schedule,relief_group,relief,obligations,mode):
    """Citizens evaluate foreseeable trajectories and payment flows.

    This score ONLY models ballot acceptance. The optimizer does NOT maximize it.
    Known future liabilities and debt interest are explicitly included.
    """
    if mode=='myopic':
        return v3.policy_value(pop,plan,estimated,np.arange(4))
    n=len(pop)
    g=pop.group
    housing=np.array([2.0,.65,.7,1.18])[g]
    climate=np.array([.6,2.1,.55,1.15])[g]
    solidarity=np.array([.52,.66,.35,.62])[g]
    patience=np.array([.88,.91,.79,.91])[g]
    # forward discounted gap to goal, with observable intermediate steps.
    improvement=np.zeros(n)
    existing=np.zeros(n)
    additional_cost=max(0.,capital_cost(plan)-capital_cost(old_x)) if np.linalg.norm(old_x-base.STATUS_QUO)>1e-6 else capital_cost(plan)
    fractions=distribution(pop,relief_group,relief)
    admin=additional_cost*(.02 if relief_group>=0 else 0)
    projected=schedule_payments(additional_cost+admin,schedule)
    current_state=np.array(state,copy=True)
    old_state=np.array(state,copy=True)
    # scale benefit to represent achievement over medium term, not only satisfaction at t
    for d in range(total_periods-t):
        current_state+=SPEED[schedule]*(plan-current_state)
        old_state+=.54*(old_x-old_state)
        newval=v3.actual_values(current_state,estimated)
        oldval=v3.actual_values(old_state,estimated)
        # shared public-objective progress, with heterogeneous interest in domains.
        dh=newval['alloggi']-oldval['alloggi']
        de=oldval['ambiente']-newval['ambiente']
        improvement+=(patience**d)*(housing*dh+climate*de+solidarity*(.52*dh+.48*de))*.36
        # obligations incurred by past policy same in both paths -> cancel;
        # new cash flow has interest and schedule and is NOT free.
        if d<len(projected):
            existing+=(patience**d)*projected[d]*fractions[g]*np.array([.18,.15,.31,.22])[g]
    # real dislocation cost before benefits arrive, higher with abrupt pace
    interruption=(SPEED[schedule]-.35)*np.array([.85,1.05,.75,.91])[g]
    risk=pop.risk*np.sum(np.maximum(estimated.g(plan),0.)**2)*2.0
    return improvement-existing-interruption-risk+pop.jitter*.03


def fraction_for_bundle(pop,model,goals,bundle,old_x,state,t,total_periods,obligations,
                        mode,domain=None):
    topic=f'dominio_{domain}' if domain is not None else 'strategia'
    if mode=='myopic':
        yes=v3.policy_value(pop,bundle.x,model,np.arange(4))>v3.policy_value(pop,old_x,model,np.arange(4))+.035
    else:
        score=subjective_voter_value(pop,model,goals,bundle.x,old_x,state,t,total_periods,
                                    bundle.schedule,bundle.relief_group,bundle.relief,obligations,mode)
        yes=score>.02
    return v3.fraction(pop,topic,yes)[0]


def finance_equity_score(pop,bundle,old_x):
    rate=distribution(pop,bundle.relief_group,bundle.relief)
    additional=max(0.,capital_cost(bundle.x)-capital_cost(old_x)) if np.linalg.norm(old_x-base.STATUS_QUO)>1e-6 else capital_cost(bundle.x)
    admin=additional*(.02 if bundle.relief_group>=0 else 0.)
    amount=schedule_payments(additional+admin,bundle.schedule).sum()
    # second-order criterion; distance in contributions is a proxy, NOT a fairness theorem
    return amount + .4*np.var(rate)*additional


def candidate_plans(goals,estimate,learner,anchor):
    """Fast constrained SLSQP; same feasible set/objectives as V3.

    In contrast to V3, uses 1 warm start (plus a fallback if needed), and
    caches solutions for identical technical information. This is an
    experimental solver choice, not a claim of global optimality.
    """
    key=(estimate.shift.tobytes(),estimate.slope.tobytes(),
         tuple((k,g.target,g.direction) for k,g in sorted(goals.items())),
         np.asarray(anchor).tobytes())
    if key in _PLAN_CACHE:
        return [x.copy() for x in _PLAN_CACHE[key]]
    constraints=[{'type':'ineq','fun':lambda z,k=k:-estimate.g(z)[k]-.07,
                  'jac':lambda z,k=k:-estimate.jac(z)[k]} for k in range(4)]
    for q,g in goals.items():
        if q=='alloggi':
            constraints.append({'type':'ineq','fun':lambda z,t=g.target:z[0]-t,
                                'jac':lambda z:np.array([1.,0.,0.])})
        elif q=='ambiente':
            constraints.append({'type':'ineq','fun':lambda z,t=g.target:t-(5.+estimate.g(z)[3]),
                                'jac':lambda z:-estimate.jac(z)[3]})
    def cost(z,variant):
        h,w,t=z
        if variant==0:return 1.20*w*w+1.05*t*t+.14*(h-6.2)**2
        if variant==1:return .65*w*w+1.75*t*t+.18*(h-6.2)**2
        return 1.8*w*w+.65*t*t+.17*(h-6.2)**2
    def feasible(z):return all(c['fun'](z)>=-1e-4 for c in constraints)
    options={'maxiter':65,'ftol':1.e-7,'disp':False}
    starts=[np.clip(anchor,base.LOW,base.HIGH)]
    out=[]
    for v in range(3):
        current=starts[0]
        opt=minimize(lambda z:cost(z,v),current,method='SLSQP',
                     bounds=list(zip(base.LOW,base.HIGH)),constraints=constraints,options=options)
        x=np.clip(opt.x,base.LOW,base.HIGH)
        if feasible(x) and all(np.linalg.norm(x-z)>1e-4 for z in out):out.append(x)
    if not out:
        for x0 in [np.array([9.0,2.3,2.1]),np.array([8.7,2.7,1.9])]:
            opt=minimize(lambda z:cost(z,0),np.clip(x0,base.LOW,base.HIGH),
                        method='SLSQP',bounds=list(zip(base.LOW,base.HIGH)),
                        constraints=constraints,options=options)
            x=np.clip(opt.x,base.LOW,base.HIGH)
            if feasible(x):out.append(x);break
    if len(_PLAN_CACHE)>4000:_PLAN_CACHE.clear()
    _PLAN_CACHE[key]=tuple(x.copy() for x in out)
    return out


def negotiate(pop,goals,estimate,learner,state,old_x,t,periods,obligations,
              method,diagnostics=False):
    """Full 4-domain feedback, optional revised bundles, then weighted global vote.

    Priorities:
    (1) all targets and constraints projected feasible;
    (2) a weighted ballot approves the package;
    (3) among admissible packages, lower finance + inequality proxy.
    """
    mode='myopic' if method==METHODS[0] else 'forward'
    phased=method in (METHODS[2],METHODS[4])
    transfers_on=method in (METHODS[3],METHODS[4])
    anchor=np.array([max(goals['alloggi'].target+.55,9.2) if 'alloggi' in goals else 9.1,.28,.48])
    anchor=np.clip(anchor,base.LOW,base.HIGH)
    # four independent feedback messages, whose Jacobian directions trace the
    # technical consequences to original strategy variables.
    domain_signal={}
    corrected=anchor.copy()
    for k in range(4):
        resid=max(0.,float(estimate.g(corrected)[k]))
        back=estimate.jac(corrected)[k]*resid
        domain_signal[base.DOMAINS[k]]={'residuo':resid,'gradiente':back.tolist()}
        if np.linalg.norm(back)>1.e-10:
            corrected=np.clip(corrected-.30*back/(np.linalg.norm(back)+1.e-12),base.LOW,base.HIGH)
    # The corrected engineering proposal is the input to candidate generation.
    # This is the actual feedback path, not merely a recorded diagnostic.
    plans=candidate_plans(goals,estimate,learner,corrected)
    if not plans:return {'approved':False,'reason':'nessun_piano_tecnico','backprop':sum(v['residuo'] for v in domain_signal.values()),
                           'domain_feedback':domain_signal,'ballots':0}
    schedules=list(SCHEDULES) if phased else ['regolare']
    transfers=candidate_groups(pop,'negotiation' if transfers_on else 'no-negotiation')
    evaluated=[]
    for j,p in enumerate(plans):
        for s in schedules:
            if not predicted_acceptable(p,goals,estimate,state,periods-t,s,learner):continue
            for relief_group,relief in transfers:
                b=Bundle(p,s,relief_group,relief,f'p{j}-{s}-g{relief_group}-{relief}')
                share=fraction_for_bundle(pop,estimate,goals,b,old_x,state,t,periods,obligations,mode)
                if share>.5:
                    # Every domain participates via topic-specific competency-weighted feedback votes;
                    # these are NOT vetoes against an otherwise approved global reconsideration.
                    local=[fraction_for_bundle(pop,estimate,goals,b,old_x,state,t,periods,obligations,mode,domain=k)
                           for k in range(4)]
                    evaluated.append((finance_equity_score(pop,b,old_x),b,share,local))
    if not evaluated:
        return {'approved':False,'reason':'voto_respinto_o_target_incompatibile',
                'backprop':sum(v['residuo'] for v in domain_signal.values()),
                'domain_feedback':domain_signal,'ballots':len(plans)*len(schedules)*len(transfers)}
    # The voting threshold is a constraint. Approval magnitude is not the objective.
    _,winner,share,local=min(evaluated,key=lambda z:z[0])
    return {'approved':True,'reason':'approvata','bundle':winner,
            'vote_share':share,'domain_shares':local,
            'backprop':sum(v['residuo'] for v in domain_signal.values()),
            'domain_feedback':domain_signal,'ballots':len(plans)*len(schedules)*len(transfers)}


def maybe_enact(pop,result,old_x,obligations,t):
    if not result['approved']:return old_x,False,0.
    bundle=result['bundle'];x=bundle.x
    if np.linalg.norm(x-old_x)<.02:return old_x,False,0.
    extra=max(0.,capital_cost(x)-capital_cost(old_x)) if np.linalg.norm(old_x-base.STATUS_QUO)>1e-6 else capital_cost(x)
    # A less costly revision can still be enacted; previous expenses remain sunk,
    # so no refunds or newly invented resources are created.
    if extra<.02:return x,True,0.
    admin=extra*(.02 if bundle.relief_group>=0 else 0.)
    obligations.append(Obligation(schedule_payments(extra+admin,bundle.schedule),
                                  distribution(pop,bundle.relief_group,bundle.relief),t))
    return x,True,extra+admin


def simulate_world(seed,n,periods,scenario,revision=True):
    rng=np.random.default_rng(seed)
    pop=v3.build_electorate(rng,n,scenario)
    theta,panel=v3.make_world(rng,periods,scenario)
    candidates=[v3.Proposal('alloggi',8.7,int((seed+17)%n)),
      v3.Proposal('alloggi',9.1,int((seed+53)%n)),
      v3.Proposal('ambiente',4.6,int((seed+23)%n)),
      v3.Proposal('ambiente',4.35,int((seed+71)%n))]
    goals,agenda_events=v3.select_goals(pop,candidates,periods)
    if len(goals)<2:return [],[],[]
    initial_goals=goals.copy()
    metrics={topic:v3.metric_vote(pop,topic,distortion=.7 if scenario=='dati_distorti' else 0.)[0]
             for topic in goals}
    noise=rng.normal(0,.10,(periods,4))
    all_rows=[];decisions=[];audits=[]
    for method in METHODS:
        learner=OnlineRLS.from_panel(panel,uncertainty=.32,noise=.16) if method!=METHODS[0] else None
        state=base.STATUS_QUO.copy();old_x=base.STATUS_QUO.copy()
        obligations=[];s='regolare';g=goals.copy()
        current_metrics=metrics.copy();metric_mismatch={q:0 for q in g}
        last_share=float('nan');last_decision='inizio';review_count=0
        for t in range(periods):
            true=as_model(theta[t]);est=learner.predictor() if learner is not None else as_model(panel)
            # Objective revision: same weighted petition + weighted vote as V3.
            if revision and t>0 and t%4==0:
                petition,rev=v3.revision_petition(pop,g,t,scenario)
                if petition is not None and rev['passed']:
                    g[petition.topic]=v3.replace(g[petition.topic],target=petition.target,
                                                 version=g[petition.topic].version+1)
                    decisions.append({'world':seed,'scenario':scenario,'method':method,'t':t+1,
                                     'event':'obiettivo_rivisto','topic':petition.topic,'old_or_new':petition.target})
            # At the first period and at scheduled control points, specialists
            # reopen engineering choices based on the predicted errors.
            if t in (0,4,7):
                result=negotiate(pop,g,est,learner,state,old_x,t,periods,obligations,method)
                if result['approved']:
                    chosen=result['bundle'];old_x,enacted,extra=maybe_enact(pop,result,old_x,obligations,t)
                    if enacted:s=chosen.schedule
                    last_share=result['vote_share']
                else:enacted=False;extra=0.
                last_decision=result['reason']
                decisions.append({'world':seed,'scenario':scenario,'method':method,'t':t+1,
                    'event':'strategia','approved':int(result['approved']),'enacted':int(enacted),
                    'status':last_decision,'share':result.get('vote_share',float('nan')),
                    'schedule':result['bundle'].schedule if result['approved'] else '',
                    'relief_group':result['bundle'].relief_group if result['approved'] else -1,
                    'relief':result['bundle'].relief if result['approved'] else 0.,
                    'backprop':result['backprop'],'ballots_checked':result['ballots'],
                    'domain_shares':str(result.get('domain_shares',[])),'extra_finance':extra,
                    'current_plan':str(old_x.tolist())})
            state=state+SPEED[s]*(old_x-state)
            observation=true.g(state)+noise[t]
            if learner is not None:learner.update(state,observation)
            actual=v3.actual_values(state,true)
            reported={q:v3.measure(actual[q],m,np.sin(seed*.17+t*.9+len(q)*.7))
                      for q,m in current_metrics.items()}
            gaps=[];official=[]
            initial_gaps=[]
            for q,target in initial_goals.items():
                sign=1. if target.direction=='min' else -1.
                initial_gaps.append(max(0.,sign*(target.target-actual[q])))
            for q,target in g.items():
                sign=1. if target.direction=='min' else -1.
                gaps.append(max(0.,sign*(target.target-actual[q])))
                official.append(max(0.,sign*(target.target-reported[q])))
                if abs(actual[q]-reported[q])>.25:metric_mismatch[q]+=1
                else:metric_mismatch[q]=0
                if metric_mismatch[q]>=2:
                    replacement,event=v3.metric_vote(pop,q,distortion=0.)
                    if replacement is not None:
                        audits.append({'world':seed,'scenario':scenario,'method':method,'t':t+1,
                                       'topic':q,'from':current_metrics[q].name,'to':replacement.name,
                                       'n_experts':event['votanti_qualificati']})
                        current_metrics[q]=replacement
                    metric_mismatch[q]=0
            burdens=current_obligation_flow(obligations,t)
            freq=np.bincount(pop.group,minlength=4)/len(pop)
            debt_future=sum(o.payments[max(t+1-o.start,0):].sum() for o in obligations
                            if t+1-o.start<len(o.payments))
            true_violation=float(np.max(np.maximum(true.g(old_x),0.)))
            all_rows.append({'world':seed,'scenario':scenario,'method':method,'t':t+1,
               'approved_plan':int(np.linalg.norm(old_x-base.STATUS_QUO)>.02),
               'target_count':len(g),'target_achieved_count':int(sum(x<=.10 for x in gaps)),
               'both_targets':int(all(x<=.10 for x in gaps)),
               'joint_success':int(all(x<=.10 for x in gaps) and true_violation<=1.e-4),
               'initial_targets':int(all(x<=.10 for x in initial_gaps)),
               'initial_joint_success':int(all(x<=.10 for x in initial_gaps) and true_violation<=1.e-4),
               'initial_objective_gap':float(sum(initial_gaps)),
               'objective_gap':float(sum(gaps)),
               'official_gap':float(sum(official)),
               'false_complete':int(all(v<=.10 for v in official) and not all(v<=.10 for v in gaps)),
               'housing':actual['alloggi'],'environment':actual['ambiente'],
               'housing_target':g['alloggi'].target,'environment_target':g['ambiente'].target,
               'true_technical_violation':true_violation,
               'weighted_last_vote':last_share,'approval_status':last_decision,
               'financial_paid':float(np.dot(freq,burdens)),
               'financial_burden_max_group':float(np.max(burdens)),
               'financial_burden_min_group':float(np.min(burdens)),
               'outstanding_debt':debt_future,
               'prediction_rmse':float(np.linalg.norm(est.g(state)-true.g(state))/2),
               'metrics_revisions':len([e for e in audits if e['world']==seed and e['method']==method and e['scenario']==scenario]),
               'goal_versions':str({q:g[q].version for q in g})})
    return all_rows,decisions,audits


def summarize(rows,decisions,periods):
    summary=[]
    for scenario in sorted(set(r['scenario'] for r in rows)):
      for method in METHODS:
        rs=[r for r in rows if r['scenario']==scenario and r['method']==method]
        finals=[r for r in rs if r['t']==periods]
        ds=[d for d in decisions if d['scenario']==scenario and d['method']==method and d['event']=='strategia']
        def mean(k):return float(np.mean([r[k] for r in rs]))
        summary.append({'scenario':scenario,'method':method,'worlds':len(finals),
            'decisions':len(ds),
            'approved_ballots_pct':round(100*np.mean([d['approved'] for d in ds]),1),
            'final_targets_reached_pct':round(100*np.mean([r['both_targets'] for r in finals]),1),
            'final_joint_success_pct':round(100*np.mean([r['joint_success'] for r in finals]),1),
            'mean_final_objective_gap':round(float(np.mean([r['objective_gap'] for r in finals])),3),
            'initial_targets_reached_final_pct':round(100*np.mean([r['initial_targets'] for r in finals]),1),
            'initial_joint_success_final_pct':round(100*np.mean([r['initial_joint_success'] for r in finals]),1),
            'initial_goal_gap_final':round(float(np.mean([r['initial_objective_gap'] for r in finals])),3),
            'mean_objective_gap':round(mean('objective_gap'),3),
            'mean_true_violation':round(mean('true_technical_violation'),3),
            'mean_financial_paid_per_period':round(mean('financial_paid'),3),
            'mean_max_group_burden':round(mean('financial_burden_max_group'),3),
            'mean_outstanding_debt_final':round(float(np.mean([r['outstanding_debt'] for r in finals])),3),
            'false_complete_pct':round(100*mean('false_complete'),1),
            'mean_prediction_rmse':round(mean('prediction_rmse'),3)})
    return summary


def write_csv(path,records):
    if not records:return
    keys=list(dict.fromkeys(k for r in records for k in r))
    with open(path,'w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader();wr.writerows(records)


def plot(rows,dest):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for scenario in sorted(set(r['scenario'] for r in rows)):
        plt.figure(figsize=(9,5))
        for method in METHODS:
            rs=[r for r in rows if r['scenario']==scenario and r['method']==method]
            periods=sorted(set(r['t'] for r in rs))
            y=[np.mean([r['objective_gap'] for r in rs if r['t']==t]) for t in periods]
            plt.plot(periods,y,marker='o',label=method)
        plt.title('Scostamento dagli obiettivi - '+scenario)
        plt.ylabel('Gap dai target (unità sintetiche)');plt.xlabel('Periodo')
        plt.grid(alpha=.25);plt.legend(fontsize=8);plt.tight_layout()
        plt.savefig(dest/f'traiettoria_{scenario}.png',dpi=140);plt.close()

def selftest():
    rng=np.random.default_rng(121)
    pop=v3.build_electorate(rng,300,'conflitto')
    # All domain & goal/strategy votes use question-relevant weights.
    for q in ('alloggi','ambiente','strategia','dominio_0','dominio_3'):
        w,_=v3.weights(pop,q)
        assert np.std(w)>0 and np.all(w>0)
    for k in range(4):
        for r in (.18,.35):
            d=distribution(pop,k,r)
            freq=np.bincount(pop.group,minlength=4)/len(pop)
            assert abs(np.dot(freq,d)-1)<1e-10 and d.min()>=0
    assert len(METHODS)==5
    # Weighted majority is not simple headcount.
    tiny=v3.Electorate(np.array([[1.,1.,1.,1.],[.1,.1,.1,.1],[.1,.1,.1,.1]]),
                      np.array([0,0,0]),np.zeros(3),np.ones(3))
    assert v3.fraction(tiny,'strategia',np.array([True,False,False]))[0]>.5
    assert abs(sum(SCHEDULES['graduale'])-1)<1e-12
    assert schedule_payments(10,'graduale').sum()>10
    assert abs(sum(schedule_payments(10,'rapida'))-sum(schedule_payments(10,'graduale')))>0.01
    assert np.linalg.norm(final_state(base.STATUS_QUO,np.array([9,2,2]),10,'graduale')-np.array([9,2,2]))<.02
    ob=[Obligation(schedule_payments(10,'regolare'),distribution(pop,2,.35),0)]
    f=np.bincount(pop.group,minlength=4)/len(pop)
    for t in range(6):assert abs(np.dot(f,current_obligation_flow(ob,t))-ob[0].payments[t])<1e-10
    # No unilateral targets changes without formal weighted V3 petition.
    g={'alloggi':v3.Goal('alloggi',8.7,'min',10), 'ambiente':v3.Goal('ambiente',4.6,'max',10)}
    original={k:v.target for k,v in g.items()}
    result=negotiate(pop,g,as_model(np.zeros((4,4))),None,base.STATUS_QUO.copy(),
                     base.STATUS_QUO.copy(),0,10,[],'V4 negoziazione adattiva')
    assert {k:v.target for k,v in g.items()}==original
    assert 'domain_feedback' in result and len(result['domain_feedback'])==4
    print('10 controlli di integrità V4: OK')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--test',action='store_true')
    parser.add_argument('--mondi',type=int,default=8)
    parser.add_argument('--cittadini',type=int,default=300)
    parser.add_argument('--periodi',type=int,default=10)
    parser.add_argument('--scenario',choices=['tutti','stabile','cambiamento','dati_distorti','conflitto'],default='tutti')
    parser.add_argument('--output',type=Path,default=Path(__file__).parent/'risultati')
    args=parser.parse_args()
    if args.test:selftest();return
    args.output.mkdir(parents=True,exist_ok=True)
    scenarios=['stabile','cambiamento','dati_distorti','conflitto'] if args.scenario=='tutti' else [args.scenario]
    rows=[];decisions=[];audits=[]
    for scenario in scenarios:
      for i in range(args.mondi):
        r,d,a=simulate_world(1000+i*37,args.cittadini,args.periodi,scenario)
        rows+=r;decisions+=d;audits+=a
    summary=summarize(rows,decisions,args.periodi)
    write_csv(args.output/'periodi.csv',rows)
    write_csv(args.output/'voti_e_revisioni.csv',decisions)
    write_csv(args.output/'audit_metriche.csv',audits)
    write_csv(args.output/'riepilogo.csv',summary)
    plot(rows,args.output)
    (args.output/'riepilogo.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('Simulated votes:',len(decisions),'metric audits:',len(audits))
if __name__=='__main__':main()