# Democrazia Ponderata Adattiva — V4: negoziazione intertemporale

**Prototipo Python sperimentale, 7 novembre 2026.** Questa simulazione utilizza esclusivamente dati e cittadini sintetici. Non dimostra la validità politica, l'equità o la superiorità del meccanismo.

## Punto di partenza: un solo principio di voto

**Tutte** le votazioni utilizzano il voto ponderato per competenza **specifica della questione**, comprese approvazione e revisione degli obiettivi, controllo delle metriche e scelta delle strategie. La V4 riutilizza le procedure della V3; non introduce una fase a voto egualitario. La competenza è una variabile **generata dal simulatore**, non una valutazione affidabile di cittadini reali.

- Ogni cittadino può presentare un obiettivo e richiederne la revisione, indipendentemente dalla propria competenza.
- Le proposte devono ottenere sostegno ponderato e un minimo di sostenitori individuali per accedere all'agenda.
- Un **voto ponderato** approva l'obiettivo; la strategia è deliberata **separatamente**.
- Solo cittadini con competenza sufficiente nel settore possono proporre e votare metriche; anche il voto sulle metriche è ponderato.
- L'obiettivo approvato comprende target, direzione, scadenza e metriche. La revisione richiede una nuova iniziativa e un nuovo voto, mai un aggiustamento automatico dell'algoritmo.

## Novità implementata

Per ogni proposta, il simulatore esegue un ciclo di verifica interdisciplinare. Per ciascun ambito, calcola un residuo di vincolo e una retropropagazione:

\[
 b_k=J_{g_k}(x)^\top\max(0,g_k(x)).
\]

La correzione orienta il punto di partenza della ricerca tecnica vincolata. Si producono più piani realizzabili **secondo le informazioni disponibili**; poi la V4 esplora modi di distribuirne i sacrifici:

1. **Scaglionamento**: rateizzazione *rapida*, *regolare*, *graduale* (sei periodi, interesse del 3% su quote differite).
2. **Redistribuzione**: sollievo del 18% o 35% del carico per uno dei quattro gruppi; gli altri gruppi finanziano la differenza. La somma dei contributi, ponderata per la popolazione, rimane esattamente uguale al costo complessivo, più una spesa amministrativa del 2% se c'è redistribuzione.
3. **Rivoto ponderato**: vengono registrati i sostegni specifici per i quattro ambiti e svolto un voto globale ponderato sul pacchetto. I voti di ambito sono **consultivi e diagnostici**, non veti automatici; un veto locale non può cambiare da solo l'obiettivo. La proposta finale non passa se il voto globale è contrario.
4. **Monitoraggio**: una volta attuata la strategia, l'effetto si realizza gradualmente. Le misurazioni aggiornano il modello RLS; una discordanza ripetuta delle metriche attiva un nuovo voto specialistico.

**Priorità:** l'algoritmo cerca anzitutto proposte che secondo il modello consentono il raggiungimento dei target entro la scadenza, nel rispetto dei vincoli tecnici stimati. Il voto ponderato è la condizione per adottarle. Fra le alternative fattibili e approvate viene minimizzato un costo finanziario sintetico (onere totale più dispersione degli oneri tra gruppi). **Non** viene massimizzata una funzione di soddisfazione dei cittadini. Le preferenze individuali simulate entrano soltanto nella decisione di voto; possono rappresentare sacrifici, valori collettivi attesi, rischio e orizzonte temporale.

La rateizzazione non crea risorse gratuite: i pagamenti tardivi aumentano per interessi. Analogamente, la compensazione non riduce il totale delle risorse necessarie. Una revisione meno costosa non restituisce automaticamente i soldi già spesi.

## Metodi confrontati

1. **V3-like immediata ponderata**: preferenze a breve termine, senza negoziazione; stimatore tecnico fisso. È un confronto di struttura **ispirato alla V3**, non la riproduzione byte-per-byte della V3 originale.
2. **V4 prospettica senza negoziazione**: stessi voti ponderati, previsioni RLS e valutazione delle conseguenze di medio periodo, ma nessuna scelta sui tempi di pagamento o sulle compensazioni.
3. **V4 solo scaglionamento**: tre profili temporali, nessun trasferimento tra gruppi.
4. **V4 solo redistribuzione**: diversi riparti degli oneri, calendario fisso.
5. **V4 negoziazione adattiva**: entrambe le leve e retropropagazione tecnica.

I metodi condividono lo **stesso elettorato, i medesimi obiettivi iniziali, lo stesso mondo fisico e le medesime perturbazioni esogene**, per permettere confronti accoppiati. Sono simulati 36 mondi, 300 cittadini, 10 periodi e quattro scenari. I mondi hanno semi uguali **tra scenari**: i quattro scenari non sono quattro campioni indipendenti. Tre occasioni di voto strategico per mondo e metodo (periodi 1, 5, 8); revisioni possibili degli obiettivi ai periodi 5 e 9.

## Come leggere le misure

La variabile **`final_joint_success_pct`** richiede **simultaneamente**:

- raggiungimento effettivo di **entrambi i target approvati** al termine;
- assenza di violazioni dei quattro vincoli tecnici nel modello **reale sintetico**, che gli agenti non conoscono in anticipo.

`initial_joint_success_final_pct` aggiunge un controllo importante: si valutano i target **originariamente approvati**, anche se sono stati successivamente revisionati con voto ponderato. `final_targets_reached_pct`, invece, controlla solo i target in vigore alla fine, indipendentemente dai vincoli tecnici reali. Il `mean_final_objective_gap` è una somma di scostamenti in unità sintetiche, utile per comparare metodi **nello stesso esperimento**, non un indicatore universale.

### Risultati, 36 società per scenario

| Scenario | V3-like immediata (successo rigoroso) | V4 prospettica senza negoziazione | V4 completa |
|---|---:|---:|---:|
| Stabile | 36,1% | 50,0% | **58,3%** |
| Cambiamento | 11,1% | 11,1% | **11,1%** |
| Dati distorti | 11,1% | 11,1% | **11,1%** |
| Conflitto elevato | 0,0% | 0,0% | **2,8%** |

La differenza accoppiata V4 completa vs immediata nello scenario stabile è **+22,2 punti**, IC bootstrap illustrativo 95% **[+2,8; +41,7]**. Se invece si confrontano V4 completa e V4 prospettica **senza negoziazione**, la differenza è **+8,3 punti**, IC **[0,0; +19,4]**. Il dato non basta a provare un beneficio generalizzabile della sola negoziazione: molte caratteristiche del simulatore restano assunte e calibrate arbitrariamente.

Nel conflitto la V4 completa approva una nuova strategia in 3 dei 108 appuntamenti di voto (2,8%), e solo 1 dei 36 mondi raggiunge entrambi i target rispettando tutti i vincoli. **Non** è un problema risolto.

Nel cambiamento e nei dati distorti il miglioramento dello scostamento medio dagli obiettivi **non** si traduce in un maggiore tasso di successo rigoroso. Il simulatore riconosce quindi la differenza tra scegliere percorsi più promettenti **secondo le previsioni** e rispettare davvero tutti i vincoli.

Nel test dati distorti la procedura di audit ha eseguito nuove votazioni specialistiche su metriche erronee. L'auditor dispone di un valore vero sintetico: nel mondo reale la misura indipendente può essere incerta o controversa.

## Riproduzione

Dalla cartella che contiene `democrazia-ponderata-adattiva/`:

```bash
python -m pip install -r democrazia-ponderata-adattiva/v4_negoziazione/requirements.txt
python democrazia-ponderata-adattiva/v4_negoziazione/simulazione_v4.py --test
python democrazia-ponderata-adattiva/v4_negoziazione/simulazione_v4.py --mondi 36 --cittadini 300 --periodi 10 --scenario tutti --output democrazia-ponderata-adattiva/v4_negoziazione/risultati
python democrazia-ponderata-adattiva/v4_negoziazione/analisi_v4.py --dir democrazia-ponderata-adattiva/v4_negoziazione/risultati
```

Per una prova rapida usare `--mondi 3`. I risultati dipendono dalle versioni delle librerie e dalla convergenza del risolutore numerico; il codice imposta semi pseudocasuali e conserva le tabelle di dettaglio.

Contenuto dei CSV:

- `risultati/periodi.csv`: risultati reali e misurati, target iniziali e revisionati, vincoli effettivi, costi, debito futuro, stato e votazioni;
- `risultati/voti_e_revisioni.csv`: esito di ogni voto strategico e di ogni revisione dell'obiettivo, piani, scaglionamento e compensazioni;
- `risultati/audit_metriche.csv`: controlli e voti specialistici per sostituire metriche distorte;
- `risultati/riepilogo.csv`: risultati aggregati;
- `risultati/confronti_accoppiati.csv`: differenze e intervalli bootstrap tra mondi appaiati;
- `risultati/confronto_cinque_metodi.png` e `traiettoria_*.png`: grafici.

## Cosa non è ancora dimostrato

- Le distribuzioni delle competenze e dei valori civici sono **artificiali**; manca una certificazione affidabile e verificabile dei pesi.
- Le differenze di propensione al sacrificio sono assunte dal codice. La regola che indica le preferenze e la loro scala può determinare il risultato.
- La redistribuzione è un modello contabile giocattolo: non descrive un vero sistema fiscale o di welfare; non modella vincoli redistributivi costituzionali, rischi di cattura o tutela effettiva delle minoranze.
- Le risorse complessive sono vincolate nel modello tecnico, ma la finanza pluriannuale è semplificata; il costo degli interessi è un parametro ipotetico.
- La retropropagazione usa un Jacobiano di una piccola struttura sintetica; non esiste una dimostrazione di convergenza della deliberazione generale.
- Il risolutore SLSQP offre candidati praticabili **secondo le stime**, non prove di fattibilità reale o ottimalità globale.
- I voti locali di settore informano la proposta, ma non sono ancora deliberazioni strutturate su emendamenti sequenziali. Il voto finale è ponderato sull'intero pacchetto.
- L'audit ideale e i mondi sintetici sovrastimano la disponibilità di un riferimento indipendente ai risultati causali.
- Il successivo problema di ricerca riguarda un **protocollo resistente a shock e errori tecnici**, con ulteriori rivoti e correzioni dei vincoli, senza cambiare automaticamente gli obiettivi.

**Conclusione:** la V4 è un ambiente sperimentale riproducibile per studiare negoziazione dei sacrifici, voto ponderato e retropropagazione. I risultati mostrano possibilità e limiti, non una prova che il sistema debba essere adottato come istituzione reale.