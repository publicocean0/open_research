#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Confronto accoppiato di strategie V11 (esperimento sintetico).
Uso: python analisi_accoppiata_v11.py risultati_portafoglio_negoziato/dettaglio.csv
"""
import argparse
import csv
import json
from collections import defaultdict
import random
from pathlib import Path

def analyze(rows, control="senza_negoziazione", treatment="negoziazione_completa",
            repetitions=5000, seed=20261107):
    grouped = defaultdict(dict)
    for row in rows:
        grouped[(row["scenario"], int(row["seed"]))][row["method"]] = int(row["joint_success"])
    output = []
    for scenario in sorted({key[0] for key in grouped}):
        pairs = [(v[control], v[treatment]) for (sc, _), v in grouped.items()
                 if sc == scenario and control in v and treatment in v]
        if not pairs:
            continue
        diffs = [b - a for a, b in pairs]
        n = len(diffs)
        rng = random.Random(seed)
        samples = sorted(100.0 * sum(rng.choices(diffs, k=n)) / n
                         for _ in range(repetitions))
        lower, upper = samples[int(0.025 * repetitions)], samples[int(0.975 * repetitions) - 1]
        output.append({
            "scenario": scenario,
            "n_coppie": n,
            "successi_base": sum(a for a, _ in pairs),
            "successi_negoziazione": sum(b for _, b in pairs),
            "solo_base": sum(a == 1 and b == 0 for a, b in pairs),
            "solo_negoziazione": sum(a == 0 and b == 1 for a, b in pairs),
            "delta_pp": round(100.0 * sum(diffs) / n, 1),
            "bootstrap95_pp": [round(lower, 1), round(upper, 1)]
        })
    return output

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", nargs="?", default=str(
        Path(__file__).resolve().parent / "risultati_portafoglio_negoziato/dettaglio.csv"))
    args = ap.parse_args()
    with open(args.file, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    print(json.dumps(analyze(rows), indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
