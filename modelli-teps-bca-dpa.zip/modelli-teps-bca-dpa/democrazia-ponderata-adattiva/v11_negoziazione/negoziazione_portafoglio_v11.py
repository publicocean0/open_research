# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
from __future__ import annotations
import argparse, csv, json
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
import portafoglio_parallelo as p
HERE = Path(__file__).resolve().parent
METHODS = ('senza_negoziazione', 'solo_calendario', 'solo_compensazioni', 'negoziazione_completa')
SCENARIOS = ('stabile', 'shock', 'shock_rumoroso', 'conflitto', 'conflitto_shock')
EARLY = np.linspace(1.15, 1.0, p.T)
TOL = 0.0005
ADMIN_RATE = 0.08
TRANSFER_UNIT = 1.0
_SOLVE_CACHE = {}

@dataclass(frozen=True)
class Package:
    plan: np.ndarray
    transfer: np.ndarray
    vote: float
    cost: float
    burden: float
    parallel_count: int
    solution: str

def counts(world):
    return np.bincount(world.group, minlength=4).astype(float)

def burden_profile(world, x):
    freq = counts(world) / len(world.group)
    project_time = np.array([1.08, 1.04, 1.09, 1.05])
    clock = np.linspace(1.0, 0.2, p.T)[:, None]
    expenditure = x * p.COSTS[None, :]
    by_group = (expenditure * (1.0 + clock * (project_time - 1.0)) @ p.BURDEN_SHARE).sum(axis=0)
    return by_group / np.maximum(freq, 1e-09) / max(p.economic_cost(x), 1e-08)

def transfer_admin(world, c):
    freq = counts(world) / len(world.group)
    return float(ADMIN_RATE * TRANSFER_UNIT * np.dot(freq, np.maximum(c, 0.0)))

def net_zero(world, transfer, atol=1e-08):
    return abs(float(counts(world) @ transfer)) <= atol

def vote(world, x, prod, transfer):
    if not net_zero(world, transfer):
        raise ValueError('compensazioni non in pareggio')
    outcome = p.indicators(x, prod)
    achievement = (min(1.0, outcome['energia'] / p.TARGET_ENERGY) + min(1.0, outcome['emissioni_evitate'] / p.TARGET_CO2)) / 2.0
    b = burden_profile(world, x)
    preferences = 0.85 * world.benefit * achievement - 0.32 * world.price_sensitivity * b[world.group] + 0.12 * transfer[world.group]
    yes = preferences >= 0.51
    w = 0.08 + world.competence @ p.RELEVANCE
    return float(np.dot(w, yes) / sum(w))

def feasible(x, prod, world, transfer, executed=None, start=0, prior_transfer=None, admin_paid=0.0):
    if x.shape != (p.T, p.K) or np.any(x < -1e-08) or np.any(x > 1 + 1e-08):
        return False
    if not net_zero(world, transfer):
        return False
    a = p.indicators(x, prod)
    if prior_transfer is None:
        prior_transfer = np.zeros(4)
    admin = transfer_admin(world, transfer - prior_transfer)
    if a['energia'] + TOL < p.TARGET_ENERGY or a['emissioni_evitate'] + TOL < p.TARGET_CO2:
        return False
    if a['stress_rete'] > p.STRESS_LIMIT + TOL:
        return False
    if a['spesa_totale'] + admin_paid + admin > p.TOTAL_BUDGET + TOL:
        return False
    if np.max(a['spesa_periodo']) > p.PERIOD_BUDGET + TOL:
        return False
    if start > 0 and a['spesa_periodo'][0] + admin_paid > p.PERIOD_BUDGET + TOL:
        return False
    if a['spesa_periodo'][start] + admin > p.PERIOD_BUDGET + TOL:
        return False
    if executed is not None and (not np.allclose(x[:start], executed[:start], atol=1e-09)):
        return False
    return True

def technical_constraints(x, prod):
    a = p.indicators(x, prod)
    return np.r_[a['energia'] - p.TARGET_ENERGY, a['emissioni_evitate'] - p.TARGET_CO2, p.STRESS_LIMIT - a['stress_rete'], p.PERIOD_BUDGET - np.array(a['spesa_periodo']), p.TOTAL_BUDGET - a['spesa_totale']]

def optimize_schedule(prod, executed, start, objective, anchor):
    key = (tuple(np.round(prod, 6)), tuple(np.round(executed.ravel(), 6)), start, objective, tuple(np.round(anchor.ravel(), 6)))
    if key in _SOLVE_CACHE:
        value = _SOLVE_CACHE[key]
        return value.copy() if value is not None else None
    shape = (p.T - start, p.K)
    prefix = executed.copy()
    def full(z):
        x = prefix.copy()
        x[start:] = z.reshape(shape)
        return x
    def constraints(z):
        return technical_constraints(full(z), prod)
    def loss(z):
        x = full(z)
        spending = x @ p.COSTS
        cost = float(np.sum(spending))
        if objective == 'costo':
            return 0.02 * cost + 0.008 * float(np.square(np.diff(x, axis=0)).sum())
        if objective == 'rateizzazione':
            return 0.018 * cost + 0.06 * float(np.dot(spending, np.linspace(1.0, 0.0, p.T))) + 0.02 * float(np.square(np.diff(spending)).sum())
        if objective == 'equita':
            project_burden = (x @ np.diag(p.COSTS) @ p.BURDEN_SHARE).sum(axis=0)
            f = project_burden / max(cost, 1e-08)
            return 0.018 * cost + 0.85 * float(np.sum((f - 0.25) ** 2)) + 0.005 * np.sum(np.diff(x, axis=0) ** 2)
        raise ValueError(objective)
    z0 = np.clip(anchor[start:].ravel(), 0, 1)
    guesses = (z0, np.full(z0.size, 0.3))
    valid = []
    for z in guesses:
        try:
            res = minimize(loss, z, method='SLSQP', bounds=[(0.0, 1.0)] * z0.size, constraints=[{'type': 'ineq', 'fun': constraints}], options={'maxiter': 140, 'ftol': 2e-07})
            x = full(res.x)
            if np.min(technical_constraints(x, prod)) >= -TOL:
                valid.append((float(loss(res.x)), x))
        except (ValueError, FloatingPointError):
            pass
    result = min(valid, key=lambda e: e[0])[1] if valid else None
    _SOLVE_CACHE[key] = result.copy() if result is not None else None
    return result

def transfers(world, x, enabled):
    yield np.zeros(4)
    if not enabled:
        return
    n = counts(world)
    f = n / n.sum()
    b = burden_profile(world, x)
    dif = b - f @ b
    for strength in (0.3, 0.6, 0.9, 1.2):
        raw = strength * dif
        raw -= np.dot(f, raw)
        if np.max(np.abs(raw)) <= 1.6:
            yield raw
    for group in range(4):
        if dif[group] <= 0.03:
            continue
        for amount in (0.35, 0.7, 1.1, 1.45):
            tr = np.full(4, -amount * f[group] / (1 - f[group]))
            tr[group] = amount
            if np.max(np.abs(tr)) <= 1.6:
                yield tr

def select_package(world, prod, executed, start, method, anchor, prior_transfer=None, admin_paid=0.0):
    if prior_transfer is None:
        prior_transfer = np.zeros(4)
    kinds = ['costo']
    if method in ('solo_calendario', 'negoziazione_completa'):
        kinds += ['rateizzazione', 'equita']
    alternatives = []
    for k in kinds:
        x = optimize_schedule(prod, executed, start, k, anchor)
        if x is not None and (not any((np.allclose(x, v) for v in alternatives))):
            alternatives.append(x)
    if not alternatives:
        return (None, {'reason': 'nessuna_soluzione_trovata', 'candidates': 0, 'technically_feasible': 0, 'approved': 0})
    viable = []
    approved = []
    for x in alternatives:
        for tr in transfers(world, x, method in ('solo_compensazioni', 'negoziazione_completa')):
            if not feasible(x, prod, world, tr, executed, start, prior_transfer, admin_paid):
                continue
            s = vote(world, x, prod, tr)
            a = p.indicators(x, prod)
            pkg = Package(x, tr, s, a['spesa_totale'] + admin_paid + transfer_admin(world, tr - prior_transfer), float(np.max(burden_profile(world, x) - tr)), int(np.max(np.sum(x > 0.03, axis=1))), method)
            viable.append(pkg)
            if s > 0.5:
                approved.append(pkg)
    if not approved:
        return (None, {'reason': 'voto_ponderato_respinto' if viable else 'nessun_piano_fattibile', 'candidates': len(alternatives), 'technically_feasible': len(viable), 'approved': 0, 'best_share': max((v.vote for v in viable), default=0.0)})
    selected = min(approved, key=lambda z: (z.cost + 0.12 * z.burden, z.cost))
    return (selected, {'reason': 'approvata', 'candidates': len(alternatives), 'technically_feasible': len(viable), 'approved': len(approved), 'best_share': max((v.vote for v in viable))})

def one_world(seed, scenario, method):
    conflict = 'conflitto' in scenario
    synthetic = p.make_world(seed, conflict=conflict)
    rng = np.random.default_rng(702000 + seed)
    prod0 = np.clip(1.0 + rng.normal(0.0, 0.075, p.K), 0.8, 1.2)
    w = p.World(synthetic.competence, synthetic.group, synthetic.benefit, synthetic.price_sensitivity, prod0)
    x0 = np.zeros((p.T, p.K))
    initial, di0 = select_package(w, prod0, x0, 0, method, np.full_like(x0, 0.42))
    enacted = np.zeros_like(x0)
    final_pkg = initial
    revision_diag = {'reason': 'non_necessaria', 'candidates': 0, 'technically_feasible': 0, 'approved': 0}
    revote_required = False
    if initial is not None:
        enacted[:2] = initial.plan[:2]
    truth = prod0.copy()
    if scenario != 'stabile' and scenario != 'conflitto':
        truth[0] *= 0.6
    revised = False
    if initial is not None and (not np.allclose(truth, prod0)):
        if 'rumoroso' in scenario:
            rng = np.random.default_rng(100000 + seed)
            estimated = truth + np.clip(rng.normal(0, 0.08, p.K), -0.16, 0.16)
        else:
            estimated = truth.copy()
        estimated = np.clip(estimated, 0.3, 1.3)
        alternative, revision_diag = select_package(w, estimated, enacted, 2, method, initial.plan, prior_transfer=initial.transfer, admin_paid=transfer_admin(w, initial.transfer))
        if alternative is not None:
            material_change = np.max(np.abs(alternative.plan[2:] - initial.plan[2:])) > 1e-05 or np.max(np.abs(alternative.transfer - initial.transfer)) > 1e-07
            revote_required = bool(material_change)
            if material_change:
                final_pkg = alternative
                revised = True
    x = final_pkg.plan if final_pkg is not None else np.zeros_like(x0)
    tr = final_pkg.transfer if final_pkg is not None else np.zeros(4)
    assert np.allclose(x[:2], enacted[:2])
    actual = p.indicators(x, truth)
    initial_fee = transfer_admin(w, initial.transfer) if initial else 0.0
    revision_fee = transfer_admin(w, tr - initial.transfer) if revised else 0.0
    total_fee = initial_fee + revision_fee
    actual_constraints = actual['stress_rete'] <= p.STRESS_LIMIT + TOL and actual['spesa_totale'] + total_fee <= p.TOTAL_BUDGET + TOL and (max(actual['spesa_periodo']) <= p.PERIOD_BUDGET + TOL) and (actual['spesa_periodo'][0] + initial_fee <= p.PERIOD_BUDGET + TOL) and (actual['spesa_periodo'][2] + revision_fee <= p.PERIOD_BUDGET + TOL)
    actual_goals = actual['energia'] + TOL >= p.TARGET_ENERGY and actual['emissioni_evitate'] + TOL >= p.TARGET_CO2
    actual_ok = initial is not None and actual_goals and actual_constraints
    oracle_x = optimize_schedule(truth, np.zeros_like(x0), 0, 'costo', np.full_like(x0, 0.42))
    oracle_ok = int(oracle_x is not None)
    if initial is not None:
        oracle_recovery = optimize_schedule(truth, enacted, 2, 'costo', initial.plan)
        # Il risolutore locale non e' un oracolo esatto: una strategia gia'
        # dimostrata fattibile e' una prova costruttiva di recuperabilita'.
        witnesses = (initial.plan, final_pkg.plan if final_pkg is not None else initial.plan)
        demonstrated = any(
            np.allclose(z[:2], enacted[:2], atol=1e-9)
            and np.min(technical_constraints(z, truth)) >= -TOL
            for z in witnesses)
        postshock_oracle_ok = int(oracle_recovery is not None or demonstrated)
    else:
        postshock_oracle_ok = 0
    return dict(seed=seed, scenario=scenario, method=method, technical_oracle_feasible=oracle_ok, postshock_oracle_feasible=postshock_oracle_ok, initial_approved=int(initial is not None), revised=int(revised), revote_required=int(revote_required), initial_reason=di0['reason'], revision_reason=revision_diag['reason'], n_initial_candidates=di0['candidates'], initial_technical_candidates=di0['technically_feasible'], initial_approval_count=di0['approved'], initial_weighted_share=round(initial.vote, 4) if initial else round(di0.get('best_share', 0.0), 4), revised_vote=round(final_pkg.vote, 4) if final_pkg else 0.0, reached_goals=int(actual_goals), respected_constraints=int(actual_constraints), joint_success=int(initial is not None and actual_ok), actual_energy=round(actual['energia'], 4), actual_co2=round(actual['emissioni_evitate'], 4), actual_grid_stress=round(actual['stress_rete'], 4), gap=round(sum(np.maximum(p.gap_vector(x, truth)[:2], 0.0)), 4), cost=round(actual['spesa_totale'] + total_fee, 4), admin_cost=round(total_fee, 4), concurrent_projects=int(np.max(np.sum(x > 0.03, axis=1))), transfer_sum=round(float(counts(w) @ tr), 10), plan_json=json.dumps(np.round(x, 4).tolist()), transfers_json=json.dumps(np.round(tr, 4).tolist()))

def run(n=24, scenarios=SCENARIOS):
    out = []
    for scenario in scenarios:
        for seed in range(n):
            for method in METHODS:
                out.append(one_world(seed, scenario, method))
    summary = []
    for sc in scenarios:
        for method in METHODS:
            subset = [r for r in out if r['scenario'] == sc and r['method'] == method]
            summary.append(dict(scenario=sc, method=method, n=len(subset), oracolo_fattibile=sum((r['technical_oracle_feasible'] for r in subset)), oracolo_recupero_post_esecuzione=sum((r['postshock_oracle_feasible'] for r in subset)), initial_approvals=sum((r['initial_approved'] for r in subset)), revisions=sum((r['revised'] for r in subset)), goal_successes=sum((r['reached_goals'] for r in subset)), technical_successes=sum((r['initial_approved'] and r['respected_constraints'] for r in subset)), constraints_respected_even_without_approval=sum((r['respected_constraints'] for r in subset)), joint_successes=sum((r['joint_success'] for r in subset)), joint_pct=round(100 * np.mean([r['joint_success'] for r in subset]), 1), mean_gap=round(float(np.mean([r['gap'] for r in subset])), 3), mean_admin=round(float(np.mean([r['admin_cost'] for r in subset])), 4)))
    return (out, summary)

def save_csv(path, rows):
    with open(path, 'w', newline='', encoding='utf8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

def plot(summary, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 5))
    scs = list(dict.fromkeys((r['scenario'] for r in summary)))
    y = np.arange(len(scs))
    for j, m in enumerate(METHODS):
        data = [r['joint_pct'] for s in scs for r in summary if r['scenario'] == s and r['method'] == m]
        ax.barh(y + (j - 1.5) * 0.18, data, height=0.18, label=m.replace('_', ' '))
    ax.set_yticks(y, scs)
    ax.set_xlim(0, 103)
    ax.set_xlabel('Target e vincoli effettivi soddisfatti (%)')
    ax.legend(fontsize=8)
    ax.set_title('V11 — Negoziazione di portafogli paralleli (simulazione sintetica)')
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)

def test():
    w = p.make_world(0, conflict=True)
    x, ok = p.optimize_portfolio(w.productivity)
    assert ok
    assert p.feedback_jacobian(x, w.productivity).shape == (3, p.T * p.K)
    assert max(np.sum(x > 0.03, axis=1)) >= 2
    for tr in transfers(w, x, True):
        assert net_zero(w, tr)
        assert transfer_admin(w, tr) >= 0
    for mode in METHODS:
        r = one_world(0, 'shock_rumoroso', mode)
        assert abs(r['transfer_sum']) < 1e-08
        assert r['concurrent_projects'] <= p.K
        if r['revised']:
            assert r['revote_required']
        if r['joint_success']:
            assert r['initial_approved'] and r['reached_goals'] and r['respected_constraints']
    failed = np.zeros((p.T, p.K))
    tr = np.zeros(4)
    assert not feasible(failed, w.productivity, w, tr)
    print('OK: voto ponderato, interventi paralleli, compensazioni a pareggio, revisioni votate, costi e obiettivi vincolanti')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--test', action='store_true')
    ap.add_argument('--mondi', type=int, default=24)
    ap.add_argument('--output', default=str(HERE / 'risultati_portafoglio_negoziato'))
    a = ap.parse_args()
    if a.test:
        test()
        return
    out = Path(a.output)
    out.mkdir(parents=True, exist_ok=True)
    rows, summary = run(a.mondi)
    save_csv(out / 'dettaglio.csv', rows)
    save_csv(out / 'riepilogo.csv', summary)
    plot(summary, out / 'confronto.png')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
