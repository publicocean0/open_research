# V11 — portafoglio parallelo e negoziazione interdisciplinare

**Stato: prototipo sperimentale, non una release validata.**

La V11 corregge il limite dei modelli precedenti, che rappresentavano le strategie soprattutto come un piano o come due interventi in sequenza. La strategia diventa un portafoglio **X[t,i]** di interventi simultanei e interdipendenti, con calendari, costi, sinergie, vincoli tecnici e budget per periodo.

Gli esempi studiano quattro interventi: rinnovabili, reti, accumuli ed efficienza. Le proposte sono valutate come pacchetto; tutte le votazioni, incluse le revisioni, sono ponderate secondo la competenza pertinente.

## Vincoli tecnici

- Target comuni e metriche già approvati: non vengono abbassati automaticamente.
- Limite di costo totale e per periodo, dipendenze di rete e impatti sui risultati.
- Gli interventi già eseguiti sono immutabili nel successivo ricalcolo.
- Le compensazioni tra gruppi sono a somma zero; la loro amministrazione consuma risorse reali.
- Una modifica materiale fuori dal mandato richiede un nuovo voto ponderato.

## Varianti sperimentali

1. Nessuna negoziazione.
2. Negoziazione del calendario.
3. Sole compensazioni redistributive.
4. Negoziazione completa di calendario e compensazioni.

La V11 comprende sia la sperimentazione parallela indipendente **V11-P**, sia un esperimento di negoziazione del portafoglio **V11-N**. Questi test non vanno confrontati direttamente con le percentuali V10 senza una calibrazione dei mondi artificiali.

Nella nuova esecuzione V11-N di 24 mondi per scenario, il conflitto senza shock si sblocca in 6/24 societa' con negoziazione completa (0/24 nelle altre tre varianti). Con conflitto e shock i successi completi sono 5/24, non 6/24. Le percentuali dipendono dai parametri sintetici e non sono generalizzabili.

## Origine e integrità del materiale

Gli originali sono stati prodotti come prototipi Python durante la ricerca.
Questa cartella documenta il loro stato senza spacciare l'esperimento V11 per una versione finale. Le fonti originali della V11-P e della V11-N sono archiviate anche negli allegati della conversazione di sviluppo; per audit è utile controllare gli hash prima di migrazioni successive.

- Archivio V11-P iniziale: `democrazia_ponderata_v11_portafoglio_parallelo.zip`
- SHA-256: `6a34e3be180ae21ee6bb0570d16b75e4374e252dcb50420d8e90d6bc9674a69b`
- Archivio integrato V11-N locale: `v11_sources_portfolio.zip`
- SHA-256: `d8ba6f90db60d8fc8228e8d3ca9024ddbdf46467eadf77854a9c03df7f11ef4c`

## Sorgenti V11 presenti nel repository

Il trasferimento dei due moduli di portafoglio parallelo e negoziazione e' ora completo come file Python leggibili:

- `portafoglio_parallelo.py`: matrice interventi x periodi, sinergie tecniche, Jacobiano, voto ponderato e rivoto;
- `negoziazione_portafoglio_v11.py`: ricerca di portafogli, calendario, compensazioni a somma zero, verifiche di bilancio, revisioni;
- `test_integrita_v11.py`: controlli di integrità e regressioni;
- `analisi_accoppiata_v11.py`: confronto a coppie tra metodi sugli stessi mondi.

Per riprodurre:

```bash
python -m pip install numpy scipy matplotlib
cd democrazia-ponderata-adattiva/v11_negoziazione
python portafoglio_parallelo.py --test
python negoziazione_portafoglio_v11.py --test
python test_integrita_v11.py
python negoziazione_portafoglio_v11.py --mondi 24
python analisi_accoppiata_v11.py risultati_portafoglio_negoziato/dettaglio.csv
```

## Diagnostica corretta

La fattibilita' tecnica *all'istante iniziale* e la possibilita' di recuperare
*dopo l'esecuzione dei primi due periodi* sono questioni diverse. L'esperimento
registra entrambe. Il risolutore SLSQP resta euristico: il mancato reperimento di
una soluzione **non prova** che questa non esista.

I risultati salvati nella cartella `risultati_portafoglio_negoziato` appartengono
alla precedente esecuzione della V11 e sono conservati solo come storico.
Per i numeri verificati e aggiornati consultare `risultati_validati/`, oppure
rieseguire il comando sopra; in particolare non prendere il vecchio 100% di
successo nello shock come risultato consolidato.

**Stato:** V11-P e V11-N sono prototipi autonomi. Non sono ancora una
integrazione completa con l'iniziativa e il voto specialistico sulle metriche
della V3, ne' un esperimento empirico su elettori reali.
