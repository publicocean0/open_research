#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""Regression checks for the V11 parallel portfolio and negotiation prototype."""
import numpy as np
import portafoglio_parallelo as p
import negoziazione_portafoglio_v11 as v

def test():
    world = p.make_world(7, n=300, conflict=True)
    x, found = p.optimize_portfolio(world.productivity)
    assert found and p.feasible(x, world.productivity)
    assert np.max(np.sum(x > 0.03, axis=1)) > 1
    assert p.feedback_jacobian(x, world.productivity).shape == (3, p.T * p.K)
    assert np.max(np.abs(p.backpropagation_signal(np.zeros_like(x), world.productivity))) > 0
    for transfer in v.transfers(world, x, True):
        assert v.net_zero(world, transfer)
        assert v.transfer_admin(world, transfer) >= 0
    modified = x.copy()
    modified[0, 0] += 0.1
    assert not v.feasible(modified, world.productivity, world, np.zeros(4),
                          executed=x, start=2)
    rejected = v.one_world(0, 'conflitto', 'senza_negoziazione')
    assert not rejected['initial_approved'] and not rejected['joint_success']
    assert not rejected['postshock_oracle_feasible']
    negotiated = v.one_world(0, 'conflitto', 'negoziazione_completa')
    assert abs(negotiated['transfer_sum']) < 1e-8
    if negotiated['joint_success']:
        assert negotiated['initial_approved']
        assert negotiated['reached_goals'] and negotiated['respected_constraints']
    if negotiated['revised']:
        assert negotiated['revote_required']
    print('OK V11: simultaneita, voto ponderato, pareggio, costi, rivoto, passato immutabile')

if __name__ == '__main__':
    test()
