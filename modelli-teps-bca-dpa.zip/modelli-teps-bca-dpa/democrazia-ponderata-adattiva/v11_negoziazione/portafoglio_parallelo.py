# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
from __future__ import annotations
from dataclasses import dataclass
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
PROJECTS = ('rinnovabili', 'reti', 'accumuli', 'efficienza')
DOMAINS = ('energia', 'infrastrutture', 'economia', 'ambiente')
COSTS = np.array([3.0, 2.2, 2.6, 1.8])
T, K = (6, 4)
PERIOD_BUDGET = 5.0
TOTAL_BUDGET = 26.0
BURDEN_SHARE = np.array([[0.34, 0.3, 0.21, 0.15], [0.22, 0.34, 0.29, 0.15], [0.16, 0.29, 0.38, 0.17], [0.38, 0.21, 0.25, 0.16]])
RELEVANCE = np.array([0.45, 0.15, 0.05, 0.35])
TARGET_ENERGY = 5.2
TARGET_CO2 = 4.6
STRESS_LIMIT = 0.52

@dataclass(frozen=True)
class World:
    competence: np.ndarray
    group: np.ndarray
    benefit: np.ndarray
    price_sensitivity: np.ndarray
    productivity: np.ndarray

def make_world(seed: int, n: int=300, conflict: bool=False) -> World:
    rng = np.random.default_rng(seed)
    groups = rng.integers(0, 4, size=n)
    competence = rng.beta(2.2, 2.2, size=(n, 4))
    for g in range(4):
        competence[groups == g, g] = np.clip(competence[groups == g, g] + 0.23, 0, 1)
    sensitivity = rng.uniform(0.8, 1.2, size=n)
    if conflict:
        sensitivity[groups == 2] *= 2.1
        sensitivity[groups == 0] *= 1.7
    benefit = rng.uniform(0.88, 1.18, size=n)
    product = np.array([1.0, 1.0, 1.0, 1.0])
    return World(competence, groups, benefit, sensitivity, product)

def indicators(x: np.ndarray, productivity: np.ndarray) -> dict:
    time_weights = np.linspace(1.15, 1.0, T)[:, None]
    s = np.sum(x * time_weights, axis=0) * productivity
    solar, grid, storage, efficiency = s
    energy = 1.12 * solar + 0.58 * grid + 0.73 * storage + 0.35 * efficiency + 0.18 * np.sqrt(max(solar * storage, 0.0) + 1e-10) + 0.22 * np.sqrt(max(solar * grid, 0.0) + 1e-10)
    co2 = 0.96 * solar + 0.12 * grid + 0.26 * storage + 1.04 * efficiency
    stress = max(0.0, 0.52 * solar - 0.38 * grid - 0.32 * storage - 0.09 * efficiency)
    spent = x @ COSTS
    return {'energia': float(energy), 'emissioni_evitate': float(co2), 'stress_rete': float(stress), 'spesa_totale': float(np.sum(spent)), 'spesa_periodo': spent.tolist()}

def gap_vector(x: np.ndarray, productivity: np.ndarray) -> np.ndarray:
    m = indicators(x, productivity)
    return np.array([TARGET_ENERGY - m['energia'], TARGET_CO2 - m['emissioni_evitate'], m['stress_rete'] - STRESS_LIMIT])

def feedback_jacobian(x: np.ndarray, productivity: np.ndarray, eps=1e-05) -> np.ndarray:
    jac = np.zeros((3, T * K))
    for j in range(T * K):
        xp = x.copy().reshape(-1)
        xm = x.copy().reshape(-1)
        xp[j] += eps
        xm[j] -= eps
        jac[:, j] = (gap_vector(xp.reshape(T, K), productivity) - gap_vector(xm.reshape(T, K), productivity)) / (2 * eps)
    return jac

def backpropagation_signal(x: np.ndarray, productivity: np.ndarray) -> np.ndarray:
    e = np.maximum(gap_vector(x, productivity), 0.0)
    return (feedback_jacobian(x, productivity).T @ e).reshape(T, K)

def economic_cost(x):
    return float(np.sum(x @ COSTS))

def technical_gap(m):
    return max(0.0, TARGET_ENERGY - m['energia']) + max(0.0, TARGET_CO2 - m['emissioni_evitate'])

def feasible(x, prod, tol=1e-05):
    m = indicators(x, prod)
    return m['energia'] >= TARGET_ENERGY - tol and m['emissioni_evitate'] >= TARGET_CO2 - tol and (m['stress_rete'] <= STRESS_LIMIT + tol) and (m['spesa_totale'] <= TOTAL_BUDGET + tol) and (max(m['spesa_periodo']) <= PERIOD_BUDGET + tol)

def weighted_support(w: World, x: np.ndarray, compensations: np.ndarray | None=None) -> float:
    if compensations is None:
        compensations = np.zeros(4)
    counts = np.bincount(w.group, minlength=4)
    if abs(float(np.dot(counts, compensations))) > 1e-08:
        raise ValueError('Le compensazioni non sono a somma zero')
    values = indicators(x, w.productivity)
    outcome = (min(1.0, values['energia'] / TARGET_ENERGY) + min(1.0, values['emissioni_evitate'] / TARGET_CO2)) / 2.0
    by_group = (x @ np.diag(COSTS) @ BURDEN_SHARE).sum(axis=0)
    burden = by_group / np.maximum(counts, 1) * len(w.group) / max(economic_cost(x), 1e-08)
    weighted_comp = 0.12 * compensations[w.group]
    utility = 0.85 * w.benefit * outcome - 0.32 * w.price_sensitivity * burden[w.group] + weighted_comp
    votes = utility >= 0.51
    weights = 0.08 + w.competence @ RELEVANCE
    return float(weights @ votes / np.sum(weights))

def optimize_portfolio(productivity, executed=None, start=0, parallel=True, initial=None):
    if executed is None:
        executed = np.zeros((T, K))
    executed = np.asarray(executed, float)
    shape = (T - start, K)
    if initial is None:
        initial = np.full(shape, 0.42)
    fixed = executed.copy()
    bounds = [(0.0, 1.0)] * int(np.prod(shape))
    if not parallel:
        order = np.array([0, 1, 2, 3, 0, 3])
        bounds = [(0.0, 1.0) if k == order[t + start] else (0.0, 0.0) for t in range(T - start) for k in range(K)]

    def full(z):
        out = fixed.copy()
        out[start:] = np.reshape(z, shape)
        return out

    def constraints(z):
        x = full(z)
        m = indicators(x, productivity)
        return np.r_[PERIOD_BUDGET - np.array(m['spesa_periodo'])[start:], TOTAL_BUDGET - m['spesa_totale'], STRESS_LIMIT - m['stress_rete'], m['energia'] - TARGET_ENERGY, m['emissioni_evitate'] - TARGET_CO2]

    def obj(z):
        x = full(z)
        m = indicators(x, productivity)
        return float(0.02 * m['spesa_totale'] + 0.005 * np.sum(np.diff(x, axis=0) ** 2))
    starts = [np.reshape(initial, -1), np.full(np.prod(shape), 0.3), np.full(np.prod(shape), 0.7)]
    feasible_candidates = []
    best_infeasible = None
    for s in starts:
        r = minimize(obj, np.array([np.clip(a, lo, hi) for a, (lo, hi) in zip(s, bounds)]), method='SLSQP', bounds=bounds, constraints=[{'type': 'ineq', 'fun': constraints}], options={'maxiter': 160, 'ftol': 1e-08})
        x = full(r.x)
        residual = float(np.min(constraints(r.x)))
        if residual >= -0.0001:
            feasible_candidates.append((obj(r.x), x))
        elif best_infeasible is None or residual > best_infeasible[0]:
            best_infeasible = (residual, x)
    if feasible_candidates:
        return (min(feasible_candidates, key=lambda a: a[0])[1], True)
    return (best_infeasible[1] if best_infeasible else fixed, False)

def plan_change_reason(x_old, x_new, threshold=0.18):
    return 'nuovo_voto_ponderato' if np.max(np.abs(x_old - x_new)) > threshold else 'modifica_limitata_da_verificare'

def simulate_one(seed=0, conflict=False, shock=True):
    w = make_world(seed, conflict=conflict)
    before, found = optimize_portfolio(w.productivity)
    vote0 = weighted_support(w, before) if found else 0.0
    approved0 = found and vote0 > 0.5
    executed = np.zeros((T, K))
    if approved0:
        executed[:2] = before[:2]
    prod = w.productivity.copy()
    if shock:
        prod[0] = 0.6
    revised = before.copy()
    revision_needed = False
    found1 = False
    revote = float('nan')
    approved1 = False
    if approved0:
        revised, found1 = optimize_portfolio(prod, executed, start=2, initial=before[2:])
        revision_needed = found1 and np.max(np.abs(revised - before)) > 0.001
        if revision_needed:
            wpost = World(w.competence, w.group, w.benefit, w.price_sensitivity, prod)
            revote = weighted_support(wpost, revised)
            approved1 = revote > 0.5
    final = (revised if approved1 else before) if approved0 else np.zeros((T, K))
    m = indicators(final, prod)
    return ({'seed': seed, 'conflitto': int(conflict), 'shock': int(shock), 'piano_iniziale_fattibile': int(found), 'voto_iniziale': round(vote0, 4), 'piano_iniziale_approvato': int(approved0), 'correzione_fattibile': int(found1), 'revisione_proposta': int(revision_needed), 'rivoto_ponderato': round(revote, 4), 'revisione_approvata': int(approved1), 'target_e_vincoli_reali': int(feasible(final, prod)), 'gap_obiettivi': round(technical_gap(m), 4), 'interventi_contemporanei': int(np.max(np.sum(final > 0.001, axis=1))), 'budget_rispettato': int(max(m['spesa_periodo']) <= PERIOD_BUDGET + 1e-05), 'stress_reale': round(m['stress_rete'], 4)}, before, revised)

def tests():
    x = np.zeros((T, K))
    x[0, 0] = 0.7
    x[0, 1] = 0.4
    assert indicators(x, np.ones(K))['energia'] > 0
    assert np.max(x @ COSTS) <= PERIOD_BUDGET
    pop = make_world(7)
    assert not np.allclose(pop.competence @ RELEVANCE, np.mean(pop.competence @ RELEVANCE))
    x1, yes = optimize_portfolio(np.ones(K))
    assert yes and feasible(x1, np.ones(K), 0.0002)
    assert max(np.sum(x1 > 0.001, axis=1)) >= 2, 'No simultaneita nel modello'
    assert feedback_jacobian(x1, np.ones(K)).shape == (3, T * K)
    more = x1.copy()
    more[:, 0] *= 1.4
    assert abs(feedback_jacobian(more, np.ones(K))[0, 2] - feedback_jacobian(x1, np.ones(K))[0, 2]) > 1e-05
    partial = np.zeros((T, K))
    partial[:2] = x1[:2]
    x2, found = optimize_portfolio(np.array([0.6, 1, 1, 1]), partial, start=2, initial=x1[2:])
    assert np.array_equal(x2[:2], partial[:2])
    counts = np.bincount(pop.group, minlength=4)
    try:
        weighted_support(pop, x1, np.array([1.0, 0.0, 0.0, 0.0]))
    except ValueError:
        pass
    else:
        raise AssertionError('Failed net-zero transfer test')
    row, _, _ = simulate_one(4)
    assert row['budget_rispettato'] == 1 if row['revisione_approvata'] else True
    print('OK V11-P: simultaneita, vincoli, voto ponderato, storia immutabile, compensazioni')

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--test', action='store_true')
    p.add_argument('--mondi', type=int, default=10)
    p.add_argument('--out', default=str(Path(__file__).resolve().parent / 'risultati' / 'portafoglio.csv'))
    a = p.parse_args()
    if a.test:
        tests()
        return
    rows = []
    for conflict in (False, True):
        for shock in (False, True):
            for seed in range(a.mondi):
                row, _, _ = simulate_one(seed, conflict, shock)
                rows.append(row)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)
    for c in (0, 1):
        for s in (0, 1):
            subgroup = [r for r in rows if r['conflitto'] == c and r['shock'] == s]
            print(json.dumps(dict(conflitto=c, shock=s, n=len(subgroup), iniziali=sum((r['piano_iniziale_approvato'] for r in subgroup)), revisione=sum((r['revisione_approvata'] for r in subgroup)), successi=sum((r['target_e_vincoli_reali'] for r in subgroup)), interventi_paralleli_max=max((r['interventi_contemporanei'] for r in subgroup))), ensure_ascii=False))
if __name__ == '__main__':
    main()
