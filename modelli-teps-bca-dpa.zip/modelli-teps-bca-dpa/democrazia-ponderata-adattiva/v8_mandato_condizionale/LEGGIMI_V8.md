# Democrazia Ponderata Adattiva — V8

## Stato e scopo

**Prototipo scientifico esplorativo, interamente sintetico.** Non dimostra la validità normativa o empirica della democrazia ponderata. Ogni cifra riguarda società artificiali e preferenze dei votanti generate tramite formule progettate dall'autore della simulazione. Tutti gli esperimenti sono riproducibili, ma i risultati non si generalizzano a elettori o governi reali.

**Domanda:** votare un mandato condizionale, che autorizza un numero limitato di correzioni future senza un ulteriore voto su ogni correzione, migliora l'attuazione di obiettivi già approvati rispetto a una politica invariabile e a un modello che chiede frequentemente un nuovo voto?

## Regole politiche e informatiche

1. **Il voto è SEMPRE ponderato per competenza pertinente**. La V8 importa esattamente i meccanismi della V3: proposta aperta a tutti, sostegno ponderato nell'agenda, voto ponderato sugli obiettivi; le metriche possono essere proposte e votate dai soli esperti qualificati. Il voto sulle strategie è ponderato per questione.
2. **Obiettivi, metriche, strategie rimangono entità distinte.** Gli obiettivi approvati restano invariati in questa prova per isolare il comportamento della strategia. La revisione democratica degli obiettivi è prevista nella V3/V4, non attivata qui.
3. **Strategia base e mandato sono due votazioni ponderate separate.** Se il mandato non viene approvato, non si possono attivare correzioni automatiche; resta possibile un nuovo voto ponderato ordinario.
4. **Il mandato non è una delega illimitata**. Viene votato con una descrizione formale delle condizioni che consentono una modifica: sensori, soglie, limiti geometrici dei parametri, impegni aggiuntivi di capitale e numero massimo di attivazioni.
5. **Retropropagazione tecnica:** il residuo dei vincoli e il relativo Jacobiano generano una direzione di correzione, usata come base di ricerca dei piani ammissibili. I modelli tecnici sono aggiornati con RLS da misure osservate durante l'esecuzione, mai con accesso diretto a valori futuri.
6. Se una correzione supera i limiti del mandato, **serve un nuovo voto ponderato**. Non viene forzata l'approvazione. La mancata approvazione non revoca il piano precedentemente legittimato.
7. Le metriche sono sottoposte a controlli indipendenti. Se due misurazioni successive divergono significativamente, una nuova metrica può essere approvata soltanto attraverso un voto ponderato specialistico; mai sostituita automaticamente.

## Mandato condizionale standard

I valori sono convenzioni di test in unità astratte:

- Segnale di allarme: due scostamenti consecutivi > 0,20 tra le osservazioni e i valori tecnici previsti.
- Variazioni cumulative ammesse rispetto al piano iniziale, sulle tre leve di azione: `[1,4; 2,3; 2,3]` in valore assoluto.
- Numero massimo di attivazioni automatiche: 3.
- Tetto all'incremento di costo di capitale impegnato da correzioni automatiche: 9 unità; i costi aggiuntivi di amministrazione (2% quando applicabili) sono inclusi nel conteggio. Gli interessi finanziari sono modellati nelle obbligazioni ma non inclusi nel tetto di capitale: non è una contabilità pubblica completa.
- Distribuzione degli oneri e calendario: quelli del mandato iniziale. Una nuova distribuzione non autorizzata richiede un nuovo voto.
- Le correzioni devono superare la verifica di ammissibilità dei vincoli e dei target secondo le stime disponibili. Questa verifica può essere errata in presenza di previsioni imperfette.

Il voto sintetico sul mandato usa una funzione che rappresenta beneficio atteso, valore assicurativo e rischio di costi futuri, senza usare gli esiti futuri della simulazione. **L'accettazione del mandato non è un dato osservato**: la sua elevata frequenza dipende anche dalla formula ipotetica adottata. Non è provato che cittadini reali approverebbero simili deleghe.

## Disegno sperimentale

- **24 mondi** differenti per ciascuno di quattro scenari: stabile, shock, shock rumoroso, shock e forte conflitto.
- **300 cittadini** e **12 periodi** per mondo.
- Per ogni mondo si usano IDENTICI parametri ambientali, rumori, elettorato e obiettivi per confrontare tre metodi:
  - `bloccato`: V7, vota una volta e non corregge.
  - `attivato`: V7, apprende e chiede nuovi voti programmati o attivati dalle deviazioni.
  - `mandato_condizionale`: V8, vota all'inizio una strategia e una autorizzazione limitata a correttivi.
- Obiettivi: soglie di abitazioni e indicatore ambientale (unità sintetiche). Vincoli tecnici: quattro discipline correlate.
- **Successo completo**: scostamento complessivo dai target originali <= 0,11 **e** massima violazione dei vincoli reali <= 0,02. Tutti gli altri esiti sono insuccessi, anche se raggiungono i target da soli.
- L'oracolo dinamico V7, riportato separatamente, conosce i veri parametri tecnici al momento del cambiamento, ma non vota. Non è un'alternativa democratica né una dimostrazione di ottimalità.

## Risultati — 24 mondi per scenario

| Scenario | Successo completo V7 adattiva | Successo completo V8 | Solo target V7 | Solo target V8 |
|---|---:|---:|---:|---:|
| Stabile | 87,5% | 87,5% | 87,5% | 87,5% |
| Shock | 0% | 0% | 4,2% | 25,0% |
| Shock + rumore | 0% | 0% | 4,2% | 25,0% |
| Shock + conflitto | 0% | 0% | 0% | 4,2% |

Nello scenario **shock**:

- Scostamento medio dai target: V7 `0,4946`, V8 `0,4059` (−17,9%).
- Violazione tecnica massima media: V7 `0,1525`, V8 `0,0905` (−40,7%).
- Nella V8, 35 interventi preautorizzati e 14 tentativi di rivoto fuori mandato; V7 ha 139 occasioni di revisione registrate, **non tutte equivalenti a votazioni effettive**. Non confrontare meccanicamente questi due conteggi come se misurassero la stessa cosa.
- I 6 mondi che raggiungono i target non rispettano contemporaneamente i vincoli reali. Quindi **nessun successo completo**.

Nello scenario stabile 21/24 mondi approvano inizialmente il piano e tutti questi 21 approvano anche il mandato; sotto shock tecnico si ripete lo stesso dato. Con forte conflitto 1/24 approva il piano e il mandato. Questi risultati illustrano la dipendenza dalla *regola sintetica del voto*, non una proprietà universale delle democrazie ponderate.

### Sensibilità dell'ampiezza del mandato

Un test di sensibilità riproducibile confronta profili `stretto` (tetti minori), `standard` e `ampio` (tetti maggiori), sullo stesso elettorato e problemi. Si vedano `sensibilita_v8.py` e `sensibilita.csv`. Nella prova di controllo con **8 mondi per scenario** (shock e shock rumoroso), restringere i limiti aumentava gli scostamenti medi; ampliare i limiti rispetto allo standard non dava vantaggi chiari. Questo rafforza la diagnosi: il collo di bottiglia non si risolve con una semplice maggiore discrezionalità dell'attuatore.

## Che cosa NON dimostra

- Non dimostra superiorità su una democrazia rappresentativa, diretta o altri metodi di decisione collettiva.
- Non esiste ancora una teoria convincente di competenza civica generalizzabile né una procedura reale validata di certificazione dei pesi.
- Non rappresenta negoziazioni umane, campagne, lobbying, disinformazione, controllo delle istituzioni, fiducia o preferenze morali in modo realistico.
- Le traiettorie tecniche e la ricerca dei piani sono modelli sintetici molto piccoli; RLS e SLSQP non sono una vera rete neurale addestrata end-to-end.
- Il test contiene **zero successi completi dopo uno shock**: non va descritta come una soluzione operativa comprovata.
- Non vi è una prova di convergenza generale; budget intertemporali e vincoli distributivi sono approssimati.
- Le bande bootstrap in `confronti_accoppiati.csv` sono descrittive dei mondi sintetici accoppiati, non intervalli di validità per la politica reale.

## File e istruzioni

Da una cartella contenente `democrazia-ponderata-adattiva/`:

```bash
python -m pip install -r democrazia-ponderata-adattiva/v8_mandato_condizionale/requirements.txt
python democrazia-ponderata-adattiva/v8_mandato_condizionale/simulazione_v8.py --test
python democrazia-ponderata-adattiva/v8_mandato_condizionale/simulazione_v8.py --mondi 24 --cittadini 300 --periodi 12
python democrazia-ponderata-adattiva/v8_mandato_condizionale/diagnostica_v8.py
python democrazia-ponderata-adattiva/v8_mandato_condizionale/sensibilita_v8.py --mondi 8 --scenari shock shock_rumoroso
```

La simulazione V8 richiede i moduli V1, V2, V3, V4 e V7 inclusi nello ZIP.

**Direzione V9:** formulare piani di risposta *multi-periodo* con margini robusti o probabilistici sui quattro vincoli, anziché limitarsi a ottimizzare una correzione locale. Verificare separatamente capacità di ricerca, ammissibilità tecnica reale, voto, tutela dei diritti e raggiungimento dei target.