#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V8: mandato condizionale ponderato, feedback, controlli di confine e audit.
Esperimento SINTETICO. Importa gli identici mondi della V7; nessun accesso a
informazioni future da parte della rete. Metodi: bloccato, attivato (V7), mandato V8.

Il mandato e' un voto ponderato separato dalla strategia iniziale, autorizza
solo un algoritmo, tetti e trigger esplicitamente descritti. Un'azione fuori
mandato richiede un nuovo voto ponderato. Nessun cambio di obiettivo/metriche
senza procedure ponderate della V3 (gli obiettivi restano fissi nel test).
"""
from __future__ import annotations
import argparse, csv, json, sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path[:0]=[str(ROOT),str(ROOT/'v2_adattiva'),str(ROOT/'v3_ponderata'),str(ROOT/'v4_negoziazione'),str(ROOT/'v7_feedback_temporale')]
import simulazione as base
import simulazione_ponderata as v3
import simulazione_v4 as v4
import simulazione_v7 as v7
from simulazione_adattiva import as_model

METHODS=('bloccato','attivato','mandato_condizionale')
SCENARIOS=v7.SCENARIOS
@dataclass(frozen=True)
class Mandate:
    reference:np.ndarray     # piano inizialmente votato
    axis_limit:np.ndarray    # intervallo cumulativo rispetto al piano votato
    max_extra_cost:float     # tetto cumulativo per tutte le correzioni
    max_activations:int
    trigger:float            # soglia deviazione ripetuta
    requires_consecutive:int
    schedule:str
    relief_group:int
    relief:float
    weighted_share:float


PROFILES={
    'standard':dict(cap=9.,limit=[1.4,2.3,2.3],max_acts=3,trigger=.20,consecutive=2,bonus=.19,price=.027),
    'stretto':dict(cap=3.5,limit=[.65,1.0,1.0],max_acts=2,trigger=.24,consecutive=2,bonus=.13,price=.035),
    'ampio':dict(cap=14.,limit=[2.0,3.0,3.0],max_acts=4,trigger=.20,consecutive=2,bonus=.19,price=.027),
}


def create_mandate(pop,goals,estimate,initial_bundle,periods,profile='standard'):
    """I cittadini votano PIANO + clausola: trigger, inviluppo, tetto di spesa.
    Formula elettorale esplicitamente sintetica, non prova di preferenze reali.
    Il voto sul mandato non e' dedotto dal successo futuro o da dati nascosti.
    """
    setting=PROFILES[profile]
    cap=setting['cap']
    x=np.asarray(initial_bundle.x,dtype=float)
    benefit=v4.subjective_voter_value(pop,estimate,goals,x,base.STATUS_QUO,
       base.STATUS_QUO,0,periods,initial_bundle.schedule,
       initial_bundle.relief_group,initial_bundle.relief,[],'forward')
    # Un mandato ha valore assicurativo previsto, ma anche rischio di spesa.
    # Preferenze eterogenee e costi prospettici; solo un'IPOTESI di comportamento.
    willingness=benefit + setting['bonus'] + .08*np.mean(pop.competence,axis=1) - setting['price']*cap*pop.risk
    yes=willingness>.02
    share,_,_=v3.fraction(pop,'strategia',yes)
    if share<=.5:return None,share
    return Mandate(x.copy(),np.array(setting['limit']),cap,setting['max_acts'],
                   setting['trigger'],setting['consecutive'],
                   initial_bundle.schedule,initial_bundle.relief_group,
                   initial_bundle.relief,share),share


def within_mandate(m,plan,current_plan,spent_so_far,activations,estimate,goals,state,periods_left):
    if m is None or activations>=m.max_activations:return False,'limite_attivazioni'
    if np.any(np.abs(plan-m.reference)>m.axis_limit+1e-9):return False,'oltre_inviluppo'
    added=max(0.,v4.capital_cost(plan)-v4.capital_cost(current_plan)) * (1.02 if m.relief_group>=0 else 1.0)
    if spent_so_far+added>m.max_extra_cost+1e-9:return False,'oltre_budget'
    if not v4.predicted_acceptable(plan,goals,estimate,state,periods_left,m.schedule):
        return False,'non_ammissibile_secondo_stime'
    return True,'entro_mandato'


def pick_correction(w,model,lr,state,plan,t,periods):
    """Ricerca il costo-minimo di alternative previste ammissibili; gli
    obiettivi governano l'ammissibilita', non il gradimento. Nessun oracolo.
    """
    goals=w['goals'];left=periods-t
    error=np.maximum(model.g(plan),0.)
    gradient=model.jac(plan).T@error
    anchor=np.clip(plan-.35*gradient/(np.linalg.norm(gradient)+1.e-10),base.LOW,base.HIGH)
    choices=[]
    for x in v4.candidate_plans(goals,model,lr,anchor):
        if np.linalg.norm(x-plan)<.02:continue
        if v4.predicted_acceptable(x,goals,model,state,left,'rapida'):
            choices.append((v4.capital_cost(x),np.asarray(x)))
    # Consente il fallback esplicito: magari non esiste un piano stimato valido.
    if not choices:return None, len(choices),float(np.linalg.norm(gradient))
    return min(choices,key=lambda z:z[0])[1],len(choices),float(np.linalg.norm(gradient))


def weighted_revote(pop,goals,model,lr,old,state,candidate,period,t,obligations):
    """Ogni cambiamento non autorizzato necessita di voto ponderato normale.
    Valuta la stessa strategia con un calendario e una distribuzione espliciti.
    """
    bundle=v4.Bundle(candidate,'rapida',-1,0.,'v8_rivoto_fuori_mandato')
    share=v4.fraction_for_bundle(pop,model,goals,bundle,old,state,t,period,
                                  obligations,mode='forward')
    return (share>.5),float(share),bundle


def simulate_mandate(w,scenario,periods,profile="standard"):
    pop=w['pop'];goals=w['goals']
    if len(goals)<2:return [],[],[]
    lr=v7.common_initial_model(w)
    state=base.STATUS_QUO.copy();plan=state.copy();schedule='regolare'
    obligations=[];rows=[];votes=[];audits=[]
    mandate=None;mandate_share=float('nan');mandate_denied=False
    monitor_flags=0;activations=0;last_action=-999
    spent_by_amendments=0.0;last_reason='inizio';last_vote=float('nan')
    original_goals={q:g.target for q,g in goals.items()}
    metrics=w['metrics'].copy();divergence={q:0 for q in goals}
    for t in range(periods):
        model=lr.predictor()
        truth=as_model(w['theta'][t])  # SOLO misure e valutazione, non voto/pianificazione
        if t==0:
            # Confronto equo: identica proposta iniziale della V7.
            initial=v7.propose_and_vote(pop,goals,model,lr,state,plan,t,periods,obligations)
            if initial.approved:
                b=initial.bundle
                old=plan.copy()
                plan,enacted,_=v4.maybe_enact(pop,{'approved':True,'bundle':b},plan,obligations,t)
                if enacted:schedule=b.schedule
                mandate,mandate_share=create_mandate(pop,goals,model,b,periods,profile)
                mandate_denied=mandate is None
                last_reason='mandato_approvato' if mandate else 'solo_piano_approvato'
                last_vote=initial.share
                votes.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
                    t=t+1,kind='strategia_iniziale',approved=1,share=initial.share,
                    authorized=0,reason='voto_ponderato',x=json.dumps(plan.tolist())))
                votes.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
                    t=t+1,kind='voto_sul_mandato',approved=int(mandate is not None),
                    share=mandate_share,authorized=int(mandate is not None),
                    reason='voto_ponderato',x=json.dumps(plan.tolist())))
            else:
                last_reason=initial.reason;last_vote=initial.share
                votes.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
                    t=t+1,kind='strategia_iniziale',approved=0,share=initial.share,
                    authorized=0,reason=initial.reason,x=json.dumps(plan.tolist())))
        elif (((mandate is not None) and monitor_flags>=mandate.requires_consecutive and t-last_action>=2)
              or ((mandate is None) and (t in (3,6,9) or (monitor_flags>=2 and t-last_action>=2)))):
            # Le segnalazioni sono prodotte nei periodi precedenti e NON dal futuro.
            monitor_flags=0;last_action=t
            candidate,count,grad=pick_correction(w,model,lr,state,plan,t,periods)
            if candidate is None:
                votes.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
                    t=t+1,kind='allarme_senza_piano',approved=0,share=float('nan'),
                    authorized=0,reason='nessuna_alternativa_stimata',x=json.dumps(plan.tolist())))
                last_reason='nessuna_alternativa_stimata'
            else:
                # Pre-approved only if no increase beyond cumulative cap and
                # per-variable corridor. Unused cap is NOT a free subsidy.
                if mandate is None:
                    is_in,why=False,'mandato_non_approvato'
                else:
                    is_in,why=within_mandate(mandate,candidate,plan,
                        spent_by_amendments,activations,model,goals,state,periods-t)
                if is_in:
                    bundle=v4.Bundle(candidate,mandate.schedule,
                              mandate.relief_group,mandate.relief,'v8_clausola')
                    newplan,enacted,charge=v4.maybe_enact(pop,{'approved':True,'bundle':bundle},
                                                          plan,obligations,t)
                    if enacted:
                        added=max(0.,v4.capital_cost(newplan)-v4.capital_cost(plan)) * (1.02 if mandate.relief_group>=0 else 1.0)
                        spent_by_amendments+=added
                        activations+=1;plan=newplan;schedule=bundle.schedule
                    last_reason='attivazione_prevista' if enacted else 'nessuna_variazione'
                    votes.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
                        t=t+1,kind='attivazione_preautorizzata',approved=int(enacted),
                        share=mandate.weighted_share,authorized=1,reason=last_reason,
                        x=json.dumps(plan.tolist()),extra_spent=spent_by_amendments,
                        backprop=grad))
                else:
                    approved,share,bundle=weighted_revote(pop,goals,model,lr,
                                      plan,state,candidate,periods,t,obligations)
                    if approved:
                        newplan,enacted,charge=v4.maybe_enact(pop,{'approved':True,'bundle':bundle},
                                                               plan,obligations,t)
                        if enacted:plan=newplan;schedule=bundle.schedule
                    last_vote=share;last_reason=('rivoto_approvato' if approved else 'rivoto_respinto')
                    votes.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
                         t=t+1,kind='rivoto_fuori_mandato',approved=int(approved),share=share,
                         authorized=0,reason=why,x=json.dumps(plan.tolist()),backprop=grad))
        # Trasformazione attuativa: tempi di esecuzione espliciti.
        state=state+v4.SPEED[schedule]*(plan-state)
        observed=truth.g(state)+w['monitoring_noise'][t]+w['contamination'][t]
        gap,values=v7.goal_gap(state,truth,goals)
        # Le metriche sono definite dal voto SPECIALISTICO, audit indipendente:
        # la revisione segue un NUOVO voto ponderato degli esperti, non un algoritmo.
        for j,(topic,g) in enumerate(goals.items()):
            metric=metrics[topic]
            recorded=v3.measure(values[topic],metric,w['metric_noise'][t,j])
            independently_checked=values[topic]+.04*np.sin(w['seed']*.01+t*1.3+j)
            if not np.isfinite(recorded):raise ArithmeticError('misurazione non valida')
            divergence[topic]=divergence[topic]+1 if abs(recorded-independently_checked)>.20 else 0
            if divergence[topic]>=2:
                new,evt=v3.metric_vote(pop,topic,distortion=0.)
                if new is not None:metrics[topic]=new
                audits.append(dict(seed=w['seed'],scenario=scenario,
                    method='mandato_condizionale',t=t+1,topic=topic,
                    metric_from=metric.name,metric_to=metrics[topic].name,
                    qualified_voters=evt.get('votanti_qualificati',0)))
                divergence[topic]=0
        discrepancy=float(np.max(np.abs(observed-model.g(state))))
        monitor_flags=monitor_flags+1 if discrepancy>(mandate.trigger if mandate else .20) else 0
        # Aggiornamento RLS usa SOLTANTO dati osservati, poi pilota sul periodo corrente.
        lr.update(state,observed)
        if t%2==1:
            probe=v7.AUDIT_PROBES[(t//2)%len(v7.AUDIT_PROBES)]
            lr.update(probe,truth.g(probe)+w['pilot_noise'][t])
        violation=float(np.maximum(truth.g(plan),0.).max())
        rows.append(dict(seed=w['seed'],scenario=scenario,method='mandato_condizionale',
              t=t+1,gap=gap,true_violation=violation,
              joint_success=int(gap<=.11 and violation<=.02),both_goals=int(gap<=.11),
              last_reason=last_reason,last_vote=last_vote,
              mandate_approved=int(mandate is not None),
              preauthorized_activations=activations,spent_amendments=spent_by_amendments,
              observation_error=discrepancy,
              predicted_rmse_state=float(np.sqrt(np.mean((model.g(state)-truth.g(state))**2))),
              x0=float(plan[0]),x1=float(plan[1]),x2=float(plan[2])))
    assert {q:g.target for q,g in goals.items()}==original_goals
    if mandate:assert spent_by_amendments<=mandate.max_extra_cost+1e-6
    return rows,votes,audits


def simulate(n_worlds=12,n=300,periods=12,scenarios=SCENARIOS):
    periods_rows=[];events=[];oracles=[];audits=[]
    for scenario in scenarios:
        for j in range(n_worlds):
            world=v7.generate_world(j,scenario,periods,n)
            if len(world['goals'])!=2:continue
            technical=v7.oracle_dynamic(world,periods)
            oracles.append(dict(seed=world['seed'],scenario=scenario,**technical))
            for method in METHODS:
                if method=='mandato_condizionale':p,e,a=simulate_mandate(world,scenario,periods)
                else:
                    p,e,a=v7.simulate_method(world,scenario,method,periods)
                periods_rows+=p;events+=e
                for audit in a:audits.append({'method':method,'scenario':scenario,**audit})
    summary=[]
    for s in scenarios:
        for m in METHODS:
            finals=[r for r in periods_rows if r['scenario']==s and r['method']==m and r['t']==periods]
            acts=[e for e in events if e['scenario']==s and e['method']==m]
            if not finals:continue
            summary.append(dict(scenario=s,method=m,worlds=len(finals),
              success_pct=round(100*np.mean([r['joint_success'] for r in finals]),1),
              goal_pct=round(100*np.mean([r['both_goals'] for r in finals]),1),
              mean_gap=round(float(np.mean([r['gap'] for r in finals])),4),
              mean_violation=round(float(np.mean([r['true_violation'] for r in finals])),4),
              mean_rmse=round(float(np.mean([r['predicted_rmse_state'] for r in periods_rows
                             if r['scenario']==s and r['method']==m])),4),
              ballot_count=sum(1 for a in acts if a.get('kind')!='attivazione_preautorizzata'),
              within_mandate_count=sum(a.get('kind')=='attivazione_preautorizzata' and a.get('approved') for a in acts),
              outside_mandate_revotes=sum(a.get('kind')=='rivoto_fuori_mandato' for a in acts)))
    return periods_rows,events,oracles,audits,summary


def write_csv(filename,records):
    if not records:return
    columns=list(dict.fromkeys(k for r in records for k in r))
    with open(filename,'w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=columns);writer.writeheader();writer.writerows(records)


def charts(data,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    scenes=sorted({r['scenario'] for r in data})
    fig,ax=plt.subplots(figsize=(10,5.5))
    names=list(METHODS);x=np.arange(len(scenes))
    for k,m in enumerate(names):
        vals=[100*np.mean([r['joint_success'] for r in data if r['scenario']==sc
                    and r['method']==m and r['t']==max(q['t'] for q in data if q['scenario']==sc)])
                  for sc in scenes]
        ax.bar(x+(k-1)*.24,vals,.23,label=m)
    ax.set_xticks(x,scenes,rotation=12);ax.set_ylabel('Raggiungimento target + vincoli (%)')
    ax.set_ylim(0,105);ax.legend();fig.tight_layout()
    fig.savefig(out/'confronto_v8.png',dpi=170);plt.close(fig)
    for sc in scenes:
        fig,ax=plt.subplots(figsize=(8.5,4.5))
        for m in names:
            r=[v for v in data if v['scenario']==sc and v['method']==m]
            t=sorted({a['t'] for a in r})
            vals=[np.mean([a['gap'] for a in r if a['t']==tt]) for tt in t]
            ax.plot(t,vals,marker='o',label=m)
        ax.set_xlabel('Periodo');ax.set_ylabel('Scostamento medio dal target originario')
        ax.set_title(sc);ax.legend();ax.grid(alpha=.2);fig.tight_layout()
        fig.savefig(out/f'traiettoria_{sc}.png',dpi=160);plt.close(fig)


def test():
    world=v7.generate_world(1,'shock',12,300)
    rows,ballots,_=simulate_mandate(world,'shock',12)
    assert len(rows)==12
    pop=world['pop']
    assert np.std(v3.weights(pop,'strategia')[0])>.01
    # La scelta ponderata puo' differire dalla conta dei cittadini.
    tiny=v3.Electorate(np.array([[1]*4,[.1]*4,[.1]*4],dtype=float),
          np.array([0,0,0]),np.zeros(3),np.ones(3))
    assert v3.fraction(tiny,'strategia',[True,False,False])[0]>.5
    # Confine autorizzato: costi e variabili non possono superare il mandato.
    old=base.STATUS_QUO.copy();b=v4.Bundle(np.array([8.5,1.5,1.5]),'regolare',-1,0.,'t')
    x=Mandate(b.x,np.array([.4,.4,.4]),5,2,.2,2,'regolare',-1,0.,.65)
    mdl=v7.common_initial_model(world).predictor()
    inside,reason=within_mandate(x,b.x+np.array([1,0,0]),b.x,0.,0,
                                   mdl,world['goals'],old,12)
    assert not inside and reason=='oltre_inviluppo'
    denied,reason=within_mandate(x,b.x,b.x,0.,2,mdl,world['goals'],old,12)
    assert not denied and reason=='limite_attivazioni'
    budget,why=within_mandate(x,b.x+np.array([.1,.1,.1]),b.x,4.99,0,mdl,world['goals'],old,12)
    assert not budget and why=='oltre_budget'
    assert all('mandate_approved' in r for r in rows)
    assert np.array_equal(world['theta'][0],world['theta'][1])
    print('OK: pesi, voto condizionale, limiti autorizzazione, obiettivi immutati, shock')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--test',action='store_true')
    parser.add_argument('--mondi',type=int,default=12)
    parser.add_argument('--cittadini',type=int,default=300)
    parser.add_argument('--periodi',type=int,default=12)
    parser.add_argument('--scenari',nargs='*',choices=SCENARIOS,default=list(SCENARIOS))
    parser.add_argument('--output',type=Path,default=HERE/'risultati')
    args=parser.parse_args()
    if args.test:test();return
    args.output.mkdir(parents=True,exist_ok=True)
    out=simulate(args.mondi,args.cittadini,args.periodi,args.scenari)
    for label,data in zip(['periodi.csv','decisioni.csv','oracoli.csv','audit_metriche.csv','riepilogo.csv'],out):
        write_csv(args.output/label,data)
    charts(out[0],args.output)
    (args.output/'parametri.json').write_text(json.dumps(vars(args),default=str,indent=2),encoding='utf-8')
    print(json.dumps(out[-1],ensure_ascii=False,indent=2))
if __name__=='__main__':main()