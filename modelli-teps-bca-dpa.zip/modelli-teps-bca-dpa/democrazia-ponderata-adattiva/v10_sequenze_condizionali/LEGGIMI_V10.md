# Democrazia Ponderata Adattiva — V10

## Scopo

Questa è una **simulazione matematica sintetica**, non una verifica scientifica di un sistema politico reale. Risponde a una domanda stretta: mantenendo il voto ponderato e i mandati della V8, una **sequenza di due interventi ottimizzati congiuntamente** riesce a raggiungere gli obiettivi più spesso di un singolo intervento o delle versioni precedenti?

Il modello usa quattro ambiti tecnici (acqua, trasporti, bilancio, ambiente), tre variabili strategiche, due obiettivi approvati tramite voto ponderato, 300 cittadini artificiali per società, fino a 12 periodi e misurazioni tecniche sintetiche. Le metriche sono deliberate dai soggetti competenti secondo il meccanismo V3.

## Meccanismo

1. **Obiettivi** e **metriche** vengono approvati con procedure distinte, sempre a voto ponderato per competenza pertinente (motore V3). Durante questo esperimento i target approvati rimangono invariati.
2. I cittadini votano il **piano iniziale**, con un sistema di voto ponderato (V7/V4).
3. Se il piano iniziale passa, votano separatamente un **mandato condizionale** con trigger, limite di variazione per ogni variabile, tetto incrementale e massimo numero di azioni (V8). Il mandato autorizza il processo algoritmico delimitato, **non una modifica illimitata**.
4. L'attuazione fa evolvere lo stato verso il piano attivo. Sensori simulati producono misure rumorose. L'algoritmo RLS aggiorna le stime senza accesso al futuro.
5. Al calendario di revisione o in presenza di allarmi tecnici, la V10 ottimizza contemporaneamente `u_1` (piano immediato) e `u_2` (piano successivo, soggetto a rivalutazione), tenendo conto della traiettoria e delle incertezze stimate.
6. Per eseguire `u_1`, si controllano anche le **conseguenze della sequenza completa** e il potenziale impegno di spesa di `u_2`. Solo se l'intervento è nell'inviluppo e nel tetto del mandato si procede senza nuovo voto; altrimenti serve un **rivoto ponderato**. La seconda azione non viene eseguita automaticamente in futuro senza nuovo controllo.
7. La verifica indipendente valuta gli **obiettivi originari** e i **vincoli tecnici reali**, ignoti al decisore. I risultati appresi possono far ripetere il ciclo, ma non cambiano autonomamente obiettivi o metriche.

### Definizioni essenziali

Con stato effettivo `s_t` e piano operativo `u_t`, l'attuazione è:

` s_(t+1) = s_t + a (u_t - s_t) `, con `a = 0,67` per la velocità rapida.

Il nuovo risolutore sceglie due piani `(u_1,u_2)` su periodi consecutivi:

` min J(u_1,u_2 | dati osservati fino a t) `,

soggetto a vincoli tecnici *stimati* sui due piani e ai target stimati alla scadenza, penalizzando scostamenti futuri, violazioni stimate, spesa incrementale e bruschi cambi di piano. Il margine di robustezza usa `learner.sd`: è un inviluppo **euristico**, non una garanzia di copertura statistica.

La variante di controllo **singolo_v10** usa gli stessi stimatori, allarmi, elettori, voti, mandato, limiti e criteri, ma impone `u_1 = u_2`. Questo è il test più pertinente per isolare l'effetto dei due stadi.

## Esperimento comparativo V8/V9/V10

- **24 società per scenario**, 300 cittadini e 12 periodi.
- Scenari: `stabile`, `shock`, `shock_rumoroso`, `shock_conflitto`.
- I mondi sono identici attraverso i metodi: stessi semi, elettori, obiettivi, vincoli e rumori.
- Riferimento di fattibilità: l'oracolo tecnico V7 (con accesso alla verità corrente e **senza voto ponderato**) raggiunge il risultato in **24/24** dei mondi di ogni scenario. Non è una prova di fattibilità politico-istituzionale.
- Successo rigoroso: al periodo finale **entrambi i target originali** sono rispettati entro `gap <= 0,11`, e la massima violazione tecnica reale sul piano attivo è `<= 0,02`. Non si certifica qui il rispetto dei vincoli in ogni periodo precedente.

| Scenario | V8 (%) | V9 robusta (%) | V10 singolo (%) | V10 due stadi (%) |
|---|---:|---:|---:|---:|
| Stabile | 87,5 | 87,5 | 87,5 | 87,5 |
| Shock | 0,0 | 8,3 | 16,7 | **33,3** |
| Shock rumoroso | 0,0 | 0,0 | 16,7 | **29,2** |
| Shock + conflitto | 0,0 | 0,0 | 0,0 | **4,2** |

Per V10 due stadi contro V10 singolo, sullo shock: **6 mondi migliorano, 2 peggiorano, 16 invariati** (differenza +16,7 punti). Bootstrap accoppiato al 95%: **[-4,17; +37,5] punti**; test esatto sui discordanti `p=0,289`. Con rumore: **6 migliorano, 3 peggiorano, 15 invariati**, differenza +12,5 punti; intervallo approssimato bootstrap **[-12,5; +37,5]**, `p=0,508`.

Gli intervalli comprendono zero: **non si può concludere che i due stadi siano intrinsecamente superiori**, pur mostrando miglioramenti in questo modello sintetico. Gli scenari riutilizzano gli stessi mondi di base e non vanno trattati come quattro campioni indipendenti.

### Che cosa non è stato dimostrato

- Che il voto ponderato sia più democratico, equo o efficace di altri sistemi istituzionali.
- Che i voti sintetici descrivano accuratamente il comportamento di cittadini reali.
- Che il risolutore trovi un ottimo globale o che la robustezza sia statisticamente certificata.
- Che approvare un mandato implichi una comprensione concreta di tutte le sequenze future: **la formula di voto sul mandato eredita la semplificazione della V8** e non valuta dettagliatamente ciascuna traiettoria condizionale.
- Che il budget cumulativo rappresenti in modo completo contabilità pubblica, diritto o debito. Il modello implementa un controllo sintetico sulle spese incrementali.
- Che i vincoli siano rispettati in ogni istante di transizione: la metrica principale verifica i vincoli sul piano attivo all'ultimo periodo.
- Che funzioni con maggioranze conflittuali: in quello scenario rimane prevalentemente bloccato.

## File e riproducibilità

Requisiti Python 3.10+, `numpy`, `scipy`, `matplotlib`; per il report statistico anche `pandas`.

Dalla cartella contenente `democrazia-ponderata-adattiva`:

```bash
python democrazia-ponderata-adattiva/v10_sequenze_condizionali/simulazione_v10.py --test
python democrazia-ponderata-adattiva/v10_sequenze_condizionali/simulazione_v10.py --mondi 24 --cittadini 300 --periodi 12 --metodi singolo_v10 sequenza_v10 --output democrazia-ponderata-adattiva/v10_sequenze_condizionali/risultati_ricalcolati
python democrazia-ponderata-adattiva/v10_sequenze_condizionali/analisi_v10.py
```

La comparazione V8/V9 è stata ricavata dai dati V9 salvati, generati sugli stessi 24 mondi sintetici. Per rigenerare anche questi metodi il simulatore V10 supporta `--metodi bloccato mandato_v8 mpc_robusto_v9 singolo_v10 sequenza_v10`, ma V9 richiede sensibilmente più tempo.

Nel pacchetto: `simulazione_v10.py` (motore e test), `analisi_v10.py` (confronti accoppiati), `risultati/` (report consolidati e grafici), `risultati_v10_24/` e `risultati_singolo_24/` (dati grezzi delle due varianti), dipendenze dei prototipi precedenti.