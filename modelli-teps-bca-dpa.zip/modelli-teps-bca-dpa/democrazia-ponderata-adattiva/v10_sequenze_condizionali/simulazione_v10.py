#!/usr/bin/env python3
# Autore: Cristian Lorenzetto (ORCID 0009-0001-4925-4728). Licenza MIT.
"""V10: politica condizionale con due interventi coordinati nel tempo.

Prototipo sintetico, NON convalida empirica della democrazia ponderata.
Confronto accoppiato V8/V9/V10 sugli stessi mondi, elettori, shock e rumori.
Ogni azione è autorizzata da un mandato ponderato pre-votato oppure da
nuovo voto ponderato. I target e le metriche non sono riscritti dal solver.

Il controllore NON legge theta reale per decidere; theta è accessibile solo
al sensore simulato e al valutatore ex post. Non sono garantiti né
l'ottimo globale né l'effettiva calibrazione probabilistica delle bande.
"""
from __future__ import annotations
import argparse,csv,json,sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.optimize import minimize

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
for p in (ROOT,ROOT/'v2_adattiva',ROOT/'v3_ponderata',ROOT/'v4_negoziazione',
          ROOT/'v7_feedback_temporale',ROOT/'v8_mandato_condizionale',ROOT/'v9_ottimizzazione_robusta'):
    sys.path.insert(0,str(p))
import simulazione as base
import simulazione_v4 as v4
import simulazione_v7 as v7
import simulazione_v8 as v8
import simulazione_v9 as v9
from simulazione_adattiva import as_model

SCENARIOS=v7.SCENARIOS
METHODS=('bloccato','mandato_v8','mpc_robusto_v9','singolo_v10','sequenza_v10')
SPEED=v4.SPEED['rapida']

@dataclass(frozen=True)
class StagedPlan:
    now:np.ndarray
    later:np.ndarray
    first_periods:int
    score:float
    residual:float
    forecast_gap:float


def state_after(state,plan,n):
    return np.asarray(plan)+(np.asarray(state)-np.asarray(plan))*(1-SPEED)**n


def simulate_pair(state,p1,p2,first,left):
    s1=state_after(state,p1,first)
    return s1,state_after(s1,p2,left-first)


def projected_goal_gap(goals,model,end):
    vals=v7.v3.actual_values(end,model)
    return sum(max(0.,g.target-vals[q]) if g.direction=='min'
               else max(0.,vals[q]-g.target) for q,g in goals.items())


def risk_losses(goals,model,learner,x1,x2,end,risk):
    # Interpreta l'incertezza come inviluppo euristico e non come certezza.
    gx=model.g(x1)+risk*learner.sd(x1)
    gy=model.g(x2)+risk*learner.sd(x2)
    ge=model.g(end)+risk*learner.sd(end)
    housing=end[0]-.90*max(0.,ge[0])-.65*max(0.,ge[1])
    environment=5.+ge[3]*base.SCALE[3]
    misses=[]
    for q,g in goals.items():
        y=housing if q=='alloggi' else environment
        misses.append(max(0.,g.target-y) if g.direction=='min' else max(0.,y-g.target))
    return np.array(misses),np.maximum(gx,0.),np.maximum(gy,0.)


def find_sequence(goals,model,learner,state,current,left,risk=.75,stages=2):
    """MPC a due stadi: sceglie simultaneamente piano ORA e piano DOPO.

    Lo stadio DOPO è una previsione condizionale, non un'autorizzazione a
    eseguirlo indipendentemente dal voto e dai limiti. Alla prossima misura
    il medesimo algoritmo ricalcola la sequenza.
    """
    left=int(left)
    if left<2:return None,{'reason':'orizzonte_insufficiente'}
    first=max(1,min(3,left//2))
    now=np.clip(current,base.LOW,base.HIGH)
    feedback=model.jac(now).T@np.maximum(model.g(now),0.)
    initial=np.clip(now-.7*feedback/(np.linalg.norm(feedback)+1e-9),base.LOW,base.HIGH)
    nominal=np.array([9.1,2.2,2.1]); ambitious=np.array([9.45,2.8,2.65])
    # A compact deterministic multi-start (more evaluations are not guaranteed better).
    starts=[np.r_[now,nominal],np.r_[initial,ambitious]]
    bounds=list(zip(np.r_[base.LOW,base.LOW],np.r_[base.HIGH,base.HIGH]))
    def endpoint(z):
        a,b=z[:3],z[3:]
        return simulate_pair(state,a,b,first,left)[1]
    def goal_margin(z,q):
        end=endpoint(z)
        val=v7.v3.actual_values(end,model)[q]
        g=goals[q]
        return (val-g.target+.12 if g.direction=='min' else g.target-val+.12)
    # Vincoli stimati su entrambe le decisioni e sulla traiettoria terminale.
    cons=[{'type':'ineq','fun':lambda z,j=j:float(.09-model.g(z[:3])[j])} for j in range(4)]
    cons += [{'type':'ineq','fun':lambda z,j=j:float(.09-model.g(z[3:])[j])} for j in range(4)]
    cons += [{'type':'ineq','fun':lambda z,q=q:float(goal_margin(z,q))} for q in goals]
    def score(z):
        p1,p2=z[:3],z[3:]
        middle,end=simulate_pair(state,p1,p2,first,left)
        miss,v1,v2=risk_losses(goals,model,learner,p1,p2,end,risk)
        # Gerarchia approssimata: target e vincoli dominano i costi.
        penalty=30*(miss@miss)+25*(v1@v1+v2@v2)
        # Intervento immediato e tardivo hanno costi comparabili, ma diversi tempi.
        newcost=max(0.,v4.capital_cost(p1)-v4.capital_cost(current))
        latecost=max(0.,v4.capital_cost(p2)-v4.capital_cost(p1))
        cost=.005*(newcost+1.03*latecost)
        move=.004*(np.sum((p1-current)**2)+np.sum((p2-p1)**2))
        interim=projected_goal_gap(goals,model,middle)
        return float(penalty+cost+move+.012*interim)
    found=[]
    for s in starts:
        opt=minimize(score,np.clip(s,np.r_[base.LOW,base.LOW],np.r_[base.HIGH,base.HIGH]),
             method='SLSQP',bounds=bounds,constraints=cons,
             options={'maxiter':30,'ftol':8e-5})
        x=np.clip(opt.x,np.r_[base.LOW,base.LOW],np.r_[base.HIGH,base.HIGH])
        residual=float(min(c['fun'](x) for c in cons))
        if residual>=-3e-4:
            found.append(StagedPlan(x[:3].copy(),x[3:].copy(),first,score(x),residual,
                                     projected_goal_gap(goals,model,endpoint(x))))
    if not found:return None,{'reason':'nessuna_sequenza_ammissibile'}
    best=min(found,key=lambda a:a.score)
    return best,{'reason':'sequenza_trovata','options':len(found),
                 'future_plan':best.later.tolist(),'projected_gap':best.forecast_gap}



def find_single_stage(goals,model,learner,state,current,left,risk=.75):
    """Ablazione: stessi allarmi, voto e vincoli V10, ma un solo intervento.

    La funzione obiettivo, i dati disponibili e le soglie sono identici al
    modello a due stadi; cambia solamente il numero di piani ottimizzati.
    """
    left=int(left)
    if left<2:return None,{'reason':'orizzonte_insufficiente'}
    first=max(1,min(3,left//2))
    now=np.clip(current,base.LOW,base.HIGH)
    feedback=model.jac(now).T@np.maximum(model.g(now),0.)
    initial=np.clip(now-.7*feedback/(np.linalg.norm(feedback)+1e-9),base.LOW,base.HIGH)
    starts=[initial,np.array([9.1,2.2,2.1])]
    def endpoint(x):return state_after(state,x,left)
    cons=[{'type':'ineq','fun':lambda z,j=j:float(.09-model.g(z)[j])} for j in range(4)]
    for q,g in goals.items():
        def goal_margin(z,topic=q,target=g):
            val=v7.v3.actual_values(endpoint(z),model)[topic]
            return float(val-target.target+.12 if target.direction=='min' else target.target-val+.12)
        cons.append({'type':'ineq','fun':goal_margin})
    def score(x):
        middle=state_after(state,x,first)
        miss,v1,v2=risk_losses(goals,model,learner,x,x,endpoint(x),risk)
        penalty=30*(miss@miss)+25*(v1@v1+v2@v2)
        cost=.005*max(0.,v4.capital_cost(x)-v4.capital_cost(current))
        move=.004*np.sum((x-current)**2)
        return float(penalty+cost+move+.012*projected_goal_gap(goals,model,middle))
    found=[]
    for st in starts:
        opt=minimize(score,np.clip(st,base.LOW,base.HIGH),method='SLSQP',
          bounds=list(zip(base.LOW,base.HIGH)),constraints=cons,
          options={'maxiter':30,'ftol':8e-5})
        x=np.clip(opt.x,base.LOW,base.HIGH)
        residual=float(min(c['fun'](x) for c in cons))
        if residual>=-3e-4:
            found.append(StagedPlan(x.copy(),x.copy(),first,score(x),residual,
                                    projected_goal_gap(goals,model,endpoint(x))))
    if not found:return None,{'reason':'nessun_piano_singolo'}
    best=min(found,key=lambda a:a.score)
    return best,{'reason':'singolo_trovato','options':len(found),
                 'future_plan':best.later.tolist(),'projected_gap':best.forecast_gap}


def sequence_within_mandate(m,staged,current,spent,activations,estimated,goals,state,left):
    if m is None:return False,'mandato_assente'
    if activations>=m.max_activations:return False,'limite_attivazioni'
    if np.any(np.abs(staged.now-m.reference)>m.axis_limit+1e-9):return False,'oltre_inviluppo'
    # All remaining scheduled actions must be inside the mandate envelope.
    if np.any(np.abs(staged.later-m.reference)>m.axis_limit+1e-9):return False,'futuro_oltre_inviluppo'
    # Constrained to the cumulative maximum planned incremental budget,
    # including the later stage in the same authorized envelope.
    candidates=[staged.now,staged.later]
    cumulative=max(0.,v4.capital_cost(candidates[0])-v4.capital_cost(current))
    cumulative+=max(0.,v4.capital_cost(candidates[1])-v4.capital_cost(candidates[0]))
    if m.relief_group>=0:cumulative*=1.02
    if spent+cumulative>m.max_extra_cost+1e-9:return False,'oltre_budget_condizionale'
    middle,end=simulate_pair(state,staged.now,staged.later,staged.first_periods,left)
    if np.max(estimated.g(staged.now))>.09 or np.max(estimated.g(staged.later))>.09:
        return False,'vincoli_stimati'
    if not v4.actual_goals_ok(end,goals,estimated,.12):return False,'target_stimati'
    return True,'mandato_condizionale'


def policy_trigger(t,flags,mandate,last_action,prev_gap,goals,estimate,state,periods):
    # Monitoring-based activation, not preknown shock; periodic review after t=0.
    if t<=0 or t-last_action<2:return False
    scheduled=t in (3,6,9)
    alert=(flags>=2)
    if not (scheduled or alert):return False
    # Triggering both on new evidence and on predicted goal trajectory.
    end=v4.final_state(state,state,periods-t,'rapida')
    gap=projected_goal_gap(goals,estimate,end)
    return alert or gap>.10 or (scheduled and prev_gap>.10)


def simulate_v10(world,scenario,periods,profile='standard',two_stages=True):
    pop=world['pop'];goals=world['goals']
    if len(goals)!=2:return [],[],[]
    learner=v7.common_initial_model(world)
    state=base.STATUS_QUO.copy();plan=state.copy();schedule='regolare'
    obligations=[];rows=[];events=[];audits=[]
    mandate=None;spent=0.;activations=0;flags=0;last_action=-99
    last_reason='inizio';last_share=float('nan');prev_gap=float('inf')
    metrics=world['metrics'].copy();divergence={q:0 for q in goals}
    oldtargets={q:g.target for q,g in goals.items()}
    method='sequenza_v10' if two_stages else 'singolo_v10'
    for t in range(periods):
        model=learner.predictor()   # only past observed data
        if t==0:
            initial=v7.propose_and_vote(pop,goals,model,learner,state,plan,t,periods,obligations)
            if initial.approved:
                bundle=initial.bundle
                nextplan,enacted,_=v4.maybe_enact(pop,{'approved':True,'bundle':bundle},plan,obligations,t)
                if enacted:plan=nextplan;schedule=bundle.schedule
                # The weighted mandate votes on predefined conditional ALGORITHM,
                # trigger, corridor, costs, and maximum number of actions.
                mandate,ms=v8.create_mandate(pop,goals,model,bundle,periods,profile)
                events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,kind='voto_piano',
                                   approved=1,share=initial.share,authorized=0))
                events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,kind='voto_mandato',
                                   approved=int(mandate is not None),share=ms,authorized=int(mandate is not None)))
                last_share=initial.share
            else:
                events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,kind='voto_piano',
                                   approved=0,share=initial.share,authorized=0))
            last_reason=initial.reason
        elif policy_trigger(t,flags,mandate,last_action,prev_gap,goals,model,state,periods):
            flags=0;last_action=t
            staged,diagnostics=(find_sequence if two_stages else find_single_stage)(
                goals,model,learner,state,plan,periods-t)
            if staged is None:
                last_reason=diagnostics['reason']
                events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,kind='nessun_piano',
                                   approved=0,authorized=0,reason=last_reason))
            elif np.linalg.norm(staged.now-plan)<.02:
                last_reason='nessuna_modifica_necessaria'
                events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,kind='piano_invariato',
                                   approved=1,authorized=1,reason=last_reason,
                                   future=json.dumps(staged.later.tolist())))
            else:
                valid,why=sequence_within_mandate(mandate,staged,plan,spent,activations,
                                                    model,goals,state,periods-t)
                # If outside mandate, ordinary weighted revote: no silent authorization.
                if valid:
                    bundle=v4.Bundle(staged.now,mandate.schedule,mandate.relief_group,
                                     mandate.relief,'v10_azione_condizionale')
                    nextplan,enacted,_=v4.maybe_enact(pop,{'approved':True,'bundle':bundle},plan,obligations,t)
                    if enacted:
                        incremental=max(0.,v4.capital_cost(nextplan)-v4.capital_cost(plan))
                        spent+=incremental*(1.02 if mandate.relief_group>=0 else 1.)
                        plan=nextplan;activations+=1;schedule=bundle.schedule
                    last_reason='azione_preautorizzata' if enacted else 'azione_invariata'
                    events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,
                        kind='azione_preautorizzata',approved=int(enacted),authorized=1,
                        share=mandate.weighted_share,reason=last_reason,
                        now=json.dumps(staged.now.tolist()),future=json.dumps(staged.later.tolist()),
                        spent=spent,forecast_gap=staged.forecast_gap))
                else:
                    approved,share,bundle=v8.weighted_revote(pop,goals,model,learner,
                         plan,state,staged.now,periods,t,obligations)
                    if approved:
                        nextplan,enacted,_=v4.maybe_enact(pop,{'approved':True,'bundle':bundle},plan,obligations,t)
                        if enacted:plan=nextplan;schedule=bundle.schedule
                    last_reason='rivoto_approvato' if approved else 'rivoto_respinto'
                    last_share=share
                    events.append(dict(seed=world['seed'],scenario=scenario,t=t+1,kind='rivoto',
                        approved=int(approved),authorized=0,share=share,reason=why,
                        now=json.dumps(staged.now.tolist()),future=json.dumps(staged.later.tolist())))
        # Implementation, audit, feedback: identical data streams to V8/V9.
        state=state+v4.SPEED[schedule]*(plan-state)
        truth=as_model(world['theta'][t])  # sensor and *evaluation only*
        observed=truth.g(state)+world['monitoring_noise'][t]+world['contamination'][t]
        gap,values=v7.goal_gap(state,truth,goals)
        measurable_gap=0.0
        for j,(topic,g) in enumerate(goals.items()):
            metric=metrics[topic]
            recorded=v7.v3.measure(values[topic],metric,world['metric_noise'][t,j])
            measurable_gap+=(max(0.,g.target-recorded) if g.direction=='min' else max(0.,recorded-g.target))
            independent=values[topic]+.04*np.sin(world['seed']*.01+t*1.3+j)
            divergence[topic]=(divergence[topic]+1 if abs(recorded-independent)>.20 else 0)
            if divergence[topic]>=2:
                new,evt=v7.v3.metric_vote(pop,topic,distortion=0.)
                if new is not None:metrics[topic]=new
                audits.append(dict(seed=world['seed'],scenario=scenario,t=t+1,topic=topic,
                                   qualified_voters=evt.get('votanti_qualificati',0)))
                divergence[topic]=0
        discrepancy=float(np.max(np.abs(observed-model.g(state))))
        flags=flags+1 if discrepancy>(mandate.trigger if mandate else .20) else 0
        learner.update(state,observed)
        if t%2==1:
            probe=v7.AUDIT_PROBES[(t//2)%len(v7.AUDIT_PROBES)]
            learner.update(probe,truth.g(probe)+world['pilot_noise'][t])
        violation=float(np.maximum(truth.g(plan),0.).max())
        rows.append(dict(seed=world['seed'],scenario=scenario,method=method,t=t+1,
                         gap=gap,true_violation=violation,
                         joint_success=int(gap<=.11 and violation<=.02),
                         both_goals=int(gap<=.11),last_reason=last_reason,
                         last_share=last_share,mandate_approved=int(mandate is not None),
                         preauthorized_activations=activations,spent_amendments=spent,
                         observation_error=discrepancy,
                         predicted_rmse_state=float(np.sqrt(np.mean((model.g(state)-truth.g(state))**2))),
                         x0=float(plan[0]),x1=float(plan[1]),x2=float(plan[2])))
        prev_gap=measurable_gap  # Solo metriche registrate, non verita' del valutatore.
    assert oldtargets=={q:g.target for q,g in goals.items()}
    if mandate:assert spent<=mandate.max_extra_cost+1e-8
    return rows,events,audits


def run(n_worlds=8,n=300,periods=12,scenarios=SCENARIOS,methods=METHODS):
    rows=[];votes=[];audits=[];oracles=[]
    for s in scenarios:
        for i in range(n_worlds):
            w=v7.generate_world(i,s,periods,n)
            if len(w['goals'])!=2:continue
            oracles.append(dict(seed=w['seed'],scenario=s,**v7.oracle_dynamic(w,periods)))
            for m in methods:
                if m in ('sequenza_v10','singolo_v10'):
                    p,e,a=simulate_v10(w,s,periods,two_stages=m=='sequenza_v10')
                elif m=='bloccato':p,e,a=v7.simulate_method(w,s,'bloccato',periods)
                elif m=='mandato_v8':p,e,a=v8.simulate_mandate(w,s,periods)
                elif m=='mpc_robusto_v9':p,e,a=v9.simulate_variant(w,s,periods,'mpc_robusto')
                else:raise ValueError(m)
                for x in p:x['method']=m
                for x in e:x['method']=m
                for x in a:x['method']=m
                rows.extend(p);votes.extend(e);audits.extend(a)
    summary=[]
    for s in scenarios:
        for m in methods:
            final=[r for r in rows if r['scenario']==s and r['method']==m and r['t']==periods]
            if not final:continue
            events=[e for e in votes if e['scenario']==s and e['method']==m]
            summary.append(dict(scenario=s,method=m,n=len(final),success_count=sum(r['joint_success'] for r in final),
                success_pct=round(100*np.mean([r['joint_success'] for r in final]),1),
                goal_pct=round(100*np.mean([r['both_goals'] for r in final]),1),
                mean_gap=round(float(np.mean([r['gap'] for r in final])),4),
                mean_violation=round(float(np.mean([r['true_violation'] for r in final])),4),
                weighted_revotes=sum(e.get('kind') in ('rivoto','rivoto_fuori_mandato') for e in events),
                preauthorized=sum(e.get('kind') in ('azione_preautorizzata','attivazione_preautorizzata')
                                   and e.get('approved') for e in events),
                no_candidate=sum(e.get('kind') in ('nessun_piano','allarme_senza_piano') for e in events)))
    return rows,votes,audits,oracles,summary


def write_csv(path,rows):
    if not rows:return
    cols=list(dict.fromkeys(k for row in rows for k in row.keys()))
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)


def plot(rows,out,scenarios,methods):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for s in scenarios:
        fig,ax=plt.subplots(figsize=(9,5))
        for m in methods:
            sample=[r for r in rows if r['scenario']==s and r['method']==m]
            if not sample:continue
            times=sorted({r['t'] for r in sample})
            ax.plot(times,[np.mean([r['gap'] for r in sample if r['t']==t]) for t in times],
                    marker='o',label=m)
        ax.set_xlabel('Periodo');ax.set_ylabel('Scostamento dai target originari (simulato)')
        ax.set_title('V10 — '+s);ax.grid(alpha=.2);ax.legend(fontsize=9);fig.tight_layout()
        fig.savefig(out/('andamento_'+s+'.png'),dpi=145);plt.close(fig)
    fig,ax=plt.subplots(figsize=(11,5))
    x=np.arange(len(scenarios));width=.20
    for i,m in enumerate(methods):
        p=[]
        for s in scenarios:
            data=[r for r in rows if r['scenario']==s and r['method']==m and r['t']==max(x['t'] for x in rows if x['scenario']==s)]
            p.append(100*np.mean([r['joint_success'] for r in data]))
        ax.bar(x+(i-(len(methods)-1)/2)*width,p,width,label=m)
    ax.set_xticks(x,scenarios,rotation=9);ax.set_ylim(0,105)
    ax.set_ylabel('Target iniziali + vincoli tecnici reali (%)')
    ax.legend(fontsize=8);fig.tight_layout();fig.savefig(out/'confronto_v10.png',dpi=160);plt.close(fig)


def tests():
    w=v7.generate_world(1,'shock',12,100)
    targets={q:g.target for q,g in w['goals'].items()}
    assert len(targets)==2
    mdl=v7.common_initial_model(w)
    p,diag=find_sequence(w['goals'],mdl.predictor(),mdl,base.STATUS_QUO.copy(),
                         np.array([9.,2.2,2.2]),9)
    if p is not None:
        assert np.all(p.now>=base.LOW) and np.all(p.later<=base.HIGH)
        assert p.first_periods>=1 and np.max(mdl.predictor().g(p.later))<=.091
    tiny=v7.v3.Electorate(np.array([[1.]*4,[.1]*4,[.1]*4]),
                          np.array([0,0,0]),np.zeros(3),np.ones(3))
    assert v7.v3.fraction(tiny,'strategia',[True,False,False])[0]>.5
    original=v8.simulate_mandate(w,'shock',12)[0]
    a,acts,_=simulate_v10(w,'shock',12)
    single,_,_=simulate_v10(w,'shock',12,two_stages=False)
    assert len(single)==12
    repeat=v8.simulate_mandate(w,'shock',12)[0]
    assert len(a)==12 and np.array_equal([r['gap'] for r in original],[r['gap'] for r in repeat])
    assert all({q:g.target for q,g in w['goals'].items()}==targets for _ in range(1))
    assert not any(e.get('kind')=='azione_preautorizzata' and e.get('authorized')!=1 for e in acts)
    # Verify no action beyond spending cap can be preauthorized.
    if p is not None:
        bundle=v4.Bundle(np.array([9.,2.,2.]),'regolare',-1,0.,'test')
        fake=v8.Mandate(bundle.x,np.array([.01,.01,.01]),.01,1,.20,2,'regolare',-1,0.,.6)
        ok,why=sequence_within_mandate(fake,p,bundle.x,.01,0,mdl.predictor(),
                                       w['goals'],base.STATUS_QUO,9)
        assert not ok
    print('OK V10: doppio stadio, pesi, audit, mandato, target invariati, baseline invariata')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--test',action='store_true')
    p.add_argument('--mondi',type=int,default=8)
    p.add_argument('--cittadini',type=int,default=300)
    p.add_argument('--periodi',type=int,default=12)
    p.add_argument('--scenari',nargs='*',choices=SCENARIOS,default=list(SCENARIOS))
    p.add_argument('--metodi',nargs='*',choices=METHODS,default=list(METHODS))
    p.add_argument('--output',type=Path,default=HERE/'risultati')
    a=p.parse_args()
    if a.test:tests();return
    a.output.mkdir(exist_ok=True,parents=True)
    outputs=run(a.mondi,a.cittadini,a.periodi,a.scenari,a.metodi)
    for name,records in zip(('periodi.csv','decisioni.csv','audit_metriche.csv','oracoli.csv','riepilogo.csv'),outputs):
        write_csv(a.output/name,records)
    plot(outputs[0],a.output,a.scenari,a.metodi)
    (a.output/'parametri.json').write_text(json.dumps(vars(a),default=str,indent=2),encoding='utf-8')
    print(json.dumps(outputs[-1],ensure_ascii=False,indent=2))
if __name__=='__main__':main()